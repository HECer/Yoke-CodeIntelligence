"""Fixed Node checks through the unchanged owned-Job runner; no native image."""
from pathlib import Path
import hashlib
import json
import os
import sys

ROOT = Path(__file__).resolve().parents[3]
CONTROL = ROOT / 'validation/integration-20261025/platform-repairs/control'
EXPECTED = 'a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7'
HEAD = '6719c3dc44ea6aae688344a1c74c5a6242c8b6f6'


def main():
    assert os.name == 'nt' and len(sys.argv) == 1
    raw = (CONTROL / 'validation_controller.py').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    scope = {'__name__': 'reviewed_node_checks', '__file__': str(CONTROL / 'validation_controller.py')}
    exec(compile(raw, scope['__file__'], 'exec'), scope)
    assert scope['ROOT'] == ROOT
    api, extended = scope['load_windows_api']()
    environment = scope['environment_for']('test')
    out = scope['new_output']('encoding-browser-node-6719c3dc-reviewed-r2')
    git = lambda label, args: scope['git_capture'](api, extended, out, environment, label, args)
    assert git('git-head-before', ['rev-parse', 'HEAD']).decode('ascii').strip() == HEAD
    assert not git('git-status-before', ['status', '--porcelain=v1', '-z', '--untracked-files=no'])
    names = git('git-files', ['ls-files', '-z']).decode('utf-8').split('\0')
    suffixes = {'.rs', '.py', '.js', '.mjs', '.cjs', '.ts', '.tsx', '.html', '.css',
                '.json', '.jsonc', '.toml', '.lock', '.md', '.yaml', '.yml', '.txt'}
    selected = sorted(name for name in names if name and Path(name).suffix in suffixes and (
        name.startswith(('native/src/', 'native/tests/', 'native/examples/', 'scripts/', 'src/',
                         'test/', 'tests/', 'bin/', 'extension/'))
        or '/' not in name or name == '.github/workflows/rust.yml'))
    before = scope['hash_selected'](selected)
    scope['write_json'](out, 'source-before.json', before)
    controls = scope['controls_map']()
    scope['write_json'](out, 'control-before.json', controls)
    node = Path('C:/Program Files/nodejs/node.exe')
    npm = node.parent / 'node_modules/npm/bin/npm-cli.js'
    assert node.is_file() and npm.is_file()
    result = {'sourceCommit': HEAD, 'completed': False, 'inputsUnchanged': False,
              'nativeImageRead': False, 'nativeExecution': False, 'sourceInputs': len(selected), 'phases': {}}
    try:
        for name, command in [('typecheck', [str(node), str(npm), 'run', 'typecheck']),
                              ('npm-test', [str(node), str(npm), 'test'])]:
            row = scope['run_owned'](api, extended, out, name, command, environment, 1200)
            result['phases'][name] = row
            scope['require'](row['completed'], 'Owned Node check incomplete: ' + name)
        after = scope['hash_selected'](selected)
        scope['write_json'](out, 'source-after.json', after)
        result['inputsUnchanged'] = before == after and controls == scope['controls_map']()
        scope['require'](result['inputsUnchanged'], 'Node check inputs changed')
        scope['require'](git('git-head-after', ['rev-parse', 'HEAD']).decode('ascii').strip() == HEAD,
                         'Node check HEAD changed')
        scope['require'](not git('git-status-after', ['status', '--porcelain=v1', '-z', '--untracked-files=no']),
                         'Node check tracked source changed')
        result['completed'] = True
    finally:
        scope['write_json'](out, 'result.json', result)
    print(json.dumps({**{k: v for k, v in result.items() if k != 'phases'},
                      'phases': {k: {key: v.get(key) for key in ['completed', 'exitCode',
                                 'treeExitedBeforeCleanup', 'activeBeforeCleanup', 'streamEOF']}
                                 for k, v in result['phases'].items()}}))


if __name__ == '__main__':
    main()
