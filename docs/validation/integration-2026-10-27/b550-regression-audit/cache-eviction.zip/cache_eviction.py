"""Evict only receipt-emitted, individually checked project Cargo caches."""
import contextlib
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys

ROOT = Path(r"C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence")
WORKTREES = Path(r"C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence")
BASE = Path("validation/integration-20261025/platform-repairs")
OUT = ROOT / BASE / "cleanup-cargo-cache-20261027"
RUNS = (
    ("t3-64b339c5", "runs/encoding-ceb23aa9-clippy-reviewed", "command"),
    ("t3-64b339c5", "runs-unit-lld-metadata/unit-lib-build-bcfcb250-reviewed", "outer"),
    ("t3-64b339c5", "runs-unit-lld-metadata/unit-lib-build-d6cd3b4a-reviewed", "outer"),
    ("t3-a8418c17", "runs/combined-dc9a4f0f-clippy-reviewed", "command"),
)
PIN_NAMES = (
    "source-before.json", "source-after.json", "source-final.json",
    "protected-before.json", "protected-after.json", "protected-final.json",
    "build-inputs-before.json", "build-inputs-after.json", "build-inputs-final.json",
    "selected-image.json", "selected-image-after.json",
    "original-control-before.json", "transaction-control-before.json",
)
CACHE_NAME = re.compile(r"lib[A-Za-z0-9_]+-[a-f0-9]{16}\.(?:rmeta|rlib)\Z")


def need(ok, label):
    if not ok:
        raise RuntimeError(label)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def raw_text(path):
    need(path.suffix in (".json", ".stdout", ".py"), "Text role required")
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
         and not before.st_file_attributes & 0x400
         and before.st_size <= 8_000_000, "Ordinary bounded text required")
    data = path.read_bytes()
    after = path.lstat()
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), "Text changed")
    return data


def norm(path):
    return os.path.normcase(os.path.abspath(path))


def referenced_paths(value, root):
    found = set()
    if isinstance(value, dict):
        for key, item in value.items():
            if isinstance(key, str) and ("/" in key or "\\" in key):
                found.add(norm(Path(key) if Path(key).is_absolute() else root / key))
            found.update(referenced_paths(item, root))
    elif isinstance(value, list):
        for item in value:
            found.update(referenced_paths(item, root))
    elif isinstance(value, str) and Path(value).is_absolute():
        found.add(norm(value))
    return found


def receipt_selection():
    emitted, excluded, pins = {}, set(), {}
    for worktree, relative, label in RUNS:
        root = WORKTREES / worktree
        run = root / BASE / relative
        job_path = run / (label + ".job.json")
        job_bytes = raw_text(job_path)
        job = json.loads(job_bytes)
        need(job["rootExitedAfterCleanup"] is True and job["activeAfterCleanup"] == 0
             and job["cleanupUnproven"] is False, "Producer not terminal")
        pins[str(job_path)] = digest(job_bytes)
        output = run / (label + ".stdout")
        output_bytes = raw_text(output)
        pins[str(output)] = digest(output_bytes)
        for line in output_bytes.decode("utf-8", "strict").splitlines():
            if not line.startswith("{"):
                continue
            row = json.loads(line)
            if row.get("reason") != "compiler-artifact":
                continue
            for filename in row.get("filenames", []):
                path = Path(filename)
                if norm(path.parent) == norm(root / "target/debug/deps") and CACHE_NAME.fullmatch(path.name):
                    emitted.setdefault(norm(path), []).append(str(output))
        for name in PIN_NAMES:
            path = run / name
            if path.exists():
                data = raw_text(path)
                pins[str(path)] = digest(data)
                excluded.update(referenced_paths(json.loads(data), root))
    return emitted, excluded, pins


class Standard(c.Structure):
    _fields_ = [("allocation", c.c_longlong), ("size", c.c_longlong),
                ("links", w.DWORD), ("pending", c.c_ubyte), ("directory", c.c_ubyte)]


class Basic(c.Structure):
    _fields_ = [("created", c.c_longlong), ("accessed", c.c_longlong),
                ("written", c.c_longlong), ("changed", c.c_longlong), ("attributes", w.DWORD)]


class FileId(c.Structure):
    _fields_ = [("volume", c.c_ulonglong), ("identity", c.c_ubyte * 16)]


k = c.WinDLL("kernel32", use_last_error=True)
k.CreateFileW.argtypes = [w.LPCWSTR, w.DWORD, w.DWORD, c.c_void_p, w.DWORD, w.DWORD, w.HANDLE]
k.CreateFileW.restype = w.HANDLE
k.GetFileInformationByHandleEx.argtypes = [w.HANDLE, c.c_int, c.c_void_p, w.DWORD]
k.GetFileInformationByHandleEx.restype = w.BOOL
k.SetFileInformationByHandle.argtypes = [w.HANDLE, c.c_int, c.c_void_p, w.DWORD]
k.SetFileInformationByHandle.restype = w.BOOL
k.CloseHandle.argtypes = [w.HANDLE]
k.CloseHandle.restype = w.BOOL


@contextlib.contextmanager
def held(path, *, directory=False, delete=False):
    handle = k.CreateFileW(str(path), 0x80 | (0x10000 if delete else 0),
                           3 if directory else 1, None, 3,
                           0x00200000 | (0x02000000 if directory else 0), None)
    if handle == c.c_void_p(-1).value:
        raise c.WinError(c.get_last_error())
    try:
        yield handle
    finally:
        need(k.CloseHandle(handle), "Handle close failed")


def metadata(path, handle, *, directory=False):
    before = path.lstat()
    values = []
    for cls, info_class in ((Standard, 1), (Basic, 0), (FileId, 18)):
        value = cls()
        if not k.GetFileInformationByHandleEx(handle, info_class, c.byref(value), c.sizeof(value)):
            raise c.WinError(c.get_last_error())
        values.append(value)
    standard, basic, identity = values
    inode = int.from_bytes(bytes(identity.identity), "little")
    need(before.st_dev == identity.volume and before.st_ino == inode and inode > 0
         and before.st_file_attributes == basic.attributes and not basic.attributes & 0x400
         and bool(standard.directory) == directory and not standard.pending, "Held path identity unavailable")
    if directory:
        need(stat.S_ISDIR(before.st_mode), "Ordinary ancestor required")
        return {"path": str(path), "device": identity.volume, "inode": inode, "attributes": basic.attributes}
    need(stat.S_ISREG(before.st_mode) and standard.links == before.st_nlink == 1
         and before.st_size == standard.size
         and before.st_mtime_ns == (basic.written - 116444736000000000) * 100,
         "Ordinary single-link cache metadata required")
    return {"path": str(path), "device": identity.volume, "inode": inode, "bytes": standard.size,
            "allocationBytes": standard.allocation, "mtimeNs": before.st_mtime_ns,
            "links": standard.links, "attributes": basic.attributes}


def routes(stack):
    pins = {}
    for worktree in sorted({run[0] for run in RUNS}):
        leaf = WORKTREES / worktree / "target/debug/deps"
        need(str(leaf.resolve()) == str(leaf), "Noncanonical cache route")
        for path in reversed((leaf, *leaf.parents)):
            if str(path) not in pins:
                handle = stack.enter_context(held(path, directory=True))
                pins[str(path)] = (path, handle, metadata(path, handle, directory=True))
    return pins


def recheck_routes(pins):
    for path, handle, before in pins.values():
        need(metadata(path, handle, directory=True) == before, "Ancestor changed")


def save_new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def main():
    need(os.name == "nt" and Path(__file__).resolve() == OUT / "cache_eviction.py", "Wrong host/controller")
    mode = sys.argv[1:]
    need(mode == ["plan"] or len(mode) == 2 and mode[0] == "apply"
         and re.fullmatch("[a-f0-9]{64}", mode[1]), "Closed invocation required")
    emitted, excluded, receipts = receipt_selection()
    with contextlib.ExitStack() as stack:
        pins = routes(stack)
        if mode == ["plan"]:
            selected = []
            for worktree in sorted({run[0] for run in RUNS}):
                leaf = WORKTREES / worktree / "target/debug/deps"
                for path in sorted(leaf.iterdir()):
                    if not CACHE_NAME.fullmatch(path.name) or norm(path) not in emitted or norm(path) in excluded:
                        continue
                    with held(path) as handle:
                        row = metadata(path, handle)
                    row["producerLogs"] = sorted(set(emitted[norm(path)]))
                    selected.append(row)
            need(0 < len(selected) <= 2500, "Candidate count budget exceeded")
            need(len({(row["device"], row["inode"]) for row in selected}) == len(selected), "Aliased cache identities")
            recheck_routes(pins)
            plan = {"schema": 1, "helperSha256": digest(raw_text(Path(__file__))),
                    "receiptPins": receipts, "files": selected, "payloadRead": False,
                    "logicalBytes": sum(row["bytes"] for row in selected),
                    "allocationBytes": sum(row["allocationBytes"] for row in selected),
                    "freeObserved": shutil.disk_usage(ROOT).free}
            save_new(OUT / "plan.json", plan)
            print(json.dumps({key: plan[key] for key in ("logicalBytes", "allocationBytes", "freeObserved")}))
            print(json.dumps({"files": len(selected), "planSha256": digest(raw_text(OUT / "plan.json"))}))
            return
        plan_bytes = raw_text(OUT / "plan.json")
        need(digest(plan_bytes) == mode[1], "Plan hash changed")
        plan = json.loads(plan_bytes)
        need(plan["helperSha256"] == digest(raw_text(Path(__file__)))
             and plan["receiptPins"] == receipts, "Preparation or receipt drift")
        need(not (OUT / "result.json").exists() and not (OUT / "events.jsonl").exists(), "Fresh operation required")
        result = {"schema": 1, "planSha256": mode[1], "completed": False, "payloadRead": False,
                  "freeBefore": shutil.disk_usage(ROOT).free, "removedFiles": 0,
                  "priorAllocationBytes": 0, "error": None}
        try:
            with (OUT / "events.jsonl").open("x", encoding="utf-8", newline="\n", buffering=1) as events:
                for index, row in enumerate(plan["files"]):
                    path = Path(row["path"])
                    need(path.parent in [WORKTREES / name / "target/debug/deps" for name in {run[0] for run in RUNS}]
                         and CACHE_NAME.fullmatch(path.name) and norm(path) in emitted
                         and norm(path) not in excluded, "Cache role changed")
                    recheck_routes(pins)
                    with held(path, delete=True) as handle:
                        expected = {key: value for key, value in row.items() if key != "producerLogs"}
                        need(metadata(path, handle) == expected, "Cache identity changed")
                        disposition = c.c_ubyte(1)
                        if not k.SetFileInformationByHandle(handle, 4, c.byref(disposition), c.sizeof(disposition)):
                            raise c.WinError(c.get_last_error())
                    need(not path.exists(), "Removal not observed")
                    events.write(json.dumps({"index": index, "path": str(path), "inode": row["inode"],
                                             "removed": True}) + "\n")
                    result["removedFiles"] += 1
                    result["priorAllocationBytes"] += row["allocationBytes"]
                    if result["removedFiles"] % 200 == 0:
                        print(json.dumps({"removedFiles": result["removedFiles"]}), flush=True)
                events.flush()
                os.fsync(events.fileno())
            need(receipt_selection()[2] == receipts, "Final receipt drift")
            recheck_routes(pins)
            result["completed"] = True
        except Exception as error:
            result["error"] = type(error).__name__ + ": " + str(error)
        finally:
            result["freeAfter"] = shutil.disk_usage(ROOT).free
            save_new(OUT / "result.json", result)
            print(json.dumps(result), flush=True)
        need(result["completed"], "Eviction incomplete; preserve receipt")


if __name__ == "__main__":
    main()
