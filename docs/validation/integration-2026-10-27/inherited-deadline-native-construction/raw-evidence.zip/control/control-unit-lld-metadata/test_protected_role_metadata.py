"""Authored inert metadata tests. This file does not execute tests on import.

All OS APIs, descriptors and filesystem observations used by lifecycle tests
are mocks. No native image, protected payload or real process is accessed.
"""
import copy
import importlib.util
import os
from pathlib import Path
import stat
import sys
from types import SimpleNamespace
import unittest
from unittest import mock


HERE = Path(__file__).absolute().parent
SPEC = importlib.util.spec_from_file_location("protected_role_metadata_under_test",
                                            HERE / "protected_role_metadata.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def file_metadata(relative, *, handle=False, readonly=False, links=1):
    permissions = 0o444 if readonly else 0o666
    if not handle and relative.endswith(".exe"):
        permissions |= 0o111
    return {"exists": True, "device": 3, "inode": 17, "bytes": 12345,
            "mtimeNs": 1_700_000_000_000_000_000, "links": links,
            "mode": stat.S_IFREG | permissions,
            "attributes": 0x21 if readonly else 0x20}


def ancestors(relative):
    return [{"path": str(path), "exists": True, "device": 3,
             "inode": index + 101, "mode": stat.S_IFDIR | 0o777,
             "attributes": 0x10}
            for index, path in enumerate(reversed((M.ROOT / relative).parents))]


def witness(relative, *, exists=True, readonly=False, links=1):
    return {"path": str(M.ROOT / relative),
            "metadata": file_metadata(relative, readonly=readonly, links=links)
            if exists else {"exists": False},
            "handleMetadata": file_metadata(relative, handle=True, readonly=readonly, links=links)
            if exists else None,
            "ancestors": ancestors(relative), "imageBytesRead": False,
            "imageExecuted": False, "desiredAccess": M.DESIRED_ACCESS,
            "fileWritesDenied": exists, "heldPathDeletionDenied": exists,
            "allAliasNamespaceDenialClaimed": False,
            "modeObservationPolicy": M.MODE_OBSERVATION_POLICY}


def inventory():
    return {relative: witness(relative) for relative in M.PROTECTED_RELATIVE}


class WitnessTests(unittest.TestCase):
    def setUp(self):
        self.relative = M.PROTECTED_RELATIVE[0]
        self.before = inventory()

    def reject_row(self, mutation, *, mutate_both=False):
        before, after = copy.deepcopy(self.before), copy.deepcopy(self.before)
        mutation(after[self.relative])
        if mutate_both:
            mutation(before[self.relative])
        with self.assertRaises(M.MetadataRefusal):
            M.checked_protected(before, after)

    def test_exact_exe_and_pdb_mode_domains_are_retained(self):
        original = copy.deepcopy(self.before)
        M.checked_protected(self.before, copy.deepcopy(self.before))
        exe = self.before[self.relative]
        self.assertEqual(exe["metadata"]["mode"], exe["handleMetadata"]["mode"] | 0o111)
        self.assertNotEqual(exe["metadata"]["mode"], exe["handleMetadata"]["mode"])
        pdb = self.before[M.PROTECTED_RELATIVE[1]]
        self.assertEqual(pdb["metadata"]["mode"], pdb["handleMetadata"]["mode"])
        self.assertEqual(self.before, original)

    def test_readonly_modes_and_recorded_hardlinks_are_supported(self):
        for relative in M.PROTECTED_RELATIVE:
            self.before[relative] = witness(relative, readonly=True, links=4)
        M.checked_protected(self.before, copy.deepcopy(self.before))
        self.assertEqual(self.before[self.relative]["metadata"]["links"], 4)
        self.assertEqual(self.before[self.relative]["handleMetadata"]["mode"], stat.S_IFREG | 0o444)

    def test_absent_leaf_keeps_complete_ancestor_evidence(self):
        self.before[self.relative] = witness(self.relative, exists=False)
        M.checked_protected(self.before, copy.deepcopy(self.before))
        self.assertIsNone(self.before[self.relative]["handleMetadata"])

    def test_absent_route_suffix_is_explicit_and_stable(self):
        self.before[self.relative] = witness(self.relative, exists=False)
        route = self.before[self.relative]["ancestors"]
        route[-1] = {"path": route[-1]["path"], "exists": False}
        M.checked_protected(self.before, copy.deepcopy(self.before))

    def test_each_cross_identity_and_metadata_field_is_required(self):
        for key in ("device", "inode", "bytes", "mtimeNs", "links", "attributes"):
            with self.subTest(key=key):
                self.reject_row(lambda row, key=key: row["handleMetadata"].__setitem__(key, row["handleMetadata"][key] + 1),
                                mutate_both=True)

    def test_each_raw_domain_mode_drift_refuses(self):
        for domain in ("metadata", "handleMetadata"):
            with self.subTest(domain=domain):
                self.reject_row(lambda row, domain=domain: row[domain].__setitem__("mode", row[domain]["mode"] ^ 0o100))

    def test_coordinated_readonly_change_still_refuses(self):
        def mutate(row):
            row.update(metadata=file_metadata(self.relative, readonly=True),
                       handleMetadata=file_metadata(self.relative, handle=True, readonly=True))
        self.reject_row(mutate)

    def test_unknown_but_regular_handle_modes_refuse(self):
        for mode in (stat.S_IFREG | 0o777, stat.S_IFREG | 0o600, stat.S_IFREG | 0o444):
            with self.subTest(mode=mode):
                self.reject_row(lambda row, mode=mode: row["handleMetadata"].__setitem__("mode", mode),
                                mutate_both=True)

    def test_wrong_exe_or_pdb_relation_refuses(self):
        self.reject_row(lambda row: row["metadata"].__setitem__("mode", row["handleMetadata"]["mode"]),
                        mutate_both=True)
        relative = M.PROTECTED_RELATIVE[1]
        before = copy.deepcopy(self.before)
        before[relative]["metadata"]["mode"] |= 0o111
        with self.assertRaises(M.MetadataRefusal):
            M.checked_protected(before, copy.deepcopy(before))

    def test_nonregular_and_reparse_leaf_observations_refuse(self):
        for domain in ("metadata", "handleMetadata"):
            for key, value in (("mode", stat.S_IFDIR | 0o777), ("attributes", 0x420),
                               ("attributes", 0x30)):
                with self.subTest(domain=domain, key=key, value=value):
                    self.reject_row(lambda row, domain=domain, key=key, value=value:
                                    row[domain].__setitem__(key, value), mutate_both=True)

    def test_missing_handle_and_unknown_attributes_refuse(self):
        self.reject_row(lambda row: row.__setitem__("handleMetadata", None), mutate_both=True)
        for domain in ("metadata", "handleMetadata"):
            with self.subTest(domain=domain):
                self.reject_row(lambda row, domain=domain: row[domain].__setitem__("attributes", None),
                                mutate_both=True)

    def test_integer_fields_never_accept_bool_or_float(self):
        for domain in ("metadata", "handleMetadata"):
            for key in ("device", "inode", "bytes", "mtimeNs", "links", "mode", "attributes"):
                for value in (True, 1.0):
                    with self.subTest(domain=domain, key=key, value=value):
                        self.reject_row(lambda row, domain=domain, key=key, value=value:
                                        row[domain].__setitem__(key, value), mutate_both=True)

    def test_witness_flags_require_actual_boolean_values(self):
        for key in ("imageBytesRead", "imageExecuted", "allAliasNamespaceDenialClaimed",
                    "fileWritesDenied", "heldPathDeletionDenied"):
            with self.subTest(key=key):
                self.reject_row(lambda row, key=key: row.__setitem__(key, 0 if row[key] is False else 1),
                                mutate_both=True)

    def test_extra_or_missing_keys_refuse(self):
        self.reject_row(lambda row: row.__setitem__("extra", False), mutate_both=True)
        self.reject_row(lambda row: row.pop("modeObservationPolicy"), mutate_both=True)
        self.reject_row(lambda row: row["handleMetadata"].__setitem__("extra", 0), mutate_both=True)
        self.reject_row(lambda row: row["metadata"].pop("mtimeNs"), mutate_both=True)

    def test_legacy_policy_and_changed_path_refuse(self):
        self.reject_row(lambda row: row.__setitem__("modeObservationPolicy", "legacy"), mutate_both=True)
        self.reject_row(lambda row: row.__setitem__("path", row["path"] + ".other"), mutate_both=True)

    def test_absent_leaf_cannot_claim_handle_or_extra_metadata(self):
        self.before[self.relative] = witness(self.relative, exists=False)
        self.reject_row(lambda row: row.__setitem__("handleMetadata", file_metadata(self.relative, handle=True)),
                        mutate_both=True)
        self.reject_row(lambda row: row["metadata"].__setitem__("bytes", 0), mutate_both=True)

    def test_exact_role_inventory_is_required(self):
        for operation in (lambda value: value.pop(self.relative),
                          lambda value: value.__setitem__("target/debug/other.exe", witness(self.relative))):
            before = copy.deepcopy(self.before)
            operation(before)
            with self.assertRaises(M.MetadataRefusal):
                M.checked_protected(before, copy.deepcopy(before))

    def test_ancestor_identity_mode_attributes_or_spelling_drift_refuses(self):
        for key, value in (("inode", 999), ("mode", stat.S_IFDIR | 0o555),
                           ("attributes", 0x11), ("path", "foreign")):
            with self.subTest(key=key):
                self.reject_row(lambda row, key=key, value=value:
                                row["ancestors"][-1].__setitem__(key, value))

    def test_reparse_missing_and_malformed_ancestors_refuse(self):
        for mutate in (
            lambda row: row["ancestors"][-1].__setitem__("attributes", 0x410),
            lambda row: row["ancestors"][-1].__setitem__("attributes", None),
            lambda row: row["ancestors"][-1].__setitem__("inode", True),
            lambda row: row["ancestors"].pop(),
            lambda row: row["ancestors"][-1].update(exists=False),
        ):
            with self.subTest(mutation=mutate):
                self.reject_row(mutate, mutate_both=True)

    def test_descendant_cannot_exist_below_an_absent_ancestor(self):
        self.before[self.relative] = witness(self.relative, exists=False)
        route = self.before[self.relative]["ancestors"]
        route[-2] = {"path": route[-2]["path"], "exists": False}
        with self.assertRaises(M.MetadataRefusal):
            M.checked_protected(self.before, copy.deepcopy(self.before))


class PinLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.relative = M.PROTECTED_RELATIVE[0]
        self.path = file_metadata(self.relative, links=2)
        self.held = file_metadata(self.relative, handle=True, links=2)
        self.route = ancestors(self.relative)
        self.api = SimpleNamespace()
        self.stack = mock.patch.multiple(M,
            protected_ancestors=mock.Mock(side_effect=lambda _: copy.deepcopy(self.route)),
            _path_observation=mock.Mock(side_effect=lambda _: copy.deepcopy(self.path)),
            _handle_observation=mock.Mock(side_effect=lambda _: copy.deepcopy(self.held)),
            _open_fd=mock.Mock(return_value=42))
        self.stack.start()
        self.addCleanup(self.stack.stop)
        self.close = mock.patch.object(M.os, "close")
        self.closed = self.close.start()
        self.addCleanup(self.close.stop)

    def test_existing_pin_retains_both_modes_and_closes_once(self):
        with M.MetadataPin(self.api, self.relative) as pin:
            row = pin.recheck()
            self.assertEqual(row["metadata"], self.path)
            self.assertEqual(row["handleMetadata"], self.held)
            self.assertEqual(row["metadata"]["links"], 2)
        self.closed.assert_called_once_with(42)
        with self.assertRaises(M.MetadataRefusal):
            pin.recheck()

    def test_returned_witness_cannot_mutate_pin_baselines(self):
        with M.MetadataPin(self.api, self.relative) as pin:
            row = pin.recheck()
            row["metadata"]["inode"] = 123
            row["handleMetadata"]["mode"] = 0
            row["ancestors"][-1]["inode"] = 123
            self.assertEqual(pin.recheck()["metadata"]["inode"], 17)
        self.closed.assert_called_once_with(42)

    def test_absent_pin_never_opens_or_closes_a_descriptor(self):
        self.path = {"exists": False}
        with M.MetadataPin(self.api, self.relative) as pin:
            self.assertIsNone(pin.recheck()["handleMetadata"])
        M._open_fd.assert_not_called()
        self.closed.assert_not_called()

    def test_constructor_identity_mismatch_closes_once(self):
        self.held["inode"] += 1
        with self.assertRaises(M.MetadataRefusal):
            M.MetadataPin(self.api, self.relative)
        self.closed.assert_called_once_with(42)

    def test_constructor_metadata_observation_failure_closes_once(self):
        M._handle_observation.side_effect = OSError("unavailable")
        with self.assertRaises(OSError):
            M.MetadataPin(self.api, self.relative)
        self.closed.assert_called_once_with(42)

    def test_constructor_close_failure_remains_failure(self):
        self.held["inode"] += 1
        self.closed.side_effect = OSError("close unavailable")
        with self.assertRaises(OSError):
            M.MetadataPin(self.api, self.relative)
        self.closed.assert_called_once_with(42)

    def test_each_path_metadata_drift_refuses_and_exit_still_closes(self):
        with self.assertRaises(M.MetadataRefusal):
            with M.MetadataPin(self.api, self.relative):
                self.path["bytes"] += 1
        self.closed.assert_called_once_with(42)

    def test_each_handle_metadata_drift_refuses_and_exit_still_closes(self):
        with self.assertRaises(M.MetadataRefusal):
            with M.MetadataPin(self.api, self.relative):
                self.held["mode"] ^= 0o100
        self.closed.assert_called_once_with(42)

    def test_ancestor_drift_refuses_and_exit_still_closes(self):
        with self.assertRaises(M.MetadataRefusal):
            with M.MetadataPin(self.api, self.relative):
                self.route[-1]["inode"] += 1
        self.closed.assert_called_once_with(42)

    def test_context_close_failure_refuses_and_is_not_retried(self):
        pin = M.MetadataPin(self.api, self.relative)
        self.closed.side_effect = OSError("close unavailable")
        with self.assertRaises(OSError):
            pin.__exit__(None, None, None)
        self.closed.assert_called_once_with(42)
        with self.assertRaises(M.MetadataRefusal):
            pin.recheck()
        with self.assertRaises(M.MetadataRefusal):
            pin.__exit__(None, None, None)
        self.closed.assert_called_once_with(42)

    def test_body_exception_is_not_suppressed(self):
        with self.assertRaisesRegex(ValueError, "body failed"):
            with M.MetadataPin(self.api, self.relative):
                raise ValueError("body failed")
        self.closed.assert_called_once_with(42)

    def test_unknown_or_traversing_role_refuses_before_open(self):
        for relative in ("../yoke.exe", "target/debug/YOKE.EXE", "target/debug/yoke.exe:stream", True):
            with self.subTest(relative=relative), self.assertRaises(M.MetadataRefusal):
                M.MetadataPin(self.api, relative)
        M._open_fd.assert_not_called()
        self.closed.assert_not_called()


class RawObservationTests(unittest.TestCase):
    def stat_info(self, *, directory=False, attributes=None):
        return SimpleNamespace(st_dev=3, st_ino=17, st_size=12345,
                               st_mtime_ns=1_700_000_000_000_000_000,
                               st_nlink=2,
                               st_mode=(stat.S_IFDIR | 0o777) if directory else (stat.S_IFREG | 0o666),
                               st_file_attributes=(0x10 if directory else 0x20)
                               if attributes is None else attributes)

    def test_raw_observation_retains_full_mode_and_attributes(self):
        info = self.stat_info()
        value = M.observation(info)
        self.assertEqual(value["mode"], info.st_mode)
        self.assertEqual(value["attributes"], info.st_file_attributes)
        self.assertEqual(value["links"], 2)

    def test_unavailable_raw_attributes_refuse(self):
        info = self.stat_info()
        del info.st_file_attributes
        with self.assertRaises(M.MetadataRefusal):
            M.observation(info)

    def test_only_explicit_not_found_is_leaf_absence(self):
        path = M.ROOT / M.PROTECTED_RELATIVE[0]
        with mock.patch.object(M.Path, "lstat", side_effect=FileNotFoundError):
            self.assertEqual(M._path_observation(path), {"exists": False})
        with mock.patch.object(M.Path, "lstat", side_effect=PermissionError):
            with self.assertRaises(PermissionError):
                M._path_observation(path)

    def test_reparse_ancestor_refuses_before_any_descendant_probe(self):
        path = M.ROOT / M.PROTECTED_RELATIVE[0]
        route = list(reversed(path.parents))
        calls = []
        def fake_lstat(parent):
            calls.append(parent)
            self.assertLessEqual(len(calls), 2, "Must not query below the rejected ancestor")
            return self.stat_info(directory=True, attributes=0x410 if len(calls) == 2 else 0x10)
        with mock.patch.object(M.Path, "lstat", autospec=True, side_effect=fake_lstat):
            with self.assertRaises(M.MetadataRefusal):
                M.protected_ancestors(path)
        self.assertEqual(calls, route[:2])

    def test_unknown_ancestor_attributes_refuse_before_descent(self):
        path = M.ROOT / M.PROTECTED_RELATIVE[0]
        info = self.stat_info(directory=True)
        del info.st_file_attributes
        with mock.patch.object(M.Path, "lstat", return_value=info) as probe:
            with self.assertRaises(M.MetadataRefusal):
                M.protected_ancestors(path)
        self.assertEqual(probe.call_count, 1)

    def test_existing_ancestor_after_missing_route_refuses(self):
        path = M.ROOT / M.PROTECTED_RELATIVE[0]
        route = list(reversed(path.parents))
        calls = []
        def fake_lstat(parent):
            calls.append(parent)
            if len(calls) == 2:
                raise FileNotFoundError
            return self.stat_info(directory=True)
        with mock.patch.object(M.Path, "lstat", autospec=True, side_effect=fake_lstat):
            with self.assertRaises(M.MetadataRefusal):
                M.protected_ancestors(path)
        self.assertEqual(calls, route[:3])


class OpeningTests(unittest.TestCase):
    def setUp(self):
        self.api = SimpleNamespace(CreateFileW=mock.Mock(return_value=24),
                                   CloseHandle=mock.Mock(return_value=1))
        self.crt = SimpleNamespace(open_osfhandle=mock.Mock(return_value=42))
        self.modules = mock.patch.dict(sys.modules, {"msvcrt": self.crt})
        self.modules.start()
        self.addCleanup(self.modules.stop)

    def test_only_execute_and_attributes_with_read_sharing_are_requested(self):
        self.assertEqual(M._open_fd(self.api, M.ROOT / M.PROTECTED_RELATIVE[0]), 42)
        self.api.CreateFileW.assert_called_once_with(
            str(M.ROOT / M.PROTECTED_RELATIVE[0]), 0xA0, 1, None, 3, 0x00200000, None)
        self.crt.open_osfhandle.assert_called_once_with(24, os.O_RDONLY | os.O_BINARY)
        self.api.CloseHandle.assert_not_called()

    def test_crt_transfer_failure_closes_the_original_handle_once(self):
        self.crt.open_osfhandle.side_effect = OSError("CRT refused")
        with self.assertRaises(OSError):
            M._open_fd(self.api, M.ROOT / M.PROTECTED_RELATIVE[0])
        self.api.CloseHandle.assert_called_once_with(24)

    def test_transfer_failure_and_close_failure_never_claim_success(self):
        self.crt.open_osfhandle.side_effect = OSError("CRT refused")
        self.api.CloseHandle.return_value = 0
        with self.assertRaises(M.MetadataRefusal):
            M._open_fd(self.api, M.ROOT / M.PROTECTED_RELATIVE[0])
        self.api.CloseHandle.assert_called_once_with(24)

    def test_invalid_native_handles_refuse_before_crt_transfer(self):
        for handle in (None, 0, -1, (1 << 64) - 1, True):
            with self.subTest(handle=handle):
                self.api.CreateFileW.return_value = handle
                with self.assertRaises(M.MetadataRefusal):
                    M._open_fd(self.api, M.ROOT / M.PROTECTED_RELATIVE[0])
        self.crt.open_osfhandle.assert_not_called()
        self.api.CloseHandle.assert_not_called()


if __name__ == "__main__":
    unittest.main()
