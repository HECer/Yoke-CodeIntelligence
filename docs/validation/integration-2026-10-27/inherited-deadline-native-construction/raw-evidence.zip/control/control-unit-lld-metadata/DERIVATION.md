# Schema-6 protected metadata derivation

The schema-5 parent manifest is
`e4569e2a0ff012e78c0c013ff23358f4cf652de5371f8c56260c80affdd4ded4`.
Its entire 24-file source bundle is frozen under `accepted-unit-lld/`; the
original earlier compiler snapshot inside it remains byte-exact too.

The new fork changes owner/schema/control and run namespaces; adds a separately
pinned protected-role metadata helper; and routes protected-role construction
and rechecks through its closed witness contract. It additionally uses typed
canonical digest equality for stored protected receipts, so Python false/0,
true/1 and integer/float equality cannot authorize image admission. No image or
producer role is widened.

The controller/worker lifecycle, commands, profiles, harnesses, cleanup, disk,
image and log budgets remain unchanged. Original CLI controls remain byte-exact.
Only the new fork's source hashes are resealed; prior receipts retain their old
owner/schema and cannot be consumed under schema 6. New helper tests and two
additional protocol guard cases are source-authored until actual run receipts
prove execution. Existing assertions and their original failure behavior remain.

The real initial b3 attempt remains refused before Cargo. A metadata-only
observation on the exact first protected file demonstrates the unequal raw modes
with equal identity, size, time, links and attributes. Published CPython 3.14.7
sources explain the filename projection; installed Python/tool binaries remain
trusted rather than content-attested. Success of an inert metadata fixture does
not establish native compilation, whole-library execution or platform acceptance.

`unit-fork.patch` records the new nonrecursive source delta; its old counterpart
is preserved in the accepted parent snapshot. This document and the manifest are
frozen preparation records, not a mutable success receipt.
