"""Closed Windows protected-role observations; no image data access or launch.

Path stat and held-handle fstat retain separate complete observations. The
documented CPython Windows filename execute-bit relation is checked rather than
erasing mode bits. These modes are observations, not NTFS ACL attestations.
Importing this module opens no file or handle.
"""
import os
from pathlib import Path
import stat


ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
PROTECTED_RELATIVE = (
    "target/debug/deps/capture_options-784339a4da3fe379.exe",
    "target/debug/deps/capture_options-784339a4da3fe379.pdb",
    "target/debug/deps/session_fixed_tools-0671ac4d8f474009.exe",
    "target/debug/deps/session_fixed_tools-0671ac4d8f474009.pdb",
    "target/debug/deps/yoke.exe", "target/debug/deps/yoke.pdb",
    "target/debug/yoke.exe", "target/debug/yoke.pdb",
    "target/release/yoke.exe", "target/release/yoke.pdb",
)
MODE_OBSERVATION_POLICY = "independent-full-path-and-handle-stat-v1"
DESIRED_ACCESS = "FILE_EXECUTE|FILE_READ_ATTRIBUTES (no FILE_READ_DATA)"
_FILE_KEYS = {"exists", "device", "inode", "bytes", "mtimeNs", "links", "mode", "attributes"}
_COMMON_KEYS = ("device", "inode", "bytes", "mtimeNs", "links", "attributes")
_ANCESTOR_KEYS = {"path", "exists", "device", "inode", "mode", "attributes"}
_WITNESS_KEYS = {
    "path", "metadata", "handleMetadata", "ancestors", "imageBytesRead",
    "imageExecuted", "desiredAccess", "fileWritesDenied",
    "heldPathDeletionDenied", "allAliasNamespaceDenialClaimed",
    "modeObservationPolicy",
}
_MAX_ID = (1 << 128) - 1
_MAX_INT = (1 << 127) - 1
_MAX_U32 = (1 << 32) - 1


class MetadataRefusal(RuntimeError):
    pass


def require(value, message):
    if not value:
        raise MetadataRefusal(message)


def _integer(value, minimum=0, maximum=_MAX_INT):
    return type(value) is int and minimum <= value <= maximum


def _closed(value, keys, message):
    require(type(value) is dict and set(value) == keys, message)


def _role_path(relative):
    require(type(relative) is str and relative in PROTECTED_RELATIVE,
            "Unknown protected role")
    require(ROOT.is_absolute() and os.path.normpath(str(ROOT)) == str(ROOT),
            "Noncanonical protected root")
    return ROOT / relative


def _file_metadata(value, *, absence=False):
    require(type(value) is dict, "Protected metadata unavailable")
    if absence and value.get("exists") is False:
        _closed(value, {"exists"}, "Unknown absent-role metadata")
        return False
    _closed(value, _FILE_KEYS, "Unknown protected file metadata")
    require(value["exists"] is True
            and _integer(value["device"], maximum=_MAX_ID)
            and _integer(value["inode"], 1, _MAX_ID)
            and _integer(value["bytes"], maximum=(1 << 63) - 1)
            and _integer(value["mtimeNs"], -_MAX_INT, _MAX_INT)
            and _integer(value["links"], 1, _MAX_U32)
            and _integer(value["mode"], maximum=_MAX_U32)
            and _integer(value["attributes"], maximum=_MAX_U32),
            "Protected file metadata unavailable")
    require(stat.S_ISREG(value["mode"])
            and not value["attributes"] & (0x400 | 0x10),
            "Protected role is not a regular non-reparse file")
    return True


def _matching_file_views(path_metadata, handle_metadata, relative):
    _file_metadata(path_metadata)
    _file_metadata(handle_metadata)
    require(all(path_metadata[key] == handle_metadata[key] for key in _COMMON_KEYS),
            "Protected path and handle identity or metadata differ")
    # CPython's Windows path-stat executable suffix observation is distinct from
    # handle fstat. Keep every raw bit and refuse any unsupported relationship.
    permissions = 0o444 if handle_metadata["attributes"] & 0x1 else 0o666
    expected_handle = stat.S_IFREG | permissions
    require(handle_metadata["mode"] == expected_handle,
            "Unsupported protected handle mode observation")
    if relative.endswith(".exe"):
        expected_path = expected_handle | 0o111
    else:
        require(relative.endswith(".pdb"), "Unsupported protected role suffix")
        expected_path = expected_handle
    require(path_metadata["mode"] == expected_path,
            "Unsupported protected path/handle mode relation")


def _checked_ancestor_row(parent, row):
    require(type(row) is dict and type(row.get("path")) is str
            and row["path"] == parent, "Protected ancestor path differs")
    if row.get("exists") is False:
        _closed(row, {"path", "exists"}, "Unknown absent ancestor metadata")
        return False
    _closed(row, _ANCESTOR_KEYS, "Unknown protected ancestor metadata")
    require(row["exists"] is True
            and _integer(row["device"], maximum=_MAX_ID)
            and _integer(row["inode"], 1, _MAX_ID)
            and _integer(row["mode"], maximum=_MAX_U32)
            and stat.S_ISDIR(row["mode"])
            and _integer(row["attributes"], maximum=_MAX_U32)
            and row["attributes"] & 0x10
            and not row["attributes"] & 0x400,
            "Protected role ancestor is not an observed ordinary directory")
    return True


def _checked_ancestors(path, observed):
    expected = [str(parent) for parent in reversed(path.parents)]
    require(type(observed) is list and len(observed) == len(expected),
            "Protected ancestor inventory unavailable")
    missing = False
    for parent, row in zip(expected, observed):
        exists = _checked_ancestor_row(parent, row)
        require(not (missing and exists), "Existing protected descendant below absent ancestor")
        missing = missing or not exists
    return not missing


def protected_ancestors(path):
    """Observe the lexical route without following a reparse directory."""
    observed = []
    missing = False
    for parent in reversed(path.parents):
        try:
            info = parent.lstat()
        except FileNotFoundError:
            observed.append({"path": str(parent), "exists": False})
            missing = True
            continue
        row = {"path": str(parent), "exists": True,
               "device": info.st_dev, "inode": info.st_ino,
               "mode": info.st_mode,
               "attributes": getattr(info, "st_file_attributes", None)}
        # Reject an unsafe ancestor before the next lstat could traverse it.
        _checked_ancestor_row(str(parent), row)
        require(not missing, "Existing protected descendant below absent ancestor")
        observed.append(row)
    _checked_ancestors(path, observed)
    return observed


def observation(info):
    value = {"exists": True, "device": info.st_dev, "inode": info.st_ino,
             "bytes": info.st_size, "mtimeNs": info.st_mtime_ns,
             "links": info.st_nlink, "mode": info.st_mode,
             "attributes": getattr(info, "st_file_attributes", None)}
    _file_metadata(value)
    return value


def _path_observation(path):
    try:
        return observation(path.lstat())
    except FileNotFoundError:
        return {"exists": False}


def _handle_observation(fd):
    return observation(os.fstat(fd))


def _open_fd(api, path):
    """Transfer one attribute/execute-only handle to one CRT descriptor."""
    import msvcrt
    require(os.name == "nt", "Windows protected metadata only")
    handle = api.CreateFileW(str(path), 0xA0, 1, None, 3, 0x00200000, None)
    require(type(handle) is int and handle > 0 and handle != (1 << 64) - 1,
            "Protected metadata pin unavailable")
    try:
        fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
    except BaseException:
        require(api.CloseHandle(handle), "Protected metadata handle close failed")
        raise
    if not _integer(fd, maximum=(1 << 31) - 1):
        require(api.CloseHandle(handle), "Protected metadata handle close failed")
        raise MetadataRefusal("Protected metadata descriptor unavailable")
    return fd


class MetadataPin:
    """Hold only the exact protected role; never read or execute its payload."""
    def __init__(self, api, relative):
        self.path = _role_path(relative)
        self.relative = relative
        self.api = api
        self.fd = None
        self.closed = False
        self.ancestors = protected_ancestors(self.path)
        self.initial = _path_observation(self.path)
        self.handle_initial = None
        exists = _file_metadata(self.initial, absence=True)
        if not exists:
            self.recheck()
            return
        require(_checked_ancestors(self.path, self.ancestors),
                "Existing protected role has an absent ancestor")
        self.fd = _open_fd(api, self.path)
        try:
            self.handle_initial = _handle_observation(self.fd)
            _matching_file_views(self.initial, self.handle_initial, relative)
            self.recheck()
        except BaseException:
            self._close()
            raise

    def _close(self):
        # Clear ownership before one close attempt. A failed close refuses;
        # retrying a possibly recycled descriptor would not prove cleanup.
        fd, self.fd = self.fd, None
        self.closed = True
        if fd is not None:
            os.close(fd)

    def recheck(self):
        require(not self.closed, "Protected metadata context is closed")
        ancestors = protected_ancestors(self.path)
        require(ancestors == self.ancestors, "Protected ancestor identities changed")
        current = _path_observation(self.path)
        _file_metadata(current, absence=True)
        require(current == self.initial, "Protected path metadata changed")
        if self.fd is not None:
            held = _handle_observation(self.fd)
            _file_metadata(held)
            require(held == self.handle_initial, "Protected held metadata changed")
            _matching_file_views(current, held, self.relative)
        else:
            require(self.initial == {"exists": False} and self.handle_initial is None,
                    "Existing protected role has no held metadata")
        row = {"path": str(self.path), "metadata": dict(self.initial),
               "handleMetadata": None if self.handle_initial is None else dict(self.handle_initial),
               "ancestors": [dict(value) for value in self.ancestors],
               "imageBytesRead": False, "imageExecuted": False,
               "desiredAccess": DESIRED_ACCESS,
               "fileWritesDenied": self.fd is not None,
               "heldPathDeletionDenied": self.fd is not None,
               "allAliasNamespaceDenialClaimed": False,
               "modeObservationPolicy": MODE_OBSERVATION_POLICY}
        _checked_witness(self.relative, row)
        return row

    def __enter__(self):
        require(not self.closed, "Protected metadata context is closed")
        return self

    def __exit__(self, *_):
        try:
            self.recheck()
        finally:
            self._close()


def _checked_witness(relative, row):
    path = _role_path(relative)
    _closed(row, _WITNESS_KEYS, "Unknown protected role witness")
    require(type(row["path"]) is str and row["path"] == str(path)
            and row["imageBytesRead"] is False and row["imageExecuted"] is False
            and row["allAliasNamespaceDenialClaimed"] is False
            and type(row["desiredAccess"]) is str and row["desiredAccess"] == DESIRED_ACCESS
            and type(row["modeObservationPolicy"]) is str
            and row["modeObservationPolicy"] == MODE_OBSERVATION_POLICY,
            "Protected role observation differs")
    route_complete = _checked_ancestors(path, row["ancestors"])
    exists = _file_metadata(row["metadata"], absence=True)
    require(row["fileWritesDenied"] is exists and row["heldPathDeletionDenied"] is exists,
            "Protected role share-denial proof differs")
    if exists:
        require(route_complete, "Existing protected role has an absent ancestor")
        _matching_file_views(row["metadata"], row["handleMetadata"], relative)
    else:
        require(row["handleMetadata"] is None, "Absent role has a handle observation")


def checked_protected(before, after):
    """Admit exact closed typed witnesses before comparing both full domains."""
    roles = set(PROTECTED_RELATIVE)
    _closed(before, roles, "Protected role inventory differs")
    _closed(after, roles, "Protected role inventory differs")
    for relative in PROTECTED_RELATIVE:
        _checked_witness(relative, before[relative])
        _checked_witness(relative, after[relative])
    # The validators above fix all scalar types, so bool/int equality cannot
    # disguise a change. Both full raw mode values remain in this comparison.
    require(before == after, "Protected role metadata differs")
