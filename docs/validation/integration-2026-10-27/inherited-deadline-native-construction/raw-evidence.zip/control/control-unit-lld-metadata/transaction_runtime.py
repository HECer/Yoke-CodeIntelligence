"""Host-invoked Windows validation only. Preparation does not execute this file.

Fixed Cargo commands, fresh producer admission, private Jobs, and create-only
receipts. This is a lifecycle guard, not an equal-privilege host sandbox.
"""
import argparse
from contextlib import ExitStack
import ctypes as c
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import threading
import time


OWNER = "integration-20261026-unit-lld-metadata-v1"
SCHEMA = 6
ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
CONTROL = ROOT / "validation/integration-20261025/platform-repairs/control-unit-lld-metadata"
RUNS = CONTROL.parent / "runs-unit-lld-metadata"
CARGO = Path(r"C:\Users\Lomi\.cargo\bin\cargo.exe")
HELPER_SHA = "d9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500"
CONTROL_NAMES = ('compiler_transaction_controller.py', 'compiler_transaction_worker.py', 'transaction_protocol.py', 'transaction_runtime.py', 'private_windows_api.py', 'test_compiler_transaction.py', 'review-manifest.json', 'README.md', '.gitattributes', 'runtime-fork.patch', 'v2-fork.patch', 'unit-fork.patch', 'DERIVATION.md', 'accepted-compiler-lld/compiler_transaction_controller.py', 'accepted-compiler-lld/compiler_transaction_worker.py', 'accepted-compiler-lld/transaction_protocol.py', 'accepted-compiler-lld/transaction_runtime.py', 'accepted-compiler-lld/private_windows_api.py', 'accepted-compiler-lld/test_compiler_transaction.py', 'accepted-compiler-lld/review-manifest.json', 'accepted-compiler-lld/README.md', 'accepted-compiler-lld/.gitattributes', 'accepted-compiler-lld/runtime-fork.patch', 'accepted-compiler-lld/v2-fork.patch', 'protected_role_metadata.py', 'test_protected_role_metadata.py', 'accepted-unit-lld/compiler_transaction_controller.py', 'accepted-unit-lld/compiler_transaction_worker.py', 'accepted-unit-lld/transaction_protocol.py', 'accepted-unit-lld/transaction_runtime.py', 'accepted-unit-lld/private_windows_api.py', 'accepted-unit-lld/test_compiler_transaction.py', 'accepted-unit-lld/review-manifest.json', 'accepted-unit-lld/README.md', 'accepted-unit-lld/.gitattributes', 'accepted-unit-lld/runtime-fork.patch', 'accepted-unit-lld/v2-fork.patch', 'accepted-unit-lld/unit-fork.patch', 'accepted-unit-lld/DERIVATION.md', 'accepted-unit-lld/accepted-compiler-lld/compiler_transaction_controller.py', 'accepted-unit-lld/accepted-compiler-lld/compiler_transaction_worker.py', 'accepted-unit-lld/accepted-compiler-lld/transaction_protocol.py', 'accepted-unit-lld/accepted-compiler-lld/transaction_runtime.py', 'accepted-unit-lld/accepted-compiler-lld/private_windows_api.py', 'accepted-unit-lld/accepted-compiler-lld/test_compiler_transaction.py', 'accepted-unit-lld/accepted-compiler-lld/review-manifest.json', 'accepted-unit-lld/accepted-compiler-lld/README.md', 'accepted-unit-lld/accepted-compiler-lld/.gitattributes', 'accepted-unit-lld/accepted-compiler-lld/runtime-fork.patch', 'accepted-unit-lld/accepted-compiler-lld/v2-fork.patch')
ACCEPTED_COMPILER_LLD_PINS = {'.gitattributes': {'bytes': 14,
                    'sha256': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9'},
 'README.md': {'bytes': 8304, 'sha256': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0'},
 'compiler_transaction_controller.py': {'bytes': 13772,
                                        'sha256': 'd6ab4fe93432a74a769e9abcdddcef40e87ef274e98fea498a219d95c2c9f29d'},
 'compiler_transaction_worker.py': {'bytes': 1600,
                                    'sha256': 'cf24492dafb4c30ce057a0885c5021339fc76fa3dba1e1efdddaf111fa1285fb'},
 'private_windows_api.py': {'bytes': 2146,
                            'sha256': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500'},
 'review-manifest.json': {'bytes': 6537,
                          'sha256': '141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9'},
 'runtime-fork.patch': {'bytes': 5828,
                        'sha256': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6'},
 'test_compiler_transaction.py': {'bytes': 48288,
                                  'sha256': 'da422d730d3db84b4967fe422d8b8106ed5bb2faac05fa95b012ec5c5ee4bed9'},
 'transaction_protocol.py': {'bytes': 45739,
                             'sha256': 'eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a'},
 'transaction_runtime.py': {'bytes': 44391,
                            'sha256': '1608c69131ab3374812496ee9ff855e2c906ac172d31f9899331aa33f2e98de8'},
 'v2-fork.patch': {'bytes': 52980,
                   'sha256': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5'}}

START_FREE = 1_200_000_000
RUN_FREE = 500_000_000
MAX_LOG = 16_000_000
MAX_SOURCE_FILES = 10_000
MAX_SOURCE_BYTES = 512_000_000
QUALIFICATION = (
    "Selected tracked source bytes and private controls are mapped before/after. "
    "External dependency/tool binaries, caches, all environment values and the entire host "
    "are not frozen. No broader platform, hosted CI, release or universal acceptance is implied. "
    "The host must execute these controllers serially and exclude other target-directory producers."
)


def require(value, message):
    if not value:
        raise RuntimeError(message)


def emit(value):
    print(json.dumps(value, ensure_ascii=True), flush=True)


def identity(info):
    return [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_nlink]


def ordinary(path, directory=False):
    path = Path(path)
    require(path.is_absolute() and os.path.normpath(str(path)) == str(path), "Noncanonical absolute path")
    for ancestor in reversed(path.parents):
        info = ancestor.lstat()
        require(stat.S_ISDIR(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400,
                "Reparse or non-directory ancestor refused")
    info = path.lstat()
    require(not getattr(info, "st_file_attributes", 0) & 0x400, "Reparse point refused")
    require(stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode),
            "Unexpected filesystem object")
    if not directory:
        require(info.st_nlink == 1 and info.st_ino != 0, "Single-link file identity required")
    return info


def source_digest(path, maximum=64_000_000):
    # This generic byte reader can never hash any EXE/PDB, including a byproduct.
    require(path.suffix.lower() not in (".exe", ".pdb"), "Executable/PDB source read forbidden")
    before = ordinary(path)
    require(0 <= before.st_size <= maximum, "Source/control byte budget exceeded")
    digest = hashlib.sha256()
    count = 0
    with path.open("rb") as stream:
        while data := stream.read(1_048_576):
            count += len(data)
            require(count <= maximum, "Growing source/control byte budget exceeded")
            digest.update(data)
    require(identity(before) == identity(ordinary(path)) and count == before.st_size,
            "Source/control changed while hashing")
    return {"sha256": digest.hexdigest(), "bytes": count}


ACCEPTED_UNIT_LLD_PINS = {'compiler_transaction_controller.py': {'bytes': 14587, 'sha256': '27607b5542b341e5a413e3cb1ff3f5058d84b1bc006a9fa0166f8f2efd87fa06'}, 'compiler_transaction_worker.py': {'bytes': 1596, 'sha256': '9873dd7172de5628b2eb38305a0e67c9658dd05d2b614d3651746bab34e48911'}, 'transaction_protocol.py': {'bytes': 57062, 'sha256': 'ed744abf77c7e4a2852999df8c7460cfe38c88c3f8773921abdd6db16554a14f'}, 'transaction_runtime.py': {'bytes': 30218, 'sha256': '5e7e57c4a3171755d20ad184eca41871082ed220a9c77e455369b8fd8a2cb360'}, 'private_windows_api.py': {'bytes': 2146, 'sha256': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500'}, 'test_compiler_transaction.py': {'bytes': 70763, 'sha256': 'caf8c068c68ff2e3e60c60957db8fd9fa6684ff1d9bdb058c9cc9fb60230bc24'}, 'review-manifest.json': {'bytes': 12994, 'sha256': 'e4569e2a0ff012e78c0c013ff23358f4cf652de5371f8c56260c80affdd4ded4'}, 'README.md': {'bytes': 11244, 'sha256': 'e1a6b02652d0b9d2c95cf8a8a50f16d2542d85700d3f1653fca9471df8554a87'}, '.gitattributes': {'bytes': 14, 'sha256': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9'}, 'runtime-fork.patch': {'bytes': 5828, 'sha256': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6'}, 'v2-fork.patch': {'bytes': 52980, 'sha256': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5'}, 'unit-fork.patch': {'bytes': 131036, 'sha256': '3a85f420dc5290bdc520b0ff9cb2c265747e33a322de9356da8119b21fe0e2b9'}, 'DERIVATION.md': {'bytes': 3977, 'sha256': '0979a73ca65c26582481c7463bf85310a8dc9e211c8d917cb7cfffe35d063ef9'}, 'accepted-compiler-lld/compiler_transaction_controller.py': {'bytes': 13772, 'sha256': 'd6ab4fe93432a74a769e9abcdddcef40e87ef274e98fea498a219d95c2c9f29d'}, 'accepted-compiler-lld/compiler_transaction_worker.py': {'bytes': 1600, 'sha256': 'cf24492dafb4c30ce057a0885c5021339fc76fa3dba1e1efdddaf111fa1285fb'}, 'accepted-compiler-lld/transaction_protocol.py': {'bytes': 45739, 'sha256': 'eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a'}, 'accepted-compiler-lld/transaction_runtime.py': {'bytes': 44391, 'sha256': '1608c69131ab3374812496ee9ff855e2c906ac172d31f9899331aa33f2e98de8'}, 'accepted-compiler-lld/private_windows_api.py': {'bytes': 2146, 'sha256': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500'}, 'accepted-compiler-lld/test_compiler_transaction.py': {'bytes': 48288, 'sha256': 'da422d730d3db84b4967fe422d8b8106ed5bb2faac05fa95b012ec5c5ee4bed9'}, 'accepted-compiler-lld/review-manifest.json': {'bytes': 6537, 'sha256': '141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9'}, 'accepted-compiler-lld/README.md': {'bytes': 8304, 'sha256': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0'}, 'accepted-compiler-lld/.gitattributes': {'bytes': 14, 'sha256': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9'}, 'accepted-compiler-lld/runtime-fork.patch': {'bytes': 5828, 'sha256': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6'}, 'accepted-compiler-lld/v2-fork.patch': {'bytes': 52980, 'sha256': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5'}}


def controls_map():
    result = {name: source_digest(CONTROL / name, 1_000_000) for name in CONTROL_NAMES}
    require(result["private_windows_api.py"]["sha256"] == HELPER_SHA, "Private helper hash differs")
    require(all(result["accepted-compiler-lld/" + name] == expected
                for name, expected in ACCEPTED_COMPILER_LLD_PINS.items()), "Immutable accepted LLD derivation differs")
    require(all(result["accepted-unit-lld/" + name] == expected
                for name, expected in ACCEPTED_UNIT_LLD_PINS.items()), "Immutable accepted unit derivation differs")
    return result


def write_json(out, name, value):
    require(re.fullmatch(r"[a-z0-9][a-z0-9.-]*\.json", name), "Invalid receipt name")
    ordinary(out, directory=True)
    # No receipt is overwritten, even on failure/retry.
    with (out / name).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=True) + "\n")


def new_output(run_id):
    require(re.fullmatch(r"[a-z][a-z0-9-]{0,95}", run_id), "Invalid create-only run ID")
    ordinary(CONTROL.parent, directory=True)
    try:
        RUNS.mkdir()
    except FileExistsError:
        pass
    ordinary(RUNS, directory=True)
    out = RUNS / run_id
    out.mkdir(exist_ok=False)
    ordinary(out, directory=True)
    return out


def load_windows_api():
    # Never import the concurrently edited working-tree host probe. Compile only
    # the reviewed, hash-pinned private helper bytes; do not create __pycache__.
    path = CONTROL / "private_windows_api.py"
    require(source_digest(path, 65_536)["sha256"] == HELPER_SHA, "Private ABI helper differs")
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == HELPER_SHA, "Private helper changed before loading")
    namespace = {"__name__": "private_reviewed_windows_api"}
    exec(compile(data, str(path), "exec"), namespace)
    result = namespace["windows_api"]()
    require(isinstance(result, tuple) and len(result) == 4 and c.sizeof(c.c_void_p) == 8,
            "Original four-item Windows ABI required")
    api, extended, _, _ = result
    for name, args, return_type in (
        ("OpenProcess", [c.c_ulong, c.c_int, c.c_ulong], c.c_void_p),
        ("IsProcessInJob", [c.c_void_p, c.c_void_p, c.POINTER(c.c_int)], c.c_int),
        ("QueryFullProcessImageNameW", [c.c_void_p, c.c_ulong, c.c_wchar_p, c.POINTER(c.c_ulong)], c.c_int),
        ("CreateFileW", [c.c_wchar_p, c.c_ulong, c.c_ulong, c.c_void_p, c.c_ulong, c.c_ulong, c.c_void_p], c.c_void_p),
        ("CreateMutexW", [c.c_void_p, c.c_int, c.c_wchar_p], c.c_void_p),
        ("ReleaseMutex", [c.c_void_p], c.c_int),
    ):
        function = getattr(api, name)
        function.argtypes, function.restype = args, return_type
    return api, extended


class ReadPin:
    """One existing ordinary file; deny writes/deletion until closed."""
    def __init__(self, api, path, maximum, image=False):
        import msvcrt

        self.path, self.maximum, self.stream = path, maximum, None
        if not image:
            require(path.suffix.lower() not in (".exe", ".pdb"), "Generic pin cannot read executable/PDB")
        before = ordinary(path)
        require((0 < before.st_size if image else 0 <= before.st_size) and before.st_size <= maximum,
                "Pinned file byte budget exceeded")
        handle = api.CreateFileW(str(path), 0x80000000, 1, None, 3, 0x00200000, None)
        require(handle not in (None, c.c_void_p(-1).value), "Write-denying read pin unavailable")
        try:
            fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
        except BaseException:
            api.CloseHandle(handle)
            raise
        self.stream = os.fdopen(fd, "rb")
        try:
            info = os.fstat(self.stream.fileno())
            require(identity(info) == identity(before) and info.st_nlink == 1,
                    "Pinned file identity differs")
            self.initial_identity = identity(info)
            self.initial_sha = self.digest()
        except BaseException:
            self.close()
            raise

    def digest(self):
        self.stream.seek(0)
        digest = hashlib.sha256()
        count = 0
        while data := self.stream.read(1_048_576):
            count += len(data)
            require(count <= self.maximum, "Pinned file grew beyond byte budget")
            digest.update(data)
        require(count == os.fstat(self.stream.fileno()).st_size, "Pinned file read incomplete")
        self.stream.seek(0)
        return digest.hexdigest()

    def bytes(self):
        self.stream.seek(0)
        result = self.stream.read(self.maximum + 1)
        require(len(result) <= self.maximum, "Pinned text receipt grew")
        return result

    def recheck(self):
        require(identity(ordinary(self.path)) == self.initial_identity
                and identity(os.fstat(self.stream.fileno())) == self.initial_identity,
                "Pinned file namespace/identity changed")
        require(self.digest() == self.initial_sha, "Pinned bytes changed")
        return self.record()

    def record(self):
        return {"path": str(self.path), "sha256": self.initial_sha,
                "fileIdentity": self.initial_identity[:2], "bytes": self.initial_identity[2],
                "mtimeNs": self.initial_identity[3], "links": self.initial_identity[4],
                "noReparseAncestors": True, "writersAndDeletionDeniedThroughRecheck": True}

    def close(self):
        if self.stream is not None:
            self.stream.close()
            self.stream = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        try:
            self.recheck()
        finally:
            self.close()


def run_owned(api, extended, out, label, argv, environment, seconds, cap=MAX_LOG,
              *, absolute_deadline_ns=None, job_name=None):
    """Every child (including read-only Git) is suspended and Job-assigned."""
    import _winapi
    import msvcrt

    require(re.fullmatch(r"[a-z0-9-]+", label), "Invalid command receipt label")
    require(Path(argv[0]).is_absolute(), "Absolute host-selected executable required")
    require(shutil.disk_usage("C:\\").free >= START_FREE, "1.2 GB start admission unavailable")
    row = {"command": argv, "deadlineSeconds": seconds, "logCapBytes": cap,
           "stdinClosed": False, "startedSuspended": False, "assignedBeforeResume": False,
           "completed": False, "treeExitedBeforeCleanup": False,
           "minimumFreeObserved": shutil.disk_usage("C:\\").free,
           "cleanupErrors": [], "streamEOF": [False, False], "readerErrors": [False, False]}
    job = process = thread = None
    assigned = False
    fds, readers, streams = [], [], []
    overflow = threading.Event()
    lock = threading.Lock()
    written = [0]
    started = time.monotonic()
    started_ns = time.monotonic_ns()
    require(type(seconds) is int and seconds > 0, "Positive fixed deadline required")
    if absolute_deadline_ns is None:
        absolute_deadline_ns = started_ns + seconds * 1_000_000_000
    require(type(absolute_deadline_ns) is int
            and started_ns < absolute_deadline_ns <= started_ns + seconds * 1_000_000_000,
            "Absolute deadline expired or refreshed")
    require(job_name is None or re.fullmatch(r"Local\\YokeUnitLLD-[0-9a-f]{64}", job_name),
            "Closed compiler transaction Job name required")
    end = min(started + seconds, absolute_deadline_ns / 1_000_000_000)
    row.update(startedMonotonicNs=started_ns, absoluteDeadlineNs=absolute_deadline_ns,
               jobName=job_name, namedJobCreatedNew=False)

    def active():
        data = c.create_string_buffer(48)
        require(api.QueryInformationJobObject(job, 1, data, 48, None), "Owned Job accounting unavailable")
        return int.from_bytes(data.raw[40:44], "little")

    def members():
        data = c.create_string_buffer(8 + 8 * 2048)
        require(api.QueryInformationJobObject(job, 3, data, len(data), None), "Owned Job members unavailable")
        assigned_count = int.from_bytes(data.raw[0:4], "little")
        count = int.from_bytes(data.raw[4:8], "little")
        require(count <= 2048 and assigned_count == count, "Owned Job member list partial/over capacity")
        result = []
        for index in range(count):
            pid = int.from_bytes(data.raw[8 + 8 * index:16 + 8 * index], "little")
            item = {"pid": pid, "imageBytesRead": False, "imageIdentityKnown": False}
            handle = api.OpenProcess(0x101000, False, pid)
            if handle:
                try:
                    inside = c.c_int()
                    if api.IsProcessInJob(handle, job, c.byref(inside)) and inside.value:
                        item["membershipConfirmed"] = True
                        name = c.create_unicode_buffer(32768)
                        size = c.c_ulong(len(name))
                        if api.QueryFullProcessImageNameW(handle, 0, name, c.byref(size)):
                            item["imagePathMetadata"] = name.value
                            # A path query is deliberately not a file identity/byte observation.
                        else:
                            item["imageQueryError"] = c.get_last_error()
                    else:
                        item["membershipConfirmed"] = False
                        item["membershipQueryError"] = c.get_last_error()
                finally:
                    require(api.CloseHandle(handle), "Owned member metadata handle close failed")
            else:
                item["openError"] = c.get_last_error()
            result.append(item)
        return result

    def drain_stream(index, fd, stream):
        try:
            while True:
                data = os.read(fd, 8192)
                if not data:
                    row["streamEOF"][index] = True
                    break
                with lock:
                    available = max(0, cap - written[0])
                    accepted = data[:available]
                    if accepted:
                        require(stream.write(accepted) == len(accepted), "Partial capped log write")
                    written[0] += len(accepted)
                    if len(data) > available:
                        overflow.set()
        except BaseException:
            row["readerErrors"][index] = True
            overflow.set()
        finally:
            try:
                os.close(fd)
            except OSError:
                row["readerErrors"][index] = True

    try:
        c.set_last_error(0)
        job = api.CreateJobObjectW(None, job_name)
        create_error = c.get_last_error()
        require(job, "Private Job unavailable")
        if job_name is not None and create_error == 183:
            # A collision handle does not confer ownership. In particular the
            # finally block must never terminate or query that existing Job.
            occupied, job = job, None
            if not api.CloseHandle(occupied):
                row["cleanupErrors"].append("occupied-job-handle-close")
            raise RuntimeError("Named Job already occupied")
        row["namedJobCreatedNew"] = job_name is not None
        limits = extended()
        limits.basic.flags = 0x2000
        require(api.SetInformationJobObject(job, 9, c.byref(limits), c.sizeof(limits)),
                "Kill-on-close Job limits unavailable")
        for suffix in (".stdout", ".stderr"):
            streams.append((out / (label + suffix)).open("xb", buffering=0))
        stdin_read, stdin_write = os.pipe()
        fds.extend((stdin_read, stdin_write))
        stdout_read, stdout_write = os.pipe()
        fds.extend((stdout_read, stdout_write))
        stderr_read, stderr_write = os.pipe()
        fds.extend((stderr_read, stderr_write))
        child_handles = [msvcrt.get_osfhandle(fd) for fd in (stdin_read, stdout_write, stderr_write)]
        for handle in child_handles:
            os.set_handle_inheritable(handle, True)
        startup = subprocess.STARTUPINFO()
        startup.dwFlags = subprocess.STARTF_USESTDHANDLES
        startup.hStdInput, startup.hStdOutput, startup.hStdError = child_handles
        startup.lpAttributeList = {"handle_list": child_handles}
        require(time.monotonic_ns() < absolute_deadline_ns, "Absolute launch deadline expired")
        process, thread, pid, _ = _winapi.CreateProcess(
            str(argv[0]), subprocess.list2cmdline(argv), None, None, True,
            subprocess.CREATE_NO_WINDOW | 4, environment, str(ROOT), startup)
        row.update(pid=pid, startedSuspended=True)
        require(api.AssignProcessToJobObject(job, process), "Suspended Job assignment failed")
        assigned = True
        row["assignedBeforeResume"] = True
        for fd in (stdin_read, stdin_write, stdout_write, stderr_write):
            os.close(fd)
            fds.remove(fd)
        row["stdinClosed"] = True
        for index, fd in enumerate((stdout_read, stderr_read)):
            reader = threading.Thread(target=drain_stream, args=(index, fd, streams[index]), daemon=True)
            readers.append(reader)
            reader.start()
            fds.remove(fd)
        row["resumePreviousSuspendCount"] = api.ResumeThread(thread)
        require(row["resumePreviousSuspendCount"] == 1, "Primary suspended thread resume failed")
        previous = time.monotonic()
        while True:
            status = _winapi.WaitForSingleObject(process, 50)
            free = shutil.disk_usage("C:\\").free
            row["minimumFreeObserved"] = min(row["minimumFreeObserved"], free)
            if free < RUN_FREE:
                row["stopReason"] = "disk-reserve"
            elif time.monotonic() >= end:
                row["stopReason"] = "deadline"
            elif overflow.is_set():
                row["stopReason"] = "log-or-reader-budget"
            if status == 0:
                row["exitCode"] = _winapi.GetExitCodeProcess(process)
                break
            require(status == 258, "Owned root wait failed")
            if row.get("stopReason"):
                break
            if time.monotonic() - previous >= 30:
                emit({"owner": OWNER, "run": out.name, "command": label,
                      "freeBytes": free, "capturedLogBytes": written[0]})
                previous = time.monotonic()
        row["rootObservedMonotonicNs"] = time.monotonic_ns()
        row["membersAtRootObservation"] = members()
        row["rootExitedAtObservation"] = _winapi.WaitForSingleObject(process, 0) == 0
        row["activeAtRootObservation"] = active()
        drain_end = min(end, time.monotonic() + 1)
        row["originalDrainSeconds"] = 1
        row["activeBeforeCleanup"] = active()
        while row["activeBeforeCleanup"] and time.monotonic() < drain_end:
            time.sleep(.01)
            free = shutil.disk_usage("C:\\").free
            row["minimumFreeObserved"] = min(row["minimumFreeObserved"], free)
            if free < RUN_FREE:
                row["stopReason"] = "disk-reserve"
                break
            row["activeBeforeCleanup"] = active()
        row["membersAfterOriginalDrain"] = members()
        row["treeExitedBeforeCleanup"] = row["activeBeforeCleanup"] == 0
        row["treeObservedMonotonicNs"] = time.monotonic_ns()
        if row["treeObservedMonotonicNs"] >= absolute_deadline_ns:
            row["stopReason"] = "deadline"
    except BaseException as error:
        row["errorType"], row["error"] = type(error).__name__, str(error)
    finally:
        # Two seconds total, including accounting, root wait, and pipe EOF.
        cleanup_end = time.monotonic() + 2
        row["cleanupSeconds"] = 2
        if process is not None and not assigned:
            try:
                _winapi.TerminateProcess(process, 124)
            except OSError:
                row["cleanupErrors"].append("own-unassigned-root-termination")
        if job is not None:
            if not api.TerminateJobObject(job, 125):
                row["cleanupErrors"].append("own-job-termination")
            try:
                while active() and time.monotonic() < cleanup_end:
                    time.sleep(.01)
                row["activeAfterCleanup"] = active()
                if row["activeAfterCleanup"] != 0:
                    row["cleanupErrors"].append("job-still-active")
            except BaseException:
                row["activeAfterCleanup"] = None
                row["cleanupErrors"].append("job-accounting")
        else:
            row["activeAfterCleanup"] = None
        row["rootExitedAfterCleanup"] = process is None
        if process is not None:
            try:
                remaining_ms = max(0, int((cleanup_end - time.monotonic()) * 1000))
                row["rootExitedAfterCleanup"] = _winapi.WaitForSingleObject(process, remaining_ms) == 0
                if not row["rootExitedAfterCleanup"]:
                    row["cleanupErrors"].append("root-exit")
            except OSError:
                row["cleanupErrors"].append("root-wait")
        for reader in readers:
            try:
                reader.join(max(0, cleanup_end - time.monotonic()))
                if reader.is_alive():
                    row["cleanupErrors"].append("log-reader-still-active")
            except BaseException:
                row["cleanupErrors"].append("log-reader-join")
        for fd in fds:
            try:
                os.close(fd)
            except OSError:
                row["cleanupErrors"].append("pipe-close")
        for handle in (thread, process, job):
            if handle is not None and not api.CloseHandle(handle):
                row["cleanupErrors"].append("handle-close")
        for stream in streams:
            try:
                stream.close()
            except OSError:
                row["cleanupErrors"].append("log-close")
    row.update(elapsedSeconds=time.monotonic() - started, capturedLogBytes=written[0],
               outputExceeded=overflow.is_set())
    row["cleanupUnproven"] = bool(row["cleanupErrors"])
    row["completed"] = ("errorType" not in row and not row.get("stopReason")
                        and row.get("exitCode") == 0 and row["startedSuspended"]
                        and row["assignedBeforeResume"] and row["stdinClosed"]
                        and row.get("resumePreviousSuspendCount") == 1
                        and row["treeExitedBeforeCleanup"] and row.get("activeAfterCleanup") == 0
                        and row["rootExitedAfterCleanup"] and not row["cleanupUnproven"]
                        and all(row["streamEOF"]) and not any(row["readerErrors"])
                        and not row["outputExceeded"])
    write_json(out, label + ".job.json", row)
    return row


def environment_for(mode):
    environment = os.environ.copy()
    forbidden = []
    for key, value in environment.items():
        upper = key.upper()
        # libtest treats some variables as presence flags, even when empty.
        if upper.startswith("RUST_TEST_"):
            forbidden.append(key)
            continue
        if (upper in {"RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS", "CARGO_ENCODED_RUSTDOCFLAGS",
                      "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUSTC", "RUSTDOC", "CARGO_BUILD_TARGET",
                      "CARGO_TARGET_DIR", "CARGO_BUILD_RUSTFLAGS", "CARGO_BUILD_RUSTC", "CARGO_BUILD_RUSTDOC",
                      "CARGO_BUILD_TARGET_DIR", "CARGO_BUILD_BUILD_DIR",
                      "CARGO_INCREMENTAL", "RUSTC_BOOTSTRAP",
                      "CARGO_BUILD_RUSTC_WRAPPER", "CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER",
                      "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_CONFIG_PARAMETERS", "GIT_CONFIG_COUNT"}
                or upper.startswith(("CARGO_PROFILE_", "CARGO_UNSTABLE_"))
                or upper.startswith("CARGO_TARGET_") and upper.endswith(("_RUSTFLAGS", "_RUNNER", "_LINKER"))):
            if value:
                forbidden.append(key)
    require(not forbidden, "Ambient compiler/target/runner/Git overrides refused: " + ", ".join(sorted(forbidden)))
    environment["PATH"] = str(CARGO.parent) + os.pathsep + environment.get("PATH", "")
    environment.update(GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
    if mode == "test":
        for key in ("SSL_CERT_FILE", "SSL_CERT_DIR", "SSLKEYLOGFILE"):
            environment.pop(key, None)
    # Do not read global configuration contents or any credential file. Unknown
    # Cargo policy refuses rather than silently changing features/profiles/flags.
    cargo_home = Path(environment.get("CARGO_HOME", str(Path.home() / ".cargo")))
    require(cargo_home.is_absolute(), "Absolute Cargo home required")
    directories = [base / ".cargo" for base in (ROOT, *ROOT.parents)] + [cargo_home]
    for directory in set(directories):
        for name in ("config", "config.toml"):
            candidate = directory / name
            require(not os.path.lexists(candidate), "Existing Cargo configuration requires separate host review")
    return environment


def git_capture(api, extended, out, environment, label, arguments):
    git = shutil.which("git.exe", path=environment["PATH"])
    require(git and Path(git).is_absolute(), "Host Git unavailable")
    argv = [git, "--no-optional-locks", "-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false",
            *arguments]
    result = run_owned(api, extended, out, label, argv, environment, 30, cap=2_000_000)
    require(result["completed"], "Read-only Git observation incomplete: " + label)
    return (out / (label + ".stdout")).read_bytes()


def source_map(api, extended, out, environment, commit, phase):
    # Untracked Cargo configuration can alter a later compiler invocation while
    # remaining invisible to the tracked-only Git inventory below.
    require(environment_for("build") == environment, "Cargo environment/configuration changed")
    head = git_capture(api, extended, out, environment, "git-head-" + phase,
                       ["rev-parse", "--verify", "HEAD"]).decode("ascii").strip()
    require(head == commit, "HEAD differs from exact host-supplied source commit")
    status = git_capture(api, extended, out, environment, "git-status-" + phase,
                         ["status", "--porcelain=v1", "-z", "--untracked-files=no"])
    require(not status, "Tracked checkout is not clean")
    listing = git_capture(api, extended, out, environment, "git-files-" + phase,
                          ["ls-files", "-z"]).decode("utf-8", "strict")
    names = [name for name in listing.split("\0") if name]
    require(len(names) == len(set(names)) and len(names) <= 100_000, "Tracked inventory duplicate/over capacity")
    selected = sorted(name for name in names if name.startswith(("native/", "scripts/", ".cargo/"))
                      or Path(name).name in ("Cargo.toml", "Cargo.lock", "rust-toolchain", "rust-toolchain.toml")
                      or name == ".github/workflows/rust.yml")
    require({"Cargo.toml", "Cargo.lock", "native/Cargo.toml", "scripts/host_powershell_probe.py",
             "scripts/run_native_tests.py", "scripts/ci_windows_temp.py", "scripts/native_shards.py",
             ".github/workflows/rust.yml"}.issubset(selected), "Required tracked inputs missing")
    for name in selected:
        require(not Path(name).is_absolute() and ".." not in Path(name).parts and "\\" not in name
                and ":" not in name and all(ord(character) >= 32 for character in name)
                and all(part.rstrip(" .") == part for part in Path(name).parts),
                "Noncanonical tracked source path")
    result = hash_selected(selected)
    write_json(out, "source-" + phase + ".json", result)
    return result


def hash_selected(names):
    require(len(names) <= MAX_SOURCE_FILES, "Selected source file count budget exceeded")
    result, size = {}, 0
    end = time.monotonic() + 120
    for name in names:
        require(time.monotonic() < end, "Selected source hashing deadline exceeded")
        entry = source_digest(ROOT / name)
        size += entry["bytes"]
        require(size <= MAX_SOURCE_BYTES, "Selected source total byte budget exceeded")
        result[name] = entry
    return result


def unique_json(data):
    def pairs(values):
        result = {}
        for key, value in values:
            require(key not in result, "Duplicate JSON object key")
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=pairs)



if __name__ == "__main__":
    raise SystemExit("Library-only unit-harness lifecycle runtime")
