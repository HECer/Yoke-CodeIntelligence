# Separate metadata-safe whole-unit validation

Owner `integration-20261026-unit-lld-metadata-v1`, schema 6. This is a new source fork,
not a relaxation or mutation of the accepted schema-5 controls. The complete
24-file parent is retained byte-for-byte under `accepted-unit-lld/`. Original
seven CLI controls and the older V2 source snapshot remain independent.

## Measured reason for the fork

At clean source b3a87d5d, all 72 original guard cases pass. The actual schema-5
`unit-lib-build-b3-r1` refuses before Cargo, with no image read or execution.
Its first existing protected EXE has path mode 33279 and held-handle mode 33206;
identity, size, modification time, links and attributes agree and stay unchanged.
The observed trusted interpreter reports CPython 3.14.7; no interpreter byte
attestation is claimed.

CPython's [path stat](https://github.com/python/cpython/blob/v3.14.7/Modules/posixmodule.c#L1915-L1937)
adds executable bits for certain filename suffixes. [Attribute conversion](https://github.com/python/cpython/blob/v3.14.7/Python/fileutils.c#L1005-L1016)
and [handle stat](https://github.com/python/cpython/blob/v3.14.7/Python/fileutils.c#L1148-L1196)
produce a different observation without that filename projection. Neither
`st_mode` is an NTFS ACL, content checksum or proof that an image can execute.

## Closed protected-role witnesses

The new helper keeps complete path and handle observations separately. Each
must remain unchanged; identity, bytes, modification time, links and attributes
must agree across them. Both must be regular files. The held mode must equal
the documented regular-file/READONLY attribute projection. The EXE path mode
must include the documented filename execute bits; a PDB path mode must equal
the held mode. No observed bits are erased. Unknown or contradictory metadata,
reparses, ancestor drift, invalid types, unavailable handles and close failures
refuse. Existing hardlinks are recorded rather than treated as single-link files.

The exact original protected-role allowlist remains. Handles request only
FILE_EXECUTE|FILE_READ_ATTRIBUTES, read sharing, OPEN_EXISTING and
FILE_FLAG_OPEN_REPARSE_POINT with no inherited handle; no FILE_READ_DATA is
requested and no image bytes are read, hashed, loaded or executed by this check.
Full lexical ancestor observations also protect absent roles. These are endpoint
observations, not continuous ancestor locks or all-alias namespace protection.
All complete witness records are compared using typed canonical digests before
the first selected-image read. Old owner/schema receipts are rejected.

## Unchanged compiler and consumer policy

Only the closed `lib` and `cli` unit suites remain. The caller supplies the exact
clean source commit. Fresh fixed output, normal test profiles, fixed installed
LLD, source/control/protected-role pins, typed Cargo admission and producer/image
matching remain mandatory. Integration targets and ancillary-bin exceptions are
not added. Existing dependency caches and installed tools remain trusted.

The build keeps its one original 3600-second deadline, at most 60 seconds of
natural inner quiescence clipped to that deadline, one-second outer drain and
sole two-second total abort. Admission remains 4 GB free, continuous reserve
500 MB, image admission 1.2 GB, image ceiling 512 MB and captured logs 16 MB.
The consumer keeps 1200 seconds, one-second drain, sole two-second abort,
`--test-threads=1`, all complete records, zero failures/filters and exactly the
seven original library ignores (zero for CLI). Force-cleaned work cannot qualify.

## Preparation versus actual acceptance

The manifest records source preparation and authored test scope only. Inherited
assertions remain, with additional typed-protected-receipt and prior-schema
refusal cases plus helper lifecycle/witness cases. No result in this README
claims those new cases have run. Parent review, guarded execution, complete
matching producer/consumer receipts and their final context/mutex checks are
required. Actual outcomes belong in separate fresh run receipts.

No old/default/private failed image is adopted. Protected native/PDB contents,
whole platform, current release, VSIX and full project qualification remain
outside this source preparation.
