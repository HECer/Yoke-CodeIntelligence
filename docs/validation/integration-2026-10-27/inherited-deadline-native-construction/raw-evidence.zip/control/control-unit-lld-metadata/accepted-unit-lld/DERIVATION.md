# Unit LLD derivation and limits

This is a separate explicit source fork, not a mutation of a loaded release module. The accepted eleven-file source snapshot is retained byte-exact inside this bundle and every snapshot byte/hash remains part of the new control map. The historical runtime-fork/v2-fork patches remain original; unit-fork.patch is the new delta. The old release result schema and consumers must refuse schema4/unit owner receipts.

The parent corrected an initially assumed test profile before implementation: the current source has dev/test debug=0 and incremental=false plus dev.package.sha2 opt-level=3. The new policy preserves those exact held source tables and selected harness opt0/debug0/assertions+overflow true. No tracked Cargo/source file was changed to accommodate a policy.

Pinned primary-source research:
- Cargo1.94 rustc command explicitly selects UserIntent::Test for --profile test and calls compile only: https://github.com/rust-lang/cargo/blob/rust-1.94.0/src/bin/cargo/commands/rustc.rs#L58-L106
- Explicit --lib produces one library root; --tests is a union of all tested targets and cannot narrow --lib: https://github.com/rust-lang/cargo/blob/rust-1.94.0/src/cargo/ops/cargo_compile/unit_generator.rs#L383-L461
- Extra args are stored only for a single root: https://github.com/rust-lang/cargo/blob/rust-1.94.0/src/cargo/ops/cargo_compile/mod.rs#L530-L541
- Cargo adds --test automatically only for a normal harness; harness=false instead gets cfg(test): https://github.com/rust-lang/cargo/blob/rust-1.94.0/src/cargo/core/compiler/mod.rs#L1281-L1295
- Rust1.94.1 --test emits an executable with libtest: https://github.com/rust-lang/rust/blob/1.94.1/src/doc/rustc/src/tests/index.md#L19-L35
- Cargo artifact kind remains the manifest target; test profile records compile mode separately: https://github.com/rust-lang/cargo/blob/rust-1.94.0/src/cargo/core/manifest.rs#L207-L218 and https://github.com/rust-lang/cargo/blob/rust-1.94.0/src/cargo/core/compiler/mod.rs#L652-L668
- Integration harnesses add ordinary package binaries, unlike this closed lib/bin-unit choice: https://github.com/rust-lang/cargo/blob/rust-1.94.0/src/cargo/core/compiler/unit_dependencies.rs#L350-L398
- Custom -o does not rewrite Cargo's normal expected-output bookkeeping: https://github.com/rust-lang/cargo/blob/rust-1.94.0/src/cargo/core/compiler/mod.rs#L589-L638

Research checked Cargo rust-1.94.0/0.95.0 and Rust1.94.1 docs; it did not retrieve the exact Cargo submodule SHA installed with Rust1.94.1. Installed tool bytes are not attested. No target/CRT/compiler installation change, default global linker configuration, native source behavior or original protected role is modified by this bundle.

Preparation source was clean01a583c59c0f6d87c679d3a1c7fb6efad22a4612. This value is historical preparation metadata only, NEVER a runtime source allowlist. Actual parent changes were in primary and remain unqualified here. Runtime accepts only its actual supplied clean HEAD plus exact current selected-source maps and all repeated proofs. Parent owns integration and all execution decisions.

The seven Windows library ignored names were independently read from host_install/output_recovery_tests, retrieval_saved_graph/tests and retrieval_scopes/capacity_tests module declarations and attributes. Main's CLI module tree contains no ignore attribute in this preparation source. Actual consumer output must retain those exact inventories; additional parent regressions cannot silently add ignores.

No controller/helper/worker/test import or function, build, Cargo, native/tool image hash/read/execution, process query, CI/T3 poll or service change was performed by this preparation agent. Only source reads/writes/copies, AST parsing, source digests, LF/static analysis and read-only Git identity/status observations were used. Central coordination action act_mvouzz8p_066b087be21d belongs to codex@EVY-unit-lld under parent act_mvnu0dg8_60185495bd70.
