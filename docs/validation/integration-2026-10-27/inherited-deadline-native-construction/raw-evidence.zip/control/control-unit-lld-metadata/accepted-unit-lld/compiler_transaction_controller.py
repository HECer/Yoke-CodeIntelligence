"""Separate, closed unit-harness compiler producer and whole-suite consumer.

Only main loads the hash-pinned protocol. Importing this source launches nothing.
"""
import argparse
from contextlib import ExitStack
import ctypes as c
import hashlib
import os
from pathlib import Path
import secrets
import shutil
import stat
import sys
import time
from types import SimpleNamespace


PROTOCOL_SHA = 'ed744abf77c7e4a2852999df8c7460cfe38c88c3f8773921abdd6db16554a14f'


def protocol():
    path = Path(__file__).absolute().parent / "transaction_protocol.py"
    before = path.lstat()
    if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
            or getattr(before, "st_file_attributes", 0) & 0x400 or not 0 < before.st_size <= 1_000_000):
        raise RuntimeError("protocol-source")
    for ancestor in path.parents:
        info = ancestor.lstat()
        if not stat.S_ISDIR(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("protocol-route")
    data = path.read_bytes()
    after = path.lstat()
    if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_nlink) !=
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_nlink)
            or hashlib.sha256(data).hexdigest() != PROTOCOL_SHA):
        raise RuntimeError("protocol-pin")
    namespace = {"__name__": "reviewed_unit_lld_protocol", "__file__": str(path)}
    exec(compile(data, str(path), "exec"), namespace)
    return SimpleNamespace(**namespace)


def arguments(argv):
    parser = argparse.ArgumentParser(description="Closed unit-harness producer/whole-suite consumer", allow_abbrev=False)
    parser.add_argument("mode", choices=("build", "test"))
    parser.add_argument("--suite", required=True, choices=("lib", "cli"))
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--producer-run-id")
    return parser.parse_args(argv)


def acquire_mutex(p, api):
    # Same per-root mutex as the immutable controllers: no concurrent producers.
    name = "Local\\YokeValidation-" + hashlib.sha256(str(p.ROOT).encode()).hexdigest()[:24]
    c.set_last_error(0)
    mutex = api.CreateMutexW(None, True, name)
    error = c.get_last_error()
    p.need(mutex not in (None, -1, (1 << 64) - 1), "owner-mutex")
    if error == 183:
        api.CloseHandle(mutex)
        raise p.Refusal("owner-mutex-occupied")
    return mutex


def release_mutex(p, api, mutex):
    released = api.ReleaseMutex(mutex)
    closed = api.CloseHandle(mutex)
    p.need(released and closed, "owner-mutex-release")


def initial_result(p, args):
    return {"owner": p.OWNER, "schema": p.SCHEMA, "mode": args.mode, "runId": args.run_id,
            "sourceCommit": args.source_commit, "suite": args.suite, "completed": False, "inputsUnchanged": False,
            "protectedMetadataUnchanged": False, "nativeImageReadAttempted": False,
            "nativeImageRead": False, "selectedImage": None, "selectedArtifact": None,
            "testSummary": None, "errorCode": None, "releaseQualification": False,
            "vsixQualification": False, "qualification": "unit-harness-build/whole-suite-only",
            "freeAfter": None}


def execute(p, args):
    p.need(os.name == "nt", "platform")
    p.run_name(args.run_id); p.commit_name(args.source_commit)
    p.suite_name(args.suite)
    p.need((args.mode == "test") == (args.producer_run_id is not None), "producer-role")
    if args.producer_run_id is not None:
        p.run_name(args.producer_run_id)
        p.need(args.producer_run_id != args.run_id, "producer-role")
    floor = p.START_FREE if args.mode == "build" else p.IMAGE_FREE
    p.need(shutil.disk_usage("C:\\").free >= floor, "start-admission")
    g = p.load_runtime(); original = p.load_original()
    api, extended = g["load_windows_api"]()
    environment = g["environment_for"]("build")
    mutex = acquire_mutex(p, api)
    out = None
    result = initial_result(p, args)
    try:
        out = g["new_output"](args.run_id)
        # Do not assert success inside ExitStack: every close/recheck is a gate.
        with ExitStack() as stack:
            source_before = g["source_map"](api, extended, out, environment, args.source_commit, "before")
            old_before = p.original_map(g); own_before = g["controls_map"]()
            control_pins = p.pin_control_files(g, api, stack)
            p.pin_rechecks(control_pins)
            p.need(p.original_map(g) == old_before and g["controls_map"]() == own_before, "control-drift")
            protected, protected_before = p.protected_pins(g, api, original, stack)
            inputs = p.build_input_pins(g, api, original, stack, suite=args.suite)
            inputs_before = p.validate_build_inputs(inputs.recheck(), source_before, suite=args.suite)
            g["write_json"](out, "build-inputs-before.json", inputs_before)
            for stem, value in (("original-control", old_before), ("transaction-control", own_before),
                                ("protected", protected_before)):
                g["write_json"](out, stem + "-before.json", value)
            request = p.request_record(args.mode, args.run_id, args.source_commit, args.producer_run_id,
                                       source_before, old_before, own_before, suite=args.suite)
            g["write_json"](out, "request.json", request)
            admitted = None
            image_pin = None
            if args.mode == "build":
                image = p.image_path(args.run_id)
                p.need(not os.path.lexists(image), "occupied-image")
                p.need(shutil.disk_usage("C:\\").free >= p.START_FREE, "build-start-admission")
                # One epoch, before wrapper launch. The worker receives this
                # exact deadline, not a new 3600-second budget.
                started_ns = time.monotonic_ns()
                spec = p.make_spec(args.run_id, args.source_commit,
                                   "Local\\YokeUnitLLD-" + secrets.token_hex(32),
                                   started_ns, source_before, old_before, own_before, inputs_before, suite=args.suite)
                p.validate_spec(spec, now_ns=time.monotonic_ns())
                g["write_json"](out, "worker-spec.json", spec)
                spec_pin = stack.enter_context(g["ReadPin"](api, out / "worker-spec.json", 64_000))
                p.need(g["unique_json"](spec_pin.bytes()) == spec, "spec-drift")
                outer = g["run_owned"](api, extended, out, "outer", request["command"], environment,
                                       p.BUILD_SECONDS, absolute_deadline_ns=spec["deadlineNs"],
                                       job_name=spec["outerJobName"])
                # Both receipts must prove natural completion. Forced cleanup
                # cannot repair a failed producer or authorize any image read.
                p.validate_outer(outer, spec, request["command"])
                outer_pins = {name: stack.enter_context(g["ReadPin"](api, out / name, p.MAX_LOG))
                              for name in ("outer.job.json", "outer.stdout", "outer.stderr")}
                p.need(g["unique_json"](outer_pins["outer.job.json"].bytes()) == outer, "outer-receipt-drift")
                p.need(sum(len(outer_pins[name].bytes()) for name in ("outer.stdout", "outer.stderr"))
                       == outer["capturedLogBytes"], "capture-length")
                inner_pin = stack.enter_context(g["ReadPin"](api, out / "inner.job.json", 64_000))
                inner = g["unique_json"](inner_pin.bytes())
                p.validate_inner(inner, spec)
                p.need(inner["naturalEmptyNs"] <= outer["rootObservedMonotonicNs"], "lifecycle-order")
                spec_pin.recheck(); inner_pin.recheck()
                for phase in ("worker-before", "worker-after"):
                    input_pin = stack.enter_context(g["ReadPin"](api, out / ("build-inputs-" + phase + ".json"), 64_000))
                    recorded = p.validate_build_inputs(g["unique_json"](input_pin.bytes()), source_before, suite=args.suite)
                    p.need(recorded == inputs_before and p.digest(recorded) == spec["buildInputsDigest"], "build-inputs-drift")
                summary = p.cargo_summary(g, original, outer_pins["outer.stdout"].bytes(), suite=args.suite)
                result["selectedArtifact"] = summary["selectedArtifact"]
                g["write_json"](out, "cargo-summary.json", summary)
            else:
                # Admission accepts the new schema only. It pins every receipt,
                # verifies both Jobs, then alone may read the selected image.
                admitted = p.producer_admission(g, api, original, stack, args.producer_run_id,
                                                args.source_commit, source_before, old_before, own_before,
                                                suite=args.suite,
                                                on_image_attempt=lambda: result.update(nativeImageReadAttempted=True))
                result["nativeImageRead"] = True
                image_pin = admitted["imagePin"]
                result["selectedArtifact"] = admitted["artifact"]
                outer = g["run_owned"](api, extended, out, "outer", request["command"], environment, p.TEST_SECONDS)
                p.validate_outer(outer, None, request["command"], p.TEST_SECONDS)
                # Hold the complete checked capture until final publication checks.
                test_pins = {name: stack.enter_context(g["ReadPin"](api, out / name, p.MAX_LOG))
                             for name in ("outer.job.json", "outer.stdout", "outer.stderr")}
                p.need(g["unique_json"](test_pins["outer.job.json"].bytes()) == outer, "outer-receipt-drift")
                p.need(sum(len(test_pins[name].bytes()) for name in ("outer.stdout", "outer.stderr"))
                       == outer["capturedLogBytes"], "capture-length")
                result["testSummary"] = p.test_summary(test_pins["outer.stdout"].bytes(), suite=args.suite)
                g["write_json"](out, "test-summary.json", result["testSummary"])
            source_after = g["source_map"](api, extended, out, environment, args.source_commit, "after")
            old_after = p.original_map(g); own_after = g["controls_map"]()
            p.need(source_after == source_before and old_after == old_before and own_after == own_before, "input-drift")
            p.pin_rechecks(control_pins)
            protected_after = p.protected_recheck(original, protected, protected_before)
            inputs_after = p.validate_build_inputs(inputs.recheck(), source_after, suite=args.suite)
            p.need(inputs_after == inputs_before, "build-inputs-drift")
            g["write_json"](out, "build-inputs-after.json", inputs_after)
            for stem, value in (("original-control", old_after), ("transaction-control", own_after),
                                ("protected", protected_after)):
                g["write_json"](out, stem + "-after.json", value)
            if args.mode == "build":
                # First image byte read is after BOTH natural Job-empty proofs
                # and all source/control/protected-role observations above.
                p.need(shutil.disk_usage("C:\\").free >= p.IMAGE_FREE, "image-admission")
                result["nativeImageReadAttempted"] = True
                image_pin = stack.enter_context(g["ReadPin"](api, image, p.MAX_IMAGE, image=True))
                result["nativeImageRead"] = True
            result["selectedImage"] = image_pin.recheck()
            selected_run = args.run_id if args.mode == "build" else args.producer_run_id
            p.image_record(result["selectedImage"], selected_run)
            g["write_json"](out, "selected-image.json", result["selectedImage"])
            # These final checks occur while controls, receipts, protected
            # entries and the selected image remain held against mutation.
            source_final = g["source_map"](api, extended, out, environment, args.source_commit, "final")
            old_final = p.original_map(g); own_final = g["controls_map"]()
            p.need(source_final == source_before and old_final == old_before and own_final == own_before, "input-drift")
            p.pin_rechecks(control_pins)
            if admitted is not None: p.recheck_admission(original, admitted)
            protected_final = p.protected_recheck(original, protected, protected_before)
            inputs_final = p.validate_build_inputs(inputs.recheck(), source_final, suite=args.suite)
            p.need(inputs_final == inputs_before, "build-inputs-drift")
            g["write_json"](out, "build-inputs-final.json", inputs_final)
            for stem, value in (("original-control", old_final), ("transaction-control", own_final),
                                ("protected", protected_final)):
                g["write_json"](out, stem + "-final.json", value)
            g["write_json"](out, "selected-image-after.json", image_pin.recheck())
            result.update(inputsUnchanged=True, protectedMetadataUnchanged=True)
        # Mutex closure is also required before a terminal success receipt.
        ending_mutex, mutex = mutex, None
        release_mutex(p, api, ending_mutex)
        p.need(shutil.disk_usage("C:\\").free >= p.RUN_FREE, "final-reserve")
        result["completed"] = True
    except BaseException as error:
        result["completed"] = False
        result.update(inputsUnchanged=False, protectedMetadataUnchanged=False)
        result["errorCode"] = error.code if isinstance(error, p.Refusal) else "controller-internal"
    finally:
        if mutex is not None:
            ending_mutex, mutex = mutex, None
            try: release_mutex(p, api, ending_mutex)
            except BaseException:
                result.update(completed=False, errorCode="owner-mutex-release")
        result["freeAfter"] = shutil.disk_usage("C:\\").free
        if out is not None:
            g["write_json"](out, "result.json", result)
    return result


def main(argv=None):
    try:
        args = arguments(sys.argv[1:] if argv is None else argv)
        p = protocol()
        result = execute(p, args)
        print("unit-lld-complete" if result["completed"] else "unit-lld-refused", flush=True)
        return 0 if result["completed"] else 1
    except BaseException:
        print("unit-lld-refused", flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
