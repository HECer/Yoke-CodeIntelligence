"""Authored adversarial checks. No test has been run during preparation.

Real Windows cases execute only inert Python children under private Jobs. They
never build, read or execute a Yoke/native image. Captures stay in private runs.
"""
from contextlib import ExitStack
import copy
import ctypes as c
import hashlib
import json
import os
from pathlib import Path
import secrets
import stat
import sys
import tempfile
import time
from types import ModuleType, SimpleNamespace
import unittest
from unittest import mock


HERE = Path(__file__).absolute().parent


def module(name, filename):
    value = ModuleType(name)
    value.__file__ = str(HERE / filename)
    exec(compile((HERE / filename).read_bytes(), value.__file__, "exec"), value.__dict__)
    return value


def protocol():
    return module("inert_test_protocol", "transaction_protocol.py")


def successful_inner(p, spec):
    row = {key: None for key in p.INNER_KEYS}
    row.update(owner=p.OWNER, schema=p.SCHEMA, role="compiler-inner", runId=spec["runId"],
               sourceCommit=spec["sourceCommit"], outerJobName=spec["outerJobName"], suite=spec["suite"],
               command=spec["cargoCommand"], startedNs=spec["startedNs"], deadlineNs=spec["deadlineNs"],
               quiescenceSeconds=60, captureOwner="outer", logCapBytes=p.MAX_LOG, reserveBytes=p.RUN_FREE,
               innerKillOnClose=False, breakawayAllowed=False, innerInitiallyEmpty=True, pid=100,
               outerMembershipBeforeCargo=True, startedSuspended=True, cargoInOuterBeforeInner=True,
               assignedBeforeResume=True, membershipConfirmedBeforeResume=True, resumePreviousSuspendCount=1,
               exitCode=0, rootExited=True, cargoExitObservedNs=spec["startedNs"] + 10 * p.NANO,
               activeAtCargoExit=1, naturalEmptyNs=spec["startedNs"] + 12 * p.NANO,
               activeBeforeClose=0, allMembersExitedNaturally=True, minimumFreeObserved=p.START_FREE,
               abortAuthority="outer", innerForcedTermination=False, cleanupWaitSeconds=0,
               handleCloseErrors=[], imageAbsentBeforeCargo=True, completed=True, failureCode=None)
    row["quiescenceDeadlineNs"] = min(spec["deadlineNs"], row["cargoExitObservedNs"] + 60 * p.NANO)
    return row


def successful_outer(p, spec):
    row = {key: None for key in p.OUTER_KEYS}
    row.update(command=p.worker_command(spec["runId"]), deadlineSeconds=3600, logCapBytes=p.MAX_LOG,
               stdinClosed=True, startedSuspended=True, assignedBeforeResume=True, completed=True,
               treeExitedBeforeCleanup=True, minimumFreeObserved=p.START_FREE, cleanupErrors=[],
               streamEOF=[True, True], readerErrors=[False, False], startedMonotonicNs=spec["startedNs"] + 1,
               absoluteDeadlineNs=spec["deadlineNs"], jobName=spec["outerJobName"], namedJobCreatedNew=True,
               pid=101, resumePreviousSuspendCount=1, exitCode=0,
               rootObservedMonotonicNs=spec["startedNs"] + 13 * p.NANO, membersAtRootObservation=[],
               rootExitedAtObservation=True, activeAtRootObservation=0, originalDrainSeconds=1,
               activeBeforeCleanup=0, membersAfterOriginalDrain=[],
               treeObservedMonotonicNs=spec["startedNs"] + 13 * p.NANO + 1,
               cleanupSeconds=2, activeAfterCleanup=0, rootExitedAfterCleanup=True,
               elapsedSeconds=13.1, capturedLogBytes=0, outputExceeded=False, cleanupUnproven=False)
    return row


def artifact(p, suite="lib"):
    kind, crate_type, source = p.SUITES[suite]
    return {"reason": "compiler-artifact", "package_id": "path+" + (p.ROOT / "native").as_uri()
            + "#yoke-code-intelligence@0.5.0", "manifest_path": str(p.ROOT / "native/Cargo.toml"),
            "target": {"kind": [kind], "crate_types": [crate_type], "name": "yoke",
                       "src_path": str(p.ROOT / source), "edition": "2024",
                       "doc": True, "doctest": False, "test": True},
            "profile": {"opt_level": "0", "debuginfo": 0, "debug_assertions": True,
                        "overflow_checks": True, "test": True}, "features": [], "filenames": [],
            "executable": str(p.ROOT / "target/debug/deps/yoke-0123456789abcdef.exe"), "fresh": False}


def golden_build_inputs(p, sources, suite="lib"):
    def manifest(relative, inode):
        return {"path": str(p.ROOT / relative), "sha256": sources[relative]["sha256"],
                "bytes": sources[relative]["bytes"], "fileIdentity": [1, inode], "mtimeNs": 10,
                "links": 1, "noReparseAncestors": True, "writersAndDeletionDeniedThroughRecheck": True}
    tool = {"path": str(p.LINKER), "metadata": {"exists": True, "device": 1, "inode": 9,
            "bytes": p.LINKER_BYTES, "mtimeNs": 10, "links": 1, "mode": stat.S_IFREG | 0o600, "attributes": 0},
            "ancestors": [{"path": str(path), "exists": True, "device": 1, "inode": 11 + index,
                           "mode": stat.S_IFDIR | 0o700, "attributes": 0}
                          for index, path in enumerate(reversed(p.LINKER.parents))],
            "handleMode": stat.S_IFREG | 0o600, "handleAttributes": None,
            "imageBytesRead": False, "imageExecuted": False,
            "desiredAccess": "FILE_EXECUTE|FILE_READ_ATTRIBUTES (no FILE_READ_DATA)",
            "fileWritesDenied": True, "heldPathDeletionDenied": True, "allAliasNamespaceDenialClaimed": False}
    return {"owner": p.OWNER, "schema": p.SCHEMA, "role": "fixed-unit-harness-lld-inputs", "suite": suite,
            "linkerPath": str(p.LINKER), "linkerFlavor": p.LINKER_FLAVOR, "linkerArguments": p.linker_arguments(),
            "outputArguments": p.output_arguments(),
            "toolMetadata": tool, "toolContentAttested": False,
            "rootManifest": manifest("Cargo.toml", 20), "nativeManifest": manifest("native/Cargo.toml", 21),
            "releaseProfile": {"lto": "thin", "codegen-units": 1, "strip": "symbols"},
            "testProfile": {"dev": {"debug": 0, "incremental": False, "package": {"sha2": {"opt-level": 3}}},
                            "test": {"debug": 0, "incremental": False},
                            "selectedArtifactProfile": {"opt_level": "0", "debuginfo": 0,
                                                        "debug_assertions": True, "overflow_checks": True, "test": True}},
            "unitHarness": {"suite": suite, "name": "yoke", "kind": [p.SUITES[suite][0]],
                            "crateTypes": [p.SUITES[suite][1]], "source": p.SUITES[suite][2],
                            "harnessSetting": "absent", "testSetting": "absent", "harnessEnabled": True,
                            "originalIgnoredInventory": list(p.LIB_IGNORED) if suite == "lib" else []},
            "nativeProfileOverridePresent": False, "cachePolicy": p.CACHE_POLICY}


def golden(p, suite="lib"):
    run = "inert-receipt-producer"
    commit = "f" * 40
    sources = {"native/src/main.rs": {"sha256": "1" * 64, "bytes": 123},
               "native/src/lib.rs": {"sha256": "6" * 64, "bytes": 300},
               "Cargo.toml": {"sha256": "4" * 64, "bytes": 90},
               "native/Cargo.toml": {"sha256": "5" * 64, "bytes": 150}}
    build_inputs = golden_build_inputs(p, sources, suite)
    originals = {"immutable": {"sha256": "2" * 64, "bytes": 123}}
    controls = {"transaction": {"sha256": "3" * 64, "bytes": 123}}
    spec = p.make_spec(run, commit, "Local\\YokeUnitLLD-" + "a" * 64,
                       100 * p.NANO, sources, originals, controls, build_inputs, suite=suite)
    selected = {"path": str(p.image_path(run)), "sha256": "b" * 64, "fileIdentity": [1, 2],
                "bytes": 123, "mtimeNs": 10, "links": 1, "noReparseAncestors": True,
                "writersAndDeletionDeniedThroughRecheck": True}
    selected_artifact = artifact(p, suite)
    summary = {"buildFinishedSuccess": True, "warningDiagnostics": 0, "errorDiagnostics": 0,
               "compilerArtifactObservations": 1, "byproductImageBytesRead": False,
               "suite": suite, "selectedArtifact": selected_artifact}
    stdout = (json.dumps(selected_artifact) + "\n" + json.dumps({"reason": "build-finished", "success": True}) + "\n").encode()
    outer = successful_outer(p, spec); outer["capturedLogBytes"] = len(stdout)
    result = {"owner": p.OWNER, "schema": p.SCHEMA, "mode": "build", "runId": run,
              "sourceCommit": commit, "suite": suite, "completed": True, "inputsUnchanged": True,
              "protectedMetadataUnchanged": True, "nativeImageReadAttempted": True,
              "nativeImageRead": True, "selectedImage": selected, "selectedArtifact": selected_artifact,
              "testSummary": None, "errorCode": None, "releaseQualification": False,
              "vsixQualification": False, "qualification": "unit-harness-build/whole-suite-only", "freeAfter": p.START_FREE}
    values = {"request.json": p.request_record("build", run, commit, None, sources, originals, controls, suite=suite),
              "result.json": result, "worker-spec.json": spec, "inner.job.json": successful_inner(p, spec),
              "outer.job.json": outer, "outer.stdout": stdout, "outer.stderr": b"", "cargo-summary.json": summary,
              "selected-image.json": selected, "selected-image-after.json": copy.deepcopy(selected)}
    for stem, value in (("source", sources), ("original-control", originals), ("transaction-control", controls), ("protected", {})):
        for phase in ("before", "after", "final"): values[stem + "-" + phase + ".json"] = copy.deepcopy(value)
    for phase in ("before", "after", "final", "worker-before", "worker-after"):
        values["build-inputs-" + phase + ".json"] = copy.deepcopy(build_inputs)
    return run, commit, sources, originals, controls, spec, values


class ClosedReceiptTests(unittest.TestCase):
    def setUp(self):
        self.p = protocol()
        self.run, self.commit, self.sources, self.originals, self.controls, self.spec, self.values = golden(self.p)

    def refused_inner(self, changes):
        row = copy.deepcopy(self.values["inner.job.json"]); row.update(changes)
        with self.assertRaises(self.p.Refusal): self.p.validate_inner(row, self.spec)

    def test_valid_closed_records(self):
        self.p.validate_spec(self.spec, now_ns=self.spec["startedNs"])
        self.p.validate_inner(self.values["inner.job.json"], self.spec)
        self.p.validate_outer(self.values["outer.job.json"], self.spec, self.p.worker_command(self.run))
        self.p.validate_result(self.values["result.json"], self.run, self.commit, suite="lib")

    def test_cargo_failure_cannot_be_hidden_by_wrapper_zero(self):
        self.refused_inner({"exitCode": 1})
        self.refused_inner({"rootExited": False})

    def test_every_owned_launch_and_natural_completion_proof_is_required(self):
        for key in ("outerMembershipBeforeCargo", "innerInitiallyEmpty", "startedSuspended", "cargoInOuterBeforeInner",
                    "assignedBeforeResume", "membershipConfirmedBeforeResume", "rootExited", "allMembersExitedNaturally"):
            with self.subTest(key=key): self.refused_inner({key: False})
        for changes in ({"innerForcedTermination": True}, {"innerKillOnClose": True}, {"breakawayAllowed": True},
                        {"activeBeforeClose": 1}, {"cleanupWaitSeconds": 2}, {"abortAuthority": "inner"}):
            with self.subTest(changes=changes): self.refused_inner(changes)

    def test_bool_counters_and_resumed_twice_refuse(self):
        for key in ("pid", "exitCode", "activeBeforeClose", "activeAtCargoExit", "cleanupWaitSeconds", "startedNs"):
            with self.subTest(key=key): self.refused_inner({key: False})
        self.refused_inner({"resumePreviousSuspendCount": 0})
        self.refused_inner({"resumePreviousSuspendCount": 2})

    def test_absolute_deadline_cannot_reset_or_expand(self):
        self.refused_inner({"deadlineNs": self.spec["deadlineNs"] + 1})
        self.refused_inner({"quiescenceDeadlineNs": self.spec["deadlineNs"]})
        self.refused_inner({"naturalEmptyNs": self.spec["deadlineNs"]})
        for key in ("startedNs", "deadlineNs"):
            changed = copy.deepcopy(self.spec); changed[key] += 1
            with self.subTest(key=key), self.assertRaises(self.p.Refusal): self.p.validate_spec(changed)
        with self.assertRaises(self.p.Refusal): self.p.validate_spec(self.spec, now_ns=self.spec["deadlineNs"])

    def test_quiescence_is_clamped_to_original_deadline(self):
        inner = successful_inner(self.p, self.spec)
        inner["cargoExitObservedNs"] = self.spec["deadlineNs"] - 2 * self.p.NANO
        inner["naturalEmptyNs"] = self.spec["deadlineNs"] - self.p.NANO
        inner["quiescenceDeadlineNs"] = self.spec["deadlineNs"]
        self.p.validate_inner(inner, self.spec)

    def test_outer_force_stream_disk_query_and_deadline_failures_refuse(self):
        changes = ({"completed": False}, {"activeBeforeCleanup": 1}, {"treeExitedBeforeCleanup": False},
                   {"cleanupErrors": ["job-accounting"]}, {"cleanupUnproven": True},
                   {"streamEOF": [True, False]}, {"readerErrors": [True, False]}, {"outputExceeded": True},
                   {"minimumFreeObserved": self.p.RUN_FREE - 1}, {"capturedLogBytes": self.p.MAX_LOG + 1},
                   {"treeObservedMonotonicNs": self.spec["deadlineNs"]}, {"namedJobCreatedNew": False},
                   {"originalDrainSeconds": 2}, {"cleanupSeconds": 3}, {"activeAfterCleanup": False},
                   {"streamEOF": [1, True]}, {"readerErrors": [False, 0]}, {"exitCode": False})
        for change in changes:
            row = copy.deepcopy(self.values["outer.job.json"]); row.update(change)
            with self.subTest(change=change), self.assertRaises(self.p.Refusal):
                self.p.validate_outer(row, self.spec, self.p.worker_command(self.run))

    def test_request_and_spec_reject_test_hooks_arbitrary_argv_and_unknown_fields(self):
        request = self.values["request.json"]
        for changes in ({"command": [sys.executable, "-c", "pass"]}, {"deadlineSeconds": True},
                        {"preparationInventoryIsSeparate": 1}, {"testArgv": ["anything"]}):
            changed = copy.deepcopy(request); changed.update(changes)
            with self.subTest(changes=changes), self.assertRaises(self.p.Refusal): self.p.validate_request(changed, request)
        changed = copy.deepcopy(self.spec); changed["cargoCommand"][-1] = str(self.p.ROOT / "target/release/yoke.exe")
        with self.assertRaises(self.p.Refusal): self.p.validate_spec(changed)

    def test_native_image_metadata_has_no_default_alias_or_link_escape(self):
        record = self.values["selected-image.json"]
        changes = ({"path": str(self.p.ROOT / "target/release/yoke.exe")}, {"links": 2}, {"links": True},
                   {"noReparseAncestors": False}, {"writersAndDeletionDeniedThroughRecheck": False},
                   {"fileIdentity": [1, True]}, {"bytes": True})
        for change in changes:
            changed = copy.deepcopy(record); changed.update(change)
            with self.subTest(change=change), self.assertRaises(self.p.Refusal): self.p.image_record(changed, self.run)

    def test_source_hardlink_and_symlink_refusal_uses_inert_text_only(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "inert.py"; source.write_text("pass\n", encoding="ascii")
            expected = hashlib.sha256(source.read_bytes()).hexdigest()
            link = Path(directory) / "alias.py"
            os.link(source, link)
            with self.assertRaises(self.p.Refusal): self.p.source_bytes(source, expected)
            link.unlink()
            try: link.symlink_to(source)
            except (OSError, NotImplementedError): return
            with self.assertRaises(self.p.Refusal): self.p.source_bytes(link, expected)

    def test_original_controls_are_immutable_and_old_result_refuses(self):
        self.assertEqual(self.p.ORIGINAL_PINS["base_controller.py"], "a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7")
        for change in ({"owner": "integration-20261025-private-release-cli-v1"}, {"schema": 1},
                       {"runId": "release-cli-isolated-f8-r2"}, {"nativeImageRead": False}):
            row = copy.deepcopy(self.values["result.json"]); row.update(change)
            with self.subTest(change=change), self.assertRaises(self.p.Refusal): self.p.validate_result(row, self.run, self.commit, suite="lib")


class ProducerAdmissionTests(ClosedReceiptTests):
    def admit(self, values=None, image_error=False, protected_error=False, inputs_error=False, input_override=None, suite="lib"):
        p = self.p; values = self.values if values is None else values
        self.image_reads = []
        class Pin:
            def __init__(pin, api, path, maximum, image=False):
                pin.path = path; pin.image = image
                if image:
                    self.image_reads.append(str(path))
                    if image_error: raise p.Refusal("image-drift")
                else:
                    if path.name not in values: raise p.Refusal("missing-receipt")
            def __enter__(pin): return pin
            def __exit__(pin, *args): pin.recheck()
            def bytes(pin):
                value = values[pin.path.name]
                return value if type(value) is bytes else json.dumps(value).encode()
            def record(pin): return copy.deepcopy(values["selected-image.json"])
            def recheck(pin): return pin.record() if pin.image else {"pinned": str(pin.path)}
        g = {"ReadPin": Pin, "ordinary": lambda *a, **k: None, "unique_json": json.loads}
        original = {"cargo_summary": lambda g, data: values["cargo-summary.json"]}
        def check(*a):
            if protected_error: raise p.Refusal("protected-drift")
            return {}
        def inputs(*a, **kwargs):
            if inputs_error: raise p.Refusal("linker-metadata")
            current = golden_build_inputs(p, self.sources, suite) if input_override is None else input_override
            return SimpleNamespace(recheck=lambda: copy.deepcopy(current))
        # Stat is metadata only, and every fake image observation is in memory.
        with mock.patch.object(Path, "lstat", return_value=SimpleNamespace(st_size=1)), \
             mock.patch.object(p, "protected_pins", return_value=({}, {})), \
             mock.patch.object(p, "protected_recheck", side_effect=check), \
             mock.patch.object(p, "build_input_pins", side_effect=inputs), \
             mock.patch.object(p.shutil, "disk_usage", return_value=SimpleNamespace(free=p.START_FREE)), ExitStack() as stack:
            return p.producer_admission(g, None, original, stack, self.run, self.commit,
                                        self.sources, self.originals, self.controls, suite=suite)

    def test_full_matching_new_producer_reaches_only_selected_image(self):
        admitted = self.admit()
        self.assertEqual(admitted["image"], self.p.image_path(self.run))
        self.assertEqual(self.image_reads, [str(self.p.image_path(self.run))])

    def test_cli_unit_producer_admission_cannot_be_consumed_as_library_or_release(self):
        _, _, _, _, _, _, values = golden(self.p, "cli")
        admitted = self.admit(values, suite="cli")
        self.assertEqual(admitted["artifact"]["target"]["kind"], ["bin"])
        self.assertIs(admitted["artifact"]["profile"]["test"], True)
        with self.assertRaises(self.p.Refusal): self.admit(values, suite="lib")
        self.assertEqual(self.image_reads, [])

    def test_suite_or_harness_proof_drift_at_every_phase_refuses_before_image(self):
        for phase in ("before", "after", "final", "worker-before", "worker-after"):
            for key, value in (("suite", "cli"), ("harnessEnabled", False)):
                values = copy.deepcopy(self.values)
                target = values["build-inputs-" + phase + ".json"]
                if key == "suite": target[key] = value
                else: target["unitHarness"][key] = value
                with self.subTest(phase=phase, key=key), self.assertRaises(self.p.Refusal): self.admit(values)
                self.assertEqual(self.image_reads, [])

    def test_all_forged_or_drifted_receipts_refuse_before_image(self):
        mutations = (("inner.job.json", "exitCode", 1), ("outer.job.json", "activeBeforeCleanup", 1),
                     ("result.json", "owner", "old-r2"), ("request.json", "producerRunId", "foreign"),
                     ("source-final.json", "foreign", {}), ("transaction-control-after.json", "foreign", {}),
                     ("selected-image.json", "path", str(self.p.ROOT / "target/release/yoke.exe")),
                     ("selected-image.json", "links", 2), ("selected-image.json", "noReparseAncestors", False),
                     ("worker-spec.json", "deadlineNs", self.spec["deadlineNs"] + self.p.NANO))
        for filename, key, value in mutations:
            values = copy.deepcopy(self.values); values[filename][key] = value
            with self.subTest(filename=filename, key=key), self.assertRaises(self.p.Refusal): self.admit(values)
            self.assertEqual(self.image_reads, [])

    def test_late_protected_failure_prevents_first_image_read(self):
        with self.assertRaises(self.p.Refusal): self.admit(protected_error=True)
        self.assertEqual(self.image_reads, [])

    def test_pin_alias_reparse_failure_is_not_success(self):
        with self.assertRaises(self.p.Refusal): self.admit(image_error=True)

    def test_cargo_json_bool_and_unknown_profile_fields_refuse(self):
        for where, key, value in (("artifact", "fresh", 0), ("artifact", "fresh", 0.0),
                                  ("profile", "test", 0), ("profile", "test", 1),
                                  ("profile", "debuginfo", False), ("profile", "debuginfo", None),
                                  ("profile", "debuginfo", 1), ("profile", "debuginfo", 2),
                                  ("profile", "debug_assertions", False), ("profile", "debug_assertions", 1),
                                  ("profile", "overflow_checks", False), ("profile", "overflow_checks", 1),
                                  ("target", "test", 1),
                                  ("target", "arbitrary", True)):
            values = copy.deepcopy(self.values); selected = values["cargo-summary.json"]["selectedArtifact"]
            (selected if where == "artifact" else selected[where])[key] = value
            with self.subTest(where=where, key=key), self.assertRaises(self.p.Refusal): self.admit(values)
            self.assertEqual(self.image_reads, [])


    def test_fixed_linker_path_flavor_order_and_no_extra_final_arguments(self):
        p = self.p
        expected = [str(p.CARGO), "rustc", "--package", "yoke-code-intelligence", "--lib",
                    "--profile", "test", "--locked", "--offline", "-j2", "--message-format=json", "--",
                    "-o", str(p.image_path(self.run)), "-C", "extra-filename=", "-C", "linker=" + str(p.LINKER), "-C", "linker-flavor=lld-link"]
        self.assertEqual(self.spec["cargoCommand"], expected)
        mutations = []
        changed = expected.copy(); changed[-3] = "linker=C:\\foreign\\lld.exe"; mutations.append(changed)
        changed = expected.copy(); changed[-1] = "linker-flavor=msvc"; mutations.append(changed)
        changed = expected.copy(); changed[-4:] = changed[-2:] + changed[-4:-2]; mutations.append(changed)
        mutations.extend((expected + ["-C", "target-feature=+crt-static"], expected[:-4],
                          expected[:12] + expected[-4:] + expected[12:-4]))
        for command in mutations:
            spec = copy.deepcopy(self.spec); spec["cargoCommand"] = command
            with self.subTest(command=command), self.assertRaises(p.Refusal): p.validate_spec(spec)

    def test_lld_input_receipt_rejects_linker_flavor_path_argument_and_policy_drift(self):
        p = self.p
        mutations = ({"linkerPath": str(p.ROOT / "rust-lld.exe")}, {"linkerFlavor": "msvc"},
                     {"linkerArguments": p.linker_arguments()[2:] + p.linker_arguments()[:2]},
                     {"linkerArguments": p.linker_arguments() + ["-C", "opt-level=1"]},
                     {"toolContentAttested": True}, {"nativeProfileOverridePresent": True},
                     {"cachePolicy": "target-dir-override"}, {"unexpected": True})
        for change in mutations:
            row = copy.deepcopy(self.values["build-inputs-before.json"]); row.update(change)
            with self.subTest(change=change), self.assertRaises(p.Refusal): p.validate_build_inputs(row, self.sources)

    def test_manifest_release_profile_requires_thin_single_codegen_and_symbols_exactly(self):
        p = self.p
        valid = b'[profile.release]\nlto="thin"\ncodegen-units=1\nstrip="symbols"\n'
        native = b'[package]\nname="inert"\n'
        self.assertEqual(p.release_profile(valid, native), {"lto": "thin", "codegen-units": 1, "strip": "symbols"})
        for source in (valid.replace(b'"thin"', b'"fat"'), valid.replace(b'"thin"', b'false'),
                       valid.replace(b'units=1', b'units=2'), valid.replace(b'units=1', b'units=true'),
                       valid.replace(b'"symbols"', b'"debuginfo"'), valid.replace(b'"symbols"', b'false'),
                       valid + b'opt-level=2\n', valid + b'inherits="dev"\n', valid + b'[profile.release.package.a]\nopt-level=1\n',
                       valid.replace(b'strip="symbols"\n', b'')):
            with self.subTest(source=source), self.assertRaises(p.Refusal): p.release_profile(source, native)
        with self.assertRaises(p.Refusal): p.release_profile(valid, native + valid)
        with self.assertRaises(p.Refusal): p.release_profile(valid + b'\xff', native)

    def test_missing_or_drifted_tool_proof_refuses_before_private_image(self):
        for phase in ("before", "after", "final", "worker-before", "worker-after"):
            filename = "build-inputs-" + phase + ".json"
            values = copy.deepcopy(self.values); del values[filename]
            with self.subTest(phase=phase, missing=True), self.assertRaises(self.p.Refusal): self.admit(values)
            self.assertEqual(self.image_reads, [])
            values = copy.deepcopy(self.values); values[filename]["toolMetadata"]["metadata"]["mtimeNs"] += 1
            with self.subTest(phase=phase, drift=True), self.assertRaises(self.p.Refusal): self.admit(values)
            self.assertEqual(self.image_reads, [])
        with self.assertRaises(self.p.Refusal): self.admit(inputs_error=True)
        self.assertEqual(self.image_reads, [])

    def test_metadata_only_linker_refuses_absent_reparse_alias_missing_identity_and_unknown_fields(self):
        p = self.p
        changes = ({"exists": False}, {"bytes": p.LINKER_BYTES + 1}, {"bytes": True}, {"inode": 0},
                   {"links": 2}, {"links": True}, {"mode": stat.S_IFDIR | 0o700}, {"attributes": 0x400})
        for change in changes:
            row = copy.deepcopy(self.values["build-inputs-before.json"]); row["toolMetadata"]["metadata"].update(change)
            with self.subTest(change=change), self.assertRaises(p.Refusal): p.validate_build_inputs(row, self.sources)
        for change in ({"imageBytesRead": True}, {"imageExecuted": True}, {"fileWritesDenied": False},
                       {"heldPathDeletionDenied": False}, {"desiredAccess": "GENERIC_READ"}, {"sha256": "f" * 64}):
            row = copy.deepcopy(self.values["build-inputs-before.json"]); row["toolMetadata"].update(change)
            with self.subTest(change=change), self.assertRaises(p.Refusal): p.validate_build_inputs(row, self.sources)
        row = copy.deepcopy(self.values["build-inputs-before.json"])
        row["toolMetadata"]["ancestors"][0]["attributes"] = 0x400
        with self.assertRaises(p.Refusal): p.validate_build_inputs(row, self.sources)

    def test_current_tool_metadata_and_source_map_drift_cannot_adopt_producer(self):
        current = copy.deepcopy(self.values["build-inputs-before.json"])
        current["toolMetadata"]["metadata"]["inode"] += 1
        with self.assertRaises(self.p.Refusal): self.admit(input_override=current)
        self.assertEqual(self.image_reads, [])
        for role in ("rootManifest", "nativeManifest"):
            values = copy.deepcopy(self.values)
            for phase in ("before", "after", "final", "worker-before", "worker-after"):
                values["build-inputs-" + phase + ".json"][role]["sha256"] = "9" * 64
            with self.subTest(role=role), self.assertRaises(self.p.Refusal): self.admit(values)
            self.assertEqual(self.image_reads, [])

    def test_build_inputs_digest_cannot_be_omitted_or_rebound(self):
        for change in ({"buildInputsDigest": "0" * 64}, {"buildInputsDigest": True}):
            values = copy.deepcopy(self.values); values["worker-spec.json"].update(change)
            with self.subTest(change=change), self.assertRaises(self.p.Refusal): self.admit(values)
            self.assertEqual(self.image_reads, [])
        values = copy.deepcopy(self.values); del values["worker-spec.json"]["buildInputsDigest"]
        with self.assertRaises(self.p.Refusal): self.admit(values)
        self.assertEqual(self.image_reads, [])

    def test_new_linker_proof_never_excuses_a_surviving_job_member(self):
        for filename, change in (("inner.job.json", {"activeBeforeClose": 1}),
                                 ("inner.job.json", {"allMembersExitedNaturally": False}),
                                 ("outer.job.json", {"activeBeforeCleanup": 1}),
                                 ("inner.job.json", {"ignoredMember": "vctip.exe"})):
            values = copy.deepcopy(self.values); values[filename].update(change)
            with self.subTest(filename=filename, change=change), self.assertRaises(self.p.Refusal): self.admit(values)
            self.assertEqual(self.image_reads, [])

    def test_old_v2_positive_consumer_refuses_new_closed_protocol_before_any_image(self):
        old = module("old_v2_positive_consumer", "../control-compiler-transaction/transaction_protocol.py")
        self.assertNotEqual(old.OWNER, self.p.OWNER); self.assertNotEqual(old.SCHEMA, self.p.SCHEMA)
        attempted = []
        values = self.values
        class Pin:
            def __init__(pin, api, path, maximum, image=False):
                pin.path = path
                if image: attempted.append(str(path)); raise AssertionError("old consumer reached image")
            def __enter__(pin): return pin
            def __exit__(pin, *args): pass
            def bytes(pin):
                value = values[pin.path.name]
                return value if type(value) is bytes else json.dumps(value).encode()
        g = {"ReadPin": Pin, "ordinary": lambda *a, **k: None, "unique_json": json.loads}
        with mock.patch.object(Path, "lstat", return_value=SimpleNamespace(st_size=1)), ExitStack() as stack:
            with self.assertRaises(old.Refusal):
                old.producer_admission(g, None, {}, stack, self.run, self.commit, self.sources, self.originals, self.controls)
        self.assertEqual(attempted, [])
        with self.assertRaises(old.Refusal): old.validate_result(values["result.json"], self.run, self.commit)

    def test_linker_metadata_preserves_distinct_regular_path_and_handle_modes(self):
        p = self.p
        path = SimpleNamespace(st_dev=1, st_ino=9, st_size=p.LINKER_BYTES, st_mtime_ns=10,
                               st_nlink=1, st_mode=stat.S_IFREG | 0o777, st_file_attributes=32)
        handle = SimpleNamespace(**path.__dict__); handle.st_mode = stat.S_IFREG | 0o666
        del handle.st_file_attributes
        route = self.values["build-inputs-before.json"]["toolMetadata"]["ancestors"]
        row = p.tool_metadata_record(path, handle, route)
        self.assertEqual(row["metadata"]["mode"], path.st_mode)
        self.assertEqual(row["handleMode"], handle.st_mode)
        self.assertNotEqual(row["metadata"]["mode"], row["handleMode"])
        self.assertIsNone(row["handleAttributes"])
        for attribute in ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_nlink"):
            changed = SimpleNamespace(**handle.__dict__)
            setattr(changed, attribute, getattr(changed, attribute) + 1)
            with self.subTest(attribute=attribute), self.assertRaises(p.Refusal): p.tool_metadata_record(path, changed, route)
        changed = SimpleNamespace(**handle.__dict__); changed.st_mode = stat.S_IFDIR | 0o777
        with self.assertRaises(p.Refusal): p.tool_metadata_record(path, changed, route)

    def test_late_linker_handle_mode_drift_refuses_without_smoothing(self):
        p = self.p
        path = SimpleNamespace(st_dev=1, st_ino=9, st_size=p.LINKER_BYTES, st_mtime_ns=10,
                               st_nlink=1, st_mode=stat.S_IFREG | 0o777, st_file_attributes=32)
        handle = SimpleNamespace(**path.__dict__); handle.st_mode = stat.S_IFREG | 0o666
        route = self.values["build-inputs-before.json"]["toolMetadata"]["ancestors"]
        pin = object.__new__(p.LinkerMetadataPin)
        pin.fd = 123; pin.ancestor_observer = lambda _: copy.deepcopy(route)
        pin.ancestors = copy.deepcopy(route); pin.initial = p.tool_metadata_record(path, handle, route)
        changed = SimpleNamespace(**handle.__dict__); changed.st_mode = stat.S_IFREG | 0o600
        with mock.patch.object(Path, "lstat", return_value=path), mock.patch.object(os, "fstat", return_value=changed):
            with self.assertRaises(p.Refusal): pin.recheck()

    def test_admitted_return_preserves_interface_with_explicit_new_input_guard(self):
        admitted = self.admit()
        self.assertEqual(set(admitted), {"image", "imagePin", "receiptPins", "record", "protectedPins", "protectedBefore", "artifact"})
        self.assertIn("held-build-inputs", admitted["receiptPins"])
        self.assertTrue(all(name in admitted["receiptPins"] for name in self.p.PRODUCER_FILES))


@unittest.skipUnless(os.name == "nt", "Controller's fixed Windows platform admission")
class ControllerPublicationTests(unittest.TestCase):
    def simulate(self, *, late_pin=False, protected_phase=None, late_inputs=False, inputs_phase=None,
                 mode="build", suite="lib", consumer_fault=None):
        p = protocol(); controller = module("inert_controller", "compiler_transaction_controller.py")
        run, commit, sources, originals, controls, _, values = golden(p, suite)
        args = SimpleNamespace(mode=mode, run_id=run if mode == "build" else "inert-receipt-consumer",
                               source_commit=commit, producer_run_id=None if mode == "build" else run, suite=suite)
        receipts = {}; attempted = []; protected_calls = [0]; input_calls = [0]
        class Pin:
            def __init__(pin, api, path, maximum, image=False):
                pin.path = path; pin.image = image
                if image: attempted.append(str(path))
            def __enter__(pin): return pin
            def __exit__(pin, *args):
                pin.recheck()
                if mode == "test" and consumer_fault == "late-capture" and pin.path.name == "outer.stdout":
                    raise p.Refusal("late-test-capture")
            def bytes(pin):
                value = receipts[pin.path.name]
                return value if type(value) is bytes else json.dumps(value).encode()
            def recheck(pin): return values["selected-image.json"] if pin.image else {"pin": str(pin.path)}
        class LateControlPin:
            def __enter__(pin): return pin
            def __exit__(pin, *args):
                if late_pin: raise p.Refusal("late-control-pin")
        def pin_controls(g, api, stack):
            stack.enter_context(LateControlPin())
            return {}
        class InputGuard:
            def __enter__(pin): return pin
            def __exit__(pin, *args):
                if late_inputs: raise p.Refusal("late-linker-pin")
            def recheck(pin):
                input_calls[0] += 1
                if input_calls[0] == inputs_phase: raise p.Refusal("linker-metadata")
                return copy.deepcopy(values["build-inputs-before.json"])
        def inputs(g, api, original, stack, **kwargs):
            return stack.enter_context(InputGuard())
        def protected(*args):
            protected_calls[0] += 1
            if protected_calls[0] == protected_phase: raise p.Refusal("protected-drift")
            return {}
        def owned(*args, **kwargs):
            if mode == "test":
                row = successful_outer(p, values["worker-spec.json"])
                row.update(command=args[4], deadlineSeconds=p.TEST_SECONDS, jobName=None, namedJobCreatedNew=False,
                           absoluteDeadlineNs=row["startedMonotonicNs"] + p.TEST_SECONDS * p.NANO)
                wire = inert_libtest_stdout(p, suite)
                if consumer_fault == "filtered": wire = wire.replace(b"0 filtered out", b"1 filtered out")
                if consumer_fault == "partial": wire = wire.replace(b"test inert::first ... ok\n", b"")
                if consumer_fault == "tree": row.update(completed=False, activeBeforeCleanup=1, treeExitedBeforeCleanup=False)
                row["capturedLogBytes"] = len(wire)
                receipts.update({"outer.stdout": wire, "outer.stderr": b"", "outer.job.json": row})
                return row
            spec = receipts["worker-spec.json"]
            row = successful_outer(p, spec)
            receipts["inner.job.json"] = successful_inner(p, spec)
            for phase in ("worker-before", "worker-after"):
                receipts["build-inputs-" + phase + ".json"] = copy.deepcopy(values["build-inputs-before.json"])
            receipts["outer.stdout"] = values["outer.stdout"]; receipts["outer.stderr"] = b""
            row["capturedLogBytes"] = len(receipts["outer.stdout"])
            receipts["outer.job.json"] = row
            return row
        def admission(g, api, original, stack, run_id, source_commit, *maps, suite, on_image_attempt):
            self.assertEqual((run_id, source_commit, suite), (run, commit, args.suite))
            on_image_attempt()
            pin = stack.enter_context(Pin(api, p.image_path(run), p.MAX_IMAGE, image=True))
            return {"image": p.image_path(run), "imagePin": pin, "receiptPins": {},
                    "record": values["selected-image.json"], "protectedPins": {}, "protectedBefore": {},
                    "artifact": values["cargo-summary.json"]["selectedArtifact"]}
        g = {"new_output": lambda run: p.RUNS / run, "source_map": lambda *args: sources,
             "controls_map": lambda: controls, "ReadPin": Pin, "unique_json": json.loads,
             "environment_for": lambda mode: {}, "load_windows_api": lambda: (None, None),
             "run_owned": owned, "write_json": lambda out, name, value: receipts.__setitem__(name, copy.deepcopy(value))}
        with mock.patch.object(p, "load_runtime", return_value=g), mock.patch.object(p, "load_original", return_value={}), \
             mock.patch.object(p, "original_map", return_value=originals), mock.patch.object(p, "pin_control_files", side_effect=pin_controls), \
             mock.patch.object(p, "protected_pins", return_value=({}, {})), \
             mock.patch.object(p, "protected_recheck", side_effect=protected), \
             mock.patch.object(p, "build_input_pins", side_effect=inputs), \
             mock.patch.object(p, "cargo_summary", return_value=values["cargo-summary.json"]), \
             mock.patch.object(p, "producer_admission", side_effect=admission), \
             mock.patch.object(p.shutil, "disk_usage", return_value=SimpleNamespace(free=p.START_FREE)), \
             mock.patch.object(controller, "acquire_mutex", return_value=1), \
             mock.patch.object(controller, "release_mutex", return_value=None):
            result = controller.execute(p, args)
        return result, attempted, receipts

    def test_success_is_published_only_after_all_context_rechecks(self):
        result, attempted, receipts = self.simulate()
        self.assertTrue(result["completed"], result)
        self.assertTrue(attempted)
        self.assertEqual(receipts["result.json"], result)

    def test_late_pin_failure_never_publishes_completed(self):
        result, attempted, receipts = self.simulate(late_pin=True)
        self.assertTrue(attempted)
        self.assertFalse(result["completed"], result)
        self.assertFalse(receipts["result.json"]["completed"])
        self.assertFalse(result["inputsUnchanged"])

    def test_protected_failure_before_image_prevents_read_and_late_failure_refuses(self):
        result, attempted, _ = self.simulate(protected_phase=1)
        self.assertFalse(result["completed"])
        self.assertEqual(attempted, [])
        self.assertFalse(result["nativeImageReadAttempted"])
        result, attempted, _ = self.simulate(protected_phase=2)
        self.assertTrue(attempted)
        self.assertFalse(result["completed"])
        self.assertFalse(result["protectedMetadataUnchanged"])

    def test_linker_recheck_failure_before_image_and_on_context_exit_remain_failure(self):
        result, attempted, _ = self.simulate(inputs_phase=2)
        self.assertFalse(result["completed"], result); self.assertEqual(attempted, [])
        self.assertFalse(result["nativeImageReadAttempted"])
        result, attempted, receipts = self.simulate(late_inputs=True)
        self.assertTrue(attempted); self.assertFalse(result["completed"], result)
        self.assertFalse(receipts["result.json"]["completed"])
        self.assertEqual(result["errorCode"], "late-linker-pin")

    def test_whole_suite_consumers_keep_matching_suite_counts_and_only_serial_argument(self):
        for suite, ignored in (("lib", 7), ("cli", 0)):
            with self.subTest(suite=suite):
                result, attempted, receipts = self.simulate(mode="test", suite=suite)
                self.assertTrue(result["completed"], result)
                self.assertEqual((result["testSummary"]["passed"], result["testSummary"]["ignored"]), (2, ignored))
                self.assertEqual(receipts["test-summary.json"], result["testSummary"])
                self.assertEqual(receipts["request.json"]["command"][1:], ["--test-threads=1"])
                self.assertEqual(len(attempted), 1)

    def test_forced_empty_tree_filtered_or_partial_test_result_stays_failed(self):
        for fault in ("tree", "filtered", "partial"):
            with self.subTest(fault=fault):
                result, _, receipts = self.simulate(mode="test", consumer_fault=fault)
                self.assertFalse(result["completed"], result)
                self.assertFalse(receipts["result.json"]["completed"])

    def test_late_test_capture_or_input_close_failure_revokes_test_completion(self):
        for options in ({"consumer_fault": "late-capture"}, {"late_inputs": True}, {"late_pin": True}):
            with self.subTest(options=options):
                result, attempted, receipts = self.simulate(mode="test", **options)
                self.assertTrue(attempted)
                self.assertFalse(result["completed"], result)
                self.assertFalse(receipts["result.json"]["completed"])


ROOT_MANIFEST = b'[workspace]\nmembers=["native"]\nresolver="2"\n[profile.release]\nlto="thin"\ncodegen-units=1\nstrip="symbols"\n[profile.dev]\ndebug=0\nincremental=false\n[profile.test]\ndebug=0\nincremental=false\n[profile.dev.package.sha2]\nopt-level=3\n'
NATIVE_MANIFEST = b'[package]\nname="yoke-code-intelligence"\nversion="0.5.0"\nedition="2024"\n[lib]\nname="yoke"\n[[bin]]\nname="yoke"\npath="src/main.rs"\n'


def inert_libtest_stdout(p, suite):
    ignored = list(p.LIB_IGNORED) if suite == "lib" else []
    lines = ["running " + str(2 + len(ignored)) + " tests", "test inert::first ... ok", "test inert::second ... ok"]
    lines.extend("test " + name + " ... ignored, retained original gate" for name in ignored)
    lines.append("test result: ok. 2 passed; 0 failed; " + str(len(ignored)) + " ignored; 0 measured; 0 filtered out; finished in 0.01s")
    return ("\n".join(lines) + "\n\n").encode()


class UnitSelectionTests(unittest.TestCase):
    def test_both_fixed_unit_commands_and_no_release_manual_test_or_integration(self):
        p = protocol()
        for suite, selector in (("lib", ["--lib"]), ("cli", ["--bin", "yoke"])):
            with self.subTest(suite=suite):
                command = p.cargo_command(p.RUNS / "inert-command", suite)
                self.assertEqual(command, [str(p.CARGO), "rustc", "--package", "yoke-code-intelligence", *selector,
                    "--profile", "test", "--locked", "--offline", "-j2", "--message-format=json", "--",
                    "-o", str(p.image_path("inert-command")), "-C", "extra-filename=", "-C", "linker=" + str(p.LINKER), "-C", "linker-flavor=lld-link"])
                self.assertFalse(set(command) & {"--release", "--test", "--tests", "--target", "--ignored", "--skip"})

    def test_cli_enum_is_required_and_refuses_every_generic_or_abbreviated_escape(self):
        controller = module("inert_unit_arguments", "compiler_transaction_controller.py")
        common = ["build", "--source-commit", "f" * 40, "--run-id", "inert-arguments"]
        with self.assertRaises(SystemExit): controller.arguments(common)
        for extra in (["--suite", "runtime"], ["--suite", "lib", "--target", "runtime"],
                      ["--suite", "lib", "--su", "cli"], ["--suite", "cli", "--", "--ignored"]):
            with self.subTest(extra=extra), self.assertRaises(SystemExit): controller.arguments(common + extra)
        for suite in ("lib", "cli"):
            self.assertEqual(controller.arguments(common + ["--suite", suite]).suite, suite)

    def test_suite_rebind_refuses_at_spec_request_result_and_input_boundaries(self):
        p = protocol(); run, commit, sources, originals, controls, spec, values = golden(p)
        for suite in ("runtime", "integration", "LIB", "", False, 0, None):
            with self.subTest(suite=suite), self.assertRaises(p.Refusal): p.cargo_command(p.RUNS / run, suite)
        changed = copy.deepcopy(spec); changed["suite"] = "cli"
        with self.assertRaises(p.Refusal): p.validate_spec(changed)
        changed = copy.deepcopy(values["request.json"]); changed["suite"] = "cli"
        with self.assertRaises(p.Refusal): p.validate_request(changed, values["request.json"])
        changed = copy.deepcopy(values["result.json"]); changed["suite"] = "cli"
        with self.assertRaises(p.Refusal): p.validate_result(changed, run, commit, suite="lib")
        with self.assertRaises(p.Refusal): p.validate_build_inputs(values["build-inputs-before.json"], sources, suite="cli")

    def test_normal_manifest_harness_can_be_absent_or_true_but_never_replaced(self):
        p = protocol()
        for suite in ("lib", "cli"):
            self.assertTrue(p.unit_harness(NATIVE_MANIFEST, suite)["harnessEnabled"])
            explicit = NATIVE_MANIFEST.replace(b'name="yoke"\n', b'name="yoke"\ntest=true\nharness=true\n')
            row = p.unit_harness(explicit, suite)
            self.assertEqual((row["harnessSetting"], row["testSetting"]), ("true", "true"))
            for invalid in (explicit.replace(b'harness=true', b'harness=false'), explicit.replace(b'test=true', b'test=false'),
                            explicit.replace(b'harness=true', b'harness=1'), explicit.replace(b'name="yoke"', b'name="foreign"'),
                            explicit.replace(b'version="0.5.0"', b'version="0.5.1"'),
                            explicit.replace(b'[lib]\n' if suite == "lib" else b'[[bin]]\n',
                                             (b'[lib]\n' if suite == "lib" else b'[[bin]]\n') + b'crate-type=["bin"]\n')):
                with self.subTest(suite=suite, invalid=invalid), self.assertRaises(p.Refusal): p.unit_harness(invalid, suite)
        with self.assertRaises(p.Refusal): p.unit_harness(NATIVE_MANIFEST.replace(b'path="src/main.rs"', b'path="tests/runtime.rs"'), "cli")

    def test_test_profile_preserves_exact_existing_tables_and_rejects_unknown_overrides(self):
        p = protocol()
        row = p.test_profile(ROOT_MANIFEST, NATIVE_MANIFEST)
        self.assertEqual(row["selectedArtifactProfile"], {"opt_level": "0", "debuginfo": 0,
                                                         "debug_assertions": True, "overflow_checks": True, "test": True})
        for invalid in (ROOT_MANIFEST.replace(b'debug=0', b'debug=2'), ROOT_MANIFEST.replace(b'debug=0', b'debug=false'),
                        ROOT_MANIFEST.replace(b'incremental=false', b'incremental=true'),
                        ROOT_MANIFEST.replace(b'opt-level=3', b'opt-level=2'), ROOT_MANIFEST.replace(b'package.sha2', b'package.other'),
                        ROOT_MANIFEST + b'[profile.test.package.other]\nopt-level=1\n',
                        ROOT_MANIFEST + b'[profile.unreviewed]\ninherits="test"\n',
                        ROOT_MANIFEST.replace(b'[profile.test]\n', b'[profile.test]\ndebug-assertions=false\n')):
            with self.subTest(invalid=invalid), self.assertRaises(p.Refusal): p.test_profile(invalid, NATIVE_MANIFEST)
        with self.assertRaises(p.Refusal): p.test_profile(ROOT_MANIFEST, NATIVE_MANIFEST + b'[profile.test]\ndebug=0\n')

    def test_selected_artifact_retains_library_or_binary_target_kind_under_test_mode(self):
        p = protocol()
        for suite, kind in (("lib", "lib"), ("cli", "bin")):
            run, commit, sources, originals, controls, spec, values = golden(p, suite)
            summary = p.cargo_summary({"unique_json": json.loads}, {}, values["outer.stdout"], suite=suite)
            self.assertEqual(summary["selectedArtifact"]["target"]["kind"], [kind])
            self.assertIs(summary["selectedArtifact"]["profile"]["test"], True)
            self.assertEqual(summary, values["cargo-summary.json"])
            for role, key, value in (("target", "kind", ["test"]), ("target", "crate_types", ["cdylib"]),
                                     ("target", "src_path", str(p.ROOT / "native/tests/runtime.rs")),
                                     ("profile", "test", False), ("profile", "debug_assertions", False),
                                     ("profile", "overflow_checks", False), ("profile", "debuginfo", False),
                                     ("profile", "debuginfo", 2), ("profile", "opt_level", "3")):
                changed = copy.deepcopy(values["cargo-summary.json"]["selectedArtifact"]); changed[role][key] = value
                wire = (json.dumps(changed) + "\n" + json.dumps({"reason": "build-finished", "success": True}) + "\n").encode()
                with self.subTest(suite=suite, role=role, key=key, value=value), self.assertRaises(p.Refusal):
                    p.cargo_summary({"unique_json": json.loads}, {}, wire, suite=suite)

    def test_consuming_unit_request_has_only_whole_harness_thread_argument(self):
        p = protocol(); run, commit, sources, originals, controls, _, _ = golden(p)
        for suite in ("lib", "cli"):
            row = p.request_record("test", "inert-consumer", commit, run, sources, originals, controls, suite=suite)
            self.assertEqual(row["command"], [str(p.image_path(run)), "--test-threads=1"])
            self.assertEqual((row["deadlineSeconds"], row["outerDrainSeconds"], row["cleanupSeconds"]), (1200, 1, 2))
            for additions in (["runtime::"], ["--ignored"], ["--skip", "one"], ["--test-threads=2"]):
                changed = copy.deepcopy(row); changed["command"] += additions
                with self.subTest(additions=additions), self.assertRaises(p.Refusal): p.validate_request(changed, row)

    def test_ambient_libtest_overrides_refuse_before_any_tool_or_test_launch(self):
        g = protocol().load_runtime()
        for key in ("RUST_TEST_THREADS", "RUST_TEST_NOCAPTURE", "RUST_TEST_SHUFFLE", "RUST_TEST_UNKNOWN"):
            for value in ("1", ""):
                with self.subTest(key=key, value=value), mock.patch.dict(os.environ, {key: value}, clear=True):
                    with self.assertRaisesRegex(RuntimeError, "Ambient compiler/target/runner/Git overrides"):
                        g["environment_for"]("build")

    def test_old_accepted_release_lld_result_refuses_new_unit_record(self):
        p = protocol(); run, commit, sources, originals, controls, _, values = golden(p)
        old = module("immutable_accepted_release_lld", "accepted-compiler-lld/transaction_protocol.py")
        self.assertNotEqual(old.OWNER, p.OWNER)
        self.assertNotEqual(old.SCHEMA, p.SCHEMA)
        with self.assertRaises(old.Refusal): old.validate_result(values["result.json"], run, commit)
        attempted = []
        class Pin:
            def __init__(pin, api, path, maximum, image=False):
                pin.path = path
                if image:
                    attempted.append(str(path))
                    raise AssertionError("release consumer reached a unit image")
            def __enter__(pin): return pin
            def __exit__(pin, *args): pass
            def bytes(pin):
                value = values[pin.path.name]
                return value if type(value) is bytes else json.dumps(value).encode()
        g = {"ReadPin": Pin, "ordinary": lambda *a, **k: None, "unique_json": json.loads}
        with mock.patch.object(Path, "lstat", return_value=SimpleNamespace(st_size=1)), ExitStack() as stack:
            with self.assertRaises(old.Refusal):
                old.producer_admission(g, None, {}, stack, run, commit, sources, originals, controls)
        self.assertEqual(attempted, [])


    def test_empty_output_suffix_is_fixed_in_each_final_command(self):
        p = protocol()
        for suite in ("lib", "cli"):
            _, _, _, _, _, spec, _ = golden(p, suite)
            original = spec["cargoCommand"]
            position = original.index("extra-filename=")
            mutations = [original[:position - 1] + original[position + 1:]]
            changed = original.copy(); changed[position] = "extra-filename=-foreign"; mutations.append(changed)
            mutations.append(original + ["-C", "extra-filename=-foreign"])
            for command in mutations:
                altered = copy.deepcopy(spec); altered["cargoCommand"] = command
                with self.subTest(suite=suite, command=command), self.assertRaises(p.Refusal):
                    p.validate_spec(altered)

    def test_output_proof_and_previous_unit_schema_refuse_before_admission(self):
        p = protocol()
        _, _, sources, _, _, _, values = golden(p)
        original = values["build-inputs-before.json"]
        p.validate_build_inputs(original, sources, suite="lib")
        mutations = []
        missing = copy.deepcopy(original); missing.pop("outputArguments"); mutations.append(missing)
        for arguments in ([], ["-C", "extra-filename=-foreign"], ["-C", "extra-filename=", "-C", "opt-level=1"]):
            changed = copy.deepcopy(original); changed["outputArguments"] = arguments; mutations.append(changed)
        old = copy.deepcopy(original); old.update(owner="integration-20261026-unit-lld-v1", schema=4); mutations.append(old)
        for proof in mutations:
            with self.subTest(proof=proof), self.assertRaises(p.Refusal):
                p.validate_build_inputs(proof, sources, suite="lib")

    def test_hashed_old_output_is_never_an_alternate_private_image_role(self):
        p = protocol()
        run, _, _, _, _, _, values = golden(p)
        original = values["selected-image.json"]
        p.image_record(original, run)
        for name in ("unit-tests-0123456789abcdef.exe", "yoke.exe"):
            record = copy.deepcopy(original); record["path"] = str(p.RUNS / run / name)
            with self.subTest(name=name), self.assertRaises(p.Refusal):
                p.image_record(record, run)


class WholeHarnessOutputTests(unittest.TestCase):
    def test_complete_lib_and_cli_outputs_preserve_original_ignored_names_and_counts(self):
        p = protocol()
        for suite, ignored in (("lib", 7), ("cli", 0)):
            result = p.test_summary(inert_libtest_stdout(p, suite), suite=suite)
            self.assertEqual((result["passed"], result["failed"], result["ignored"], result["measured"], result["filteredOut"]), (2, 0, ignored, 0, 0))
            self.assertEqual(result["ignoredTests"], list(p.LIB_IGNORED) if suite == "lib" else [])

    def test_failed_filtered_measured_partial_and_repeated_records_never_qualify(self):
        p = protocol(); wire = inert_libtest_stdout(p, "cli")
        invalids = (wire.replace(b'0 failed', b'1 failed'), wire.replace(b'0 measured', b'1 measured'),
                    wire.replace(b'0 filtered out', b'1 filtered out'), wire.replace(b'2 passed', b'0 passed'),
                    wire.replace(b'2 tests', b'3 tests'), wire.replace(b'test inert::second ... ok\n', b''),
                    wire.replace(b'inert::second', b'inert::first'), wire + b'late output\n', b'')
        for invalid in invalids:
            with self.subTest(invalid=invalid), self.assertRaises(p.Refusal): p.test_summary(invalid, suite="cli")

    def test_equal_ignored_totals_with_changed_promoted_or_missing_inventory_refuse(self):
        p = protocol(); wire = inert_libtest_stdout(p, "lib")
        for invalid in (wire.replace(p.LIB_IGNORED[0].encode(), b'foreign::ignored'),
                        wire.replace(b' ... ignored, retained original gate', b' ... ok', 1),
                        wire.replace(b'7 ignored', b'6 ignored')):
            with self.subTest(invalid=invalid), self.assertRaises(p.Refusal): p.test_summary(invalid, suite="lib")
        with self.assertRaises(p.Refusal): p.test_summary(wire, suite="cli")
        with self.assertRaises(p.Refusal): p.test_summary(inert_libtest_stdout(p, "cli"), suite="lib")


def inert_compiler_argv(mode):
    helper_seconds = 1.6 if mode == "linger" else 30
    # Open only the test compiler's retained, owned root before acknowledging
    # readiness. Sleep begins after the actual root exit receipt, removing a
    # scheduling assumption from the >1s direct-gate comparison.
    helper = ("import ctypes as c,sys,time; k=c.WinDLL('kernel32',use_last_error=True); "
              "k.OpenProcess.argtypes=[c.c_ulong,c.c_int,c.c_ulong]; k.OpenProcess.restype=c.c_void_p; "
              "k.WaitForSingleObject.argtypes=[c.c_void_p,c.c_ulong]; k.WaitForSingleObject.restype=c.c_ulong; "
              "k.CloseHandle.argtypes=[c.c_void_p]; k.CloseHandle.restype=c.c_int; "
              "h=k.OpenProcess(0x100000,False,int(sys.argv[1])); assert h; print('ready',flush=True); "
              "s=k.WaitForSingleObject(h,10000); assert k.CloseHandle(h); assert s==0; "
              "time.sleep(" + str(helper_seconds) + ")")
    code = ("import os,subprocess,sys; p=subprocess.Popen([sys.executable,'-I','-c'," + repr(helper)
            + ",str(os.getpid())],stdout=subprocess.PIPE,text=True); "
              "assert p.stdout.readline()=='ready\\n'; print('inert compiler',flush=True)")
    if mode == "output": code += "; sys.stdout.write('x'*200000); sys.stdout.flush()"
    return [str(Path(sys.executable).absolute()), "-I", "-c", code]


def inert_worker(spec_path, fault, mode):
    """Internal test entry; never reachable from the production CLI or spec."""
    p = protocol(); g = p.load_runtime(); api, extended = g["load_windows_api"](); p.configure_worker_api(api)
    spec = json.loads(Path(spec_path).read_text())
    outer = api.OpenJobObjectW(4, False, spec["outerJobName"])
    try:
        p.need(outer and p.member(api, api.GetCurrentProcess(), outer), "test-outer-membership")
        row = p.inner_run(g, api, extended, spec, outer, os.environ.copy(),
                          _trusted_test_argv=inert_compiler_argv(mode), _test_fault=None if fault == "none" else fault)
        g["write_json"](Path(spec_path).parent, "inner.job.json", row)
        return 0 if row["completed"] else 1
    finally:
        api.CloseHandle(outer)


class CargoConfigurationTests(unittest.TestCase):
    def test_untracked_config_refuses_before_any_source_observation(self):
        for phase in ("before", "after", "final"):
            for location in ("root", "ancestor", "cargo-home"):
                for name in ("config", "config.toml"):
                    with self.subTest(phase=phase, location=location, name=name), tempfile.TemporaryDirectory() as temporary:
                        owned = Path(temporary).resolve()
                        root = owned / "parent/project"
                        root.mkdir(parents=True)
                        cargo_home = owned / "cargo-home"
                        cargo_home.mkdir()
                        g = protocol().load_runtime()
                        git = mock.Mock(side_effect=AssertionError("Git must remain uncalled"))
                        hashed = mock.Mock(side_effect=AssertionError("Sources must remain unread"))
                        real_lexists = os.path.lexists
                        def exists(path):
                            return real_lexists(path) if Path(path).is_relative_to(owned) else False
                        with mock.patch.dict(g, ROOT=root, git_capture=git, hash_selected=hashed), \
                             mock.patch.dict(os.environ, {"USERPROFILE": str(owned), "CARGO_HOME": str(cargo_home)}, clear=True), \
                             mock.patch.object(os.path, "lexists", side_effect=exists):
                            retained = g["environment_for"]("build")
                            directory = {"root": root / ".cargo", "ancestor": root.parent / ".cargo",
                                         "cargo-home": cargo_home}[location]
                            directory.mkdir(exist_ok=True)
                            candidate = directory / name
                            original = b"[build]\njobs = 1\n"
                            candidate.write_bytes(original)
                            with self.assertRaisesRegex(RuntimeError, "Existing Cargo configuration"):
                                g["source_map"](None, None, owned, retained, "f" * 40, phase)
                            git.assert_not_called()
                            hashed.assert_not_called()
                            self.assertEqual(candidate.read_bytes(), original)

    def test_environment_drift_refuses_and_clean_environment_reaches_source_map(self):
        g = protocol().load_runtime()
        retained = {"owned": "initial"}
        git = mock.Mock(side_effect=[b"f" * 40 + b"\n", b"", b"Cargo.toml\0Cargo.lock\0native/Cargo.toml\0scripts/host_powershell_probe.py\0scripts/run_native_tests.py\0scripts/ci_windows_temp.py\0scripts/native_shards.py\0.github/workflows/rust.yml\0"])
        hashed = mock.Mock(return_value={"owned": {"bytes": 0, "sha256": "0" * 64}})
        written = mock.Mock()
        with mock.patch.dict(g, git_capture=git, hash_selected=hashed, write_json=written,
                             environment_for=mock.Mock(return_value={"owned": "changed"})):
            with self.assertRaisesRegex(RuntimeError, "Cargo environment/configuration changed"):
                g["source_map"](None, None, HERE, retained, "f" * 40, "after")
            git.assert_not_called()
            hashed.assert_not_called()
            g["environment_for"].return_value = retained
            self.assertEqual(g["source_map"](None, None, HERE, retained, "f" * 40, "final"), hashed.return_value)
            self.assertEqual(git.call_count, 3)
            written.assert_called_once_with(HERE, "source-final.json", hashed.return_value)


@unittest.skipUnless(os.name == "nt", "Windows nested Jobs required")
class InertWindowsLifecycleTests(unittest.TestCase):
    def prepare(self):
        p = protocol(); g = p.load_runtime(); api, extended = g["load_windows_api"]()
        out = g["new_output"]("inert-lld-" + secrets.token_hex(12))
        # Keep the real protocol's 3600-second origin/difference, but start this
        # inert challenge with only six seconds REMAINING. Never reset in worker.
        start = time.monotonic_ns() - (p.BUILD_SECONDS - 6) * p.NANO
        spec = p.make_spec(out.name, "f" * 40, "Local\\YokeUnitLLD-" + secrets.token_hex(32),
                           start, {}, {}, {}, {}, suite="lib")
        g["write_json"](out, "worker-spec.json", spec)
        return p, g, api, extended, out, spec

    def run_wrapper(self, fault="none", mode="linger", cap=16_000_000, inject=None):
        p, g, api, extended, out, spec = self.prepare()
        argv = [str(Path(sys.executable).absolute()), "-I", str(Path(__file__).absolute()),
                "--owned-inert-worker", str(out / "worker-spec.json"), fault, mode]
        with ExitStack() as stack:
            if inject == "disk":
                calls = [0]
                def disk(_):
                    calls[0] += 1
                    return SimpleNamespace(free=p.START_FREE if calls[0] < 4 else 0)
                stack.enter_context(mock.patch.object(g["shutil"], "disk_usage", side_effect=disk))
            if inject == "stream":
                read = os.read
                def broken_read(fd, size): raise OSError("inert reader fault")
                stack.enter_context(mock.patch.object(g["os"], "read", side_effect=broken_read))
            row = g["run_owned"](api, extended, out, "outer", argv, os.environ.copy(), 6, cap=cap,
                                  absolute_deadline_ns=spec["deadlineNs"], job_name=spec["outerJobName"])
        return p, g, api, extended, out, spec, row

    def test_delayed_helper_is_natural_under_new_transaction_but_fails_old_direct_gate(self):
        p, g, api, extended, out, spec, row = self.run_wrapper()
        self.assertTrue(row["completed"], row)
        inner = json.loads((out / "inner.job.json").read_text())
        self.assertTrue(inner["completed"], inner)
        self.assertGreater(inner["naturalEmptyNs"] - inner["cargoExitObservedNs"], p.NANO)
        self.assertEqual(inner["activeBeforeClose"], 0)
        old = p.load_original()["load_base"]()
        direct_out = g["new_output"]("inert-direct-" + secrets.token_hex(12))
        direct = old["run_owned"](api, extended, direct_out, "command", inert_compiler_argv("linger"), os.environ.copy(), 6)
        self.assertFalse(direct["completed"], direct)
        self.assertGreater(direct["activeBeforeCleanup"], 0)
        self.assertEqual(direct["activeAfterCleanup"], 0)

    def test_neverending_member_keeps_failure_after_forced_cleanup(self):
        *_, row = self.run_wrapper(mode="forever")
        self.assertFalse(row["completed"], row)
        self.assertEqual(row["activeAfterCleanup"], 0, row)
        self.assertLessEqual(row["elapsedSeconds"], 8.5, row)

    def test_assignment_resume_query_and_wrapper_crash_do_not_orphan(self):
        for fault in ("after-create", "assignment", "resume", "query", "wrapper-crash"):
            with self.subTest(fault=fault):
                *_, row = self.run_wrapper(fault=fault)
                self.assertFalse(row["completed"], row)
                self.assertEqual(row["activeAfterCleanup"], 0, row)
                self.assertTrue(row["rootExitedAfterCleanup"], row)
                self.assertFalse(row["cleanupUnproven"], row)

    def test_output_disk_and_reader_faults_remain_failure_after_cleanup(self):
        for kwargs in ({"mode": "output", "cap": 64}, {"inject": "disk"}, {"inject": "stream"}):
            with self.subTest(kwargs=kwargs):
                *_, row = self.run_wrapper(**kwargs)
                self.assertFalse(row["completed"], row)
                self.assertEqual(row["activeAfterCleanup"], 0, row)

    def test_named_job_collision_never_terminates_or_queries_the_existing_job(self):
        p, g, api, extended, out, spec = self.prepare()
        owned_existing = api.CreateJobObjectW(None, spec["outerJobName"])
        self.assertTrue(owned_existing)
        try:
            with mock.patch.object(api, "TerminateJobObject", wraps=api.TerminateJobObject) as terminate, \
                 mock.patch.object(api, "QueryInformationJobObject", wraps=api.QueryInformationJobObject) as query:
                row = g["run_owned"](api, extended, out, "collision", inert_compiler_argv("linger"),
                                      os.environ.copy(), 6, absolute_deadline_ns=spec["deadlineNs"],
                                      job_name=spec["outerJobName"])
            self.assertFalse(row["completed"], row)
            self.assertFalse(row["startedSuspended"], row)
            terminate.assert_not_called()
            query.assert_not_called()
        finally:
            self.assertTrue(api.CloseHandle(owned_existing))

    def test_real_inert_unit_consumer_keeps_original_one_second_drain(self):
        p, g, api, extended, out, _ = self.prepare()
        command = inert_compiler_argv("linger")
        # A valid synthetic whole-suite footer cannot excuse a surviving member.
        command[-1] += ";sys.stdout.write(" + repr(inert_libtest_stdout(p, "cli").decode()) + ");sys.stdout.flush()"
        row = g["run_owned"](api, extended, out, "test-consumer", command, os.environ.copy(), p.TEST_SECONDS)
        self.assertEqual(row["deadlineSeconds"], 1200)
        self.assertEqual((row["originalDrainSeconds"], row["cleanupSeconds"]), (1, 2))
        self.assertFalse(row["completed"], row)
        self.assertGreater(row["activeBeforeCleanup"], 0, row)
        self.assertEqual(row["activeAfterCleanup"], 0, row)
        with self.assertRaises(p.Refusal): p.validate_outer(row, None, command, p.TEST_SECONDS)

    def test_real_inert_unit_consumer_completes_capture_and_empty_tree(self):
        p, g, api, extended, out, _ = self.prepare()
        wire = inert_libtest_stdout(p, "cli")
        command = [str(Path(sys.executable).absolute()), "-I", "-c", "import sys;sys.stdout.buffer.write(" + repr(wire) + ");sys.stdout.flush()"]
        row = g["run_owned"](api, extended, out, "test-consumer", command, os.environ.copy(), p.TEST_SECONDS)
        p.validate_outer(row, None, command, p.TEST_SECONDS)
        self.assertEqual(row["activeBeforeCleanup"], 0, row)
        self.assertEqual((out / "test-consumer.stdout").read_bytes(), wire)
        self.assertEqual(p.test_summary(wire, suite="cli")["passed"], 2)


if __name__ == "__main__":
    if len(sys.argv) == 5 and sys.argv[1] == "--owned-inert-worker":
        try: code = inert_worker(sys.argv[2], sys.argv[3], sys.argv[4])
        except BaseException: code = 1
        os._exit(code)
    unittest.main()
