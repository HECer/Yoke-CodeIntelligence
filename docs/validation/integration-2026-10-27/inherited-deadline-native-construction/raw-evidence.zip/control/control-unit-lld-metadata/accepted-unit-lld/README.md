# Separate LLD unit-harness protocol: source preparation only

Owner `integration-20261026-unit-lld-v2`, schema 5. This NEW bundle is an explicit source fork of the accepted compiler-LLD source bundle. No authored module/function, guard test, compiler, worker or native image has been imported, executed, built, read or hashed during this preparation. AST parsing and source-only hash/LF/static checks establish no runtime acceptance. All release, VSIX, platform and project qualification flags remain false.

## Exact caller source, two closed units

The caller must supply the actual complete 40-hex `--source-commit`. The runtime checks that exact HEAD and a clean tracked tree, maps the selected native/script/Cargo/workflow source bytes, and repeats those observations before/after/final. It never certifies the preparation HEAD or a future parent patch by assumption. The primary runtime/CLI fixes are outside this worktree and outside this agent's write scope. Parent integration and a new matching source freeze must precede execution.

`compiler_transaction_controller.py` has only `build` and `test` modes. `--suite` is REQUIRED and is exactly `lib` or `cli`. Build takes no producer ID; test requires a distinct matching `--producer-run-id`. There is no generic target, executable, compiler argument, environment, request deadline, test filter or test-hook option. Every run directory is fresh and create-only under `runs-unit-lld-fixed-output`.

The fixed build command prefix is:

```text
C:\Users\Lomi\.cargo\bin\cargo.exe rustc --package yoke-code-intelligence <UNIT> --profile test --locked --offline -j2 --message-format=json -- -o <fresh-owned-run>\unit-tests.exe -C linker=C:\Users\Lomi\.rustup\toolchains\1.94.1-x86_64-pc-windows-msvc\lib\rustlib\x86_64-pc-windows-msvc\bin\rust-lld.exe -C linker-flavor=lld-link
```

For `lib`, `<UNIT>` is exactly `--lib`. The selected Cargo target is name `yoke`, kind `['lib']`, crate types `['lib']`, exact `native/src/lib.rs`. For `cli`, it is exactly `--bin yoke`, kind `['bin']`, crate types `['bin']`, exact `native/src/main.rs`. Both selected compiler artifacts must have `profile.test:true`, `fresh:false`, opt level string `'0'`, debuginfo integer `0`, assertions `true` and overflow checks `true`, with the exact package URI, package version 0.5.0 and edition 2024.

No `--release`, manually supplied rustc `--test`, global RUSTFLAGS, target/CRT change or alternate linker exists. Normal selected target `test` and `harness` settings must be absent or Boolean true. Cargo 1.94's `--profile test` selects test mode and automatically adds rustc `--test` for that normal harness. An explicitly false/custom harness refuses before Cargo. Library target kind remains `lib` even though rustc emits an executable harness; a binary unit harness remains Cargo kind `bin`.

Integration targets are deliberately absent. An integration target also adds ordinary package-bin build dependencies whose extra image roles and linker choices are unresolved. This policy supplies no exception for them. A dependency/build-script/proc-macro/cc-rs MSVC helper may still exist during these two unit builds; any lingering owned member still fails.

## Preserve the actual profiles and tool/source witnesses

The held root/native manifest bytes are checked against the selected source map. The root profile table must be EXACTLY the existing release/dev/test tables: release `lto='thin'`, `codegen-units=1`, `strip='symbols'`; dev `debug=0`, `incremental=false`, with only `package.sha2.opt-level=3`; test `debug=0`, `incremental=false`. No unknown profile/package override or native manifest profile table is accepted. This preserves actual source; it does not replace it with assumed built-in debuginfo 2 defaults. All nested Boolean/integer types are checked separately from value equality.

The selected source target and normal harness are separately recorded in `unitHarness`. The closed `suite` is bound in worker spec, request, inner receipt, result and build-input proof. Source/profile/harness/tool proofs are retained at before/after/final and worker-before/worker-after, compared by exact digests, and rechecked while their contexts remain held. Compiler configuration/environment refusal repeats at late source observations. Ambient `RUST_TEST_*` overrides also refuse; no hidden filter, shuffle, nocapture or thread override is silently cleared.

The fixed installed LLD handle requests FILE_EXECUTE|FILE_READ_ATTRIBUTES, WITHOUT FILE_READ_DATA. It preserves the exact independent path and handle observations and refuses drift, links, reparses and missing identity. Tool contents are neither read nor attested. Existing default target and global dependency caches, installed compiler/toolchain/SDK/library binaries, Python and equal-privilege host processes remain trusted. This is not an equal-privilege sandbox or complete compiler attestation.

## Original lifecycle and independent private-image admission

Compilation retains ONE absolute 3600-second deadline established before wrapper launch. The suspended Cargo process is confirmed in the owned outer Job, assigned to an initially empty inner Job and resumed once. After actual Cargo exit zero, EVERY inner member must exit naturally within at most 60 seconds clipped to that same absolute deadline. There is no named helper exception, breakaway, inner kill-on-close, inner termination or extra cleanup wait. The outer owner's original one-second natural drain and sole two-second TOTAL abort remain. Output/EOF/reader/disk/accounting failures remain failures even if forced cleanup reaches zero.

Build admission remains 4,000,000,000 free bytes, continuous 500,000,000-byte reserve, 16,000,000 aggregate captured log bytes, separate 1,200,000,000-byte image admission and 512,000,000-byte image ceiling. The unchanged original seven protected-role controls remain held/rechecked with no protected image byte read. Default executable/PDB roles are not waived.

The first fresh private image read occurs only after natural inner/outer completion, exact source/control/protected/profile/harness observations and a fresh selected Cargo artifact. `-o`, initial absence, the exact private role, held identity, single link, no reparses, byte cap and selected image hash bind the actual image. Cargo's normal `executable` and `filenames` fields are metadata ONLY and cannot select the private image. No old/default/cached image adoption or legacy producer fallback exists.

Consumers hold every producer receipt and the admitted exact image, repeat all proofs before publication, and recheck/close every relevant context and release the mutex before `completed:true`. Late context/mutex failures revoke completion. Attempted image-read flags remain honest on failure.

## Whole-harness consumer only

The admitted image receives ONLY `--test-threads=1`. No name filter, skip, ignored/ignored-only, shuffle or arbitrary argument is exposed. The request has the original library gate's 1200-second budget, the ORIGINAL one-second natural drain and two-second sole abort. The compiler's 60-second quiescence allowance NEVER applies to a test consumer.

Both actual exit zero AND natural all-owned empty tree before forced cleanup are mandatory. Complete bounded streams and capture lengths are required. The final full libtest result must report zero failed, zero measured and zero filtered, positive passed count, matching initial running count and unique complete per-test terminal records. Exact pass and ignore counts are retained; no fixed fabricated pass total is certified.

The original Windows library ignored inventory is exactly seven names, bound in protocol/input proofs and checked against actual output: the host output-recovery worker, six existing retrieval capacity/saved-row gates. Their exact names are in `LIB_IGNORED`. Static inspection of all CLI modules reachable from main found zero original ignores; CLI requires zero. New, missing, renamed or promoted ignored tests refuse even when aggregate counts match. These ignored gates remain unexecuted, not passed.

## Preserved derivation and review boundary

`accepted-compiler-lld/` contains the ENTIRE original eleven-file source bundle BYTE-EXACT. Its original manifest is `141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9`, protocol `eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a`, runtime `1608c69131ab3374812496ee9ff855e2c906ac172d31f9899331aa33f2e98de8`. It is retained source evidence, not a relocated runnable producer. Its accepted execution receipts are outside this preparation and are not changed or relabeled. Runtime control mapping enforces every retained snapshot hash.

The original seven `control-cli` files, ten-file v2 bundle, valid F8/E89 receipts and actual sibling accepted LLD controls remain untouched. Original runtime/v2 derivation patches are preserved; `unit-fork.patch` records this separate fork. `DERIVATION.md` records source support and remaining assumptions. Runtime legacy standalone build/test/Clippy entry points were removed from this new fork; it is library-only. No old module globals are changed to authorize a new target.

The inherited 50 effective guard cases remain, adapted to explicit unit receipt shapes; new inert tests cover both suites, profile/harness/target rebind, old-release refusal, ambient override refusal, complete result/ignored inventory, late publication and consumer drain/cleanup. This is authored coverage intent ONLY. Parent must first review the frozen source/manifest, run meaningful guarded inert tests serially, then build/run each whole admitted unit harness against the eventual actual source HEAD. Full required project checks, hosted platforms, integration targets and release qualification remain separate and unrun here. No instruction in this file authorizes execution by itself.

## Parent output-name correction

Schema 4's first actual library build compiled successfully and ended its Jobs naturally, but the compiler produced `unit-tests-<Cargo hash>.exe`. Its missing predeclared `unit-tests.exe` role correctly refused admission; no bytes of that rejected image were read, hashed or adopted.

This separate schema 5 command adds exactly `-C extra-filename=` between the fixed `-o` role and fixed LLD arguments. Cargo appends selected-target arguments after its default filename suffix; Rust's stable string option accepts the empty suffix. This binds the predeclared output name without changing test profiles, target, CRT, limits or broadening image selection. No glob, rename, alternate hashed file, failed image or default Cargo executable is adopted. The before/after/final/worker input proofs bind the exact `outputArguments` list. A fresh producer is mandatory.

Primary source: [Rust 1.94.1 option parsing](https://github.com/rust-lang/rust/blob/1.94.1/compiler/rustc_session/src/options.rs#L1987), [Cargo argument ordering](https://github.com/rust-lang/cargo/blob/rust-1.94.0/src/cargo/core/compiler/mod.rs#L737-L761). Parent source revision adds three causal output-name/proof/old-role guards (72 effective total). Existing receipt-typing assertions remain; computed and stored Cargo summaries/artifacts use canonical typed digests.
