BEGIN TRANSACTION;
CREATE TABLE cache(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "cache" VALUES('0d8af7deecaf3fce86641ceffbcb86ec5705faf2309de6c67006a77c969b1bbe','{"entities":[{"id":"","key":"main.py:file:0","snapshotId":"","path":"main.py","name":"main.py","qualifiedName":"main.py","kind":"file","language":"python","signature":"main.py [python]","startByte":0,"endByte":48,"startLine":1,"endLine":3,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"","key":"main.py:function:18","snapshotId":"","path":"main.py","name":"visible","qualifiedName":"main.py/visible","kind":"function","language":"python","signature":"def visible():","startByte":18,"endByte":46,"startLine":2,"endLine":3,"nameStartByte":22,"nameEndByte":29,"parentKey":"main.py:file:0","producer":"yoke-tree-sitter-8"}],"edges":[{"sourceKey":"main.py:file:0","targetLabel":"main.py:function:18","relation":"contains","startByte":18,"endByte":46,"startLine":2,"endLine":3}],"diagnostics":[],"resolution":{"language":"python","scopes":[{"start":0,"end":48,"parent":null,"function":false},{"start":18,"end":46,"parent":0,"function":true}],"bindings":[{"scope":0,"name":"visible","definedAt":0,"target":{"kind":"entity","value":"main.py:function:18"}}],"uses":[]}}');
PRAGMA writable_schema=ON;
INSERT INTO sqlite_master(type,name,tbl_name,rootpage,sql)VALUES('table','documents','documents',0,'CREATE VIRTUAL TABLE documents USING fts5(snapshot UNINDEXED,path UNINDEXED,text)');
INSERT INTO "documents" VALUES('c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7','main.py','# owned 💡 é
def visible():
    return 7
');
CREATE TABLE 'documents_config'(k PRIMARY KEY, v) WITHOUT ROWID;
INSERT INTO "documents_config" VALUES('version',4);
CREATE TABLE 'documents_content'(id INTEGER PRIMARY KEY, c0, c1, c2);
INSERT INTO "documents_content" VALUES(1,'c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7','main.py','# owned 💡 é
def visible():
    return 7
');
CREATE TABLE 'documents_data'(id INTEGER PRIMARY KEY, block BLOB);
INSERT INTO "documents_data" VALUES(1,X'01000006');
INSERT INTO "documents_data" VALUES(10,X'000000000101010001010101');
INSERT INTO "documents_data" VALUES(137438953473,X'00000045023037010601020701036465660106010204010165010601020301056F776E65640106010202010672657475726E0106010206010776697369626C65010601020504080A080C0D');
CREATE TABLE 'documents_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
INSERT INTO "documents_docsize" VALUES(1,X'000006');
CREATE TABLE 'documents_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
INSERT INTO "documents_idx" VALUES(1,X'',2);
CREATE TABLE graphs(id TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "graphs" VALUES('c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7','{"snapshotId":"c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7","entities":[{"id":"12d2032025ac1378935817d529aaaf6f57e90cdbd47bb51775a286bb7d3a9b13","key":"main.py:file:0","snapshotId":"c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7","path":"main.py","name":"main.py","qualifiedName":"main.py","kind":"file","language":"python","signature":"main.py [python]","startByte":0,"endByte":48,"startLine":1,"endLine":3,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"8f3ce614e3ba2fb36e5c1086d42bf045d7de4b7b22d6d46159768ffd0a2b4603","key":"main.py:function:18","snapshotId":"c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7","path":"main.py","name":"visible","qualifiedName":"main.py/visible","kind":"function","language":"python","signature":"def visible():","startByte":18,"endByte":46,"startLine":2,"endLine":3,"nameStartByte":22,"nameEndByte":29,"parentKey":"main.py:file:0","producer":"yoke-tree-sitter-8"}],"observations":[{"id":"e132f444a1ba7a065b5217369eec1204a2fe0aee3c41197a6cde80bb384dab75","snapshotId":"c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7","source":"12d2032025ac1378935817d529aaaf6f57e90cdbd47bb51775a286bb7d3a9b13","target":"8f3ce614e3ba2fb36e5c1086d42bf045d7de4b7b22d6d46159768ffd0a2b4603","targetLabel":"main.py:function:18","relation":"contains","resolution":"syntactic","evidenceIds":["4d9f877fe85dfdd2bf199b49fec4b586662d929f6cb2909817775203b10bb6a4"],"producer":"yoke-tree-sitter-8"}],"evidence":[{"id":"4d9f877fe85dfdd2bf199b49fec4b586662d929f6cb2909817775203b10bb6a4","snapshotId":"c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7","path":"main.py","contentHash":"df1522f626d45daa5d2e607e16d3a14fe3a758f1979c0108fa3753912429bfde","startByte":18,"endByte":46,"startLine":2,"endLine":3,"anchor":"exact","trust":"source-data","producer":"yoke-tree-sitter-8"}],"diagnostics":[],"coverage":{"indexedFiles":1,"sourceFiles":1,"languages":{"python":1},"unresolved":0,"omissions":0,"exhaustive":false,"semantic":false,"limitations":["Structural candidate resolution is not compiler binding or exhaustive runtime coverage.","Unsupported text formats have full-text search but no AST semantics. Binary/media files are explicitly omitted.","Lexical/import/receiver bindings are syntax-local candidates. Parallel targets preserve possible dispatch; dynamic assignment, dependencies and runtime targets remain nonexhaustive."]}}');
CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "meta" VALUES('workspace','55e304db7b22e2ae04c5e8a14fa377419406a3205d40aef970fdfb76b1075b6a');
INSERT INTO "meta" VALUES('latest','c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7');
INSERT INTO "meta" VALUES('last_disk_index_snapshot_id','c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7');
CREATE TABLE records(kind TEXT NOT NULL,id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(kind,id));
INSERT INTO "records" VALUES('native_agent_session_v1','6b0b4c32bc97aa0ce23da93421b68c26df35e8775b9be0e9d51986e77a4c17fd','{"id":"6b0b4c32bc97aa0ce23da93421b68c26df35e8775b9be0e9d51986e77a4c17fd","label":"legacy","workspaceId":"55e304db7b22e2ae04c5e8a14fa377419406a3205d40aef970fdfb76b1075b6a","hostFingerprint":"38a53d395e5877b2ab01a36b2b2b28c3c2b8a2f643a5aec574f5965199dc55ad","activeProject":"default","context":"desktop-app","modes":["interactive","editing"],"onboardedProjects":[],"removedProjects":[],"revision":0}');
INSERT INTO "records" VALUES('snapshot-published','c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7','{"publishedAtMs":1792678394477,"snapshotId":"c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7","workspaceId":"55e304db7b22e2ae04c5e8a14fa377419406a3205d40aef970fdfb76b1075b6a"}');
CREATE TABLE snapshots(id TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "snapshots" VALUES('c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7','{"id":"c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7","workspaceId":"55e304db7b22e2ae04c5e8a14fa377419406a3205d40aef970fdfb76b1075b6a","kind":"disk","files":[{"path":"main.py","hash":"df1522f626d45daa5d2e607e16d3a14fe3a758f1979c0108fa3753912429bfde","size":48,"language":"python","mode":420}],"omissions":[],"captureConsistency":"stable-double-scan"}');
INSERT INTO sqlite_master(type,name,tbl_name,rootpage,sql)VALUES('table','symbols','symbols',0,'CREATE VIRTUAL TABLE symbols USING fts5(snapshot UNINDEXED,id UNINDEXED,name,path UNINDEXED,signature)');
INSERT INTO "symbols" VALUES('c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7','12d2032025ac1378935817d529aaaf6f57e90cdbd47bb51775a286bb7d3a9b13','main.py main.py main py main py','main.py','main.py [python]');
INSERT INTO "symbols" VALUES('c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7','8f3ce614e3ba2fb36e5c1086d42bf045d7de4b7b22d6d46159768ffd0a2b4603','visible main.py/visible visible main py visible','main.py','def visible():');
CREATE TABLE 'symbols_config'(k PRIMARY KEY, v) WITHOUT ROWID;
INSERT INTO "symbols_config" VALUES('version',4);
CREATE TABLE 'symbols_content'(id INTEGER PRIMARY KEY, c0, c1, c2, c3, c4);
INSERT INTO "symbols_content" VALUES(1,'c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7','12d2032025ac1378935817d529aaaf6f57e90cdbd47bb51775a286bb7d3a9b13','main.py main.py main py main py','main.py','main.py [python]');
INSERT INTO "symbols_content" VALUES(2,'c8b64f616da93f8d365804f85cdb259b3628832aa27a36eff0c6406ff9f693d7','8f3ce614e3ba2fb36e5c1086d42bf045d7de4b7b22d6d46159768ffd0a2b4603','visible main.py/visible visible main py visible','main.py','def visible():');
CREATE TABLE 'symbols_data'(id INTEGER PRIMARY KEY, block BLOB);
INSERT INTO "symbols_data" VALUES(1,X'020000100005');
INSERT INTO "symbols_data" VALUES(10,X'000000000101010001010101');
INSERT INTO "symbols_data" VALUES(137438953473,X'000000590430646566020601040201046D61696E0112010202040404010402010801020306010270790112010203040404010403010801020406030474686F6E0106010404010776697369626C650212010202050305010403040A17150B');
CREATE TABLE 'symbols_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
INSERT INTO "symbols_docsize" VALUES(1,X'0000080003');
INSERT INTO "symbols_docsize" VALUES(2,X'0000080002');
CREATE TABLE 'symbols_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
INSERT INTO "symbols_idx" VALUES(1,X'',2);
PRAGMA writable_schema=OFF;
COMMIT;
