from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,re,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','symbol-workspace-routes-r1').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-google-http-guard-');exec(compile(prefix,str(script),'exec'))
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
prior=w/'validation/integration-20261018/symbol-workspace-routes-preflight';pre=json.loads((prior/'result.json').read_bytes());inputs=json.loads((prior/'source-before.json').read_bytes());assert pre['complete'] and pre['allJobsEmpty'] and pre['sourceInputsUnchanged'] and len(inputs)==1048 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');assert sha(w/'native/tests/fixtures/postgres-catalog-response.jsonl')=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47'
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';targets=['workspace-lib','symbol_workspace_routes','symbol_workspace'];complete=False
try:
 for target in targets:
  deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()};(out/(target+'-before-generated.json')).write_text(json.dumps(sorted(p.name for p in before if p.suffix.lower() in ['.exe','.pdb']),indent=2)+'\n',encoding='utf8')
  command=[cargo,'test','--locked','-j','2',*(['--lib','--','session_config::'] if target=='workspace-lib' else ['--test',target,'--']),'--nocapture','--test-threads=1'];run(target,command,expected=None,timeout=600)
  assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed';assert rows[-1]['exitCode']==0,(target,rows[-1]['exitCode']);cleanup=[]
  for p in deps.iterdir():
   if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(('yoke' if target.endswith('-lib') else target)+'-'):continue
   assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h
   try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':True})
   except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
  (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n');assert rows[-1]['exitCode']==0,(target,rows[-1]['exitCode'])

 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':targets,'rows':rows},indent=2)+'\n')
assert complete
