from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/symbol-workspace-routes-compat-green';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-symbol-workspace-folders-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])
import sqlite3
redroot=w/'validation/integration-20261018/symbol-workspace-routes-compat-red';red=json.loads((redroot/'result.json').read_bytes());assert red['complete'] and red['allJobsEmpty'];source=Path(red['sourceRoot']);cwd=source
phase=w/'validation/integration-20261018/symbol-workspace-routes-final';checked=json.loads((phase/'result.json').read_bytes());frozen=json.loads((phase/'source-before.json').read_bytes());assert checked['complete'] and checked['allJobsEmpty'] and checked['cliSha256']==native_hash and len(frozen)==1048 and all(sha(w/name)==digest for name,digest in frozen.items())
def database():
 db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode()
 finally:db.close()
def source_files():return {p.relative_to(source).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(source).parts}
original_sql=(redroot/'original-store.sql').read_bytes();assert database()==original_sql and source_files()==red['sourceGitFiles'];complete=False
try:
 for label,key in [('selected-config','configArgv'),('plain-config','plainConfigArgv'),('selected-real-hover-mcp','mcpArgv')]:
  command=[str(native) if a==red['originalCli'] else a for a in red[key]];assert run('current-'+label,command)==(redroot/('old-'+label+'.stdout')).read_bytes()
 assert database()==original_sql and source_files()==red['sourceGitFiles'] and sha(Path(red['originalCli']))==red['originalCliSha256']
 for key in ['selectedProfile','plainProfile','serverConfiguration']:assert sha(Path(red[key]))==red[key+'Sha256']
 assert sha(w/'native/tests/fixtures/symbol-workspace-lsp.mjs')==red['fixtureSha256'] and all(sha(w/name)==digest for name,digest in frozen.items()) and sha(native)==native_hash
 (out/'final-store.sql').write_bytes(database());complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'originalCliSha256':red['originalCliSha256'],'cliSha256':native_hash,'selectedAndPlainConfigurationRawExact':complete,'actualSelectedHoverMcp53RawExact':complete,'wholeLogicalSqlUnchangedBeforeAndAfter':complete,'sourceGitHostProviderConfigurationAndFixtureBytesExact':complete,'frozenInputs':len(frozen),'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
