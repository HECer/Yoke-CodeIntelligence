from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/rust-rename-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-semantic-rust-live-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import sqlite3
qualified=json.loads((w/'validation/integration-20261018/dashboard-final2/result.json').read_bytes());assert qualified['complete'] and qualified['allJobsEmpty'] and qualified['cliSha256']==native_hash
inputs={n:sha(w/n) for n in json.loads((w/'validation/integration-20261018/dashboard-final2/source-before.json').read_bytes())};assert len(inputs)==1065
(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip();assert head=='d792a53ce6ddce878a39a0bfc0f239ed46bd03f3'
toolchain=Path(r'C:/Users/Lomi/.rustup/toolchains/1.94.1-x86_64-pc-windows-msvc/bin');ra=toolchain/'rust-analyzer.exe';ra_hash=sha(ra);env['PATH']=str(toolchain)+os.pathsep+env['PATH'];env['RUSTUP_HOME']=r'C:/Users/Lomi/.rustup';version=run('rust-analyzer-version',[ra,'--version']).decode().strip()
first=chr(0x130);second='i'+chr(0x307);primary='app/src/'+first;additional='app/src/'+second
(source/primary).mkdir(parents=True);(source/additional).mkdir()
(source/'app/Cargo.toml').write_bytes(b'[package]\nname="owned_rename_live_app"\nversion="0.0.0"\nedition="2021"\nbuild=false\n')
(source/'app/src/lib.rs').write_bytes(('#[path="'+first+'/mod.rs"] pub mod first;\n#[path="'+second+'/mod.rs"] pub mod second;\n').encode())
header=('// owned '+chr(0x1f4a1)+' e'+chr(0x301)+'\r\n').encode();app=header+b'pub fn local() -> u32 { 8 }\r\n';extra=header+b'pub fn helper() -> u32 { crate::first::local() }\r\n'
original={primary+'/mod.rs':app,additional+'/mod.rs':extra}
for name,data in original.items():(source/name).write_bytes(data)
profile=jobroot/'host.json';profile.write_text(json.dumps({'context':'desktop-app','languageServers':{'global':['rust']},'symbolWorkspaceFolders':{'global':[primary]},'additionalWorkspaceFolders':{'global':[additional]}}),encoding='utf8')
spec=jobroot/'servers.json';spec.write_text(json.dumps([{'backendId':'rust','command':str(ra),'configuration':{'passiveProfile':'rust_analyzer'}}]),encoding='utf8')
new_name='local_renomm'+chr(233);messages=[{'jsonrpc':'2.0','id':1,'method':'initialize'},{'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':'ci_session','arguments':{'operation':'refactor.prepare','args':{'operation':'rename','arguments':{'relativePath':primary+'/mod.rs','namePath':'local','newName':new_name}}}}}]
driver=jobroot/'client.cjs';driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync(process.argv[2],JSON.parse(process.argv[3]),{input:JSON.parse(process.argv[4]).map(m=>JSON.stringify(m)).join(String.fromCharCode(10))+String.fromCharCode(10),maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8')
before={str(p):sha(p) for p in [profile,spec,driver,*source.rglob('*.rs'),*source.rglob('Cargo.toml')]}
command=[str(native),'--root',str(source),'--timeout','60000','--max-bytes','4000000','--language-server-config',str(spec),'--trust-servers','serve-session','--id','rename-live','--profile','native','--host-profile',str(profile)]
complete=False
try:
 raw=run('actual-installed-rust-rename',[str(node),str(driver),str(native),json.dumps(command[1:]),json.dumps(messages)],timeout=120)
 responses=[json.loads(line) for line in raw.decode().splitlines()];reply=next(row['result'] for row in responses if row.get('id')==2);assert not reply['isError'],reply
 value=json.loads(reply['content'][0]['text']);assert value['status']=='ok',value;data=value['data'];plan=data['plan'];assert {f['path'] for f in plan['files']}==set(original),plan
 for f in plan['files']:
  expected=original[f['path']].replace(b'local',new_name.encode());assert f['beforeHash']==hashlib.sha256(original[f['path']]).hexdigest() and f['afterHash']==hashlib.sha256(expected).hexdigest(),f
  assert (source/'.yoke/blobs'/f['afterHash']).read_bytes()==expected
 assert all(sha(Path(n))==h for n,h in before.items()) and all(sha(w/n)==h for n,h in inputs.items()) and sha(ra)==ra_hash
 connection=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:counts=dict(connection.execute('SELECT kind,COUNT(*) FROM records GROUP BY kind'));assert counts.get('plan',0)==1 and not any(counts.get(k,0) for k in ['approval','journal','receipt']),counts
 finally:connection.close()
 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'sourceCommit':head,'cliSha256':native_hash,'frozenInputs':len(inputs),'rustAnalyzerVersion':version,'rustAnalyzerSha256':ra_hash,'ownedFixtureRoot':str(jobroot),'ownedHostAndSourceBytesExact':all(sha(Path(n))==h for n,h in before.items()),'sourceExecutionAuthorized':False,'applyCalled':False,'newName':new_name,'original':{n:hashlib.sha256(b).hexdigest() for n,b in original.items()},'all77RuntimeAcceptanceCertified':False,'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete



