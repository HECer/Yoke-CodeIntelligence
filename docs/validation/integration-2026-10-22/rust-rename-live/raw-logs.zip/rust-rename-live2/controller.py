from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/rust-rename-live2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-semantic-rust-live-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import sqlite3
prior=w/'validation/integration-20261018/rust-rename-live1';baseline=json.loads((prior/'result.json').read_bytes());assert baseline['complete'] and baseline['allJobsEmpty'] and baseline['sourceInputsUnchanged'] and baseline['cliSha256']==native_hash
inputs=json.loads((prior/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
jobroot=Path(baseline['ownedFixtureRoot']);source=jobroot/'source';cwd=source;profile=jobroot/'host.json';spec=jobroot/'servers.json';driver=jobroot/'client.cjs'
toolchain=Path(r'C:/Users/Lomi/.rustup/toolchains/1.94.1-x86_64-pc-windows-msvc/bin');ra=toolchain/'rust-analyzer.exe';assert sha(ra)==baseline['rustAnalyzerSha256'];env['PATH']=str(toolchain)+os.pathsep+env['PATH'];env['RUSTUP_HOME']=r'C:/Users/Lomi/.rustup'
rows1=[json.loads(s) for s in (prior/'actual-installed-rust-rename.stdout').read_text(encoding='utf8').splitlines()];value=json.loads(next(x['result']['content'][0]['text'] for x in rows1 if x.get('id')==2));d=value['data']
first=chr(0x130);second='i'+chr(0x307);primary='app/src/'+first;additional='app/src/'+second
assert d['sourceExecutionAuthorized']==False and d['commandsExecuted']==False and d['complete']==False and d['serverProfileBinding']['contentHash']==baseline['rustAnalyzerSha256'] and d['selectedBackendId']=='rust'
assert d['additionalWorkspaceFolders']==[additional] and d['additionalWorkspaceScope']['sourceCaptureWidened']==False
original=(source/(primary+'/mod.rs')).read_bytes();target=d['intent']['source'];assert target['contentHash']==hashlib.sha256(original).hexdigest() and target['nameStartByte']==original.index(b'local') and target['nameEndByte']==original.index(b'local')+5
before={str(p):sha(p) for p in [profile,spec,driver,*source.rglob('*.rs'),*source.rglob('Cargo.toml')]}
readonly=jobroot/'read-only-host.json';readonly.write_text(json.dumps({**json.loads(profile.read_bytes()),'primaryReadOnly':True}),encoding='utf8')
base_request={'operation':'refactor.prepare','args':{'operation':'rename','arguments':{'relativePath':primary+'/mod.rs','namePath':'local','newName':baseline['newName']}}}
def invoke(name,selected,session,calls):
 messages=[{'jsonrpc':'2.0','id':1,'method':'initialize'},*[{'jsonrpc':'2.0','id':i+2,'method':'tools/call','params':{'name':'ci_session','arguments':call}} for i,call in enumerate(calls)]]
 command=[str(native),'--root',str(source),'--timeout','60000','--max-bytes','4000000','--language-server-config',str(spec),'--trust-servers','serve-session','--id',session,'--profile','native','--host-profile',str(selected)]
 raw=run(name,[str(node),str(driver),str(native),json.dumps(command[1:]),json.dumps(messages)],expected=None,timeout=120)
 return [json.loads(line) for line in raw.decode().splitlines()]
complete=False
try:
 refused=invoke('read-only-refuses-rename',readonly,'read-only-live',[base_request]);response=next(r['result'] for r in refused if r.get('id')==2);assert response['isError'] and 'read-only' in response['content'][0]['text'].lower(),response
 refused=invoke('stale-host-binding-refuses-before-mcp',readonly,'rename-live',[base_request]);assert rows[-1]['exitCode']==1 and b'host' in (out/'stale-host-binding-refuses-before-mcp.stderr').read_bytes().lower()
 invalid=json.loads(json.dumps(base_request));invalid['args']['arguments']['newName']='../../escape'
 refused=invoke('invalid-identifier-refuses',profile,'invalid-name-live',[invalid]);response=next(r['result'] for r in refused if r.get('id')==2);assert response['isError'],response
 refused=invoke('planning-refuses-rename',profile,'planning-live',[{'operation':'switchModes','args':{'modes':['planning']}},base_request]);response=next(r['result'] for r in refused if r.get('id')==3);assert response['isError'] and 'editing disabled' in response['content'][0]['text'].lower(),response
 connection=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:counts=dict(connection.execute('SELECT kind,COUNT(*) FROM records GROUP BY kind'));assert counts.get('plan',0)==1 and not any(counts.get(k,0) for k in ['approval','journal','receipt']),counts
 finally:connection.close()
 assert all(sha(Path(n))==h for n,h in before.items()) and all(sha(w/n)==h for n,h in inputs.items()) and sha(ra)==baseline['rustAnalyzerSha256'];complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'cliSha256':native_hash,'frozenInputs':len(inputs),'originalIntentUtf8SourceHashAndNameOffsetsExact':True,'actualSelectedExecutableHashBound':True,'sourceExecutionAuthorized':d['sourceExecutionAuthorized'],'commandsExecuted':d['commandsExecuted'],'sourceCaptureWidened':d['additionalWorkspaceScope']['sourceCaptureWidened'],'readOnlyPlanningStaleHostAndInvalidIdentifierRefused':complete,'noNewPlansOrApprovalJournalReceipt':complete,'ownedHostAndSourceBytesExact':all(sha(Path(n))==h for n,h in before.items()),'all77RuntimeAcceptanceCertified':False,'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete

