BEGIN TRANSACTION;
CREATE TABLE cache(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "cache" VALUES('f810ff40cab253fa6fb00df3ee3ba69204a39da1dc27022823f0d41f21b469e3','{"entities":[{"id":"","key":".gitignore:file:0","snapshotId":"","path":".gitignore","name":".gitignore","qualifiedName":".gitignore","kind":"file","language":"text","signature":".gitignore [text]","startByte":0,"endByte":25,"startLine":1,"endLine":2,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"}],"edges":[],"diagnostics":[],"resolution":{"language":"","scopes":[],"bindings":[],"uses":[]}}');
INSERT INTO "cache" VALUES('aa68b86ee8848846632f97ac74681cf85a1e79ea5a7fed826303d0b47db13ab6','{"entities":[{"id":"","key":".ignore:file:0","snapshotId":"","path":".ignore","name":".ignore","qualifiedName":".ignore","kind":"file","language":"text","signature":".ignore [text]","startByte":0,"endByte":19,"startLine":1,"endLine":1,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"}],"edges":[],"diagnostics":[],"resolution":{"language":"","scopes":[],"bindings":[],"uses":[]}}');
INSERT INTO "cache" VALUES('9dd3a6a2eaf2dddb3a090dac57a3e2cedc06689188510d604f08a3c363c9aca0','{"entities":[{"id":"","key":"main.rs:file:0","snapshotId":"","path":"main.rs","name":"main.rs","qualifiedName":"main.rs","kind":"file","language":"rust","signature":"main.rs [rust]","startByte":0,"endByte":36,"startLine":1,"endLine":2,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"","key":"main.rs:function:19","snapshotId":"","path":"main.rs","name":"visible","qualifiedName":"main.rs/visible","kind":"function","language":"rust","signature":"fn visible()","startByte":19,"endByte":34,"startLine":2,"endLine":2,"nameStartByte":22,"nameEndByte":29,"parentKey":"main.rs:file:0","producer":"yoke-tree-sitter-8"}],"edges":[{"sourceKey":"main.rs:file:0","targetLabel":"main.rs:function:19","relation":"contains","startByte":19,"endByte":34,"startLine":2,"endLine":2}],"diagnostics":[],"resolution":{"language":"rust","scopes":[{"start":0,"end":36,"parent":null,"function":false},{"start":19,"end":34,"parent":0,"function":true},{"start":32,"end":34,"parent":1,"function":false}],"bindings":[{"scope":0,"name":"visible","definedAt":0,"target":{"kind":"entity","value":"main.rs:function:19"}}],"uses":[]}}');
PRAGMA writable_schema=ON;
INSERT INTO sqlite_master(type,name,tbl_name,rootpage,sql)VALUES('table','documents','documents',0,'CREATE VIRTUAL TABLE documents USING fts5(snapshot UNINDEXED,path UNINDEXED,text)');
INSERT INTO "documents" VALUES('73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','.gitignore','ignored/
root-ignored.rs
');
INSERT INTO "documents" VALUES('73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','.ignore','ordinary-ignore.rs
');
INSERT INTO "documents" VALUES('73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','main.rs','// owned 💡 é
fn visible() {}
');
CREATE TABLE 'documents_config'(k PRIMARY KEY, v) WITHOUT ROWID;
INSERT INTO "documents_config" VALUES('version',4);
CREATE TABLE 'documents_content'(id INTEGER PRIMARY KEY, c0, c1, c2);
INSERT INTO "documents_content" VALUES(1,'73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','.gitignore','ignored/
root-ignored.rs
');
INSERT INTO "documents_content" VALUES(2,'73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','.ignore','ordinary-ignore.rs
');
INSERT INTO "documents_content" VALUES(3,'73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','main.rs','// owned 💡 é
fn visible() {}
');
CREATE TABLE 'documents_data'(id INTEGER PRIMARY KEY, block BLOB);
INSERT INTO "documents_data" VALUES(1,X'0300000B');
INSERT INTO "documents_data" VALUES(10,X'000000000101010001010101');
INSERT INTO "documents_data" VALUES(137438953473,X'0000006B02306503060102030102666E0306010204010669676E6F7265020601020307016401080102020401086F7264696E61727902060102020204776E656403060102020104726F6F74010601020302017301060102050106010204010776697369626C6503060102050408090D090F0B0B0D');
CREATE TABLE 'documents_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
INSERT INTO "documents_docsize" VALUES(1,X'000004');
INSERT INTO "documents_docsize" VALUES(2,X'000003');
INSERT INTO "documents_docsize" VALUES(3,X'000004');
CREATE TABLE 'documents_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
INSERT INTO "documents_idx" VALUES(1,X'',2);
CREATE TABLE graphs(id TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "graphs" VALUES('73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','{"snapshotId":"73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59","entities":[{"id":"d02aa75060ea980f813a1df917a549aad16b2592459dc95065434a5f13c60d53","key":".gitignore:file:0","snapshotId":"73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59","path":".gitignore","name":".gitignore","qualifiedName":".gitignore","kind":"file","language":"text","signature":".gitignore [text]","startByte":0,"endByte":25,"startLine":1,"endLine":2,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"d21e636ef358524010bb712e8156d9d9137865ed8c6dcc7973c5a9b1f0949b73","key":".ignore:file:0","snapshotId":"73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59","path":".ignore","name":".ignore","qualifiedName":".ignore","kind":"file","language":"text","signature":".ignore [text]","startByte":0,"endByte":19,"startLine":1,"endLine":1,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"d15f119e7f88cbe3f254399275ad8535fb9db70654ef30de16cd502f76f24d9f","key":"main.rs:file:0","snapshotId":"73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59","path":"main.rs","name":"main.rs","qualifiedName":"main.rs","kind":"file","language":"rust","signature":"main.rs [rust]","startByte":0,"endByte":36,"startLine":1,"endLine":2,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"003a336c08b943dbaaf32373b79eb4fb72338af2c2e3c0f57d03a41bc984d623","key":"main.rs:function:19","snapshotId":"73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59","path":"main.rs","name":"visible","qualifiedName":"main.rs/visible","kind":"function","language":"rust","signature":"fn visible()","startByte":19,"endByte":34,"startLine":2,"endLine":2,"nameStartByte":22,"nameEndByte":29,"parentKey":"main.rs:file:0","producer":"yoke-tree-sitter-8"}],"observations":[{"id":"a71e0c937578eb15e65a4567d677ed7298fed81bebec63ba94fd9f0828e938c5","snapshotId":"73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59","source":"d15f119e7f88cbe3f254399275ad8535fb9db70654ef30de16cd502f76f24d9f","target":"003a336c08b943dbaaf32373b79eb4fb72338af2c2e3c0f57d03a41bc984d623","targetLabel":"main.rs:function:19","relation":"contains","resolution":"syntactic","evidenceIds":["382b316a79d745ea483482dc6bc7efb7d4af195a18a39a22cccefc93c21318fc"],"producer":"yoke-tree-sitter-8"}],"evidence":[{"id":"382b316a79d745ea483482dc6bc7efb7d4af195a18a39a22cccefc93c21318fc","snapshotId":"73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59","path":"main.rs","contentHash":"554cf3eb6f27a8676d591e4738494b1bc2c81d1a332f8d81653645e994c89b7f","startByte":19,"endByte":34,"startLine":2,"endLine":2,"anchor":"exact","trust":"source-data","producer":"yoke-tree-sitter-8"}],"diagnostics":[],"coverage":{"indexedFiles":3,"sourceFiles":3,"languages":{"rust":1,"text":2},"unresolved":0,"omissions":1,"exhaustive":false,"semantic":false,"limitations":["Structural candidate resolution is not compiler binding or exhaustive runtime coverage.","Unsupported text formats have full-text search but no AST semantics. Binary/media files are explicitly omitted.","Lexical/import/receiver bindings are syntax-local candidates. Parallel targets preserve possible dispatch; dynamic assignment, dependencies and runtime targets remain nonexhaustive."]}}');
CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "meta" VALUES('workspace','51df5512537141c88bc9d5090eb839e4e604c2668f4ae5f1f66c0bf6d61d9be1');
INSERT INTO "meta" VALUES('latest','73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59');
INSERT INTO "meta" VALUES('last_disk_index_snapshot_id','73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59');
CREATE TABLE records(kind TEXT NOT NULL,id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(kind,id));
INSERT INTO "records" VALUES('native_agent_session_v1','fdd1d011ff5345d99c6560ddd5a17d6fbd4fb9d724ca59c7f78c8131d27c6892','{"id":"fdd1d011ff5345d99c6560ddd5a17d6fbd4fb9d724ca59c7f78c8131d27c6892","label":"legacy","workspaceId":"51df5512537141c88bc9d5090eb839e4e604c2668f4ae5f1f66c0bf6d61d9be1","hostFingerprint":"494bea712331038e530d27a4d9f11c1693ae133ed284f7c05758cb056cbbff4b","activeProject":"default","context":"desktop-app","modes":["interactive","editing"],"onboardedProjects":[],"removedProjects":[],"revision":0}');
INSERT INTO "records" VALUES('snapshot-published','73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','{"publishedAtMs":1792676324576,"snapshotId":"73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59","workspaceId":"51df5512537141c88bc9d5090eb839e4e604c2668f4ae5f1f66c0bf6d61d9be1"}');
CREATE TABLE snapshots(id TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "snapshots" VALUES('73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','{"id":"73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59","workspaceId":"51df5512537141c88bc9d5090eb839e4e604c2668f4ae5f1f66c0bf6d61d9be1","kind":"disk","files":[{"path":".gitignore","hash":"3176e0a4911316f31f37afcb0dc65bfb15e187a314eb744e858c64dab64d8ae3","size":25,"language":"text","mode":420},{"path":".ignore","hash":"7e3bd707039b010a88b409cdc71e520b0d5e4382f568879a3e0ed69ae2a4123d","size":19,"language":"text","mode":420},{"path":"main.rs","hash":"554cf3eb6f27a8676d591e4738494b1bc2c81d1a332f8d81653645e994c89b7f","size":36,"language":"rust","mode":420}],"omissions":[{"path":".env","reason":"protected-path"}],"captureConsistency":"stable-double-scan"}');
INSERT INTO sqlite_master(type,name,tbl_name,rootpage,sql)VALUES('table','symbols','symbols',0,'CREATE VIRTUAL TABLE symbols USING fts5(snapshot UNINDEXED,id UNINDEXED,name,path UNINDEXED,signature)');
INSERT INTO "symbols" VALUES('73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','d02aa75060ea980f813a1df917a549aad16b2592459dc95065434a5f13c60d53','.gitignore .gitignore  gitignore  gitignore','.gitignore','.gitignore [text]');
INSERT INTO "symbols" VALUES('73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','d21e636ef358524010bb712e8156d9d9137865ed8c6dcc7973c5a9b1f0949b73','.ignore .ignore  ignore  ignore','.ignore','.ignore [text]');
INSERT INTO "symbols" VALUES('73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','d15f119e7f88cbe3f254399275ad8535fb9db70654ef30de16cd502f76f24d9f','main.rs main.rs main rs main rs','main.rs','main.rs [rust]');
INSERT INTO "symbols" VALUES('73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','003a336c08b943dbaaf32373b79eb4fb72338af2c2e3c0f57d03a41bc984d623','visible main.rs/visible visible main rs visible','main.rs','fn visible()');
CREATE TABLE 'symbols_config'(k PRIMARY KEY, v) WITHOUT ROWID;
INSERT INTO "symbols_config" VALUES('version',4);
CREATE TABLE 'symbols_content'(id INTEGER PRIMARY KEY, c0, c1, c2, c3, c4);
INSERT INTO "symbols_content" VALUES(1,'73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','d02aa75060ea980f813a1df917a549aad16b2592459dc95065434a5f13c60d53','.gitignore .gitignore  gitignore  gitignore','.gitignore','.gitignore [text]');
INSERT INTO "symbols_content" VALUES(2,'73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','d21e636ef358524010bb712e8156d9d9137865ed8c6dcc7973c5a9b1f0949b73','.ignore .ignore  ignore  ignore','.ignore','.ignore [text]');
INSERT INTO "symbols_content" VALUES(3,'73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','d15f119e7f88cbe3f254399275ad8535fb9db70654ef30de16cd502f76f24d9f','main.rs main.rs main rs main rs','main.rs','main.rs [rust]');
INSERT INTO "symbols_content" VALUES(4,'73af5faeeb3abdf10d75206274c7c9190c137b5cc9348af8d95726d0bc709d59','003a336c08b943dbaaf32373b79eb4fb72338af2c2e3c0f57d03a41bc984d623','visible main.rs/visible visible main rs visible','main.rs','fn visible()');
CREATE TABLE 'symbols_data'(id INTEGER PRIMARY KEY, block BLOB);
INSERT INTO "symbols_data" VALUES(1,X'040000180009');
INSERT INTO "symbols_data" VALUES(10,X'000000000101010001010101');
INSERT INTO "symbols_data" VALUES(137438953473,X'000000900330666E0406010402010967697469676E6F72650112010202030303010402010669676E6F7265021201020203030301040201046D61696E03120102020404040104020108010203060102727303120102030404040104030108010204060203757374030601040401047465787401060104030106010403010776697369626C6504120102020503050104030409161317150A10');
CREATE TABLE 'symbols_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
INSERT INTO "symbols_docsize" VALUES(1,X'0000040002');
INSERT INTO "symbols_docsize" VALUES(2,X'0000040002');
INSERT INTO "symbols_docsize" VALUES(3,X'0000080003');
INSERT INTO "symbols_docsize" VALUES(4,X'0000080002');
CREATE TABLE 'symbols_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
INSERT INTO "symbols_idx" VALUES(1,X'',2);
PRAGMA writable_schema=OFF;
COMMIT;
