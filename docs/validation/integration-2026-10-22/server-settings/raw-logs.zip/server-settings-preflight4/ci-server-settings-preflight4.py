from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/server-settings-preflight4';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import re,traceback
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
old=json.loads((w/'validation/integration-20261018/git-ignore-policy-final3/source-before.json').read_bytes())
for name in ['native/src/server_settings.rs','native/tests/server_settings.rs','native/tests/fixtures/server-settings-lsp.mjs']:old[name]='new'
inputs={n:sha(w/n) for n in old};assert len(inputs)==1057;(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');assert sha(w/'native/tests/fixtures/postgres-catalog-response.jsonl')=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47'
complete=False
try:
 run('clippy',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','clippy','--locked','--all-targets','-j','2','--','-D','warnings'],timeout=600);assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
