BEGIN TRANSACTION;
CREATE TABLE cache(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "cache" VALUES('f810ff40cab253fa6fb00df3ee3ba69204a39da1dc27022823f0d41f21b469e3','{"entities":[{"id":"","key":".gitignore:file:0","snapshotId":"","path":".gitignore","name":".gitignore","qualifiedName":".gitignore","kind":"file","language":"text","signature":".gitignore [text]","startByte":0,"endByte":25,"startLine":1,"endLine":2,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"}],"edges":[],"diagnostics":[],"resolution":{"language":"","scopes":[],"bindings":[],"uses":[]}}');
INSERT INTO "cache" VALUES('aa68b86ee8848846632f97ac74681cf85a1e79ea5a7fed826303d0b47db13ab6','{"entities":[{"id":"","key":".ignore:file:0","snapshotId":"","path":".ignore","name":".ignore","qualifiedName":".ignore","kind":"file","language":"text","signature":".ignore [text]","startByte":0,"endByte":19,"startLine":1,"endLine":1,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"}],"edges":[],"diagnostics":[],"resolution":{"language":"","scopes":[],"bindings":[],"uses":[]}}');
INSERT INTO "cache" VALUES('9dd3a6a2eaf2dddb3a090dac57a3e2cedc06689188510d604f08a3c363c9aca0','{"entities":[{"id":"","key":"main.rs:file:0","snapshotId":"","path":"main.rs","name":"main.rs","qualifiedName":"main.rs","kind":"file","language":"rust","signature":"main.rs [rust]","startByte":0,"endByte":36,"startLine":1,"endLine":2,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"","key":"main.rs:function:19","snapshotId":"","path":"main.rs","name":"visible","qualifiedName":"main.rs/visible","kind":"function","language":"rust","signature":"fn visible()","startByte":19,"endByte":34,"startLine":2,"endLine":2,"nameStartByte":22,"nameEndByte":29,"parentKey":"main.rs:file:0","producer":"yoke-tree-sitter-8"}],"edges":[{"sourceKey":"main.rs:file:0","targetLabel":"main.rs:function:19","relation":"contains","startByte":19,"endByte":34,"startLine":2,"endLine":2}],"diagnostics":[],"resolution":{"language":"rust","scopes":[{"start":0,"end":36,"parent":null,"function":false},{"start":19,"end":34,"parent":0,"function":true},{"start":32,"end":34,"parent":1,"function":false}],"bindings":[{"scope":0,"name":"visible","definedAt":0,"target":{"kind":"entity","value":"main.rs:function:19"}}],"uses":[]}}');
PRAGMA writable_schema=ON;
INSERT INTO sqlite_master(type,name,tbl_name,rootpage,sql)VALUES('table','documents','documents',0,'CREATE VIRTUAL TABLE documents USING fts5(snapshot UNINDEXED,path UNINDEXED,text)');
INSERT INTO "documents" VALUES('1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','.gitignore','ignored/
root-ignored.rs
');
INSERT INTO "documents" VALUES('1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','.ignore','ordinary-ignore.rs
');
INSERT INTO "documents" VALUES('1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','main.rs','// owned 💡 é
fn visible() {}
');
CREATE TABLE 'documents_config'(k PRIMARY KEY, v) WITHOUT ROWID;
INSERT INTO "documents_config" VALUES('version',4);
CREATE TABLE 'documents_content'(id INTEGER PRIMARY KEY, c0, c1, c2);
INSERT INTO "documents_content" VALUES(1,'1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','.gitignore','ignored/
root-ignored.rs
');
INSERT INTO "documents_content" VALUES(2,'1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','.ignore','ordinary-ignore.rs
');
INSERT INTO "documents_content" VALUES(3,'1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','main.rs','// owned 💡 é
fn visible() {}
');
CREATE TABLE 'documents_data'(id INTEGER PRIMARY KEY, block BLOB);
INSERT INTO "documents_data" VALUES(1,X'0300000B');
INSERT INTO "documents_data" VALUES(10,X'000000000101010001010101');
INSERT INTO "documents_data" VALUES(137438953473,X'0000006B02306503060102030102666E0306010204010669676E6F7265020601020307016401080102020401086F7264696E61727902060102020204776E656403060102020104726F6F74010601020302017301060102050106010204010776697369626C6503060102050408090D090F0B0B0D');
CREATE TABLE 'documents_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
INSERT INTO "documents_docsize" VALUES(1,X'000004');
INSERT INTO "documents_docsize" VALUES(2,X'000003');
INSERT INTO "documents_docsize" VALUES(3,X'000004');
CREATE TABLE 'documents_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
INSERT INTO "documents_idx" VALUES(1,X'',2);
CREATE TABLE graphs(id TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "graphs" VALUES('1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','{"snapshotId":"1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219","entities":[{"id":"736bd5bedd3eee48fef48af0a71d03b77dbbf2fc71e03f73d5f80e4e661ac1cc","key":".gitignore:file:0","snapshotId":"1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219","path":".gitignore","name":".gitignore","qualifiedName":".gitignore","kind":"file","language":"text","signature":".gitignore [text]","startByte":0,"endByte":25,"startLine":1,"endLine":2,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"938f0ced160fdf243b9e2f8d34140e4be8c5c9193bcf380f22ab4de3c39ab473","key":".ignore:file:0","snapshotId":"1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219","path":".ignore","name":".ignore","qualifiedName":".ignore","kind":"file","language":"text","signature":".ignore [text]","startByte":0,"endByte":19,"startLine":1,"endLine":1,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"9f8256500080b1fa057bb5d86ecaeccb74cacad793097fca4c20829ec2379a6b","key":"main.rs:file:0","snapshotId":"1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219","path":"main.rs","name":"main.rs","qualifiedName":"main.rs","kind":"file","language":"rust","signature":"main.rs [rust]","startByte":0,"endByte":36,"startLine":1,"endLine":2,"nameStartByte":null,"nameEndByte":null,"parentKey":null,"producer":"yoke-tree-sitter-8"},{"id":"0ba1ecc74ef92af550a1824f0f9a10a8aac40a424d14c604491d1cb54c084804","key":"main.rs:function:19","snapshotId":"1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219","path":"main.rs","name":"visible","qualifiedName":"main.rs/visible","kind":"function","language":"rust","signature":"fn visible()","startByte":19,"endByte":34,"startLine":2,"endLine":2,"nameStartByte":22,"nameEndByte":29,"parentKey":"main.rs:file:0","producer":"yoke-tree-sitter-8"}],"observations":[{"id":"7f53b78012b8456ee66f2296d642a61e1781c8490e2d21645caf5d6eb4d2b376","snapshotId":"1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219","source":"9f8256500080b1fa057bb5d86ecaeccb74cacad793097fca4c20829ec2379a6b","target":"0ba1ecc74ef92af550a1824f0f9a10a8aac40a424d14c604491d1cb54c084804","targetLabel":"main.rs:function:19","relation":"contains","resolution":"syntactic","evidenceIds":["4b898a8aff99632dded70e643c5e033390e5c9a19a812790dcb46a08e480702b"],"producer":"yoke-tree-sitter-8"}],"evidence":[{"id":"4b898a8aff99632dded70e643c5e033390e5c9a19a812790dcb46a08e480702b","snapshotId":"1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219","path":"main.rs","contentHash":"554cf3eb6f27a8676d591e4738494b1bc2c81d1a332f8d81653645e994c89b7f","startByte":19,"endByte":34,"startLine":2,"endLine":2,"anchor":"exact","trust":"source-data","producer":"yoke-tree-sitter-8"}],"diagnostics":[],"coverage":{"indexedFiles":3,"sourceFiles":3,"languages":{"rust":1,"text":2},"unresolved":0,"omissions":1,"exhaustive":false,"semantic":false,"limitations":["Structural candidate resolution is not compiler binding or exhaustive runtime coverage.","Unsupported text formats have full-text search but no AST semantics. Binary/media files are explicitly omitted.","Lexical/import/receiver bindings are syntax-local candidates. Parallel targets preserve possible dispatch; dynamic assignment, dependencies and runtime targets remain nonexhaustive."]}}');
CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "meta" VALUES('workspace','ed2294fd4393d1e334940d3da98bcf7df19b9b6a3d98ac7b958ac3b2029a9144');
INSERT INTO "meta" VALUES('latest','1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219');
INSERT INTO "meta" VALUES('last_disk_index_snapshot_id','1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219');
CREATE TABLE records(kind TEXT NOT NULL,id TEXT NOT NULL,value TEXT NOT NULL,PRIMARY KEY(kind,id));
INSERT INTO "records" VALUES('native_agent_session_v1','160b34d0d4581989e692992522d0df326c127a5376281bebedfdf12c6625da82','{"id":"160b34d0d4581989e692992522d0df326c127a5376281bebedfdf12c6625da82","label":"legacy","workspaceId":"ed2294fd4393d1e334940d3da98bcf7df19b9b6a3d98ac7b958ac3b2029a9144","hostFingerprint":"c75e76fb0f150ef99e9874077c6abb43a0df0cd1ac5591a5ff86df048879db17","activeProject":"default","context":"desktop-app","modes":["interactive","editing"],"onboardedProjects":[],"removedProjects":[],"revision":0}');
INSERT INTO "records" VALUES('snapshot-published','1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','{"publishedAtMs":1792670674084,"snapshotId":"1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219","workspaceId":"ed2294fd4393d1e334940d3da98bcf7df19b9b6a3d98ac7b958ac3b2029a9144"}');
CREATE TABLE snapshots(id TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO "snapshots" VALUES('1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','{"id":"1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219","workspaceId":"ed2294fd4393d1e334940d3da98bcf7df19b9b6a3d98ac7b958ac3b2029a9144","kind":"disk","files":[{"path":".gitignore","hash":"3176e0a4911316f31f37afcb0dc65bfb15e187a314eb744e858c64dab64d8ae3","size":25,"language":"text","mode":420},{"path":".ignore","hash":"7e3bd707039b010a88b409cdc71e520b0d5e4382f568879a3e0ed69ae2a4123d","size":19,"language":"text","mode":420},{"path":"main.rs","hash":"554cf3eb6f27a8676d591e4738494b1bc2c81d1a332f8d81653645e994c89b7f","size":36,"language":"rust","mode":420}],"omissions":[{"path":".env","reason":"protected-path"}],"captureConsistency":"stable-double-scan"}');
INSERT INTO sqlite_master(type,name,tbl_name,rootpage,sql)VALUES('table','symbols','symbols',0,'CREATE VIRTUAL TABLE symbols USING fts5(snapshot UNINDEXED,id UNINDEXED,name,path UNINDEXED,signature)');
INSERT INTO "symbols" VALUES('1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','736bd5bedd3eee48fef48af0a71d03b77dbbf2fc71e03f73d5f80e4e661ac1cc','.gitignore .gitignore  gitignore  gitignore','.gitignore','.gitignore [text]');
INSERT INTO "symbols" VALUES('1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','938f0ced160fdf243b9e2f8d34140e4be8c5c9193bcf380f22ab4de3c39ab473','.ignore .ignore  ignore  ignore','.ignore','.ignore [text]');
INSERT INTO "symbols" VALUES('1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','9f8256500080b1fa057bb5d86ecaeccb74cacad793097fca4c20829ec2379a6b','main.rs main.rs main rs main rs','main.rs','main.rs [rust]');
INSERT INTO "symbols" VALUES('1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','0ba1ecc74ef92af550a1824f0f9a10a8aac40a424d14c604491d1cb54c084804','visible main.rs/visible visible main rs visible','main.rs','fn visible()');
CREATE TABLE 'symbols_config'(k PRIMARY KEY, v) WITHOUT ROWID;
INSERT INTO "symbols_config" VALUES('version',4);
CREATE TABLE 'symbols_content'(id INTEGER PRIMARY KEY, c0, c1, c2, c3, c4);
INSERT INTO "symbols_content" VALUES(1,'1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','736bd5bedd3eee48fef48af0a71d03b77dbbf2fc71e03f73d5f80e4e661ac1cc','.gitignore .gitignore  gitignore  gitignore','.gitignore','.gitignore [text]');
INSERT INTO "symbols_content" VALUES(2,'1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','938f0ced160fdf243b9e2f8d34140e4be8c5c9193bcf380f22ab4de3c39ab473','.ignore .ignore  ignore  ignore','.ignore','.ignore [text]');
INSERT INTO "symbols_content" VALUES(3,'1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','9f8256500080b1fa057bb5d86ecaeccb74cacad793097fca4c20829ec2379a6b','main.rs main.rs main rs main rs','main.rs','main.rs [rust]');
INSERT INTO "symbols_content" VALUES(4,'1a09e7fe47ef7c039c844579f7d3bd7eec05581e394ff793d7974ca11e796219','0ba1ecc74ef92af550a1824f0f9a10a8aac40a424d14c604491d1cb54c084804','visible main.rs/visible visible main rs visible','main.rs','fn visible()');
CREATE TABLE 'symbols_data'(id INTEGER PRIMARY KEY, block BLOB);
INSERT INTO "symbols_data" VALUES(1,X'040000180009');
INSERT INTO "symbols_data" VALUES(10,X'000000000101010001010101');
INSERT INTO "symbols_data" VALUES(137438953473,X'000000900330666E0406010402010967697469676E6F72650112010202030303010402010669676E6F7265021201020203030301040201046D61696E03120102020404040104020108010203060102727303120102030404040104030108010204060203757374030601040401047465787401060104030106010403010776697369626C6504120102020503050104030409161317150A10');
CREATE TABLE 'symbols_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
INSERT INTO "symbols_docsize" VALUES(1,X'0000040002');
INSERT INTO "symbols_docsize" VALUES(2,X'0000040002');
INSERT INTO "symbols_docsize" VALUES(3,X'0000080003');
INSERT INTO "symbols_docsize" VALUES(4,X'0000080002');
CREATE TABLE 'symbols_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
INSERT INTO "symbols_idx" VALUES(1,X'',2);
PRAGMA writable_schema=OFF;
COMMIT;
