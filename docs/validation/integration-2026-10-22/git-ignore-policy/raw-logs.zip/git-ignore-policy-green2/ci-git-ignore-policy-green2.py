from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/git-ignore-policy-green2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-symbol-workspace-folders-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])
import sqlite3,collections
redroot=w/'validation/integration-20261018/git-ignore-policy-red2';red=json.loads((redroot/'result.json').read_bytes());assert red['complete'] and red['allJobsEmpty'];original_command_binary=red['configArgv'][0]
for argument_key in ['configArgv','mcpArgv','selectedArgv']:red[argument_key]=[str(native) if str(value)==original_command_binary else value for value in red[argument_key]]
source=Path(red['sourceRoot']);cwd=source
phase=w/'validation/integration-20261018/git-ignore-policy-r5';checked=json.loads((phase/'result.json').read_bytes());frozen=json.loads((phase/'source-before.json').read_bytes());assert checked['complete'] and checked['allJobsEmpty'] and checked['cliSha256']==native_hash and len(frozen)==1054 and all(sha(w/name)==digest for name,digest in frozen.items())
def database():
 db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:
  tables={table:dict(db.execute('SELECT '+key+',value FROM '+table)) for table,key in [('snapshots','id'),('graphs','id'),('cache','key'),('meta','key')]}
  tables['records']={(kind,record_id):value for kind,record_id,value in db.execute('SELECT kind,id,value FROM records')}
  tables['symbols']=collections.Counter(db.execute('SELECT snapshot,id,name,path,signature FROM symbols'))
  tables['documents']=collections.Counter(db.execute('SELECT snapshot,path,text FROM documents'))
  return ('\n'.join(db.iterdump())+'\n').encode(),tables
 finally:db.close()
def source_files():return {path.relative_to(source).as_posix():{'bytes':path.stat().st_size,'sha256':sha(path)} for path in source.rglob('*') if path.is_file() and '.yoke' not in path.relative_to(source).parts}
def replacement(command,mapping):return [mapping.get(str(arg),str(arg)) for arg in command]
def config_command(profile_path,label):return replacement(red['configArgv'],{red['legacyProfile']:str(profile_path),'legacy':label})
def mcp_command(profile_path,label):
 command=list(red['mcpArgv']);command[3]=json.dumps(replacement(json.loads(command[3]),{red['legacyProfile']:str(profile_path),'legacy':label}));return command
def mcp_data(raw,default_skip=None):
 replies=[json.loads(line) for line in raw.decode().splitlines()];assert len(next(value['result']['tools'] for value in replies if value.get('id')==2))==53;catalog=next(value['result']['tools'] for value in replies if value.get('id')==2)
 if default_skip is not None:assert next(tool for tool in catalog if tool['name']=='search_for_pattern')['inputSchema']['properties']['skip_ignored_files']['default']==default_skip
 reply=next(value['result'] for value in replies if value.get('id')==3);assert not reply['isError'],reply;outer=json.loads(reply['content'][0]['text']);assert outer['status']=='ok',outer;return outer['data']
original_sql,original=database();assert original_sql==(redroot/'original-store.sql').read_bytes() and source_files()==red['sourceGitFiles'];complete=False
try:
 for name,key,expected in [('config','configArgv','old-legacy-config.stdout'),('mcp','mcpArgv','old-legacy-mcp53-symbols.stdout')]:assert run('legacy-absent-'+name,red[key])==(redroot/expected).read_bytes()
 base=json.loads(Path(red['legacyProfile']).read_bytes())
 for label,value in [('null',None),('empty',{})]:
  profile=jobroot/(label+'.json');profile.write_text(json.dumps({**base,'gitIgnore':value}),encoding='utf8');assert run('legacy-'+label+'-config',config_command(profile,'legacy'))==(redroot/'old-legacy-config.stdout').read_bytes();assert run('legacy-'+label+'-mcp',mcp_command(profile,'legacy'))==(redroot/'old-legacy-mcp53-symbols.stdout').read_bytes()
 assert database()[0]==original_sql;(out/'legacy-whole-store-before-selection.sql').write_bytes(database()[0])
 selected=Path(red['selectedProfile']);configuration=json.loads(run('selected-config',config_command(selected,'selected')))['results'][0];assert configuration['gitIgnore']=={'global':False} and configuration['gitIgnoreResolved']==False
 value=mcp_data(run('selected-symbols-mcp53',mcp_command(selected,'selected')),False);names={item['name'] for item in value['items']};assert {'visible','ignored_root','ignored_nested'}<=names and not {'ordinary_filtered','hard_target','hard_dependency'}&names
 workspace=jobroot/'workspace.json';workspace.write_text(json.dumps({**base,'gitIgnore':{'global':False},'symbolWorkspaceFolders':{'global':['ignored']}}),encoding='utf8');value=mcp_data(run('selected-workspace-ignored-symbols-mcp53',mcp_command(workspace,'workspace')),False);assert len(value['items'])==1 and value['items'][0]['path']=='ignored/'+chr(233)+'.rs' and value['symbolIndexScope']['sourcesInScope']==1
 filtered=jobroot/'filtered.json';filtered.write_text(json.dumps({**base,'gitIgnore':{'global':True}}),encoding='utf8');value=mcp_data(run('explicit-true-keeps-original-filter',mcp_command(filtered,'filtered')),True);assert any(item['name']=='visible' for item in value['items']) and not any(item['name'].startswith('ignored_') for item in value['items'])
 driver=jobroot/'pattern.cjs';messages=[{'jsonrpc':'2.0','id':1,'method':'initialize'},{'jsonrpc':'2.0','id':2,'method':'tools/list'},{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'search_for_pattern','arguments':{'substring_pattern':'ignored_nested'}}}];driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync(process.argv[2],JSON.parse(process.argv[3]),{input:"+json.dumps('\n'.join(json.dumps(message,separators=(',',':')) for message in messages)+'\n')+",maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8');command=mcp_command(selected,'selected');command[1]=str(driver);assert mcp_data(run('actual-pattern-default-honors-selected-analysis',command),False)['total']==1
 other=jobroot/'catalog-other';other.mkdir();(other/'ignored').mkdir();(other/'main.rs').write_bytes(b'fn other() {}\n');(other/'ignored/hidden.rs').write_bytes(b'fn ignored_nested() {}\n');(other/'.gitignore').write_bytes(b'ignored/\n')
 catalog_profile=jobroot/'catalog.json';catalog_base={key:value for key,value in base.items() if key!='steering'};catalog_profile.write_text(json.dumps({**catalog_base,'gitIgnore':{'global':False,'projects':{'second':{'project':True}}},'projects':[{'name':'second','root':str(other),'readOnly':True,'queryOnly':False}]}),encoding='utf8')
 messages=[{'jsonrpc':'2.0','id':1,'method':'initialize'},{'jsonrpc':'2.0','method':'notifications/initialized'},{'jsonrpc':'2.0','id':2,'method':'tools/list'},{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'activate_project','arguments':{'session_id':'catalog','project':'second'}}},{'jsonrpc':'2.0','id':4,'method':'tools/list'},{'jsonrpc':'2.0','id':5,'method':'tools/call','params':{'name':'search_for_pattern','arguments':{'substring_pattern':'ignored_nested'}}}]
 driver=jobroot/'catalog.cjs';driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync(process.argv[2],JSON.parse(process.argv[3]),{input:"+json.dumps('\n'.join(json.dumps(message,separators=(',',':')) for message in messages)+'\n')+",maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8');command=mcp_command(catalog_profile,'catalog');command[1]=str(driver);raw=run('actual-catalog-default-project-change-notification',command);replies=[json.loads(line) for line in raw.decode().splitlines()];results={message['id']:message['result'] for message in replies if 'id' in message}
 assert results[1]['capabilities']['tools']['listChanged']==True and not results[3]['isError']
 for response_id,expected in [(2,False),(4,True)]:assert next(tool for tool in results[response_id]['tools'] if tool['name']=='search_for_pattern')['inputSchema']['properties']['skip_ignored_files']['default']==expected
 assert any(message.get('method')=='notifications/tools/list_changed' for message in replies);assert not results[5]['isError'];assert json.loads(results[5]['content'][0]['text'])['data']['total']==0
 policy=jobroot/'policy.yml';policy.write_bytes(b'# owned pinned policy\r\nignore_all_files_in_gitignore: false\r\n');selection=jobroot/'selection.json';selection.write_text(json.dumps({'hostProfile':base,'files':[{'path':str(policy),'sha256':sha(policy),'target':{'kind':'global'}}]}),encoding='utf8');yaml_command=[str(native),'--timeout','60000','--max-bytes','4000000','session-config','plan','--selection',str(selection),'--allow-configuration-read','--allow-policy-projection'];plan=json.loads(run('actual-yaml-plan',yaml_command));assert plan['hostProfile']['gitIgnore']=={'global':False} and plan['runtimeTrustFromYaml']==False and plan['sourceBytesRewritten']==False
 output=jobroot/'projected.json';run('actual-yaml-export',[native,'--timeout','60000','--max-bytes','4000000','session-config','export','--selection',selection,'--output',output,'--allow-configuration-read','--allow-policy-projection','--allow-output']);assert run('yaml-resumes-same-selected-binding',config_command(output,'selected'))==(out/'selected-config.stdout').read_bytes()
 for name,command in [('legacy-to-selected-binding',config_command(selected,'legacy')),('selected-to-legacy-binding',config_command(red['legacyProfile'],'selected'))]:assert not run(name,command,expected=None) and rows[-1]['exitCode']==1 and b'Session host binding changed' in (out/(name+'.stderr')).read_bytes()
 # Current-capture growth may append source and FTS rows; immutable old values
 # must stay exact. Latest is a mutable operational marker, not source evidence.
 final_sql,current=database()
 for table in ['snapshots','graphs','cache','records']:assert all(current[table].get(record_key)==value for record_key,value in original[table].items()),table
 assert current['meta']['workspace']==original['meta']['workspace']
 original_snapshots=set(original['snapshots'])
 for table in ['symbols','documents']:assert collections.Counter({row:count for row,count in current[table].items() if row[0] in original_snapshots})==original[table],table
 assert run('legacy-config-after-new-captures',red['configArgv'])==(redroot/'old-legacy-config.stdout').read_bytes() and run('legacy-symbols-after-new-captures',red['mcpArgv'])==(redroot/'old-legacy-mcp53-symbols.stdout').read_bytes()
 (out/'final-store.sql').write_bytes(database()[0]);assert source_files()==red['sourceGitFiles'] and sha(Path(red['originalCli']))==red['originalCliSha256']
 for key in ['legacyProfile','selectedProfile']:assert sha(Path(red[key]))==red[key+'Sha256']
 assert policy.read_bytes()==b'# owned pinned policy\r\nignore_all_files_in_gitignore: false\r\n' and all(sha(w/name)==digest for name,digest in frozen.items()) and sha(native)==native_hash;complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'originalCliSha256':red['originalCliSha256'],'cliSha256':native_hash,'legacyAbsentNullEmptyConfigurationMcp53AndSymbolsRawExact':complete,'wholeOriginalSqlExactBeforeSelectedCapture':complete,'originalSnapshotsGraphsCacheRecordsAndOriginalFtsMultiplicityExact':complete,'currentCaptureGrowthAllowedWithoutClaimingWholeSqlEquality':True,'actualSelectedIgnoredSymbolsWorkspacePatternDefaultAndTrueFilterQualified':complete,'equivalentPinnedYamlResumesJsonBinding':complete,'bindingUpgradeDowngradeRefused':complete,'sourceGitHostYamlAndOldImageBytesExact':complete,'frozenInputs':len(frozen),'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
