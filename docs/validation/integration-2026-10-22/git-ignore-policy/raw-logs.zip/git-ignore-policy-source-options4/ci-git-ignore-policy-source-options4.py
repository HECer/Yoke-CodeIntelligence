from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/git-ignore-policy-source-options4';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import re,traceback
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
phase=w/'validation/integration-20261018/git-ignore-policy-final3';checked=json.loads((phase/'result.json').read_bytes());inputs=json.loads((phase/'source-before.json').read_bytes());assert checked['complete'] and checked['allJobsEmpty'] and checked['sourceInputsUnchanged'] and len(inputs)==1054 and all(sha(w/name)==digest for name,digest in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
test_source=w/'native/tests/capture_options.rs';assert sha(test_source)==inputs['native/tests/capture_options.rs'];private_output=jobroot/'capture-options-build';private_output.mkdir(exist_ok=False);assert not list(private_output.iterdir());(out/'before-generated.json').write_text(json.dumps({'resolvedParent':str(private_output.resolve()),'files':[]},indent=2)+'\n',encoding='utf8');complete=False
try:
 cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';raw=run('current-library-artifacts',[cargo,'build','--locked','-j','2','--lib','--message-format=json'],timeout=600);assert all(sha(w/name)==digest for name,digest in inputs.items());messages=[json.loads(line) for line in raw.decode().splitlines() if line.strip()];externs={}
 for name in ['yoke','tempfile','serde_json','rusqlite']:
  found=[filename for message in messages if message.get('reason')=='compiler-artifact' and message['target']['name']==name and (name!='yoke' or Path(message['target']['src_path']).resolve()==(w/'native/src/lib.rs').resolve()) and (name!='serde_json' or 'float_roundtrip' in message['features']) for filename in message['filenames'] if filename.endswith('.rlib')];assert len(found)==1,(name,found);externs[name]=found[0]
 native_paths=sorted({path for message in messages if message.get('reason')=='build-script-executed' for path in message['linked_paths']});assert native_paths
 compiler=r'C:\Users\Lomi\.rustup\toolchains\1.94.1-x86_64-pc-windows-msvc\bin\rustc.exe';version=run('compiler-version',[compiler,'--version']).decode().strip();assert version.startswith('rustc 1.94.1 ')
 arguments=[compiler,'--edition=2024','--test',str(test_source),'--crate-name','yoke_owned_capture_options_qualification','--emit=link','-C','debuginfo=0','--out-dir',str(private_output),'-L','dependency='+str(w/'target/debug/deps')]
 for name,path in externs.items():arguments.extend(['--extern',name+'='+path])
 for path in native_paths:arguments.extend(['-L',path])
 run('compile-unaltered-original-tests-owned-name',arguments,timeout=600);assert all(sha(w/name)==digest for name,digest in inputs.items());executable=private_output/'yoke_owned_capture_options_qualification.exe';assert executable.is_file() and executable.resolve().parent==private_output.resolve()
 stdout=run('all-original-capture-option-functions',[executable,'--nocapture','--test-threads=1'],timeout=600);assert re.search(rb'test result: ok\. 8 passed; 0 failed; 0 ignored;',stdout)
 expected=set(re.findall(r'^fn ([a-z_0-9]+)\(',test_source.read_text(encoding='utf8'),re.M));observed=set(re.findall(rb'^test ([a-z_0-9]+) \.\.\. ok\r?$',stdout,re.M));assert len(expected)==8 and {name.decode() for name in observed}==expected
 cleanup=[]
 for path in private_output.iterdir():
  if path.suffix.lower() not in ['.exe','.pdb']:continue
  assert path.resolve().parent==private_output.resolve() and path.is_file() and not path.is_symlink() and path.stem=='yoke_owned_capture_options_qualification';digest=sha(path);size=path.stat().st_size;assert sha(path)==digest;path.unlink();cleanup.append({'name':path.name,'bytes':size,'sha256':digest,'deleted':True})
 (out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf8');assert all(sha(w/name)==digest for name,digest in inputs.items());complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'inputs':len(inputs),'sourceInputsUnchanged':all(sha(w/name)==digest for name,digest in inputs.items()),'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'exactOriginalSource':str(test_source),'originalSourceSha256':sha(test_source),'originalFunctionsPassed':8 if complete else None,'compilerUsesOwnedNameAndDirectory':True,'originalCargoTestTargetExecuted':False,'protectedOriginalFailedLinkOutputTouched':False,'noTestSourceEditsOrSkips':True,'cliSha256':sha(native),'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
