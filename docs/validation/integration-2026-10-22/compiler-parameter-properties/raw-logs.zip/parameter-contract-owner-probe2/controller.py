from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/parameter-contract-owner-probe2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-dashboard-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import sqlite3
qualified=json.loads((w/'validation/integration-20261018/parameter-contract-r3/result.json').read_bytes());assert qualified['complete'] and qualified['allJobsEmpty'] and qualified['cliSha256']==native_hash
inputs=json.loads((w/'validation/integration-20261018/parameter-contract-r3/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
path='src/'+chr(0x3c0)+'-'+chr(0x1f600)+'.ts';(source/'src').mkdir();marker=jobroot/'must-not-execute';header='\ufeff// owned '+chr(0x1f4a1)+' e'+chr(0x301)+'\r\n'
text=header+'''declare const require:any;
require('node:fs').writeFileSync(MARKER,'executed');
export function makeBase(){return class {constructor(public value:string){}};} export class Base extends makeBase(){}
export class Generic<T> extends Base {other!:T;override value='GETTER_OLD';}
interface Root{run(v:string):string;} interface Left extends Root{} interface Right extends Root{}
export class Field<T> implements Left,Right {other!:T;run=(v:string)=>'FIELD_OLD'+v;}
function reader(x:Base){return x.value;}
function writer(x:Base){x.value='write';}
function caller(x:Root){x.run('p1');x.run('p2');}
'''.replace('MARKER',json.dumps(str(marker))).replace('\n','\r\n')
(source/path).write_bytes(text.encode());(source/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'strict':True,'target':'ES2022','module':'CommonJS','noEmit':True},'files':[path]}),encoding='utf8');(source/'.gitignore').write_bytes(b'.yoke/\n')
run('git-add',[*g,'add','--all']);run('git-base-commit',[*g,'commit','-m','Owned compiler property contract base']);base=run('git-base-id',[*g,'rev-parse','HEAD']).decode().strip()
head=text.replace('GETTER_OLD','GETTER_HEAD').replace('FIELD_OLD','FIELD_HEAD');(source/path).write_bytes(head.encode());options=jobroot/'workflow-options.json';options.write_text(json.dumps({'baseRef':base,'historyLimit':1,'branchLimit':0}),encoding='utf8')
common=[str(native),'--root',str(source),'--timeout','60000','--max-bytes','4000000'];workflow=json.loads(run('actual-native-git-workflow',[*common,'git','analyze','--git',str(git),'--trust-git','--options',str(options)],timeout=120));report=workflow['artifactId']

def database():
 c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(c.iterdump())+'\n').encode()
 finally:c.close()
before=database();old=Path(json.loads((w/'validation/integration-20261018/parameter-contract-old/result.json').read_bytes())['originalCli']);assert sha(old)=='4644a4351f0b66ab58f4b862d5f43655c1730cc62ed91ca68fdc897bb6f1b32b'
command=[*common,'git','compiler-affected',report,'--node',str(node),'--typescript',str(compiler),'--trust-compiler']
old_raw=run('old-valid-type-alias',[str(old),*command[1:]],expected=None,timeout=120);old_exit=rows[-1]['exitCode']
current_raw=run('current-valid-type-alias',command,expected=None,timeout=120);current_exit=rows[-1]['exitCode']
assert old_exit==0 and json.loads(old_raw)['complete']==False,old_exit
assert current_exit==0 and json.loads(current_raw)['complete']==False
assert database()==before and not marker.exists() and all(sha(w/n)==h for n,h in inputs.items())
(out/'result.json').write_text(json.dumps({'complete':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':True,'frozenInputs':len(inputs),'cliSha256':native_hash,'oldExitCode':old_exit,'currentExitCode':current_exit,'validTypeAliasBecameRefusal':current_exit!=0,'originalSqlExact':True,'projectCodeExecuted':False,'fixtureHasCompilerErrors':False,'scope':'Probe new property-role admission against existing unsupported type-literal heritage coverage; no production changes.'},indent=2)+'\n',encoding='utf8')
print(json.dumps({'oldExit':old_exit,'currentExit':current_exit,'regression':current_exit!=0}))
