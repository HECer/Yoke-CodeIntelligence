from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-agent-interface-green').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-agent-interface-green-');exec(compile(prefix,str(script),'exec'))
raw=w/'validation/integration-20261018';final=json.loads((raw/'session-agent-interface-final/result.json').read_bytes());assert final['complete'] and final['cliSha256']==native_hash
red_out=raw/'session-agent-interface-red';red=json.loads((red_out/'result.json').read_bytes());root=Path(red['sourceRoot']);profile=Path(red['profile']);original=profile.read_bytes();common=red['argv'];old_records=json.loads((red_out/'original-records.json').read_bytes())
def sql():
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8')
 finally:db.close()
def records():
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return {(k,i):v for k,i,v in db.execute('select kind,id,value from records order by kind,id')}
 finally:db.close()
def selected(value):profile.write_text(json.dumps(value),encoding='utf8')
def mcp(name,interface,messages):
 selected({'context':'desktop-app','agentInterface':interface,'steering':{}})
 server=list(red['serverArgv']);server[server.index('--id')+1]=interface
 driver=jobroot/(name+'.cjs');driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync("+json.dumps(str(native))+","+json.dumps(server[1:])+",{input:"+json.dumps('\n'.join(json.dumps(m,separators=(',',':')) for m in messages)+'\n')+",maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8');shutil.copyfile(driver,out/driver.name)
 reply=run(name,[node,driver],expected=None,timeout=90)
 return [json.loads(s) for s in reply.decode('utf8').splitlines()]
def item(reply,i):return next(x for x in reply if x.get('id')==i)
def request(i,name,args):return {'jsonrpc':'2.0','id':i,'method':'tools/call','params':{'name':name,'arguments':args}}
original_code=Path(red['driver']).read_text(encoding='utf8');original_input=json.loads(original_code.split('{input:',1)[1].split(',maxBuffer:',1)[0]);base=[json.loads(s) for s in original_input.splitlines()];assert [m['id'] for m in base]==[1,2,3,4]
old_reply=[json.loads(s) for s in (red_out/'original-mixed-mcp-positive.stdout').read_text(encoding='utf8').splitlines()];old_tools=item(old_reply,2)['result']['tools'];before=sql();assert before==(red_out/'original-store.sql').read_bytes();(out/'legacy-store-before.sql').write_bytes(before)
try:
 selected({'context':'desktop-app','steering':{}})
 value=run('original-cli-without-setting',[*common,'--id','positive']);assert value==(red_out/'original-configuration.stdout').read_bytes()
 value=run('same-original-mixed-mcp-without-setting',[node,red['driver']]);assert value==(red_out/'original-mixed-mcp-positive.stdout').read_bytes() and sql()==before
 (out/'legacy-store-after.sql').write_bytes(sql())
 marker=jobroot/'must-not-execute.txt';code="open("+json.dumps(str(marker))+",'w').write('unexpected')"
 controls={'activate_project','remove_project','query_project','serena_repl','initial_instructions','serena_info'}
 for interface,count in [('tools',52),('repl',6)]:
  selected({'context':'desktop-app','agentInterface':interface,'steering':{}})
  value=json.loads(run('same-original-'+interface+'-setting-admitted',[*common,'--id',interface]));assert value['results'][0]['steering']['agentInterface']==interface
  messages=[*base,request(5,'serena_info',{'topic':'jet_brains_debug_repl'}),request(6,'serena_repl',{'session_id':interface,'code':code})]
  reply=mcp('same-original-'+interface+'-mcp',interface,messages);assert rows[-1]['exitCode']==0
  expected=[t for t in old_tools if (t['name']!='serena_repl' if interface=='tools' else t['name'] in controls)]
  assert len(expected)==count and item(reply,2)['result']['tools']==expected
  assert item(reply,4)['result']['isError']==(interface=='repl')
  assert item(reply,5)['result']['isError']==False
  assert item(reply,6)['result']['isError'] and not marker.exists()
  denied=run('old-session-'+interface+'-binding-refused',[*common,'--id','positive'],expected=None);assert rows[-1]['exitCode']==1 and not denied and b'Session host binding changed' in (out/('old-session-'+interface+'-binding-refused.stderr')).read_bytes()
 for bad_value in ['auto','REPL',True,[]]:
  selected({'agentInterface':bad_value});prior=sql();name='invalid-interface-'+str(type(bad_value).__name__)+'-'+str(bad_value).replace('[]','array');value=run(name,[*common,'--id','invalid'],expected=None);assert rows[-1]['exitCode']==1 and not value and sql()==prior
 # Runtime selection and trust remain separate; use a new host-bound session.
 runtime_base=list(red['serverArgv']);runtime_base[runtime_base.index('--id')+1]='repl-runtime'
 messages=[base[0],base[1],request(3,'serena_info',{'topic':'jet_brains_debug_repl'}),request(4,'serena_repl',{'session_id':'repl-runtime','code':"{'answer':40+2,'hasMemory':hasattr(s,'mem'),'text':s.fs.read_file('main.rs')['text']}"}),request(5,'read_file',{'relative_path':'main.rs'})]
 def runtime_mcp(name,trust):
  red['serverArgv']=list(runtime_base);red['serverArgv'][red['serverArgv'].index('--id')+1]='repl-runtime'
  selected({'context':'desktop-app','agentInterface':'repl','steering':{'global':{'excludedApis':['mem']}}})
  argv=[*red['serverArgv'],'--python',r'C:\Python314\python.exe']+(['--trust-python'] if trust else [])
  driver=jobroot/(name+'.cjs');driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync("+json.dumps(str(native))+","+json.dumps(argv[1:])+",{input:"+json.dumps('\n'.join(json.dumps(m,separators=(',',':')) for m in messages)+'\n')+",maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8');shutil.copyfile(driver,out/driver.name);reply=run(name,[node,driver],expected=None,timeout=90);return [json.loads(s) for s in reply.decode('utf8').splitlines()]
 reply=runtime_mcp('explicit-trusted-runtime',True);assert rows[-1]['exitCode']==0 and len(item(reply,2)['result']['tools'])==6
 data=json.loads(item(reply,4)['result']['content'][0]['text']);assert not item(reply,4)['result']['isError'] and data['data']['result']=={'answer':42,'hasMemory':False,'text':(root/'main.rs').read_bytes().decode('utf8')};assert item(reply,5)['result']['isError']
 reply=runtime_mcp('explicit-untrusted-runtime-refused',False);assert rows[-1]['exitCode']==1 and not reply and not marker.exists()
finally:profile.write_bytes(original)
current=records();assert all(current.get((r['kind'],r['id']))==r['value'] for r in old_records)
files={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in root.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(root).parts};assert files==red['sourceGitFiles'] and profile.read_bytes()==original
(out/'result.json').write_text(json.dumps({'complete':True,'cliSha256':native_hash,'sameOriginalRedSourceRoot':str(root),'legacyCliAndFull53McpRawAndLogicalSqlExact':True,'tools52AndRepl6ExactOriginalSchemaSubsets':True,'noRuntimeSelectionOrTrustGrant':True,'realTrustedPythonAnswer42AndSourceRead':True,'independentApiExclusionAndToolCallRefusals':True,'invalidValuesBeforePublicationAndOldBindingRefused':True,'originalRecordValuesAndSourceGitExact':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'modelCalled':False,'analyzedSourceExecuted':False,'commands':rows},indent=2)+'\n',encoding='utf8');print('Same original interface CLI/MCP fixture GREEN.',flush=True)
