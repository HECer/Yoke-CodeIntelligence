from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/session-config-yaml-green';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-session-config-yaml-green-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])
import sqlite3
redroot=w/'validation/integration-20261018/session-config-yaml-red';red=json.loads((redroot/'result.json').read_bytes());source=Path(red['sourceRoot']);cwd=source;selection=Path(red['selection']);assert sha(selection)==red['selectionSha256']
frozen=json.loads((w/'validation/integration-20261018/session-config-yaml-final2/source-before.json').read_bytes());assert len(frozen)==1033 and all(sha(w/n)==h for n,h in frozen.items())
def source_files():return {p.relative_to(source).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(source).parts}
def sql_bytes():
 db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8')
 finally:db.close()
assert source_files()==red['sourceGitFiles'];original_sql=(redroot/'original-store.sql').read_bytes();assert sql_bytes()==original_sql
selected_files=[selection,Path(red['profile']),Path(red['equivalentProfile']),*[Path(x['path']) for x in red['yamlFiles']]];original_hosts={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in selected_files}
for item in red['yamlFiles']:assert sha(Path(item['path']))==item['sha256']
for name,argv,old in [('legacy-json-configuration',red['baselineArgv'],'original-json-configuration'),('equivalent-json-configuration',red['equivalentArgv'],'equivalent-json-configuration')]:
 assert run(name,argv)==(redroot/(old+'.stdout')).read_bytes()
for driver in red['drivers']:assert run(driver['label']+'-legacy-mcp',[node,driver['path']])==(redroot/(driver['label']+'-json-mcp.stdout')).read_bytes()
assert sql_bytes()==original_sql
plan_argv=red['planArgv'];plan=run('same-original-yaml-plan',plan_argv);value=json.loads(plan);assert value['schema']=='native_session_config_yaml_v1' and not value['sourceExecuted'] and not value['templatesEvaluated'] and not value['storeOpened'];assert [s['originalSha256'] for s in value['sources']]==[s['sha256'] for s in red['yamlFiles']]
assert run('same-original-yaml-plan-repeat',plan_argv)==plan
exact=list(plan_argv);exact[exact.index('--max-bytes')+1]=str(len(plan));assert run('plan-exact-byte-boundary',exact)==plan
short=list(exact);short[short.index('--max-bytes')+1]=str(len(plan)-1);assert not run('plan-one-byte-short',short,expected=None) and rows[-1]['exitCode']==1
output=jobroot/'projected-host.json';common=[native,'--timeout','60000','--max-bytes','4000000','session-config'];export=[*common,'export','--selection',selection,'--output',output,'--allow-configuration-read','--allow-policy-projection','--allow-output'];export_reply=run('same-original-yaml-profile-export',export);receipt=json.loads(export_reply);assert receipt['outputCreated'] and not receipt['sourceExecuted'] and not receipt['storeOpened'] and receipt['profileSha256']==sha(output) and receipt['profileBytes']==output.stat().st_size
equivalent_argv=[str(output) if str(a)==red['equivalentProfile'] else a for a in red['equivalentArgv']];assert run('same-original-yaml-profile-session',equivalent_argv)==(redroot/'equivalent-json-configuration.stdout').read_bytes()
driver=next(d for d in red['drivers'] if d['label']=='equivalent');text=Path(driver['path']).read_text(encoding='utf8');old=json.dumps(red['equivalentProfile']);assert text.count(old)==1;text=text.replace(old,json.dumps(str(output)));newdriver=jobroot/'projected-mcp.cjs';newdriver.write_text(text,encoding='utf8');assert run('same-original-yaml-profile-mcp',[node,newdriver])==(redroot/'equivalent-json-mcp.stdout').read_bytes()
projected=output.read_bytes();assert not run('profile-output-already-exists',export,expected=None) and rows[-1]['exitCode']==1 and output.read_bytes()==projected
for flag in ['--allow-configuration-read','--allow-policy-projection','--allow-output']:
 args=[a for a in export if a!=flag];assert not run('missing-'+flag[2:],args,expected=None) and rows[-1]['exitCode']==1
bad=jobroot/'invalid-selection.json';spec=json.loads(selection.read_bytes());spec['files'][0]['sha256']='0'*64;bad.write_text(json.dumps(spec),encoding='utf8');changed=[str(bad) if str(a)==str(selection) else a for a in plan_argv];assert not run('stale-original-file-pin',changed,expected=None) and rows[-1]['exitCode']==1
absent=jobroot/'must-not-open-source';assert not run('source-root-flags-refused',[native,'--root',absent,*plan_argv[1:]],expected=None) and rows[-1]['exitCode']==1 and not absent.exists()
assert source_files()==red['sourceGitFiles'] and sql_bytes()==original_sql and all(p.stat().st_size==original_hosts[str(p)]['bytes'] and sha(p)==original_hosts[str(p)]['sha256'] for p in selected_files) and all(sha(w/n)==h for n,h in frozen.items()) and sha(native)==native_hash
(out/'original-host-files.json').write_text(json.dumps(original_hosts,indent=2)+'\n',encoding='utf8');(out/'final-store.sql').write_bytes(sql_bytes());(out/'result.json').write_text(json.dumps({'complete':True,'cliSha256':native_hash,'originalCliSha256':red['cliSha256'],'sourceRoot':str(source),'legacy53AndRestricted37JsonMcpRawExact':True,'yamlProjectedProfileResumesOriginalRestrictedBinding':True,'yamlProjectedCliAndMcpRawExact':True,'wholeLogicalSqlExact':True,'sourceGitFilesExact':True,'selectionAndYamlRawFilesExact':True,'profileOutputSha256':sha(output),'planExactOutputBytes':len(plan),'oneByteShortRefused':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'frozenInputsUnchanged':all(sha(w/n)==h for n,h in frozen.items()),'sourceExecuted':False,'networkRequests':0,'modelCalls':0,'rows':rows},indent=2)+'\n',encoding='utf8')
