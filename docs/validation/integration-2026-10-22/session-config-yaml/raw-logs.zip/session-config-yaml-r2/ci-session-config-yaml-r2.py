from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/session-config-yaml-r2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-session-config-yaml-r2-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
prior=w/'validation/integration-20261018/session-config-yaml-r1';old=json.loads((prior/'source-before.json').read_bytes());previous=json.loads((prior/'result.json').read_bytes());assert previous['complete'] and previous['allJobsEmpty'] and previous['sourceInputsUnchanged']
helper='native/tests/session_config_cli.rs';inputs={n:sha(w/n) for n in old};assert len(inputs)==1033 and {n for n in old if old[n]!=inputs[n]}=={helper};before_helper=(w/helper).read_bytes().replace(b'yoke::model::hash(fs::read(',b'yoke::model::hash(&fs::read(');assert hashlib.sha256(before_helper).hexdigest()==old[helper];(out/'standalone-cli-helper-before.rs').write_bytes(before_helper);(out/'standalone-cli-helper-after.rs').write_bytes((w/helper).read_bytes());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
deps=w/'target/debug/deps';depout=out/'dep-info';depout.mkdir();attested=[];reused=[]
for row in previous['rows']:
 name=row['name']
 if name in ['git-init','session_config_cli']:continue
 assert row['exitCode']==0 and row['activeAfterCleanup']==0
 stderr=(prior/(name+'.stderr')).read_text(encoding='utf8');match=re.search(r'Running [^\r\n]*\((target[\\/][^\r\n)]+\.exe)\)',stderr);assert match,name
 dep=(w/match.group(1).replace('\\','/')).with_suffix('.d');assert dep.resolve().parent==deps.resolve() and dep.is_file();data=dep.read_bytes();normalized=data.decode('utf8').replace('\\','/');assert helper not in normalized,name
 if name=='session-config-lib':assert 'native/src/session_config.rs' in normalized and 'native/src/session_config_tests.rs' in normalized
 (depout/dep.name).write_bytes(data);attested.append({'target':name,'path':dep.relative_to(w).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'changedStandaloneHelperAbsent':True})
 for suffix in ['stdout','stderr']:shutil.copyfile(prior/(name+'.'+suffix),out/(name+'.'+suffix))
 rows.append({**row,'reusedCheckedPhase':'session-config-yaml-r1','reusedRelevantInputHashes':1032,'excludedStandaloneTestHelper':helper,'rerun':False});reused.append(name)
assert len(reused)==16
inventory=subprocess.check_output(['rg','--files','target/debug/deps','-g','yoke-*.d'],cwd=w).decode('utf8').splitlines();main_deps=[]
for name in inventory:
 dep=w/name;data=dep.read_bytes();normalized=data.decode('utf8').replace('\\','/')
 if 'native/src/main.rs' not in normalized or 'native/src/session_config_cli.rs' not in normalized:continue
 assert helper not in normalized;(depout/dep.name).write_bytes(data);main_deps.append({'path':dep.relative_to(w).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'changedStandaloneHelperAbsent':True})
assert main_deps
(out/'reuse-attestation.json').write_text(json.dumps({'sameRelevantInputHashes':1032,'currentFrozenInputs':1033,'onlyChangedFile':helper,'correction':'Remove two Clippy needless borrows in the standalone integration test helper; reconstructed prior bytes match its tested SHA. No product or other test input changed.','reusedTargets':reused,'reusedTargetDepInfo':attested,'currentMainDepInfo':main_deps,'priorHelperSha256':old[helper],'currentHelperSha256':inputs[helper]},indent=2)+'\n',encoding='utf8')
complete=False
try:
 before={p.resolve() for p in deps.iterdir() if p.is_file()};run('session_config_cli',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','test','--locked','-j','2','--test','session_config_cli','--','--nocapture','--test-threads=1'],timeout=600);assert all(sha(w/n)==h for n,h in inputs.items());cleanup=[]
 for p in deps.iterdir():
  if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith('session_config_cli-'):continue
  assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();digest=sha(p);size=p.stat().st_size;assert sha(p)==digest
  try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':digest,'deleted':True})
  except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':digest,'deleted':False,'reason':'completed output held; preserved'})
 (out/'session_config_cli-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf8');complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':previous['targets'],'currentRunTargets':['session_config_cli'],'reusedRelevantInputs':1032,'reusedTargets':reused,'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
