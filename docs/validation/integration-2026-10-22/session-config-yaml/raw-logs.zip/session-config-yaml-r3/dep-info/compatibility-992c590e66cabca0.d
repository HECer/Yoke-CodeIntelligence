C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\compatibility-992c590e66cabca0.d: native\tests\compatibility.rs

C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\compatibility-992c590e66cabca0.exe: native\tests\compatibility.rs

native\tests\compatibility.rs:
