C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\meaning_archive_primitives-be6fb85907c913ec.d: native\tests\meaning_archive_primitives.rs

C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\meaning_archive_primitives-be6fb85907c913ec.exe: native\tests\meaning_archive_primitives.rs

native\tests\meaning_archive_primitives.rs:
