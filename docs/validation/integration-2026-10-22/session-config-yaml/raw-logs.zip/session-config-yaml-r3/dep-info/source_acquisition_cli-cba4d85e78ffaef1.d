C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\source_acquisition_cli-cba4d85e78ffaef1.d: native\tests\source_acquisition_cli.rs

C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\source_acquisition_cli-cba4d85e78ffaef1.exe: native\tests\source_acquisition_cli.rs

native\tests\source_acquisition_cli.rs:

# env-dep:CARGO_BIN_EXE_yoke=C:\\Users\\Lomi\\Documents\\NN-Developed\\Yoke-CodeIntelligence\\target\\debug\\yoke.exe
