C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\google_workspace_http_cli-ce5740ff574cbbc0.d: native\tests\google_workspace_http_cli.rs

C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\google_workspace_http_cli-ce5740ff574cbbc0.exe: native\tests\google_workspace_http_cli.rs

native\tests\google_workspace_http_cli.rs:

# env-dep:CARGO_BIN_EXE_yoke=C:\\Users\\Lomi\\Documents\\NN-Developed\\Yoke-CodeIntelligence\\target\\debug\\yoke.exe
