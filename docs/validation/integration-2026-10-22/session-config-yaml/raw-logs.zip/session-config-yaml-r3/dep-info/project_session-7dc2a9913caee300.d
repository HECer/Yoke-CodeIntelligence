C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\project_session-7dc2a9913caee300.d: native\tests\project_session.rs

C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\target\debug\deps\project_session-7dc2a9913caee300.exe: native\tests\project_session.rs

native\tests\project_session.rs:

# env-dep:CARGO_MANIFEST_DIR=C:\\Users\\Lomi\\Documents\\NN-Developed\\Yoke-CodeIntelligence\\native
