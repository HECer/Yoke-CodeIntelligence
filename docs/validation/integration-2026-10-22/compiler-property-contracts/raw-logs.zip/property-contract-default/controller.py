from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/property-contract-default';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
baseline=json.loads((w/'validation/integration-20261018/property-contract-old/result.json').read_bytes());jobroot=Path(baseline['sourceRoot']).parent;source=jobroot/'source';cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']




import sqlite3
phase=w/'validation/integration-20261018/property-contract-r1';qualified=json.loads((phase/'result.json').read_bytes());inputs=json.loads((phase/'source-before.json').read_bytes());assert qualified['complete'] and qualified['allJobsEmpty'] and qualified['sourceInputsUnchanged'] and qualified['cliSha256']==native_hash and len(inputs)==1065 and all(sha(w/name)==digest for name,digest in inputs.items());assert sha(Path(baseline['originalCli']))==baseline['originalCliSha256']=='b83fa60bdcb1030f7f129261796c05ed70df3b6e72e9c33cad6c5aa5117e0eac';assert all(sha(Path(name))==digest for name,digest in baseline['files'].items())
def exact_source():
 current={path.relative_to(source).as_posix():{'bytes':path.stat().st_size,'sha256':sha(path)} for path in source.rglob('*') if path.is_file() and '.yoke' not in path.relative_to(source).parts};assert current==baseline['sourceGitFiles']
def memory():
 connection=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True);backup=sqlite3.connect(':memory:')
 try:connection.backup(backup)
 finally:connection.close()
 return backup
def dump(db):return ('\n'.join(db.iterdump())+'\n').encode()

def native_data_equal(left,right,label):
 left_rows=[json.loads(line) for line in left.decode().splitlines()];right_rows=[json.loads(line) for line in right.decode().splitlines()];assert len(left_rows)==len(right_rows)
 for index,(left_row,right_row) in enumerate(zip(left_rows,right_rows)):
  if left_row.get('id') not in [2,3]:assert left_row==right_row;continue
  left_text=left_row['result']['content'][0]['text'];right_text=right_row['result']['content'][0]['text'];left_value=json.loads(left_text);right_value=json.loads(right_text)
  for value in [left_value,right_value]:
   assert isinstance(value['requestId'],str) and len(value['requestId'])==64 and isinstance(value['metrics']['durationMs'],(int,float));del value['requestId'];del value['metrics']['durationMs']
  assert left_value==right_value,(label,index)
  marker='"data":';left_start=left_text.index(marker)+len(marker);right_start=right_text.index(marker)+len(marker);_,left_end=json.JSONDecoder().raw_decode(left_text,left_start);_,right_end=json.JSONDecoder().raw_decode(right_text,right_start);left_data=left_text[left_start:left_end].encode();right_data=right_text[right_start:right_end].encode();assert left_data==right_data
  (out/(label+'-id'+str(left_row['id'])+'-original-data.json')).write_bytes(left_data);(out/(label+'-id'+str(left_row['id'])+'-current-data.json')).write_bytes(right_data)
  left_row['result']['content'][0]['text']='checked-native-envelope';right_row['result']['content'][0]['text']='checked-native-envelope';assert left_row==right_row
original_sql=(w/'validation/integration-20261018/property-contract-old/original-store.sql').read_bytes();original=memory();assert dump(original)==original_sql;original_records={(kind,id):value for kind,id,value in original.execute('SELECT kind,id,value FROM records')};exact_source();complete=False
try:
 config=list(baseline['configArgv']);config[0]=str(native);raw=run('default-config-raw',config);assert raw==(w/'validation/integration-20261018/property-contract-old/old-configuration.stdout').read_bytes()
 
 original_native=list(baseline['nativeMcpArgv']);original_native[2]=baseline['originalCli'];original_repeat=run('original-native-envelope-repeat',original_native);native_data_equal((w/'validation/integration-20261018/property-contract-old/old-real-primary-lsp-hover-and-references.stdout').read_bytes(),original_repeat,'original-repeat')
 for name,key,old_raw in [('default-serena-mcp53-raw','mcpArgv','old-mcp53-primary-symbols'),('default-real-lsp-raw','nativeMcpArgv','old-real-primary-lsp-hover-and-references')]:
  command=list(baseline[key]);command[2]=str(native);raw=run(name,command);before=(w/'validation/integration-20261018/property-contract-old'/(old_raw+'.stdout')).read_bytes()
  if key=='nativeMcpArgv':native_data_equal(before,raw,'current-default')
  else:assert raw==before

 with memory() as current:assert dump(current)==original_sql
 selected_config=[baseline['selectedProfile'] if a==baseline['legacyProfile'] else a for a in config];selected_config=[('dashboard' if index>0 and selected_config[index-1]=='--id' else value) for index,value in enumerate(selected_config)];run('selected-config',selected_config)
 selected=list(baseline['nativeMcpArgv']);selected[2]=str(native);args=json.loads(selected[3]);args=[baseline['selectedProfile'] if a==baseline['legacyProfile'] else a for a in args];args=[('dashboard' if i>0 and args[i-1]=='--id' else a) for i,a in enumerate(args)];selected[3]=json.dumps(args)
 messages=[{'jsonrpc':'2.0','id':1,'method':'initialize'},{'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':'ci_session','arguments':{'operation':'openDashboard','args':{}}}},{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'ci_session','arguments':{'operation':'configuration','args':{}}}}]
 safe=jobroot/'dashboard-safe-replay.cjs';safe.write_text(r"const cp=require('node:child_process'),net=require('node:net');const p=cp.spawnSync(process.argv[2],JSON.parse(process.argv[3]),{input:JSON.parse(process.argv[4]).map(m=>JSON.stringify(m)).join(String.fromCharCode(10))+String.fromCharCode(10),maxBuffer:8000000,windowsHide:true});if(p.error||p.status!==0)throw Error('owned native replay failed');const rows=p.stdout.toString().trim().split(/\r?\n/).map(s=>JSON.parse(s));const row=rows.find(v=>v.id===2);const value=JSON.parse(row.result.content[0].text);if(value.status!=='ok'||value.data.browserOpened!==false)throw Error('dashboard admission failed');const url=new URL(value.data.url);if(url.hostname!=='127.0.0.1'||!/^#[a-f0-9]{64}$/.test(url.hash))throw Error('dashboard private URL invalid');value.data.url='[private dashboard URL redacted]';row.result.content[0].text=JSON.stringify(value);const client=net.createConnection({host:'127.0.0.1',port:Number(url.port)});client.setTimeout(1000);client.on('connect',()=>{client.destroy();throw Error('dashboard listener survived host exit')});client.on('timeout',()=>{client.destroy();throw Error('dashboard close probe timed out')});client.on('error',e=>{if(e.code!=='ECONNREFUSED')throw Error('unexpected close probe');process.stdout.write(rows.map(v=>JSON.stringify(v)).join(String.fromCharCode(10))+String.fromCharCode(10));process.stdout.write(JSON.stringify({privateUrlRedactedBeforeLogging:true,dashboardListenerClosedAfterHostExit:true})+String.fromCharCode(10))});",encoding='utf8')
 run('actual-dashboard-open-close-private-url-redacted',[node,safe,native,selected[3],json.dumps(messages)]);assert b'"dashboardListenerClosedAfterHostExit":true' in (out/'actual-dashboard-open-close-private-url-redacted.stdout').read_bytes()
 run('upgrade-refused',[baseline['selectedProfile'] if a==baseline['legacyProfile'] else a for a in config],expected=None);assert rows[-1]['exitCode']==1 and b'Session host binding changed' in (out/'upgrade-refused.stderr').read_bytes()
 run('downgrade-refused',[baseline['legacyProfile'] if a==baseline['selectedProfile'] else a for a in selected_config],expected=None);assert rows[-1]['exitCode']==1 and b'Session host binding changed' in (out/'downgrade-refused.stderr').read_bytes()
 current=memory()
 try:
  records={(kind,id):value for kind,id,value in current.execute('SELECT kind,id,value FROM records')};assert all(records.get(key)==value for key,value in original_records.items());new=set(records)-set(original_records);assert new and all(kind=='native_agent_session_v1' for kind,id in new)
  for kind,id in new:current.execute('DELETE FROM records WHERE kind=? AND id=?',(kind,id))
  current.commit();assert dump(current)==original_sql
 finally:current.close()
 raw=run('default-config-after-dashboard-raw',config);assert raw==(out/'default-config-raw.stdout').read_bytes();command=list(baseline['nativeMcpArgv']);command[2]=str(native);raw=run('default-real-lsp-after-dashboard-raw',command);native_data_equal((out/'default-real-lsp-raw.stdout').read_bytes(),raw,'default-after-dashboard');exact_source();assert all(sha(Path(name))==digest for name,digest in baseline['files'].items());assert sha(Path(baseline['originalCli']))==baseline['originalCliSha256'];assert all(sha(w/name)==digest for name,digest in inputs.items()) and sha(native)==native_hash;complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/name)==digest for name,digest in inputs.items()),'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'cliSha256':native_hash,'frozenInputs':len(inputs),'sameOldNewOwnedFixture':True,'defaultConfigurationMcp53AndLiteralLspDataRawExact':complete,'onlyNativeRequestIdDurationExcludedAfterOldRepeatProof':complete,'wholeOriginalSqlExactBeforeNewBinding':complete,'originalSqlReconstructedRemovingOnlyNewSessionRowsAfterActualOpenClose':complete,'actualDashboardPrivateUrlValidatedThenRedacted':complete,'dashboardListenerClosedAfterActualHostExit':complete,'staleUpgradeDowngradeRefused':complete,'sourceGitHostOldImageBytesExact':complete,'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
