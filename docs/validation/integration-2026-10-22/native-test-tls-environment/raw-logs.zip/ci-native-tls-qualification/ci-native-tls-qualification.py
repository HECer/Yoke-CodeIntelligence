from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
primary=Path('C:\\Users\\Lomi\\Documents\\NN-Developed\\Yoke-CodeIntelligence');w=Path('C:\\Users\\Lomi\\AppData\\Local\\Temp\\yoke-owned-ci-tls-ip2ly52_\\checkout');out=primary/'validation/integration-20261018/ci-native-tls-qualification';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=primary/'target/debug/yoke.exe'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import re,traceback
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';env['CARGO_TARGET_DIR']=str(primary/'target');env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
base=json.loads((primary/'validation/integration-20261018/source-exclusions-final3/source-before.json').read_bytes());names=set(base)|{'.github/workflows/rust.yml','scripts/run_native_tests.py','scripts/tests/test_native_test_runner.py'};inputs={n:sha(w/n) for n in sorted(names)};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
assert sha(w/'native/tests/fixtures/postgres-catalog-response.jsonl')=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47';complete=False;cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';python=r'C:\Python314\python.exe';ambient=('SSL_CERT_FILE','SSL_CERT_DIR','SSLKEYLOGFILE')
def unchanged():assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen CI source changed'
try:
 run('python-tests',[python,'-X','utf8','-m','unittest','discover','-s','scripts/tests','-v'],timeout=120);unchanged()
 for target,arguments in [('google-http-lib',['--lib','--','google_workspace::native_http::','--nocapture','--test-threads=1']),('google-http-cli',['--test','google_workspace_http_cli','--','--nocapture','--test-threads=1'])]:
  for name in ambient:env[name]='owned-ambient-ci-fixture'
  run(target,[python,'-X','utf8','scripts/run_native_tests.py','--locked','-j','2',*arguments],timeout=600);unchanged();assert all(env[n]=='owned-ambient-ci-fixture' for n in ambient)
  for name in ambient:env.pop(name)
 run('clippy-focused',[cargo,'clippy','--locked','--lib','--test','google_workspace_http_cli','-j','2','--','-D','warnings'],timeout=600);unchanged()
 for name,command in [('npm-ci',['cmd.exe','/d','/c','npm.cmd ci']),('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:run(name,command,timeout=600);unchanged()
 run('format-target-metadata',[cargo,'metadata','--no-deps','--format-version','1'],timeout=60);metadata=json.loads((out/'format-target-metadata.stdout').read_bytes());roots=sorted(set(t['src_path'] for package in metadata['packages'] for t in package['targets']));assert len(roots)==338;(out/'format-targets.json').write_text(json.dumps(roots,indent=2)+'\n',encoding='utf8')
 for i in range(0,len(roots),20):run('format-targets-'+str(i//20),[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','--check',*roots[i:i+20]],timeout=120);unchanged()
 complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'worktree':str(w),'baseCommit':'2ea772a1a343e2b326f0febf4ac1d850ada6cec5','sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'ambientOverridesInjectedOnlyIntoOwnedTestLauncher':list(ambient),'productionTlsRefusalUnchanged':True,'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
