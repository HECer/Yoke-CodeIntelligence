from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-optional-defaults-green').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-optional-defaults-green-');exec(compile(prefix,str(script),'exec'))
raw=w/'validation/integration-20261018';final=json.loads((raw/'session-optional-defaults-final/result.json').read_bytes());assert final['complete'] and final['cliSha256']==native_hash
red_out=raw/'session-optional-defaults-red';red=json.loads((red_out/'result.json').read_bytes());runtime_out=raw/'session-optional-defaults-runtime-red';runtime=json.loads((runtime_out/'result.json').read_bytes());root=Path(red['sourceRoot']);profile=Path(red['profile']);original=profile.read_bytes();common=red['argv'];old_records=json.loads((red_out/'original-records.json').read_bytes());facts=json.loads((Path(os.environ['TEMP'])/'ci-serena-public-optional-surface-20261022/native-projection.json').read_bytes());optional=set(facts['optionalTools']);optional_apis=runtime['optionalMethods'];controls={'activate_project','remove_project','query_project','serena_repl','initial_instructions','serena_info'}
def sql():
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8')
 finally:db.close()
def records():
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return {(k,i):v for k,i,v in db.execute('select kind,id,value from records order by kind,id')}
 finally:db.close()
def selected(value):profile.write_text(json.dumps(value),encoding='utf8')
def item(reply,i):return next(x for x in reply if x.get('id')==i)
original_code=Path(red['driver']).read_text(encoding='utf8');original_input=json.loads(original_code.split('{input:',1)[1].split(',maxBuffer:',1)[0]);base_messages=[json.loads(s) for s in original_input.splitlines()];old_reply=[json.loads(s) for s in (red_out/'original-mixed-mcp-positive.stdout').read_text(encoding='utf8').splitlines()];old_tools=item(old_reply,2)['result']['tools'];marker=jobroot/'must-not-run.txt'
def exchange(name,label,value,runtime_enabled=False,trust=True,expected=0):
 selected(value);server=list(red['serverArgv']);server[server.index('--id')+1]=label
 if runtime_enabled:
  server+=['--python',r'C:\Python314\python.exe']+(['--trust-python'] if trust else [])
  messages=[base_messages[0],base_messages[1],{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'serena_repl','arguments':{'session_id':label,'code':runtime['cell']}}},base_messages[3],{'jsonrpc':'2.0','id':5,'method':'tools/call','params':{'name':'serena_info','arguments':{'topic':'jet_brains_debug_repl'}}}]
 else:
  messages=[*base_messages,{'jsonrpc':'2.0','id':5,'method':'tools/call','params':{'name':'serena_info','arguments':{'topic':'jet_brains_debug_repl'}}},{'jsonrpc':'2.0','id':6,'method':'tools/call','params':{'name':'serena_repl','arguments':{'session_id':label,'code':"open("+json.dumps(str(marker))+",'w').write('unexpected')"}}}]
 driver=jobroot/(name+'.cjs');driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync("+json.dumps(str(native))+","+json.dumps(server[1:])+",{input:"+json.dumps('\n'.join(json.dumps(m,separators=(',',':')) for m in messages)+'\n')+",maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8');shutil.copyfile(driver,out/driver.name);reply=run(name,[node,driver],expected=expected,timeout=90);assert not marker.exists();return [json.loads(s) for s in reply.decode('utf8').splitlines()]
before=sql();assert before==(red_out/'original-store.sql').read_bytes();(out/'legacy-store-before.sql').write_bytes(before)
try:
 selected({'context':'desktop-app','steering':{}})
 assert run('original-cli-no-migration',[*common,'--id','positive'])==(red_out/'original-configuration.stdout').read_bytes()
 assert run('same-original-mixed53-mcp-no-migration',[node,red['driver']])==(red_out/'original-mixed-mcp-positive.stdout').read_bytes()
 assert run('same-original-runtime50-mcp-no-migration',[node,runtime['driver']])==(runtime_out/'original-runtime50-optional8-positive.stdout').read_bytes()
 assert sql()==before;(out/'legacy-store-after.sql').write_bytes(sql())
 for interface in ['tools','repl']:
  value={'context':'desktop-app','agentInterface':interface,'steering':{}};reply=exchange('legacy-'+interface,'legacy-'+interface,value,interface=='repl');expected=[t for t in old_tools if (t['name']!='serena_repl' if interface=='tools' else t['name'] in controls)];assert item(reply,2)['result']['tools']==expected
  if interface=='repl':assert json.loads(item(reply,3)['result']['content'][0]['text'])['data']['result']=={'answer':42,'visibleCount':50,'optionalPresent':{m:True for m in optional_apis}}
 for label,interface in [('defaults',None),('defaults-tools','tools')]:
  value={'context':'desktop-app','optionalDefaults':'serena_optional_v1','steering':{}}
  if interface:value['agentInterface']=interface
  selected(value);cfg=json.loads(run('admitted-'+label,[*common,'--id',label]))['results'][0];assert cfg['steering']['optionalDefaults']=='serena_optional_v1' and cfg['steering']['excludedApis']==sorted(optional_apis)
  reply=exchange('same-original-'+label,label,value);assert item(reply,2)['result']['tools']==[t for t in old_tools if t['name'] not in optional];assert len(item(reply,2)['result']['tools'])==29 and not item(reply,4)['result']['isError'] and item(reply,5)['result']['isError'] and item(reply,6)['result']['isError']
  denied=run('old-binding-'+label+'-refused',[*common,'--id','positive'],expected=None);assert rows[-1]['exitCode']==1 and not denied and b'Session host binding changed' in (out/('old-binding-'+label+'-refused.stderr')).read_bytes()
 cases=[('defaults-repl',{'context':'desktop-app','optionalDefaults':'serena_optional_v1','agentInterface':'repl','steering':{}},6,42,[],True),('included',{'context':'desktop-app','optionalDefaults':'serena_optional_v1','agentInterface':'tools','steering':{'cli':{'includedOptionalTools':['serena_repl','serena_info'],'includedApis':['ext.list_projects']}}},31,43,['ext.list_projects'],False),('all-apis',{'context':'desktop-app','optionalDefaults':'serena_optional_v1','agentInterface':'repl','steering':{'cli':{'includedApis':['lsp','edit','ext']}}},6,50,optional_apis,True)]
 for label,value,count,api_count,included,repl_view in cases:
  selected(value);run('admitted-'+label,[*common,'--id',label]);reply=exchange('runtime-'+label,label,value,True);expected=[t for t in old_tools if t['name'] in controls] if repl_view else [t for t in old_tools if t['name'] not in optional or t['name'] in ['serena_repl','serena_info']];assert item(reply,2)['result']['tools']==expected and len(expected)==count and not item(reply,3)['result']['isError']
  assert json.loads(item(reply,3)['result']['content'][0]['text'])['data']['result']=={'answer':42,'visibleCount':api_count,'optionalPresent':{m:m in included for m in optional_apis}};assert item(reply,4)['result']['isError']==repl_view and not item(reply,5)['result']['isError']
 included_value=cases[1][1];reply=exchange('included-without-runtime','included',included_value);assert item(reply,6)['result']['isError'] and not item(reply,5)['result']['isError']
 reply=exchange('included-without-trust','included',included_value,True,False,None);assert rows[-1]['exitCode']==1 and not reply and b'trust' in (out/'included-without-trust.stderr').read_bytes().lower()
 fixed={'context':'desktop-app','optionalDefaults':'serena_optional_v1','steering':{'global':{'fixedTools':['serena_info']}}};reply=exchange('fixed-optional-base','fixed',fixed);assert item(reply,2)['result']['tools']==[t for t in old_tools if t['name']=='serena_info'] and not item(reply,5)['result']['isError']
 selected({'context':'desktop-app','steering':{}});denied=run('selected-binding-downgrade-refused',[*common,'--id','defaults'],expected=None);assert rows[-1]['exitCode']==1 and not denied and b'Session host binding changed' in (out/'selected-binding-downgrade-refused.stderr').read_bytes()
 for i,bad in enumerate(['unknown','SERENA_OPTIONAL_V1',True,[],{}]):
  selected({'optionalDefaults':bad});prior=sql();denied=run('invalid-version-before-publication-'+str(i),[*common,'--id','invalid'],expected=None);assert rows[-1]['exitCode']==1 and not denied and sql()==prior
finally:profile.write_bytes(original)
current=records();assert all(current.get((r['kind'],r['id']))==r['value'] for r in old_records);files={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in root.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(root).parts};assert files==red['sourceGitFiles'] and profile.read_bytes()==original
(out/'result.json').write_text(json.dumps({'complete':True,'cliSha256':native_hash,'sameOriginalRedSourceRoot':str(root),'legacyFullCli53Mcp50RuntimeRawAndLogicalSqlExact':True,'legacyExplicitTools52Repl6And50MethodsPreserved':True,'selected29ToolsAndRepl6AreExactOriginalSchemaSubsets':True,'realSelected42Included43AndRestored50ApiMethods':True,'fixedOptionalBaseAndIncludedClassicReplFunctional':True,'noRuntimeAndUntrustedRefusedWithoutHostEffect':True,'upgradeDowngradeUnknownVersionsBeforePublicationRefused':True,'allOriginalRecordsAndSourceGitExact':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'modelCalled':False,'analyzedSourceExecuted':False,'commands':rows},indent=2)+'\n',encoding='utf8');print('Same original versioned optional-default CLI/MCP fixture GREEN.',flush=True)
