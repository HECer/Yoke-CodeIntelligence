from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-inclusions-green').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-inclusions-green-');exec(compile(prefix,str(script),'exec'))
raw=w/'validation/integration-20261018';final=json.loads((raw/'session-inclusions-final/result.json').read_bytes());assert final['complete'] and final['cliSha256']==native_hash
red_out=raw/'session-inclusions-red';red=json.loads((red_out/'result.json').read_bytes());root=Path(red['sourceRoot']);profile=Path(red['profile']);original=profile.read_bytes();common=red['argv'];old_records=json.loads((red_out/'original-records.json').read_bytes())
def sql():
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8')
 finally:db.close()
def records():
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return {(k,i):v for k,i,v in db.execute('select kind,id,value from records order by kind,id')}
 finally:db.close()
def selected(value):profile.write_text(json.dumps(value),encoding='utf8')
def item(reply,i):return next(x for x in reply if x.get('id')==i)
restricted={'context':'desktop-app','steering':{'global':{'excludedTools':['read_file'],'excludedApis':['fs.read_file']}}}
code=Path(red['restrictedDriver']).read_text(encoding='utf8');original_input=json.loads(code.split('{input:',1)[1].split(',maxBuffer:',1)[0]);base_messages=[json.loads(s) for s in original_input.splitlines()];assert [m['id'] for m in base_messages]==[1,2,3,4,5]
old_reply=[json.loads(s) for s in (red_out/'original-mixed-mcp-positive.stdout').read_text(encoding='utf8').splitlines()];old_tools=item(old_reply,2)['result']['tools']
def mcp(name,label):
 server=list(red['restrictedServerArgv']);server[server.index('--id')+1]=label
 messages=json.loads(json.dumps(base_messages));messages[-1]['params']['arguments']['session_id']=label
 driver=jobroot/(name+'.cjs');driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync("+json.dumps(str(native))+","+json.dumps(server[1:])+",{input:"+json.dumps('\n'.join(json.dumps(m,separators=(',',':')) for m in messages)+'\n')+",maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8');shutil.copyfile(driver,out/driver.name);reply=run(name,[node,driver],timeout=90);return [json.loads(s) for s in reply.decode('utf8').splitlines()]
before=sql();(out/'legacy-store-before.sql').write_bytes(before)
try:
 selected({'context':'desktop-app','steering':{}})
 assert run('original-cli-without-inclusions',[*common,'--id','positive'])==(red_out/'original-configuration.stdout').read_bytes()
 assert run('same-original-mixed-mcp-without-inclusions',[node,red['driver']])==(red_out/'original-mixed-mcp-positive.stdout').read_bytes()
 selected(restricted)
 assert run('same-original-restricted-cli',[*common,'--id','restricted'])==(red_out/'original-restricted-configuration.stdout').read_bytes()
 assert run('same-original-restricted-mcp',[node,red['restrictedDriver']])==(red_out/'original-restricted-mcp-positive.stdout').read_bytes()
 assert sql()==before;(out/'legacy-store-after.sql').write_bytes(sql())
 for label,cli,tool_allowed,api_allowed in [
  ('includedOptionalTools',{'includedOptionalTools':['read_file']},True,False),
  ('includedApis',{'includedApis':['fs.read_file']},False,True),
  ('both',{'includedOptionalTools':['read_file'],'includedApis':['fs.read_file']},True,True),
 ]:
  selected({**restricted,'steering':{**restricted['steering'],'cli':cli}})
  cfg=json.loads(run('same-original-'+label+'-setting-admitted',[*common,'--id',label]))['results'][0]
  assert cfg['steering']['inclusions']==[{'source':'cli','tools':cli.get('includedOptionalTools',[]),'apis':cli.get('includedApis',[])}]
  reply=mcp('same-original-'+label+'-mcp',label)
  assert item(reply,2)['result']['tools']==[t for t in old_tools if tool_allowed or t['name']!='read_file']
  assert item(reply,4)['result']['isError']==(not tool_allowed)
  assert not item(reply,5)['result']['isError'];data=json.loads(item(reply,5)['result']['content'][0]['text'])['data']['result']
  assert data=={'answer':42,'hasRead':api_allowed,'text':(root/'main.rs').read_bytes().decode('utf8') if api_allowed else None}
  value=run('old-binding-'+label+'-refused',[*common,'--id','restricted'],expected=None);assert rows[-1]['exitCode']==1 and not value and b'Session host binding changed' in (out/('old-binding-'+label+'-refused.stderr')).read_bytes()
 for label,host_value in [('unknown-tool',{'steering':{'cli':{'includedOptionalTools':['unknown']}}}),('unknown-api',{'steering':{'cli':{'includedApis':['fs.unknown']}}}),('fixed-conflict',{'steering':{'cli':{'fixedTools':['get_current_config'],'includedOptionalTools':['read_file']}}})]:
  selected(host_value);prior=sql();value=run('invalid-'+label+'-before-publication',[*common,'--id','invalid'],expected=None);assert rows[-1]['exitCode']==1 and not value and sql()==prior
finally:profile.write_bytes(original)
current=records();assert all(current.get((r['kind'],r['id']))==r['value'] for r in old_records)
files={str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in root.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(root).parts};assert files==red['sourceGitFiles'] and profile.read_bytes()==original
(out/'result.json').write_text(json.dumps({'complete':True,'cliSha256':native_hash,'sameOriginalRedSourceRoot':str(root),'legacyAndRestrictedCliFullMcpRawSchemasAndLogicalSqlExact':True,'toolOnlyApiOnlyAndCombinedInclusionsFunctionalAndIndependent':True,'originalSchemaSubsetsExact':True,'realTrustedPythonAnswer42AndOriginalSourceRead':True,'oldBindingsAndInvalidBeforePublicationRefused':True,'originalRecordsAndSourceGitExact':True,'noExecutionTrustOrSourceApplicationGrantAdded':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'modelCalled':False,'analyzedSourceExecuted':False,'commands':rows},indent=2)+'\n',encoding='utf8');print('Same original tool/API inclusion fixture GREEN.',flush=True)
