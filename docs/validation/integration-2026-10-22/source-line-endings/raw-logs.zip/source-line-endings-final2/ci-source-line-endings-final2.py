from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/source-line-endings-final2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import re,traceback
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';prior=w/'validation/integration-20261018/source-line-endings-checks2';checked=json.loads((prior/'result.json').read_bytes());inputs=json.loads((prior/'source-before.json').read_bytes());assert checked['complete'] and checked['allJobsEmpty'] and checked['sourceInputsUnchanged'] and len(inputs)==1037 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
for row in checked['rows']:
 name=row['name']
 if name=='git-init':continue
 assert row['activeAfterCleanup']==0
 if name!='cargo-format-all-windows-limit':assert row['exitCode']==0
 for ext in ['stdout','stderr']:shutil.copyfile(prior/(name+'.'+ext),out/(name+'.'+ext))
 rows.append({**row,'reusedCheckedPhase':'source-line-endings-checks2','rerun':False})
shutil.copyfile(prior/'format-targets.json',out/'format-targets.json')
targets=['shared-lib','source_line_endings','plan_integrity','project_session','session_mcp','session_steering','session_primary_read_only','session_config_cli','session_refactor','session_root_aliases','session_review','agent_repl','agent_facade_semantics','compatibility','compatibility_review','compiler_inline','compiler_inline_body','compiler_inline_predicates','compiler_move','lsp','lsp_action_resolve','lsp_enrichment','refactor_intents','semantic_refactor','facade_directory_move','directory_move_live','facade_file_move','facade_file_rename'];assert len(targets)==28
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';complete=False
try:
 for target in targets:
  deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()}
  # libtest OR filters after -- are documented at doc.rust-lang.org/rustc/tests/index.html#filters.
  command=[cargo,'test','--locked','-j','2',*(['--lib','--','source_line_endings::','session_config::','changes::'] if target=='shared-lib' else ['--test',target,'--']),'--nocapture','--test-threads=1']
  run(target,command,expected=None,timeout=1200 if target=='compiler_inline_body' else 600);assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed';cleanup=[]
  for p in deps.iterdir():
   if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(('yoke' if target=='shared-lib' else target)+'-'):continue
   assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h
   try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':True})
   except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
  (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf8');assert rows[-1]['exitCode']==0,(target,rows[-1]['exitCode'])
 complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':targets,'reusedTargets':[],'checksReusedOnExactInputs':'source-line-endings-checks2','sharedLibFilters':['source_line_endings::','session_config::','changes::'],'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
