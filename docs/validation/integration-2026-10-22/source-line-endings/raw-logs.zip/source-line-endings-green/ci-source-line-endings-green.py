from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/source-line-endings-green';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-green-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])
import sqlite3
redroot=w/'validation/integration-20261018/source-line-endings-red';red=json.loads((redroot/'result.json').read_bytes());source=Path(red['sourceRoot']);cwd=source;profile=Path(red['profile']);selected=Path(red['lineEndingsProfile']);assert sha(profile)==red['profileSha256'] and sha(selected)==red['lineEndingsProfileSha256']
final=w/'validation/integration-20261018/source-line-endings-final2';result=json.loads((final/'result.json').read_bytes());frozen=json.loads((final/'source-before.json').read_bytes());assert len(frozen)==1037 and result['complete'] and result['allJobsEmpty'] and result['cliSha256']==native_hash and all(sha(w/n)==h for n,h in frozen.items())
def source_files():return {p.relative_to(source).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(source).parts}
def database():
 db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8'),{(k,i):v for k,i,v in db.execute('select kind,id,value from records')}
 finally:db.close()
original_sql,original_records=database();assert original_sql==(redroot/'original-store.sql').read_bytes() and source_files()==red['sourceGitFiles']
assert run('legacy-absent-configuration-raw',red['configArgv'])==(redroot/'original-config-positive.stdout').read_bytes()
assert run('legacy-absent-mcp53-source-raw',[node,red['driver']])==(redroot/'original-mcp-read-positive.stdout').read_bytes()
explicit_null=jobroot/'null.json';explicit_null.write_text(json.dumps({**json.loads(profile.read_bytes()),'sourceLineEndings':None}),encoding='utf8')
null_argv=[str(explicit_null) if str(a)==str(profile) else a for a in red['configArgv']];assert run('legacy-explicit-null-configuration-raw',null_argv)==(redroot/'original-config-positive.stdout').read_bytes()
driver_text=Path(red['driver']).read_text(encoding='utf8');assert driver_text.count(json.dumps(str(profile)))==1;null_driver=jobroot/'null-mcp.cjs';null_driver.write_text(driver_text.replace(json.dumps(str(profile)),json.dumps(str(explicit_null))),encoding='utf8');assert run('legacy-explicit-null-mcp53-source-raw',[node,null_driver])==(redroot/'original-mcp-read-positive.stdout').read_bytes()
assert database()[0]==original_sql
oldplan=red['originalPrepared']['data']['plan'];oldblob=source/'.yoke/blobs'/oldplan['files'][0]['afterHash'];original_plan_bytes=oldblob.read_bytes();assert original_plan_bytes==b'// owned\r\nfn planned() {}\n' and 'sourceLineEnding' not in oldplan
common=[str(native),'--root',str(source),'--allow-writes','--timeout','60000','--max-bytes','4000000'];oldchecked=json.loads(run('original-stored-plan-checked-replay',[*common,'invoke','ci_verify','--args',json.dumps({'planId':oldplan['id']})]));assert oldchecked['status']=='ok'
formatted=json.loads(run('same-original-host-setting-green',red['formattedArgv']));assert formatted['results'][0]['sourceLineEnding']=='crlf'
prepare_argv=[str(red['editRequests']) if str(a)==str(red['configuration']) else a for a in red['formattedArgv']];prepared=json.loads(run('same-original-edits-formatted-plan',prepare_argv))['results'][0]['data']['plan'];assert prepared['sourceLineEnding']=='crlf';expected=b'// owned\r\nfn planned() {}\r\n';actual=(source/'.yoke/blobs'/prepared['files'][0]['afterHash']).read_bytes();assert actual==expected and prepared['files'][0]['afterHash']==hashlib.sha256(expected).hexdigest() and oldblob.read_bytes()==original_plan_bytes
checked=json.loads(run('formatted-plan-checked-replay',[*common,'invoke','ci_verify','--args',json.dumps({'planId':prepared['id']})]));assert checked['status']=='ok'
yaml_plan=json.loads(run('same-original-yaml-setting-green',red['yamlPlanArgv']));assert yaml_plan['hostProfile']['sourceLineEndings']=={'projects':{'default':{'project':'crlf'}}} and not yaml_plan['sourceBytesRewritten']
output=jobroot/'yaml-profile.json';run('same-original-yaml-export',[native,'--timeout','60000','--max-bytes','4000000','session-config','export','--selection',red['selection'],'--output',output,'--allow-configuration-read','--allow-policy-projection','--allow-output'])
equivalent=jobroot/'equivalent-json.json';equivalent.write_text(json.dumps({**json.loads(profile.read_bytes()),'sourceLineEndings':{'projects':{'default':{'project':'crlf'}}}}),encoding='utf8')
yaml_argv=[*common,'session','--id','yaml-equivalent','--host-profile',str(equivalent),'--requests',red['configuration']];before=run('equivalent-json-binding',yaml_argv);yaml_argv=[str(output) if str(a)==str(equivalent) else a for a in yaml_argv];assert run('yaml-resumes-equivalent-json-binding',yaml_argv)==before
for name,argv in [('absent-to-selected-binding',[str(selected) if str(a)==str(profile) else a for a in red['configArgv']]),('selected-to-null-binding',[str(explicit_null) if str(a)==str(selected) else a for a in red['formattedArgv']])]:
 assert not run(name,argv,expected=None) and rows[-1]['exitCode']==1 and b'Session host binding changed' in (out/(name+'.stderr')).read_bytes()
final_sql,current_records=database();assert all(current_records.get(key)==value for key,value in original_records.items());assert source_files()==red['sourceGitFiles'] and not(source/'planned.rs').exists() and sha(profile)==red['profileSha256'] and sha(selected)==red['lineEndingsProfileSha256'] and sha(Path(red['yaml']))==red['yamlSha256'] and sha(Path(red['selection']))==red['selectionSha256'] and all(sha(w/n)==h for n,h in frozen.items())
(out/'final-store.sql').write_bytes(final_sql);(out/'result.json').write_text(json.dumps({'complete':True,'cliSha256':native_hash,'originalCliSha256':red['cliSha256'],'sourceRoot':str(source),'legacyAbsentNullCliAndMcpRawExact':True,'wholeLegacySqlExactBeforeNewBindings':True,'originalStoredRecordValuesExactAfterNewBindings':True,'originalMixedPlanBytesAndCheckedReplayExact':True,'selectedPlanAfterBytesAndHashesExact':True,'yamlEquivalentJsonBindingResumed':True,'bindingUpgradeDowngradeRefused':True,'sourceGitHostYamlBytesExact':True,'sourceWritten':False,'frozenInputs':len(frozen),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'commands':rows},indent=2)+'\n',encoding='utf8')
