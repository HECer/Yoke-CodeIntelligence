from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/source-line-endings-checks2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import re,traceback
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';prior=w/'validation/integration-20261018/source-line-endings-final';r=json.loads((prior/'result.json').read_bytes());old=json.loads((prior/'source-before.json').read_bytes());assert r['allJobsEmpty'] and r['sourceInputsUnchanged'] and len(old)==1037;inputs={n:sha(w/n) for n in old};assert {n for n in old if old[n]!=inputs[n]}=={'native/src/session_config.rs'};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';complete=False
def unchanged():assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed'
try:
 for name,argv in [('clippy',[cargo,'clippy','--locked','--all-targets','-j','2','--','-D','warnings']),('build',[cargo,'build','--locked','-j','2','--bin','yoke']),('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:run(name,argv,timeout=600);unchanged()
 run('cargo-format-all-windows-limit',[cargo,'fmt','--all','--check'],expected=None,timeout=120);unchanged()
 if rows[-1]['exitCode']!=0:assert b'os error 206' in (out/'cargo-format-all-windows-limit.stderr').read_bytes()
 metadata=json.loads(run('format-target-metadata',[cargo,'metadata','--no-deps','--format-version','1'],timeout=60));unchanged();roots=sorted(set(t['src_path'] for package in metadata['packages'] for t in package['targets']));assert len(roots)>300;(out/'format-targets.json').write_text(json.dumps(roots,indent=2)+'\n',encoding='utf8')
 for i in range(0,len(roots),20):run('format-targets-'+str(i//20),[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','--check',*roots[i:i+20]],timeout=120);unchanged()
 complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
