from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,re,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','google-http-export-final').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-google-http-final-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';prior=w/'validation/integration-20261018/google-http-export-r4';narrow=json.loads((prior/'result.json').read_bytes());old=json.loads((prior/'source-before.json').read_bytes());inputs={n:sha(w/n) for n in old};assert len(inputs)==1028 and inputs==old and narrow['complete'] and narrow['allJobsEmpty'];(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');assert sha(w/'native/tests/fixtures/postgres-catalog-response.jsonl')=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47'
targets=list(narrow['targets']);assert len(targets)==12;reused=[]
for row in narrow['rows']:
 name=row['name']
 if name=='git-init':continue
 assert name in targets and row['exitCode']==0 and row['activeAfterCleanup']==0
 for ext in ['stdout','stderr']:shutil.copyfile(prior/(name+'.'+ext),out/(name+'.'+ext))
 rows.append({**row,'reusedCheckedPhase':'google-http-export-r4','rerun':False});reused.append(name)
assert len(reused)==12;targets=[t for t in targets if t not in reused];assert len(targets)==0;cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';complete=False
try:
 for target in targets:
  deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()};run(target,[cargo,'test','--locked','-j','2','--test',target,'--','--nocapture','--test-threads=1'],expected=None,timeout=90 if target=='mcp_http' else 300);assert all(sha(w/n)==h for n,h in inputs.items());cleanup=[]
  for p in deps.iterdir():
   if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(target+'-'):continue
   assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h
   try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':True})
   except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
  (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf8');assert rows[-1]['exitCode']==0,(target,rows[-1]['exitCode'])
 for name,argv in [('clippy',[cargo,'clippy','--locked','--all-targets','-j','2','--','-D','warnings']),('fmt',[cargo,'fmt','--all','--check']),('build',[cargo,'build','--locked','-j','2','--bin','yoke']),('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:
  run(name,argv,timeout=600);assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed'
 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':targets,'reusedTargets':reused,'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
