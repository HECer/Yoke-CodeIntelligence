from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/google-http-export-green2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-google-http-green-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

red=json.loads((w/'validation/integration-20261018/google-http-export-red/result.json').read_bytes());source=Path(red['sourceRoot']);cwd=source;config=Path(red['httpConfig']);original_config=config.read_bytes();old_spec=json.loads(original_config);archive=Path(red['archive']);assert sha(archive)==red['archiveSha256'];frozen=json.loads((w/'validation/integration-20261018/google-http-export-final/source-before.json').read_bytes());assert len(frozen)==1028 and all(sha(w/n)==h for n,h in frozen.items())
original_source_files={n.replace('\\','/'):v for n,v in red['sourceGitFiles'].items()}
def files():return {p.relative_to(source).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.rglob('*') if p.is_file()}
assert files()==original_source_files;common=[native,'--timeout','60000','--max-bytes','4000000','source-acquisition'];plan_tail=['google-http-plan','--config',config,'--source-root',source,'--allow-shortcut-read','--trust-native-exporter'];complete=False
try:
 old=run('original-native-pin-stale-refusal',[*common,*plan_tail],expected=None);assert rows[-1]['exitCode']==1 and not old and b'google_workspace_native_exporter_changed' in (out/'original-native-pin-stale-refusal.stderr').read_bytes()
 selected={**old_spec,'expectedExporterSha256':native_hash};config.write_text(json.dumps(selected),encoding='utf8');selected_bytes=config.read_bytes();assert {k for k in old_spec if old_spec[k]!=selected[k]}=={'expectedExporterSha256'}
 plan=run('same-original-native-header-plan-green',[*common,*plan_tail]);v=json.loads(plan);assert v['schema']=='native_google_workspace_http_plan_v1' and v['requests']==0 and not v['credentialsRead'] and not v['outputCreated'] and v['resourceKeyPresent'] and v['resourceKeyTransport']=='X-Goog-Drive-Resource-Keys';assert v['metadata']['shortcutSha256']==old_spec['expectedShortcutSha256'] and v['metadata']['fileId']==old_spec['expectedFileId'] and v['exporterClaim']['executableSha256']==native_hash;assert b'owned_resource_key_canary' not in plan and not (source/'.yoke').exists()
 assert run('same-original-native-plan-repeat',[*common,*plan_tail])==plan
 replay=run('same-original-received-archive-replay',[*common,'google-read','--input',archive]);assert replay==(w/'validation/integration-20261018/google-http-export-red/original-received-archive-replay-positive.stdout').read_bytes()
 oldgws=run('same-original-gws-key-refusal',red['gwsArgv'],expected=None);assert rows[-1]['exitCode']==1 and not oldgws;assert (out/'same-original-gws-key-refusal.stderr').read_bytes()==(w/'validation/integration-20261018/google-http-export-red/original-resource-key-transport-refused.stderr').read_bytes()
 capture=['google-http-capture','--config',config,'--source-root',source,'--output',source.parent/'must-not-create-native.json','--allow-shortcut-read','--allow-network','--allow-private-credential','--trust-native-exporter','--access-token-stdin','--allow-output']
 for flag in ['--allow-shortcut-read','--allow-network','--allow-private-credential','--trust-native-exporter','--access-token-stdin','--allow-output']:
  refused=run('missing-'+flag[2:],[*common,*[a for a in capture if a!=flag]],expected=None);assert rows[-1]['exitCode']==1 and not refused and b'google_workspace_http_host_permission_required' in (out/('missing-'+flag[2:]+'.stderr')).read_bytes()
 for index in range(3):
  changed=dict(selected)
  if index==0:changed['accessToken']='owned_rejected_private_canary'
  elif index==1:changed['expectedShortcutSha256']='0'*64
  else:changed['address']='0.0.0.0:443'
  config.write_text(json.dumps(changed),encoding='utf8');refused=run('invalid-selection-'+str(index),[*common,*capture],expected=None);assert rows[-1]['exitCode']==1 and not refused and b'owned_rejected_private_canary' not in (out/('invalid-selection-'+str(index)+'.stderr')).read_bytes();config.write_bytes(selected_bytes)
 empty=run('empty-private-input-refused-before-network',[*common,*capture],expected=None);assert rows[-1]['exitCode']==1 and not empty and b'google_workspace_private_token' in (out/'empty-private-input-refused-before-network.stderr').read_bytes()
 assert not (source.parent/'must-not-create-native.json').exists() and files()==original_source_files and sha(archive)==red['archiveSha256'] and all(sha(w/n)==h for n,h in frozen.items()) and sha(native)==native_hash
 complete=True
finally:
 config.write_bytes(original_config)
 (out/'result.json').write_text(json.dumps({'complete':complete,'cliSha256':native_hash,'sourceRoot':str(source),'originalPublishedCliSha256':red['cliSha256'],'sameOriginalReplayRawBytesExact':replay==(w/'validation/integration-20261018/google-http-export-red/original-received-archive-replay-positive.stdout').read_bytes() if 'replay' in globals() else False,'sourceGitFilesExact':files()==original_source_files,'originalArchiveExact':sha(archive)==red['archiveSha256'],'originalConfigRestored':config.read_bytes()==original_config,'onlyHostNativeImagePinSelectedForPlan':True,'noGoogleDocumentAccessed':True,'noCredentialsRead':True,'noNetworkRequests':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'frozenSourceUnchanged':all(sha(w/n)==h for n,h in frozen.items()),'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
