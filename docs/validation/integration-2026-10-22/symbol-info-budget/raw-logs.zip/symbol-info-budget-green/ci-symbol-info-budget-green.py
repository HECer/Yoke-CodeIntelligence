from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/symbol-info-budget-green';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import sqlite3
redroot=w/'validation/integration-20261018/symbol-info-budget-red';red=json.loads((redroot/'result.json').read_bytes());reviewroot=redroot.with_name('symbol-info-budget-red-hover-review');review=json.loads((reviewroot/'result.json').read_bytes());assert review['complete'] and review['correctedEnvelopeReadback'] and not review['commandRerun']
source=Path(red['sourceRoot']);cwd=source;profile=Path(red['profile']);selected=Path(red['exclusionsProfile']);assert sha(profile)==red['profileSha256'] and sha(selected)==red['exclusionsProfileSha256']
phase=w/'validation/integration-20261018/symbol-info-budget-final';result=json.loads((phase/'result.json').read_bytes());frozen=json.loads((phase/'source-before.json').read_bytes());assert len(frozen)==1044 and result['complete'] and result['allJobsEmpty'] and result['cliSha256']==native_hash and all(sha(w/n)==h for n,h in frozen.items())
def source_files():return {f.relative_to(source).as_posix():{'bytes':f.stat().st_size,'sha256':sha(f)} for f in source.rglob('*') if f.is_file() and '.yoke' not in f.relative_to(source).parts}
def database():
 db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8'),{(k,i):v for k,i,v in db.execute('select kind,id,value from records')}
 finally:db.close()
original_sql,original_records=database();assert original_sql==(reviewroot/'expanded-original-store.sql').read_bytes() and source_files()==red['sourceGitFiles']
assert run('legacy-absent-config-raw',red['configArgv'])==(redroot/'original-config-positive.stdout').read_bytes()
assert run('legacy-absent-mcp53-raw',[node,red['driver']])==(redroot/'original-mcp53-private-read-positive.stdout').read_bytes()
driver=Path(review['driver']);arguments=review['arguments'];log=Path(review['log']);fixture=Path(review['fixture']);servers=Path(review['serverConfiguration']);assert sha(fixture)==review['fixtureSha256'] and sha(servers)==review['serverConfigurationSha256']
old_hover=(redroot.with_name('symbol-info-budget-red-hover')/'original-unlimited-hover-mcp.stdout').read_bytes();assert sha(redroot.with_name('symbol-info-budget-red-hover')/'original-unlimited-hover-mcp.stdout')==review['rawStdoutSha256']
assert run('legacy-absent-actual-hover-mcp-raw',[node,driver,native,json.dumps(arguments)])==old_hover
for name,policy in [('null',None),('empty',{'globalMs':None,'projects':{'default':{'localMs':None}}})]:
 path=jobroot/(name+'.json');path.write_text(json.dumps({**json.loads(profile.read_bytes()),'symbolInfoBudgets':policy}),encoding='utf8')
 argv=[str(path) if str(a)==str(profile) else a for a in red['configArgv']];assert run('legacy-'+name+'-configuration-raw',argv)==(redroot/'original-config-positive.stdout').read_bytes()
 script=Path(red['driver']).read_text(encoding='utf8');assert script.count(json.dumps(str(profile)))==1;copy=jobroot/(name+'-mcp.cjs');copy.write_text(script.replace(json.dumps(str(profile)),json.dumps(str(path))),encoding='utf8');assert run('legacy-'+name+'-mcp53-raw',[node,copy])==(redroot/'original-mcp53-private-read-positive.stdout').read_bytes()
 argv=[str(path) if str(a)==str(profile) else a for a in arguments];assert run('legacy-'+name+'-actual-hover-mcp-raw',[node,driver,native,json.dumps(argv)])==old_hover
assert database()[0]==original_sql
config=json.loads(run('same-original-host-budget-green',red['excludedArgv']))['results'][0];assert config['symbolInfoBudgets']=={'globalMs':1} and config['symbolInfoBudgetMs']==1
def hover_count():return sum(json.loads(l).get('method')=='textDocument/hover' for l in log.read_text(encoding='utf8').splitlines())
for name,path,ms,expected in [('bounded',selected,1,1),('unlimited',jobroot/'zero.json',0,3)]:
 if name=='unlimited':path.write_text(json.dumps({**json.loads(profile.read_bytes()),'symbolInfoBudgets':{'globalMs':0}}),encoding='utf8')
 argv=['hover-'+name if a=='legacy-hover' else str(path) if str(a)==str(profile) else a for a in arguments];before=hover_count();response=run('actual-mcp-'+name+'-hover',[node,driver,native,json.dumps(argv)]);values=[json.loads(l) for l in response.decode().splitlines()];call=next(v['result'] for v in values if v.get('id')==3);assert not call['isError'];outer=json.loads(call['content'][0]['text']);assert outer['status']=='ok';value=outer['data'];assert len(value['items'])==3 and value['symbolInfo']['budgetMs']==ms and value['symbolInfo']['retrieved']==expected and value['symbolInfo']['omitted']==3-expected and hover_count()-before==expected
 assert sum('info' in v for v in value['items'])==expected
 for item in value['items']:
  if 'info' not in item:assert item['infoOmitted']['reason']=='symbol_info_budget_elapsed'
common=[str(native),'--root',str(source),'--allow-writes','--timeout','60000','--max-bytes','4000000','session','--id','budgeted','--host-profile',str(selected)]
reply=json.loads(run('selected-scope-does-not-change-source-reads',[*common,'--requests',red['readRequests']]))['results'][0];assert reply['status']=='ok'
oldplan=red['originalPlan'];assert (source/'.yoke/blobs'/oldplan['files'][0]['afterHash']).read_bytes()==b'// owned\r\nfn planned() {}\n'
prepared=json.loads(run('selected-budget-does-not-change-source-preparation',[*common,'--requests',red['editRequests']]))['results'][0];assert prepared['status']=='ok' and not(source/'private/new.rs').exists()
yaml_plan=json.loads(run('same-original-fractional-seconds-yaml-green',red['yamlPlanArgv']));assert yaml_plan['hostProfile']['symbolInfoBudgets']=={'globalMs':1} and not yaml_plan['sourceBytesRewritten']
output=jobroot/'yaml-profile.json';run('same-original-yaml-export',[native,'--timeout','60000','--max-bytes','4000000','session-config','export','--selection',red['selection'],'--output',output,'--allow-configuration-read','--allow-policy-projection','--allow-output']);before=run('selected-json-binding',red['excludedArgv']);argv=[str(output) if str(a)==str(selected) else a for a in red['excludedArgv']];assert run('yaml-resumes-same-json-binding',argv)==before
for name,argv in [('absent-to-selected-binding',[str(selected) if str(a)==str(profile) else a for a in red['configArgv']]),('selected-to-absent-binding',[str(profile) if str(a)==str(selected) else a for a in red['excludedArgv']])]:
 assert not run(name,argv,expected=None) and rows[-1]['exitCode']==1 and b'Session host binding changed' in (out/(name+'.stderr')).read_bytes()
final_sql,records=database();assert all(records.get(k)==v for k,v in original_records.items()) and source_files()==red['sourceGitFiles'] and sha(profile)==red['profileSha256'] and sha(selected)==red['exclusionsProfileSha256'] and sha(Path(red['yaml']))==red['yamlSha256'] and sha(Path(red['selection']))==red['selectionSha256'] and sha(fixture)==review['fixtureSha256'] and sha(servers)==review['serverConfigurationSha256'] and all(sha(w/n)==h for n,h in frozen.items()) and sha(native)==native_hash
(out/'final-store.sql').write_bytes(final_sql);(out/'result.json').write_text(json.dumps({'complete':True,'cliSha256':native_hash,'originalCliSha256':red['cliSha256'],'legacyAbsentNullEmptyConfigurationMcp53AndActualHoverRawExact':True,'wholeExpandedLegacySqlExactBeforeNewBindings':True,'originalStoredRecordValuesExactAfterNewBindings':True,'actualBoundedAndZeroUnlimitedHoverMcpQualified':True,'originalMixedPlanBytesSourceReadsAndPreparationUnaffected':True,'yamlEquivalentJsonBindingResumed':True,'bindingUpgradeDowngradeRefused':True,'sourceGitHostYamlFixtureConfigurationBytesExact':True,'sourceWritten':False,'frozenInputs':len(frozen),'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'commands':rows},indent=2)+'\n',encoding='utf8')
