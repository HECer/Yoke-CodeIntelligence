from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/symbol-info-budget-red-hover';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=Path(json.loads((w/'validation/integration-20261018/symbol-info-budget-red/original-cli-copy.json').read_bytes())['path'])
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import sqlite3
redroot=w/'validation/integration-20261018/symbol-info-budget-red';red=json.loads((redroot/'result.json').read_bytes());source=Path(red['sourceRoot']);cwd=source
assert native_hash==red['cliSha256']
def database():
 db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8'),{(k,i):v for k,i,v in db.execute('select kind,id,value from records')}
 finally:db.close()
def source_files():return {f.relative_to(source).as_posix():{'bytes':f.stat().st_size,'sha256':sha(f)} for f in source.rglob('*') if f.is_file() and '.yoke' not in f.relative_to(source).parts}
before,records=database();assert before==(redroot/'original-store.sql').read_bytes() and source_files()==red['sourceGitFiles']
log=jobroot/'requests.jsonl';fixture=w/'native/tests/fixtures/symbol-info-budget-lsp.mjs';fixture_hash=sha(fixture);servers=jobroot/'servers.json';servers.write_text(json.dumps([{'language':'rust','command':str(node),'args':[str(fixture),str(log),'100',''],'configuration':{'passiveProfile':'contract_fixture'}}]),encoding='utf8')
arguments=['--root',str(source),'--timeout','60000','--max-bytes','4000000','--language-server-config',str(servers),'--trust-servers','serve-session','--id','legacy-hover','--profile','serena','--host-profile',red['profile']]
messages=[{'jsonrpc':'2.0','id':1,'method':'initialize'},{'jsonrpc':'2.0','id':2,'method':'tools/list'},{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'find_symbol','arguments':{'name_path_pattern':'*','include_info':True}}}]
driver=jobroot/'hover.cjs';driver.write_text("const cp=require('node:child_process');const result=cp.spawnSync(process.argv[2],JSON.parse(process.argv[3]),{input:"+json.dumps(''.join(json.dumps(m)+'\n' for m in messages))+",encoding:'utf8',timeout:60000,maxBuffer:8000000});process.stdout.write(result.stdout??'');process.stderr.write(result.stderr??'');process.exit(result.status??1);",encoding='utf8')
response=run('original-unlimited-hover-mcp',[node,driver,native,json.dumps(arguments)]);reply=[json.loads(l) for l in response.decode().splitlines()];assert len(next(v['result']['tools'] for v in reply if v.get('id')==2))==53;call=next(v['result'] for v in reply if v.get('id')==3);assert not call['isError'];value=json.loads(call['content'][0]['text']);assert len(value['items'])==3 and all('info' in i for i in value['items']) and 'symbolInfo' not in value
assert sum(json.loads(l)['method']=='textDocument/hover' for l in log.read_text(encoding='utf8').splitlines())==3
sql,after=database();assert all(after.get(k)==v for k,v in records.items()) and source_files()==red['sourceGitFiles'] and sha(fixture)==fixture_hash and sha(native)==native_hash
(out/'expanded-original-store.sql').write_bytes(sql);(out/'result.json').write_text(json.dumps({'complete':True,'originalCli':str(native),'originalCliSha256':native_hash,'fixture':str(fixture),'fixtureSha256':fixture_hash,'serverConfiguration':str(servers),'serverConfigurationSha256':sha(servers),'log':str(log),'driver':str(driver),'arguments':arguments,'originalStoredValuesExact':True,'sourceGitBytesExact':True,'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'commands':rows},indent=2)+'\n',encoding='utf8')
