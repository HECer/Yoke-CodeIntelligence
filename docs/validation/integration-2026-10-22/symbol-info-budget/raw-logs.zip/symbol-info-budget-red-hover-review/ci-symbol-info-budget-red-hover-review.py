from pathlib import Path
import hashlib,json,os,shutil,sqlite3
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');p=Path(os.environ['TEMP']);first=w/'validation/integration-20261018/symbol-info-budget-red-hover';out=first.with_name('symbol-info-budget-red-hover-review');out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
def sha(f):
 h=hashlib.sha256()
 with f.open('rb') as stream:
  while b:=stream.read(65536):h.update(b)
 return h.hexdigest()
rows=[json.loads(l) for l in (p/'ci-symbol-info-budget-red-hover-controller.stdout').read_text(encoding='utf8').splitlines() if l.startswith('{')];assert len(rows)==2 and all(r['exitCode']==0 and r['activeAfterCleanup']==0 for r in rows)
assert json.loads((p/'ci-symbol-info-budget-red-hover-terminal.json').read_bytes())['exitCode']==1
reply=[json.loads(l) for l in (first/'original-unlimited-hover-mcp.stdout').read_text(encoding='utf8').splitlines()];call=next(v['result'] for v in reply if v.get('id')==3);assert not call['isError'];outer=json.loads(call['content'][0]['text']);assert outer['status']=='ok';value=outer['data'];assert len(value['items'])==3 and all('info' in v for v in value['items']) and 'symbolInfo' not in value
red=json.loads((first.parent/'symbol-info-budget-red/result.json').read_bytes());source=Path(red['sourceRoot']);command=rows[-1]['command'];native=Path(command[2]);arguments=json.loads(command[3]);configuration=Path(arguments[arguments.index('--language-server-config')+1]);spec=json.loads(configuration.read_bytes());fixture=Path(spec[0]['args'][0]);log=Path(spec[0]['args'][1]);before=json.loads((first.parent/'symbol-info-budget-preflight3/source-before.json').read_bytes())
assert sha(native)==red['cliSha256'] and sha(fixture)==before['native/tests/fixtures/symbol-info-budget-lsp.mjs'] and sha(Path(red['profile']))==red['profileSha256']
assert sum(json.loads(l).get('method')=='textDocument/hover' for l in log.read_text(encoding='utf8').splitlines())==3
actual={f.relative_to(source).as_posix():{'bytes':f.stat().st_size,'sha256':sha(f)} for f in source.rglob('*') if f.is_file() and '.yoke' not in f.relative_to(source).parts};assert actual==red['sourceGitFiles']
db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
try:
 records={(k,i):v for k,i,v in db.execute('select kind,id,value from records')};sql=('\n'.join(db.iterdump())+'\n').encode('utf8')
finally:db.close()
original=json.loads((first.parent/'symbol-info-budget-red/original-records.json').read_bytes());assert all(records.get((r['kind'],r['id']))==r['value'] for r in original)
(out/'expanded-original-store.sql').write_bytes(sql);(out/'result.json').write_text(json.dumps({'complete':True,'kind':'recorded_successful_command_readback','originalHarnessFailed':True,'harnessFailure':'Outer MCP native envelope was read as its data payload; KeyError items.','commandRerun':False,'correctedEnvelopeReadback':True,'rawStdoutSha256':sha(first/'original-unlimited-hover-mcp.stdout'),'originalCli':str(native),'originalCliSha256':sha(native),'fixture':str(fixture),'fixtureSha256':sha(fixture),'serverConfiguration':str(configuration),'serverConfigurationSha256':sha(configuration),'driver':command[1],'arguments':arguments,'log':str(log),'originalStoredValuesExact':True,'sourceGitBytesExact':True,'allRecordedCommandJobsEmpty':True,'commands':rows},indent=2)+'\n',encoding='utf8');print('Read back genuine original CLI success:3 hover results; failed outer-envelope harness remains recorded as failed.')
