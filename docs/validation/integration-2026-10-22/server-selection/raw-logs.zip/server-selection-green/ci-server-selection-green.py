from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/server-selection-green';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-symbol-workspace-folders-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])
import sqlite3
redroot=w/'validation/integration-20261018/server-selection-red2';red=json.loads((redroot/'result.json').read_bytes());assert red['complete'] and red['allJobsEmpty'];source=Path(red['sourceRoot']);cwd=source
phase=w/'validation/integration-20261018/server-selection-final';checked=json.loads((phase/'result.json').read_bytes());frozen=json.loads((phase/'source-before.json').read_bytes());assert checked['complete'] and checked['allJobsEmpty'] and checked['cliSha256']==native_hash and len(frozen)==1051 and all(sha(w/name)==digest for name,digest in frozen.items())
def database():
 db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode(),{(kind,record_id):value for kind,record_id,value in db.execute('select kind,id,value from records')}
 finally:db.close()
def source_files():return {p.relative_to(source).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(source).parts}
original_sql=(redroot/'original-store.sql').read_bytes();initial_sql,original_records=database();assert initial_sql==original_sql and source_files()==red['sourceGitFiles'];complete=False
def replace(command,mapping):return [mapping.get(str(arg),str(arg)) for arg in command]
def real_mcp(name,profile_path,registry_path,label,paths,expected):
 messages=[{'jsonrpc':'2.0','id':1,'method':'initialize'},{'jsonrpc':'2.0','id':2,'method':'tools/list'}]
 for index,path in enumerate(paths,3):messages.append({'jsonrpc':'2.0','id':index,'method':'tools/call','params':{'name':'find_symbol','arguments':{'name_path_pattern':'*','relative_path':path,'include_info':True}}})
 command=red['mcpArgv'];server_args=json.loads(command[3]);server_args=replace(server_args,{red['legacyProfile']:str(profile_path),red['legacyServers']:str(registry_path),'legacy':label})
 driver=jobroot/(name+'.cjs');driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync(process.argv[2],JSON.parse(process.argv[3]),{input:"+json.dumps('\n'.join(json.dumps(message,separators=(',',':')) for message in messages)+'\n')+",maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8')
 raw=run(name,[node,driver,native,json.dumps(server_args)]);values=[json.loads(line) for line in raw.decode().splitlines()];assert len(next(v['result']['tools'] for v in values if v.get('id')==2))==53
 for index,backend in enumerate(expected,3):
  reply=next(v['result'] for v in values if v.get('id')==index);assert not reply['isError'],reply;outer=json.loads(reply['content'][0]['text']);assert outer['status']=='ok' and outer['data']['items'],outer
  for item in outer['data']['items']:
   info=item['info'];actor=json.loads(info['response']['contents']['value'])['actor'];assert actor==backend,(name,item);assert info['selectedBackendId']==backend and info['backendSelection']['runtimeCertification']==False
 return raw
try:
 for label,key in [('legacy-config','configArgv'),('legacy-mcp53-real-hover','mcpArgv')]:assert run('current-'+label,red[key])==(redroot/('old-'+label+'.stdout')).read_bytes()
 for label,key,expected in [('dormant-registry-config','registryArgv','old-legacy-config.stdout'),('dormant-registry-mcp','mcpArgv','old-legacy-mcp53-real-hover.stdout')]:
  command=replace(red[key],{red['legacyServers']:red['registry']})
  if key=='mcpArgv':command[3]=json.dumps(replace(json.loads(command[3]),{red['legacyServers']:red['registry']}))
  assert run(label,command)==(redroot/expected).read_bytes()
 base=json.loads(Path(red['legacyProfile']).read_bytes())
 for label,value in [('null',None),('empty',{})]:
  profile=jobroot/(label+'.json');profile.write_text(json.dumps({**base,'languageServers':value}),encoding='utf8')
  for name,key,expected in [('config','configArgv','old-legacy-config.stdout'),('mcp','mcpArgv','old-legacy-mcp53-real-hover.stdout')]:
   command=replace(red[key],{red['legacyProfile']:str(profile),red['legacyServers']:red['registry']})
   if key=='mcpArgv':command[3]=json.dumps(replace(json.loads(command[3]),{red['legacyProfile']:str(profile),red['legacyServers']:red['registry']}))
   assert run('legacy-'+label+'-'+name,command)==(redroot/expected).read_bytes()
 assert database()[0]==original_sql; (out/'legacy-store-before-new-bindings.sql').write_bytes(database()[0])
 assert not run('selected-legacy-registration-insufficient',red['selectionArgv'],expected=None) and rows[-1]['exitCode']==1 and b'language_server_not_host_registered' in (out/'selected-legacy-registration-insufficient.stderr').read_bytes()
 selected_command=replace(red['selectionArgv'],{red['legacyServers']:red['registry'],'legacy':'selected'})
 selected_config=json.loads(run('selected-registered-config',selected_command))['results'][0];assert selected_config['languageServersResolved']==['rust'] and selected_config['registeredBackendIds']==['rust']
 # The actor is independent from its backend ID in the original host-owned fixture.
 registry_value=json.loads(Path(red['registry']).read_bytes());registry_value[1]['args'][-1]='rust';registry=jobroot/'runtime-registry.json';registry.write_text(json.dumps(registry_value),encoding='utf8')
 # A different invocation is a different host binding, so use a fresh session label.
 real_mcp('selected-real-rust-hover',red['selectedProfile'],registry,'selected-runtime',['src/main.rs'],['rust'])
 fixture=w/'native/tests/fixtures/server-selection-lsp.mjs';log=jobroot/'order-protocol.log';full=jobroot/'full-registry.json'
 full.write_text(json.dumps([{'backendId':backend,'command':str(node),'args':[str(fixture),str(log),backend],'configuration':{'passiveProfile':'contract_fixture'}} for backend in ['angular','typescript']]),encoding='utf8')
 for backend_ids,label in [(['angular','typescript'],'angular-first'),(['typescript','angular'],'typescript-first')]:
  profile=jobroot/(label+'.json');profile.write_text(json.dumps({**base,'languageServers':{'global':backend_ids}}),encoding='utf8');real_mcp(label,profile,full,label,['entry.ts','extra.mts','src/main.rs'],[backend_ids[0]]*3)
 for label,command in [('legacy-upgrade',replace(red['selectionArgv'],{red['legacyServers']:red['registry']})),('selected-downgrade',replace(red['configArgv'],{red['legacyServers']:red['registry'],'legacy':'selected'}))]:
  assert not run(label,command,expected=None) and rows[-1]['exitCode']==1 and b'Session host binding changed' in (out/(label+'.stderr')).read_bytes()
 final_sql,records=database();assert all(records.get(record_key)==value for record_key,value in original_records.items());added=set(records)-set(original_records);assert len(added)==4 and all(record_key[0]=='native_agent_session_v1' for record_key in added);assert {json.loads(records[record_key])['label'] for record_key in added}=={'selected','selected-runtime','angular-first','typescript-first'}
 connection=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True);memory=sqlite3.connect(':memory:')
 try:
  connection.backup(memory)
  for record_key in added:memory.execute('DELETE FROM records WHERE kind=? AND id=?',record_key)
  memory.commit();restored=('\n'.join(memory.iterdump())+'\n').encode();assert restored==original_sql
 finally:memory.close();connection.close()
 (out/'original-store-reconstructed.sql').write_bytes(restored);(out/'final-store.sql').write_bytes(final_sql)
 assert source_files()==red['sourceGitFiles'] and sha(Path(red['originalCli']))==red['originalCliSha256']
 for key in ['legacyProfile','selectedProfile','legacyServers','registry']:assert sha(Path(red[key]))==red[key+'Sha256']
 assert sha(fixture)==red['fixtureSha256'] and all(sha(w/name)==digest for name,digest in frozen.items()) and sha(native)==native_hash;complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'originalCliSha256':red['originalCliSha256'],'cliSha256':native_hash,'legacyAbsentNullEmptyAndDormantRegistryConfigurationMcp53RawExact':complete,'wholeLogicalSqlExactBeforeNewBindings':complete,'completeOriginalSqlReconstructedRemovingOnlyFourNewSessionRowsInMemory':complete,'oldRecordValuesAndSourceGitHostProviderBytesExact':complete,'actualSelectedAndOrderedFallbackCliMcpQualified':complete,'bindingUpgradeDowngradeRefused':complete,'frozenInputs':len(frozen),'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
