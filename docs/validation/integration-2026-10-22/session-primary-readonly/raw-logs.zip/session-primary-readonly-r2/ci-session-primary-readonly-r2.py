from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,re,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-primary-readonly-r2').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-google-http-guard-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
old=json.loads((w/'validation/integration-20261018/session-config-yaml-final2/source-before.json').read_bytes())
for name in ['native/docs/session-config.md','native/tests/session_primary_read_only.rs']:old[name]='new'
inputs={n:sha(w/n) for n in old};assert len(inputs)==1035;(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');assert sha(w/'native/tests/fixtures/postgres-catalog-response.jsonl')=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47'
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';targets=['session_primary_read_only','session-config-lib','session_config_cli','project_session','session_mcp','session_steering','session_inclusions','session_fixed_tools','session_optional_defaults','session_agent_interface','session_memory_patterns','session_startup_project','agent_repl_api_selection','agent_repl','agent_repl_lifecycle','session_refactor','session_root_aliases','compatibility','compatibility_review','trail_adapter','graphify_adapter','session_review','session_collections_admission'];complete=False
try:
 for target in targets:
  deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()}
  command=[cargo,'test','--locked','-j','2',*(['--lib','session_config::'] if target=='session-config-lib' else ['--test',target]),'--','--nocapture','--test-threads=1'];run(target,command,expected=None,timeout=600)
  assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed';cleanup=[]
  for p in deps.iterdir():
   if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(('yoke' if target=='session-config-lib' else target)+'-'):continue
   assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h
   try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':True})
   except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
  (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n');assert rows[-1]['exitCode']==0,(target,rows[-1]['exitCode'])

 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':targets,'rows':rows},indent=2)+'\n')
assert complete
