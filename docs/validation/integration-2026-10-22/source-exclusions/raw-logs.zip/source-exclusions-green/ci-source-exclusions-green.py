from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/source-exclusions-green';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-exclusions-green-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])
import sqlite3
redroot=w/'validation/integration-20261018/source-exclusions-red';red=json.loads((redroot/'result.json').read_bytes());source=Path(red['sourceRoot']);cwd=source;profile=Path(red['profile']);selected=Path(red['exclusionsProfile']);assert sha(profile)==red['profileSha256'] and sha(selected)==red['exclusionsProfileSha256']
phase=w/'validation/integration-20261018/source-exclusions-final3';result=json.loads((phase/'result.json').read_bytes());frozen=json.loads((phase/'source-before.json').read_bytes());assert len(frozen)==1039 and result['complete'] and result['allJobsEmpty'] and result['cliSha256']==native_hash and all(sha(w/n)==h for n,h in frozen.items())
def source_files():return {p.relative_to(source).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(source).parts}
def database():
 db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8'),{(k,i):v for k,i,v in db.execute('select kind,id,value from records')}
 finally:db.close()
original_sql,original_records=database();assert original_sql==(redroot/'original-store.sql').read_bytes() and source_files()==red['sourceGitFiles']
assert run('legacy-absent-configuration-raw',red['configArgv'])==(redroot/'original-config-positive.stdout').read_bytes()
assert run('legacy-absent-mcp53-private-read-raw',[node,red['driver']])==(redroot/'original-mcp53-private-read-positive.stdout').read_bytes()
for name,value in [('null',None),('empty',{'global':[],'projects':{'default':{'local':None}}})]:
 path=jobroot/(name+'.json');path.write_text(json.dumps({**json.loads(profile.read_bytes()),'sourceExclusions':value}),encoding='utf8');argv=[str(path) if str(a)==str(profile) else a for a in red['configArgv']];assert run('legacy-'+name+'-configuration-raw',argv)==(redroot/'original-config-positive.stdout').read_bytes()
 text=Path(red['driver']).read_text(encoding='utf8');assert text.count(json.dumps(str(profile)))==1;driver=jobroot/(name+'-mcp.cjs');driver.write_text(text.replace(json.dumps(str(profile)),json.dumps(str(path))),encoding='utf8');assert run('legacy-'+name+'-mcp53-private-read-raw',[node,driver])==(redroot/'original-mcp53-private-read-positive.stdout').read_bytes()
assert database()[0]==original_sql
config=json.loads(run('same-original-source-exclusions-host-green',red['excludedArgv']))['results'][0];assert config['sourceExclusions']=={'global':[['private/**']]} and config['sourceExclusionCaseInsensitive'] is True
common=[str(native),'--root',str(source),'--allow-writes','--timeout','60000','--max-bytes','4000000','session','--id','excluded','--host-profile',str(selected)]
reply=run('selected-private-read-denied',[*common,'--requests',red['readRequests']],expected=None)
if reply:assert json.loads(reply)['results'][0]['status']=='error'
else:assert rows[-1]['exitCode']==1
reply=run('selected-private-create-denied',[*common,'--requests',red['editRequests']],expected=None)
if reply:assert json.loads(reply)['results'][0]['status']=='error'
else:assert rows[-1]['exitCode']==1
assert not(source/'private/new.rs').exists()
oldplan=red['originalPlan'];historical=jobroot/'historical.json';historical.write_text(json.dumps([{'operation':'fs.read','args':{'path':'private/hide.rs','snapshotId':oldplan['baseSnapshotId']}},{'operation':'fs.read','args':{'path':'private/new.rs','snapshotId':oldplan['resultSnapshotId']}}]),encoding='utf8');reply=json.loads(run('original-history-remains-explicitly-readable',[*common,'--requests',str(historical)]));assert all(v['status']=='ok' for v in reply['results'])
virtual=source/'.yoke/blobs'/oldplan['files'][0]['afterHash'];assert virtual.read_bytes()==b'// owned\r\nfn planned() {}\n'
old_snapshot=jobroot/'old-snapshot-edit.json';old_snapshot.write_text(json.dumps([{'operation':'edit.prepare','args':{**red['editArgs'],'snapshotId':oldplan['baseSnapshotId']}}]),encoding='utf8');reply=json.loads(run('current-write-scope-cannot-use-original-snapshot',[*common,'--requests',str(old_snapshot)]));assert reply['results'][0]['status']=='error' and 'source_excluded_by_current_host_selection' in json.dumps(reply)
allowed=jobroot/'allowed.json';allowed.write_text(json.dumps([{'operation':'edit.prepare','args':{'edits':[{'kind':'create','path':'src/allowed.rs','text':'fn allowed() {}\n'}]}}]),encoding='utf8');prepared=json.loads(run('selected-allowed-plan-positive',[*common,'--requests',str(allowed)]))['results'][0];assert prepared['status']=='ok'
yaml_plan=json.loads(run('same-original-ignored-paths-yaml-green',red['yamlPlanArgv']));assert yaml_plan['hostProfile']['sourceExclusions']=={'global':[['private/**']]} and not yaml_plan['sourceBytesRewritten']
output=jobroot/'yaml-profile.json';run('same-original-yaml-export',[native,'--timeout','60000','--max-bytes','4000000','session-config','export','--selection',red['selection'],'--output',output,'--allow-configuration-read','--allow-policy-projection','--allow-output']);before=run('selected-json-binding',red['excludedArgv']);argv=[str(output) if str(a)==str(selected) else a for a in red['excludedArgv']];assert run('yaml-resumes-same-json-binding',argv)==before
for name,argv in [('absent-to-selected-binding',[str(selected) if str(a)==str(profile) else a for a in red['configArgv']]),('selected-to-absent-binding',[str(profile) if str(a)==str(selected) else a for a in red['excludedArgv']])]:
 assert not run(name,argv,expected=None) and rows[-1]['exitCode']==1 and b'Session host binding changed' in (out/(name+'.stderr')).read_bytes()
final_sql,current_records=database();assert all(current_records.get(k)==v for k,v in original_records.items()) and source_files()==red['sourceGitFiles'] and sha(profile)==red['profileSha256'] and sha(selected)==red['exclusionsProfileSha256'] and sha(Path(red['yaml']))==red['yamlSha256'] and sha(Path(red['selection']))==red['selectionSha256'] and all(sha(w/n)==h for n,h in frozen.items());assert not(source/'src/allowed.rs').exists() and not(source/'private/new.rs').exists()
(out/'final-store.sql').write_bytes(final_sql);(out/'result.json').write_text(json.dumps({'complete':True,'cliSha256':native_hash,'originalCliSha256':red['cliSha256'],'sourceRoot':str(source),'legacyAbsentNullEmptyCliAndMcpRawExact':True,'wholeLegacySqlExactBeforeNewBindings':True,'originalRecordValuesExactAfterNewBindings':True,'originalMixedPlanBytesAndHistoricalReadsExact':True,'currentSelectionDeniesReadAndPreparationIncludingOriginalSnapshot':True,'allowedPreparationPositive':True,'yamlEquivalentJsonBindingResumed':True,'bindingUpgradeDowngradeRefused':True,'sourceGitHostYamlBytesExact':True,'sourceWritten':False,'frozenInputs':len(frozen),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'commands':rows},indent=2)+'\n',encoding='utf8')
