from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/source-exclusions-capture-relink2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import re,traceback
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
prior=w/'validation/integration-20261018/source-exclusions-r1';old=json.loads((prior/'result.json').read_bytes());inputs=json.loads((prior/'source-before.json').read_bytes());assert old['complete'] and old['allJobsEmpty'] and len(inputs)==1039 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
deps=(w/'target/debug/deps').resolve();exe=deps/'capture_options-ci-source-exclusions-relink2.exe';assert not exe.exists();complete=False;sealed=None
try:
 run('compile-fresh-output',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','rustc','--manifest-path','native/Cargo.toml','--locked','-j','2','--test','capture_options','--','-C','extra-filename=-ci-source-exclusions-relink2'],timeout=600)
 assert exe.is_file() and not exe.is_symlink() and exe.resolve().parent==deps;sealed=sha(exe);assert all(sha(w/n)==h for n,h in inputs.items())
 cwd=w/'native';env['CARGO_MANIFEST_DIR']=str(cwd);env['CARGO_MANIFEST_PATH']=str(cwd/'Cargo.toml');run('capture_options',[exe,'--nocapture','--test-threads=1'],timeout=600);assert all(sha(w/n)==h for n,h in inputs.items()) and sha(exe)==sealed
 cleanup=[]
 for artifact in [exe,exe.with_suffix('.pdb')]:
  if not artifact.exists():continue
  assert artifact.resolve().parent==deps and not artifact.is_symlink();h=sha(artifact);size=artifact.stat().st_size;assert sha(artifact)==h
  try:artifact.unlink();cleanup.append({'name':artifact.name,'bytes':size,'sha256':h,'deleted':True})
  except PermissionError:cleanup.append({'name':artifact.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
 (out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf8');complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'testExeSha256':sealed,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'originalFailedOutputsUntouched':True,'outputFilenameOverrideOnly':True,'originalTestsUnchanged':True,'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
