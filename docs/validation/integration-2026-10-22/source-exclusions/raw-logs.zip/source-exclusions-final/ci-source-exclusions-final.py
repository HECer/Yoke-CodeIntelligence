from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/source-exclusions-final';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import re,traceback
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
prior=w/'validation/integration-20261018/source-exclusions-r1';focused=json.loads((prior/'result.json').read_bytes());inputs=json.loads((prior/'source-before.json').read_bytes());assert focused['complete'] and focused['allJobsEmpty'] and focused['sourceInputsUnchanged'] and len(inputs)==1039 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
for row in focused['rows']:
 name=row['name']
 if name=='git-init':continue
 assert row['exitCode']==0 and row['activeAfterCleanup']==0
 for ext in ['stdout','stderr']:shutil.copyfile(prior/(name+'.'+ext),out/(name+'.'+ext))
 rows.append({**row,'reusedCheckedPhase':'source-exclusions-r1','rerun':False})
lint=w/'validation/integration-20261018/source-exclusions-preflight2';lint_result=json.loads((lint/'result.json').read_bytes());assert lint_result['complete'] and lint_result['allJobsEmpty'] and json.loads((lint/'source-before.json').read_bytes())==inputs
row=next(r for r in lint_result['rows'] if r['name']=='clippy');assert row['exitCode']==0 and row['activeAfterCleanup']==0
for ext in ['stdout','stderr']:shutil.copyfile(lint/('clippy.'+ext),out/('clippy.'+ext))
rows.append({**row,'reusedCheckedPhase':'source-exclusions-preflight2','rerun':False})
targets=['capture_options','capture_policy','capture_changes','capture_epoch_selection','capture_analyzer8_fixture','ignored_capture','ignored_capture_cli','ignored_facades','monorepo_scopes','scoped_resolution','deadline_scope','session_config_cli','project_session','session_mcp','session_primary_read_only','session_root_aliases','source_line_endings','plan_integrity','session_refactor','lsp_dependency_scope','facade_directory_move','compatibility','agent_repl'];assert len(targets)==23
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';complete=False
def unchanged():assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed'
try:
 for target in targets:
  deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()};run(target,[cargo,'test','--locked','-j','2','--test',target,'--','--nocapture','--test-threads=1'],expected=None,timeout=600);unchanged();cleanup=[]
  for p in deps.iterdir():
   if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(target+'-'):continue
   assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h
   try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':True})
   except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
  (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf8');assert rows[-1]['exitCode']==0,(target,rows[-1]['exitCode'])
 for name,command in [('build',[cargo,'build','--locked','-j','2','--bin','yoke']),('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:run(name,command,timeout=600);unchanged()
 run('cargo-format-all-windows-limit',[cargo,'fmt','--all','--check'],expected=None,timeout=120);unchanged()
 if rows[-1]['exitCode']!=0:assert b'os error 206' in (out/'cargo-format-all-windows-limit.stderr').read_bytes()
 metadata=json.loads(run('format-target-metadata',[cargo,'metadata','--no-deps','--format-version','1'],timeout=60));unchanged();roots=sorted(set(t['src_path'] for package in metadata['packages'] for t in package['targets']));assert len(roots)==338;(out/'format-targets.json').write_text(json.dumps(roots,indent=2)+'\n',encoding='utf8')
 for i in range(0,len(roots),20):run('format-targets-'+str(i//20),[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','--check',*roots[i:i+20]],timeout=120);unchanged()
 complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':targets,'reusedTargets':['source-scopes-lib','source_exclusions'],'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
