from pathlib import Path
import copy,hashlib,json,os,re,subprocess,zipfile
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');tmp=Path(os.environ['TEMP']);raw=w/'validation/integration-20261018';out=w/'docs/validation/integration-2026-10-22/source-exclusions'
sha=lambda b:hashlib.sha256(b).hexdigest();load=lambda p:json.loads(p.read_bytes())
source=load(tmp/'ci-source-exclusions-commit-source.result.json')['sourceCommit'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==source
phase=raw/'source-exclusions-final3';final=load(phase/'result.json');manifest=load(phase/'source-before.json');assert final['complete'] and final['allJobsEmpty'] and final['sourceInputsUnchanged'] and len(manifest)==1039 and all(sha((w/n).read_bytes())==h for n,h in manifest.items())
totals={}
for row in final['rows']:
 p=phase/(row['name']+'.stdout')
 if not p.exists():continue
 matches=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_bytes())
 if matches:assert len(matches)==1;totals[row['name']]=dict(zip(['passed','failed','ignored'],map(int,matches[0])))
assert len(totals)==25 and all(x['failed']==0 for x in totals.values());passed=sum(x['passed'] for x in totals.values());ignored=sum(x['ignored'] for x in totals.values());assert totals['source_exclusions']['passed']==7 and totals['source-scopes-lib']['passed']==29
npm=(phase/'npm-tests.stdout').read_bytes();assert re.search(rb'\bpass 260\r?\n',npm) and re.search(rb'\bfail 0\r?\n',npm) and re.search(rb'\bskipped 3\r?\n',npm)
format_roots=load(phase/'format-targets.json');assert len(format_roots)==338
green=load(raw/'source-exclusions-green/result.json');assert green['complete'] and green['allJobsEmpty'] and green['cliSha256']==final['cliSha256'] and green['legacyAbsentNullEmptyCliAndMcpRawExact'] and green['wholeLegacySqlExactBeforeNewBindings'] and green['originalRecordValuesExactAfterNewBindings']
names=['docs/STATUS.md','docs/REMAINING_WORK.md','docs/ARCHITECTURE.md','docs/parity/native-reconciliation-2026-10-15.json','native/docs/session-steering.md','README.md'];before={n:(w/n).read_bytes() for n in names};after={}
block=f'''Explicit sourceExclusions and selected YAML ignored_paths now add bounded
Gitignore-style negative rules per global/project/local host layer. Independent
groups combine by exclusion; a later layer cannot reopen an earlier restriction.
Concrete case semantics and ordered patterns bind immutable capture options.
Current preparation and workspace application also check the current host scope,
including plans based on older snapshots, before journals/source writes.
Historical reads, checked replay, isolated verification copies and recovery keep
their original evidence and bytes. Secondary projects derive from original host
options, independently of primary-project rules. Empty/absent/null policies keep
legacy identities. These are source selections, not OS access-control grants.

At source {source[:8]}, {passed} Rust functions pass across 25 scoped targets with
{ignored} existing ignores on 1039 frozen inputs; 12 functions are new. Initial
Clippy finds two test-only default-field assignments, corrected to equivalent
initializers. All-target Clippy -Dwarnings then passes. The first regression
attempt fails linking capture_options (LNK1000/0xc0000006, nested 0xc000007f);
a cleanup hash error initially masks that failure. A retry reports LNK1104 for
the same output. Failed artifacts and protected processes are preserved.
An explicit-package cargo rustc build under a fresh EXE filename runs the same
unchanged capture_options tests successfully. No environment cause is certified.
The first fresh-output command rejects the virtual manifest; its corrected
package selection passes. A temporary launcher typo starts no Cargo and is fixed.
No failed/partial result counts as a pass. Focused tests, Clippy and the genuine
fresh-output test are reused only with identical source hashes and empty Jobs.
Build/typecheck and npm260/3 skips pass. Cargo fmt --all hits Windows OS206;
all {len(format_roots)} actual Cargo format target roots pass bounded rustfmt checks.
Actual published-CLI RED/SAME-fixture GREEN preserves absent/null/empty CLI/MCP
RAW, whole original SQL before additions and original records afterward.
Old mixed-plan/historical bytes, source/Git/host/YAML and equivalent JSON/YAML
session bindings remain exact. Owned executed verification, approved application
and recovery are exercised in Rust, including current-scope refusal of an older
fully approved/verified plan. See [the contract](../native/docs/session-config.md#source-exclusion-groups)
and [indexed evidence](validation/integration-2026-10-22/source-exclusions/README.md).
The ten remaining project keys, broader configuration/backend/client and full
R1-R9/353/Windows/main/release acceptance remain open. Original inventory
assessments, OS1314 fixtures and system settings are unchanged.

'''.encode()
for n in names[:2]:
 data=before[n];marker=b'## Current integration work\n\n' if n=='docs/STATUS.md' else data[:data.index(b'\n')+1]+b'\n';prefix,body=data.split(marker,1);intro,tail=body.split(b'### Remaining scope\n\n',1);scope,history=tail.split(b'### Earlier source checkpoints\n\n',1);after[n]=prefix+marker+block+b'### Remaining scope\n\n'+scope+b'### Earlier source checkpoints\n\n'+intro+history
n=names[2];marker=b'Host-selected source line endings resolve';assert before[n].count(marker)==1;after[n]=before[n].replace(marker,b'Explicit additive source exclusions bind ordered Gitignore-style groups and\nconcrete case semantics into capture options. Replayed scopes validate every\nmember; current host exclusions additionally constrain prepare/workspace apply.\nHistorical evidence and recovery remain independent. Named engines derive\nfrom original host options, so primary-only filters do not leak to secondary\nprojects. Missing rules preserve preceding serialized identities.\n\n'+marker)
n=names[3];prior=json.loads(before[n]);desired=copy.deepcopy(prior);residual=next(x for x in desired['residualRegister'] if x['id']=='dashboard_and_configuration_layers');residual['nativeSourceExclusionsCheckpoint']={'sourceCommit':source,'index':'docs/validation/integration-2026-10-22/source-exclusions/index.json','frozenInputs':1039,'distinctRustFunctionsPassed':passed,'existingIgnored':ignored,'newFunctions':12,'legacyAbsentNullEmptyRawAndBindingExact':True,'additiveGlobalProjectLocalYamlValidated':True,'immutableCapturedRulesAndConcreteCaseValidated':True,'currentWorkspaceScopeOldPlanRefusalValidated':True,'historicalReadReplayIsolationRecoveryExact':True,'verifiedWorkspaceApplicationAndExactRecoveryValidated':True,'freshOutputUnchangedCaptureOptionsTestsPassed':True,'failedLinkArtifactsAndProtectedProcessesPreserved':True,'cargoFormatAllOs206':True,'actualCargoFormatTargetRootsChecked':len(format_roots),'fullParityCertified':False};assert desired['inventoryLedger']==prior['inventoryLedger'] and desired['ledgerSummary']==prior['ledgerSummary'];styles=[v for v in [False,True] if (json.dumps(prior,ensure_ascii=v,indent=2)+'\n').encode()==before[n]];assert styles;after[n]=(json.dumps(desired,ensure_ascii=styles[0],indent=2)+'\n').encode()
n=names[4];after[n]=before[n]+b'\nExplicit sourceExclusions and selected YAML ignored_paths add independent negative\nsource rules without weakening earlier host exclusions or runtime/write gates.\nCaptured rules replay independently; current workspace writes also check current\nselection. See [source exclusions](session-config.md#source-exclusion-groups).\n'
n=names[5];marker=b'before review and verification; saved plans and original captures stay immutable.';assert before[n].count(marker)==1;after[n]=before[n].replace(marker,marker+b'\nAdditive per-project source exclusions also bind captures and current workspace\nwrite scope while retaining exact historical evidence and recovery.')
assert not out.exists();out.mkdir(parents=True);directories=[]
for suffix in ['red','preflight','preflight2','r1','final','final2','capture-relink','capture-relink2','final3','green']:
 directory=raw/('source-exclusions-'+suffix);assert directory.exists();directories.append(directory)
 for tail in ['.py','-runner.py','-owner.json','-child.json','-terminal.json','-controller.stdout','-controller.stderr']:
  p=tmp/('ci-source-exclusions-'+suffix+tail)
  if p.exists():(directory/p.name).write_bytes(p.read_bytes())
# The failed launcher started only Python with a nonexistent controller path.
directory=raw/'source-exclusions-capture-relink2'
for p in tmp.glob('ci-source-exclusions-capture-relink22-*'):
 if p.is_file() and not p.is_symlink():(directory/p.name).write_bytes(p.read_bytes())
members=[]
with zipfile.ZipFile(out/'raw-logs.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for directory in directories:
  for p in sorted(directory.rglob('*')):
   if not p.is_file():continue
   assert not p.is_symlink();data=p.read_bytes();name=p.relative_to(raw).as_posix();z.writestr(name,data);members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
with zipfile.ZipFile(out/'raw-logs.zip') as z:
 assert len(z.infolist())==len(members)
 for m in members:data=z.read(m['path']);assert len(data)==m['bytes'] and sha(data)==m['sha256']
(out/'raw-index.json').write_text(json.dumps({'zipSha256':sha((out/'raw-logs.zip').read_bytes()),'rawBytes':sum(m['bytes'] for m in members),'zipBytes':(out/'raw-logs.zip').stat().st_size,'members':members},indent=2)+'\n',encoding='utf8')
prior_manifest=load(raw/'source-line-endings-final2/source-before.json');name='native/src/capture.rs';head=subprocess.check_output(['git','show','fffe8bad61916d67693a68ea0214902ce230b441:'+name],cwd=w);current=(w/name).read_bytes();original=head.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n');assert sha(original)==prior_manifest[name] and current.count(b'\r\n')==current.count(b'\n')
(out/'source-eol-attestation.json').write_text(json.dumps([{'path':name,'priorFrozenWorktreeSha256':prior_manifest[name],'priorGitBlobSha256':sha(head),'priorFrozenEqualsPriorGitWithCrlf':True,'currentTestedBytesSha256':sha(current),'reason':'Preserve original tested worktree CRLF; commit exact newly tested bytes with autocrlf=false.'}],indent=2)+'\n',encoding='utf8')
checkpoint={'sourceCommit':source,'cliSha256':final['cliSha256'],'frozenInputs':1039,'rust':{'targets':totals,'distinctPassed':passed,'failed':0,'existingIgnored':ignored,'newFunctions':12},'formatTargetRoots':len(format_roots),'cargoFormatAllWindowsOs206':True,'npm':{'passed':260,'failed':0,'existingSkipped':3},'allQualifiedJobsEmpty':True,'fullStatusComplete':False,'fullNativeCurrentHeadCertified':False,'originalInventoryAssessmentsUnchanged':True,'systemSettingsChanged':False,'rawMembers':len(members)}
(out/'checkpoint.json').write_text(json.dumps(checkpoint,indent=2)+'\n',encoding='utf8')
readme=f'''# Additive source-exclusion checkpoint

Source: {source}. Code Intelligence 0.5.0, Windows. The broader STATUS task remains open.

{passed} distinct Rust functions pass across 25 scoped targets; {ignored} existing ignores.
Twelve new functions exercise matching, Unicode/case/parent/negation/limits,
strict YAML layers, current write checks, immutable historical reads/replay,
verified application/recovery and independent secondary project scopes.
All qualified results bind 1039 unchanged input hashes and empty Windows Jobs.
Clippy -Dwarnings, build/typecheck and npm260/3 skips pass. Cargo fmt --all
hits OS206; all {len(format_roots)} actual format roots pass bounded rustfmt invocations.
This does not certify current whole-native or full Windows parity acceptance.

The original published binary first proves baseline positives and missing host/
YAML settings. SAME-fixture GREEN preserves absent/null/empty CLI/MCP RAW and
full original SQL before new bindings, then all original stored record values.
Original mixed-plan bytes and explicit historical reads remain exact; current
excluded reads/preparation refuse, including preparation from older snapshots.
Allowed preparation succeeds. Equivalent JSON/YAML resumes one binding; changed
host selection refuses. Original source/Git/host/YAML bytes are unchanged.
The CLI control previews plans; Rust tests separately perform real approved,
owned-command-verified application and exact recovery, and deny an older fully
approved/verified plan under current exclusions before journal/source writes.

Failure history is retained losslessly. Two test-only Clippy initializer warnings
are corrected before the qualified source freeze. The first regression link fails
LNK1000 with 0xc0000006/nested0xc000007f; its cleanup read encounters OSError28.
The retry preserves incomplete outputs and fails LNK1104 on that same EXE.
No definitive environmental cause is claimed. A fresh output name succeeds and
runs the unchanged original capture_options harness. Its first Cargo command
rejects the virtual workspace manifest; explicit native/Cargo.toml fixes package
selection. A temporary launcher typo starts no Cargo and is then corrected.
Failed artifacts, original protected processes and original test source remain
untouched. No failed/partial result counts as a pass. Focused tests, Clippy and
the genuine fresh-output result are reused only on identical source hashes.

source-eol-attestation.json proves capture.rs retains its previously tested
worktree CRLF convention. No untested normalization occurs. raw-index.json gives
byte counts and SHA256 for every raw ZIP member, including controllers, complete
stdout/stderr, terminal/owner state, cleanup and source guards. checkpoint.json
lists per-target totals; post-validation-docs.json records six explanatory edits.
Original inventory assessments, OS1314 fixtures and Windows settings are unchanged.
Authenticated Google, ten remaining project keys, wider configuration/client/
backend, R1-R9/353/Windows/main/release acceptance remain open.
'''
(out/'README.md').write_text(readme,encoding='utf8')
record={'sourceCommit':source,'frozenValidationInputs':1039,'files':{n:{'beforeSha256':sha(before[n]),'afterSha256':sha(after[n]),'reason':'Post-validation explanatory status/contract reference; no behavior changed.'} for n in names}}
for n,data in after.items():(w/n).write_bytes(data)
(out/'post-validation-docs.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
assert {n for n,h in manifest.items() if sha((w/n).read_bytes())!=h}==set(names)
print(json.dumps({'sourceCommit':source,'passed':passed,'ignored':ignored,'targets':len(totals),'formatRoots':len(format_roots),'rawMembers':len(members),'postValidationDocs':len(names),'fullStatusComplete':False}))
