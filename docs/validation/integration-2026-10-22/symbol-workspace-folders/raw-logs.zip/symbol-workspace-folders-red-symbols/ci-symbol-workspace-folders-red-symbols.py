from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/symbol-workspace-folders-red-symbols';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-symbol-workspace-folders-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])
import sqlite3
redroot=w/'validation/integration-20261018/symbol-workspace-folders-red';red=json.loads((redroot/'result.json').read_bytes());source=Path(red['sourceRoot']);cwd=source;original=source.parent/'original-yoke.exe';assert sha(original)==red['cliSha256'];profile=Path(red['profile'])
messages=[{'jsonrpc':'2.0','id':1,'method':'initialize'},{'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':'find_symbol','arguments':{'name_path_pattern':'*','include_body':True}}}]
server=red['serverArgv'];driver=jobroot/'symbols.cjs';driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync("+json.dumps(str(original))+","+json.dumps(server[1:])+",{input:"+json.dumps('\n'.join(json.dumps(m,separators=(',',':')) for m in messages)+'\n')+",maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8')
raw=run('original-full-symbol-search-mcp',[node,driver]);values=[json.loads(l) for l in raw.decode().splitlines()];result=next(v['result'] for v in values if v.get('id')==2);assert not result['isError'];value=json.loads(result['content'][0]['text']);assert value['status']=='ok' and len(value['data']['items'])==3
connection=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
try:dump=('\n'.join(connection.iterdump())+'\n').encode();records=[{'kind':k,'id':i,'value':v} for k,i,v in connection.execute('select kind,id,value from records order by kind,id')]
finally:connection.close()
(out/'expanded-original-store.sql').write_bytes(dump);(out/'expanded-original-records.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8');(out/'result.json').write_text(json.dumps({'complete':True,'driver':str(driver),'sourceRoot':str(source),'originalCli':str(original),'originalCliSha256':sha(original),'rawSha256':sha(out/'original-full-symbol-search-mcp.stdout'),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'rows':rows},indent=2)+'\n',encoding='utf8')
