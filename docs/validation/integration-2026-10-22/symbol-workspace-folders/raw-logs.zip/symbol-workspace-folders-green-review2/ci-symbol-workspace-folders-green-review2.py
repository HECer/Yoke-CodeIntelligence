from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/symbol-workspace-folders-green-review2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  while chunk:=stream.read(65536):h.update(chunk)
 return h.hexdigest()
native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-line-endings-final-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])

import sqlite3
redroot=w/'validation/integration-20261018/symbol-workspace-folders-red';red=json.loads((redroot/'result.json').read_bytes());symbolsroot=redroot.with_name('symbol-workspace-folders-red-symbols');oldgreen=redroot.with_name('symbol-workspace-folders-green');source=Path(red['sourceRoot']);cwd=source;profile=Path(red['profile']);selected=Path(red['exclusionsProfile'])
phase=w/'validation/integration-20261018/symbol-workspace-folders-final';result=json.loads((phase/'result.json').read_bytes());frozen=json.loads((phase/'source-before.json').read_bytes());assert len(frozen)==1047 and result['complete'] and result['allJobsEmpty'] and result['cliSha256']==native_hash and all(sha(w/n)==h for n,h in frozen.items())
old_controller=(oldgreen/'controller.py').read_bytes();assert old_controller==(Path(os.environ['TEMP'])/'ci-symbol-workspace-folders-green.py').read_bytes() and b"'src/?.rs'" in old_controller
original_records={(v['kind'],v['id']):v['value'] for v in json.loads((symbolsroot/'expanded-original-records.json').read_bytes())}
def source_files():return {f.relative_to(source).as_posix():{'bytes':f.stat().st_size,'sha256':sha(f)} for f in source.rglob('*') if f.is_file() and '.yoke' not in f.relative_to(source).parts}
def database():
 db=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode(),{(k,i):v for k,i,v in db.execute('select kind,id,value from records')}
 finally:db.close()
assert source_files()==red['sourceGitFiles']
for name in ['absent','null','empty']:
 for label,expected in [('configuration',(redroot/'original-config-positive.stdout').read_bytes()),('mcp53',(redroot/'original-mcp53-private-read-positive.stdout').read_bytes()),('symbols',(symbolsroot/'original-full-symbol-search-mcp.stdout').read_bytes())]:
  assert (oldgreen/('legacy-'+name+'-'+label+'-raw.stdout')).read_bytes()==expected
config=json.loads((oldgreen/'same-original-host-roots-green.stdout').read_bytes())['results'][0];assert config['symbolWorkspaceFolders']=={'global':['src']} and config['symbolWorkspaceFoldersResolved']==['src']
values=[json.loads(l) for l in (oldgreen/'actual-selected-mcp-symbol-index.stdout').read_bytes().decode().splitlines()];reply=next(v['result'] for v in values if v.get('id')==2);assert not reply['isError'];outer=json.loads(reply['content'][0]['text']);assert outer['status']=='ok';value=outer['data'];assert len(value['items'])==1 and value['items'][0]['path']=='src/'+chr(233)+'.rs' and value['symbolIndexScope']['folders']==['src'] and value['symbolIndexScope']['baseGraphMutated']==False
initial_sql,records=database();assert all(records.get(k)==v for k,v in original_records.items());added=set(records)-set(original_records);assert len(added)==2 and {json.loads(records[k])['label'] for k in added}=={'budgeted','workspace-mcp'} and all(k[0]=='native_agent_session_v1' for k in added)
connection=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True);memory=sqlite3.connect(':memory:')
try:
 connection.backup(memory)
 for record_key in added:memory.execute('DELETE FROM records WHERE kind=? AND id=?',record_key)
 memory.commit();restored=('\n'.join(memory.iterdump())+'\n').encode();assert restored==(symbolsroot/'expanded-original-store.sql').read_bytes()
finally:memory.close();connection.close()
(out/'reviewed-preexisting-store.sql').write_bytes(restored);(out/'reviewed-initial-store.sql').write_bytes(initial_sql)
complete=False
try:
 common=[str(native),'--root',str(source),'--allow-writes','--timeout','60000','--max-bytes','4000000','session','--id','budgeted','--host-profile',str(selected)]
 reply=json.loads(run('selected-index-keeps-other-source-reads',[*common,'--requests',red['readRequests']]))['results'][0];assert reply['status']=='ok'
 oldplan=red['originalPlan'];assert (source/'.yoke/blobs'/oldplan['files'][0]['afterHash']).read_bytes()==b'// owned\r\nfn planned() {}\n'
 prepared=json.loads(run('selected-index-keeps-other-source-preparation',[*common,'--requests',red['editRequests']]))['results'][0];assert prepared['status']=='ok' and not(source/'private/new.rs').exists()
 yaml_plan=json.loads(run('same-original-workspace-yaml-green',red['yamlPlanArgv']));assert yaml_plan['hostProfile']['symbolWorkspaceFolders']=={'global':['src']} and not yaml_plan['sourceBytesRewritten']
 output=jobroot/'yaml-profile.json';run('same-original-yaml-export',[native,'--timeout','60000','--max-bytes','4000000','session-config','export','--selection',red['selection'],'--output',output,'--allow-configuration-read','--allow-policy-projection','--allow-output']);before=run('selected-json-binding',red['excludedArgv']);argv=[str(output) if str(a)==str(selected) else a for a in red['excludedArgv']];assert run('yaml-resumes-same-json-binding',argv)==before
 for name,argv in [('absent-to-selected-binding',[str(selected) if str(a)==str(profile) else a for a in red['configArgv']]),('selected-to-absent-binding',[str(profile) if str(a)==str(selected) else a for a in red['excludedArgv']])]:
  assert not run(name,argv,expected=None) and rows[-1]['exitCode']==1 and b'Session host binding changed' in (out/(name+'.stderr')).read_bytes()
 final_sql,records=database();assert all(records.get(k)==v for k,v in original_records.items()) and source_files()==red['sourceGitFiles'] and sha(profile)==red['profileSha256'] and sha(selected)==red['exclusionsProfileSha256'] and sha(Path(red['yaml']))==red['yamlSha256'] and sha(Path(red['selection']))==red['selectionSha256'] and all(sha(w/n)==h for n,h in frozen.items()) and sha(native)==native_hash
 (out/'final-store.sql').write_bytes(final_sql);complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'cliSha256':native_hash,'originalCliSha256':red['cliSha256'],'legacyAbsentNullEmptyConfigurationMcp53AndSymbolSearchRawExact':True,'wholeExpandedLegacySqlExactBeforeNewBindings':False,'completeLegacySqlReconstructedExactlyByRemovingOnlyTwoNewBindingsFromMemoryBackup':True,'originalStoredRecordValuesExactAfterNewBindings':True,'actualSelectedMcpSymbolIndexQualified':True,'recordedSuccessfulSegmentRerun':False,'initialGreenHarnessFailedOnAsciiPathExpectation':True,'originalMixedPlanBytesSourceReadsAndPreparationUnaffected':complete,'yamlEquivalentJsonBindingResumed':complete,'bindingUpgradeDowngradeRefused':complete,'sourceGitHostYamlBytesExact':complete,'sourceWritten':False,'frozenInputs':len(frozen),'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'commands':rows},indent=2)+'\n',encoding='utf8')
assert complete
