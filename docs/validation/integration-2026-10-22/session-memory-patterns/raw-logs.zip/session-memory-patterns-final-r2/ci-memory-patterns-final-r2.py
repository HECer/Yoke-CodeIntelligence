from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,re,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-memory-patterns-final-r2').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-memory-patterns-final-r2-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';prior=w/'validation/integration-20261018/session-memory-patterns-final';old=json.loads((prior/'result.json').read_bytes());old_inputs=json.loads((prior/'source-before.json').read_bytes());inputs={n:sha(w/n) for n in old_inputs};changed=[n for n in inputs if inputs[n]!=old_inputs[n]];assert changed==['native/tests/session_memory_patterns.rs'];assert old['sourceInputsUnchanged'] and old['allJobsEmpty'] and not old['complete']
before=(prior/'session_memory_patterns-test-before.rs').read_bytes();after=(w/changed[0]).read_bytes();assert hashlib.sha256(before).hexdigest()==old_inputs[changed[0]];assert before.count(b'    let rows = e.store.db.prepare(')==1;expected=before.replace(b'    let rows = e.store.db.prepare(',b'    e.store.db.prepare(',1).replace(b'.collect::<Result<_,_>>().unwrap();\n    rows\n}',b'.collect::<Result<_,_>>().unwrap()\n}',1);assert after==expected
(out/'test-helper-before.rs').write_bytes(before);(out/'test-helper-after.rs').write_bytes(after);(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');projection={'allFrozenInputs':1020,'byteExactUnchangedInputsFor25ReusedTargets':1019,'onlyChangedInput':changed[0],'oldSha256':old_inputs[changed[0]],'newSha256':inputs[changed[0]],'exactChange':'Remove one redundant let binding and return its expression in the new test module only. No production, dependency, fixture or other test input changes.','rerunTarget':'session_memory_patterns','otherTargetsDoNotCompileThisSeparateTestModule':True};(out/'reuse-input-projection.json').write_text(json.dumps(projection,indent=2)+'\n',encoding='utf8')
reused=[]
for row in old['rows']:
 name=row['name'];p=prior/(name+'.stdout')
 if name=='session_memory_patterns' or not p.exists():continue
 matches=re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_bytes())
 if not matches:continue
 assert len(matches)==1 and row['exitCode']==0 and int(matches[0][1])==0 and row['activeAfterCleanup']==0
 for ext in ['stdout','stderr']:shutil.copyfile(prior/(name+'.'+ext),out/(name+'.'+ext))
 rows.append({**row,'previousReusePhase':row.get('reusedCheckedPhase'),'reusedCheckedPhase':'session-memory-patterns-final','rerun':False,'inputProjection':'reuse-input-projection.json'});reused.append(name)
assert len(reused)==25
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';complete=False
try:
 target='session_memory_patterns';deps=w/'target/debug/deps';known={p.resolve() for p in deps.iterdir() if p.is_file()};run(target,[cargo,'test','--locked','-j','2','--test',target,'--','--nocapture','--test-threads=1'],timeout=300);assert all(sha(w/n)==h for n,h in inputs.items());cleanup=[]
 for p in deps.iterdir():
  if p.resolve() in known or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(target+'-'):continue
  assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h
  try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':True})
  except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
 (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf8')
 for name,argv in [('clippy',[cargo,'clippy','--locked','--all-targets','-j','2','--','-D','warnings']),('fmt',[cargo,'fmt','--all','--check']),('build',[cargo,'build','--locked','-j','2','--bin','yoke']),('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:
  run(name,argv,timeout=600);assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed'
 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'reusedTargets':reused,'reuseInputProjection':projection,'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
