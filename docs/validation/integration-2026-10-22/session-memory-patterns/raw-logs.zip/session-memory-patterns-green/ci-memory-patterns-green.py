from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-memory-patterns-green').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-memory-patterns-green-');exec(compile(prefix,str(script),'exec'))
raw=w/'validation/integration-20261018';final=json.loads((raw/'session-memory-patterns-final-r4/result.json').read_bytes());assert final['complete'] and final['cliSha256']==native_hash
red_out=raw/'session-memory-patterns-red';red=json.loads((red_out/'result.json').read_bytes());root=Path(red['sourceRoot']);profile=Path(red['profile']);original=profile.read_bytes();common=red['argv'];original_records=json.loads((red_out/'original-records.json').read_bytes())
def records():
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return {(k,i):v for k,i,v in db.execute('select kind,id,value from records order by kind,id')}
 finally:db.close()
def dump():
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8')
 finally:db.close()
def note_rows():return {k:v for k,v in records().items() if k[0] in ['native_named_note_head_v1','native_named_note_revision_v1']}
def source_files():return {str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in root.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(root).parts}
before=dump();(out/'legacy-store-before.sql').write_bytes(before);before_notes=note_rows();(out/'original-note-records.json').write_text(json.dumps([{'kind':k,'id':i,'value':v} for (k,i),v in sorted(before_notes.items())],indent=2)+'\n',encoding='utf8');profile.write_text(json.dumps({'steering':{}}),encoding='utf8')
try:
 legacy=run('original-legacy-list-read',[*common,'--id','positive']);assert legacy==(red_out/'original-stable-list-read.stdout').read_bytes()
finally:profile.write_bytes(original)
after=dump();(out/'legacy-store-after.sql').write_bytes(after);assert before==after and note_rows()==before_notes
reply=json.loads(run('same-original-regex-input',[*common,'--id','restricted']));listed,read=reply['results'];assert [x['name'] for x in listed['items']]==['keep1','keep12'] and read['readOnly'] and read['note']['content']=='Owned note keep1'
old=json.loads((red_out/'original-stable-list-read.stdout').read_bytes())['results'];assert read['note']==old[1]['note'];assert listed['items']==[{**x,'readOnly':x['name']=='keep1'} for x in old[0]['items'] if x['name']!='archive/hidden'];assert note_rows()==before_notes
probe=jobroot/'requests.json';argv=list(common);argv[argv.index('--requests')+1]=str(probe)
for name,operation,args,message in [
 ('hidden-read','notes.read',{'name':'archive/hidden'},b'Note unavailable under host policy'),
 ('readonly-write','notes.write',{'name':'keep1','content':'changed'},b'Note is read-only'),
 ('readonly-target-rename','notes.rename',{'oldName':'keep12','newName':'keep2'},b'Note is read-only'),
 ('caller-cannot-disable-policy','notes.read',{'name':'archive/hidden','ignoredMemoryPatterns':[]},b'Unknown note argument'),
]:
 probe.write_text(json.dumps([{'operation':operation,'args':args}]),encoding='utf8');value=run(name,[*argv,'--id','restricted'],expected=None);assert rows[-1]['exitCode']==1 and not value and message in (out/(name+'.stderr')).read_bytes();assert note_rows()==before_notes
probe.write_text(json.dumps([{'operation':'notes.read','args':{'name':'keep12'}},{'operation':'configuration','args':{}}]),encoding='utf8');allowed=json.loads(run('allowed-read-and-explicit-policy',[*argv,'--id','restricted']))['results'];assert allowed[0]['note']['content']=='Owned note keep12' and not allowed[0]['readOnly'];assert allowed[1]['steering']['ignoredMemoryPatterns']==['^archive/'] and allowed[1]['executionAuthority']=='explicit_host_configuration_only'
denied=run('old-session-new-policy-binding',[*common,'--id','positive'],expected=None);assert rows[-1]['exitCode']==1 and not denied and b'Session host binding changed' in (out/'old-session-new-policy-binding.stderr').read_bytes()
server=[str(native),'--root',str(root),'--max-bytes','4000000','--timeout','60000','serve-session','--id','restricted','--profile','serena','--host-profile',str(profile)];messages=[{'jsonrpc':'2.0','id':1,'method':'initialize'},{'jsonrpc':'2.0','id':2,'method':'tools/list'},{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'list_memories','arguments':{}}},{'jsonrpc':'2.0','id':4,'method':'tools/call','params':{'name':'read_memory','arguments':{'memory_name':'archive/hidden'}}}]
driver=jobroot/'same-original-mcp.cjs';driver.write_text("const cp=require('node:child_process');const p=cp.spawnSync("+json.dumps(str(native))+","+json.dumps(server[1:])+",{input:"+json.dumps('\n'.join(json.dumps(m,separators=(',',':')) for m in messages)+'\n')+",maxBuffer:8000000,windowsHide:true});if(p.error)throw p.error;process.stdout.write(p.stdout);process.stderr.write(p.stderr);process.exitCode=p.status;",encoding='utf8');shutil.copyfile(driver,out/driver.name);responses=[json.loads(line) for line in run('same-original-real-mcp',[node,driver]).decode('utf8').splitlines()];assert len(next(x['result']['tools'] for x in responses if x.get('id')==2))==53;assert next(x['result']['isError'] for x in responses if x.get('id')==4);mcp_list=next(x['result'] for x in responses if x.get('id')==3);assert not mcp_list['isError'];mcp_data=json.loads(mcp_list['content'][0]['text'])['data'];assert mcp_data['items']==listed['items'];assert note_rows()==before_notes
bad=jobroot/'invalid-host.json';bad.write_text(json.dumps({'steering':{'global':{'ignoredMemoryPatterns':['[']}}}),encoding='utf8');bad_argv=list(argv);bad_argv[bad_argv.index('--host-profile')+1]=str(bad);before_bad=dump();denied=run('invalid-policy-before-publication',[*bad_argv,'--id','bad'],expected=None);assert rows[-1]['exitCode']==1 and not denied and dump()==before_bad
current=records();assert all(current.get((x['kind'],x['id']))==x['value'] for x in original_records);assert source_files()==red['sourceGitFiles'] and profile.read_bytes()==original and note_rows()==before_notes
result={'complete':True,'cliSha256':native_hash,'sameOriginalRedSourceRoot':str(root),'originalLegacyListReadRawBytesExact':True,'legacyFullLogicalSqlExact':True,'sameOriginalRegexInputNowAdmitted':True,'sameOriginalNoteValuesAnchorsAndHeadsExact':True,'hiddenAndReadOnlyCliAndMcpAdmissionQualified':True,'allowedReadsAndMetadataWithoutExecutionGrant':True,'callerCannotDisableHostPolicy':True,'changedHostBindingRefused':True,'invalidPolicyNoSessionPublication':True,'allOriginalRecordsAndSourceGitBytesExact':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'modelCalled':False,'analyzedSourceExecuted':False,'commands':rows};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print('Original memory regex CLI/MCP fixture GREEN and legacy raw/logical Store preservation qualified.',flush=True)
