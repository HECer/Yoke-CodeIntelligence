from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,re,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-memory-patterns-r1').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-memory-patterns-guard-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
old=json.loads((w/'validation/integration-20261018/session-startup-project-final/source-before.json').read_bytes());old['native/tests/session_memory_patterns.rs']='new';inputs={n:sha(w/n) for n in old};assert len(inputs)==1020;(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');assert sha(w/'native/tests/fixtures/postgres-catalog-response.jsonl')=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47'
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';targets=['session_memory_patterns','notes','agent_memory_namespaces','session_steering','agent_repl_api_selection','session_startup_project'];complete=False
try:
 for target in targets:
  deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()}
  run(target,[cargo,'test','--locked','-j','2','--test',target,'--','--nocapture','--test-threads=1'],expected=None,timeout=90 if target=='mcp_http' else 600)
  assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed';cleanup=[]
  for p in deps.iterdir():
   if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(target+'-'):continue
   assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h
   try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':True})
   except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
  (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n');assert rows[-1]['exitCode']==0,(target,rows[-1]['exitCode'])

 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':targets,'rows':rows},indent=2)+'\n')
assert complete
