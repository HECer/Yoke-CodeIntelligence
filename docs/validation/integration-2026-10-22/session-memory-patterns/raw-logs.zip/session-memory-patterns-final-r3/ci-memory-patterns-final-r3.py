from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-memory-patterns-final-r3').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-memory-patterns-final-r3-');exec(compile(prefix,str(script),'exec'))
cwd=w;prior=w/'validation/integration-20261018/session-memory-patterns-final-r2';old=json.loads((prior/'result.json').read_bytes());inputs=json.loads((prior/'source-before.json').read_bytes());assert len(inputs)==1020 and all(sha(w/n)==h for n,h in inputs.items());assert old['sourceInputsUnchanged'] and old['allJobsEmpty'] and not old['complete'];assert [r['name'] for r in old['rows'] if r['exitCode']!=0]==['npm-tests'];diagnostic=json.loads((w/'validation/integration-20261018/session-memory-patterns-npm-diagnostic/result.json').read_bytes());assert diagnostic['passed'] and diagnostic['allJobsEmpty'] and diagnostic['sourceInputsUnchanged']
(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
for name in ['reuse-input-projection.json','reused-target-depinfo.json','test-helper-before.rs','test-helper-after.rs']:shutil.copyfile(prior/name,out/name)
for row in old['rows']:
 if row['name'] in ['git-init','npm-tests']:continue
 assert row['exitCode']==0 and row['activeAfterCleanup']==0
 for ext in ['stdout','stderr']:shutil.copyfile(prior/(row['name']+'.'+ext),out/(row['name']+'.'+ext))
 rows.append({**row,'reusedCompletedGuard':'session-memory-patterns-final-r2','rerun':False})
complete=False
try:
 run('npm-tests',['cmd.exe','/d','/c','npm.cmd test'],timeout=600);assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'reuseInputProjection':old['reuseInputProjection'],'reusedCompletedCurrentInputChecks':'session-memory-patterns-final-r2','isolatedOriginalNpmCasePassedWithoutSourceChange':True,'windowsGitListingCauseEstablished':False,'rows':rows},indent=2)+'\n',encoding='utf8')
assert complete
