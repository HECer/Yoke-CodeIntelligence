from pathlib import Path
import subprocess,json,hashlib,time,sys
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/git-compiler-invocations-r1';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={n:sha(w/n) for n in json.loads((w/'validation/integration-20261018/git-compiler-affected-r3/source-before.json').read_text())};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');(out/'controller.py').write_bytes(Path(__file__).read_bytes())
rows=[]
def run(name,argv):
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:code=subprocess.run(argv,cwd=w,stdout=stdout,stderr=stderr,timeout=1200).returncode
 assert all(sha(w/n)==h for n,h in inputs.items());rows.append({'name':name,'argv':argv,'exitCode':code,'seconds':round(time.monotonic()-start,3)});(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows[-1]),flush=True);return code
assert run('javascript-syntax',[r'C:\Program Files\nodejs\node.exe','--check',str(w/'native/src/compiler_hierarchy_worker.cjs')])==0
deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()};code=run('git_compiler_affected',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','test','--locked','-j','2','--test','git_compiler_affected','--','--test-threads=1']);cleanup=[]
for p in deps.iterdir():
 if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith('git_compiler_affected-'):continue
 assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h;p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h})
(out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'complete':True,'sourceInputsUnchanged':True,'inputs':len(inputs),'exitCode':code,'rows':rows},indent=2)+'\n');sys.exit(code)
