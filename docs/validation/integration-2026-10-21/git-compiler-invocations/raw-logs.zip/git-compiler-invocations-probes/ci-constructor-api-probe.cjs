const ts=require('C:/Users/Lomi/Documents/NN-Developed/Yoke-CodeIntelligence/node_modules/typescript/lib/typescript.js');
const src=`class Base { constructor(v:string); constructor(v:string) {} static go(){return 1;} }
class Derived extends Base { static override go(){return 2;} }
class Explicit extends Base { constructor(v:string){super(v);} static override go(){return 3;} }
class Empty {} class Generic<T>{constructor(v:T){}}
interface Factory {new(v:string):Base;}
function dynamic(C:typeof Base,F:Factory){ new C('a');new F('b');C.go(); }
function direct(){new Derived('c');new Explicit('d');new Empty();new Generic<string>('g');Base.go();}
function tag(s:TemplateStringsArray):string;function tag(s:TemplateStringsArray){return s[0];}
function tagged(){return tag\`hello\`;}
`;
const name='probe.ts',file=ts.createSourceFile(name,src,ts.ScriptTarget.Latest,true),options={strict:true,target:ts.ScriptTarget.ES2022};
options.types=[];options.noEmit=true;
const host=ts.createCompilerHost(options),read=host.getSourceFile.bind(host);host.getSourceFile=(p,v,...rest)=>p===name?file:read(p,v,...rest);
const program=ts.createProgram([name],options,host),checker=program.getTypeChecker();
console.log('diagnostics',ts.getPreEmitDiagnostics(program).map(d=>ts.flattenDiagnosticMessageText(d.messageText,' ')));
console.log('constructorKey',ts.InternalSymbolName?.Constructor);
function decl(d){return d&&{kind:ts.SyntaxKind[d.kind],text:d.getText().slice(0,120),parent:ts.SyntaxKind[d.parent.kind]};}
function walk(n){
 if(ts.isClassDeclaration(n)){const symbol=checker.getSymbolAtLocation(n.name),t=checker.getTypeOfSymbolAtLocation(symbol,n.name);console.log('class',n.name.text,'ctor',checker.getSignaturesOfType(t,ts.SignatureKind.Construct).map(s=>decl(s.declaration)),'memberSymbols',[...(symbol.members||[])].map(([k,s])=>[k,s.declarations?.map(decl)]));}
 if(ts.isCallExpression(n)||ts.isNewExpression(n)||ts.isTaggedTemplateExpression(n)){const sig=checker.getResolvedSignature(n),target=sig?.declaration,e=ts.isTaggedTemplateExpression(n)?n.tag:n.expression,et=checker.getTypeAtLocation(e),sym=checker.getSymbolAtLocation(e);console.log('invoke',n.getText(),decl(target),'exprtype',checker.typeToString(et),'exprsymbol',sym&&{name:sym.name,flags:sym.flags},'result',checker.typeToString(checker.getTypeAtLocation(n)),checker.getTypeAtLocation(n).getSymbol()?.name);}
 ts.forEachChild(n,walk);
}walk(file);
