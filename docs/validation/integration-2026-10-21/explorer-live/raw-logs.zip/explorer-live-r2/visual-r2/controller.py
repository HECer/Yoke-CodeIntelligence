from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,tempfile,time,_winapi,shutil,socket
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018/explorer-live-r2';out=raw/'visual-r2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native=w/'target/debug/yoke.exe';browser=Path(r'C:\Program Files\Google\Chrome\Application\chrome.exe');native_hash=sha(native);browser_hash=sha(browser)
inputs=json.loads((raw/'source-before.json').read_text());assert all(sha(w/n)==h for n,h in inputs.items())
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-live-explorer-'));env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
for name in ['Desktop','Documents','Downloads']:(jobroot/'home'/name).mkdir(exist_ok=True)
reviewed=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=reviewed[reviewed.index('k=ctypes.WinDLL('):reviewed.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner[:runner.index('rows=[]')],'reviewed Windows Job definitions','exec'))
job=k.CreateJobObjectW(None,None);assert job;limits=Extended();limits.basic.flags=0x2000;assert k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits));handles=[];rows=[];ports=[]
def active():
    info=ctypes.create_string_buffer(48);assert k.QueryInformationJobObject(job,1,info,48,None);return int.from_bytes(info.raw[40:44],'little')
def spawn(name,argv):
    with open(os.devnull,'rb') as inp,(jobroot/(name+'.stdout')).open('wb') as stdout,(jobroot/(name+'.stderr')).open('wb') as stderr:
        inherited=[msvcrt.get_osfhandle(f.fileno()) for f in [inp,stdout,stderr]]
        for handle in inherited:os.set_handle_inheritable(handle,True)
        si=subprocess.STARTUPINFO();si.dwFlags=subprocess.STARTF_USESTDHANDLES;si.hStdInput,si.hStdOutput,si.hStdError=inherited;si.lpAttributeList={'handle_list':inherited}
        hp,ht,pid,tid=_winapi.CreateProcess(None,subprocess.list2cmdline([str(x) for x in argv]),None,None,True,subprocess.CREATE_NO_WINDOW|0x00000004,env,str(jobroot),si)
        handles.extend([hp,ht]);assert k.AssignProcessToJobObject(job,hp);assert k.ResumeThread(ht)!=0xffffffff
    rows.append({'name':name,'pid':pid,'startedSuspended':True,'assignedBeforeResume':True,'argv':[str(x) for x in argv]});return hp
def announce(name,hp):
    path=jobroot/(name+'.stdout');start=time.monotonic()
    while True:
        data=path.read_bytes()
        if b'\n' in data:return json.loads(data.split(b'\n',1)[0])
        assert _winapi.WaitForSingleObject(hp,0)==258,'Owned native Explorer exited before readiness';assert time.monotonic()-start<45,'Native Explorer startup deadline';time.sleep(.05)
versions={str(i):("\ufeff// π 😀 </script><script>globalThis.INJECTED=1</script>\r\nexport function liveValue() {\r\n  const label = 'LIVE_VERSION_"+str(i)+"';\r\n  return label;\r\n}\r\nexport function caller() { return liveValue(); }\r\n") for i in range(1,5)}
result={'app':'Code Intelligence','version':'0.5.0','nativeCliSha256':native_hash,'browserSha256':browser_hash,'fixtureRoot':str(jobroot),'privateCapabilityFilesExcludedFromPublishedEvidence':True,'sourceCodeExecuted':False,'modelRequested':False,'osNetworkIsolationAttested':False};start=time.monotonic()
try:
    servers={}
    for name,allow in [('allowed',True),('denied',False)]:
        source=jobroot/name;source.mkdir();(source/'π.ts').write_bytes(versions['1'].encode('utf8'));argv=[native,'--root',source,'explorer','--max-requests','1000']+(['--allow-rebuild'] if allow else [])
        hp=spawn(name,argv);value=announce(name,hp);base=value['url'].split('/#')[0];port=int(base.rsplit(':',1)[1]);ports.append(port);servers[name]={**value,'origin':base,'sourceRoot':str(source)}
    profile=jobroot/'profile';profile.mkdir();hp=spawn('browser',[browser,'--headless=new','--user-data-dir='+str(profile),'--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-default-apps','--disable-features=MediaRouter,Translate','--window-size=1440,1000','about:blank'])
    until=time.monotonic()+25
    while not(profile/'DevToolsActivePort').is_file():assert time.monotonic()<until and _winapi.WaitForSingleObject(hp,0)==258;time.sleep(.05)
    debug_port=int((profile/'DevToolsActivePort').read_text().splitlines()[0]);private=jobroot/'private-ready.json';private.write_text(json.dumps({'servers':servers,'versions':versions},ensure_ascii=False),encoding='utf8')
    ready={'out':str(out),'debugPort':debug_port,'privateReadyPath':str(private),'sourceRoot':servers['allowed']['sourceRoot'],'nativeCliSha256':native_hash,'origins':{name:value['origin'] for name,value in servers.items()},'capabilityValuesExcluded':True};(out/'ready.json').write_text(json.dumps(ready,indent=2)+'\n');print(json.dumps({'ready':True,'debugPort':debug_port,'origins':ready['origins']}),flush=True)
    while not(out/'stop.request').exists():assert time.monotonic()-start<900,'Owned live audit deadline';time.sleep(.1)
    result['explicitCleanupRequested']=True
finally:
    assert k.TerminateJobObject(job,125);until=time.monotonic()+10
    while active() and time.monotonic()<until:time.sleep(.05)
    result['activeAfterCleanup']=active()
    for handle in handles+[job]:k.CloseHandle(handle)
    closed=[]
    for port in ports:
        until=time.monotonic()+3
        while True:
            with socket.socket() as probe:probe.settimeout(.2);value=probe.connect_ex(('127.0.0.1',port))!=0
            if value or time.monotonic()>=until:closed.append(value);break
            time.sleep(.05)
    result.update(commands=rows,allOwnJobsEmpty=result['activeAfterCleanup']==0,servicePortsClosed=all(closed),sourceInputsUnchanged=all(sha(w/n)==h for n,h in inputs.items()),nativeCliUnchanged=sha(native)==native_hash,browserUnchanged=sha(browser)==browser_hash)
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['allOwnJobsEmpty','servicePortsClosed','sourceInputsUnchanged','nativeCliUnchanged']}),flush=True)
