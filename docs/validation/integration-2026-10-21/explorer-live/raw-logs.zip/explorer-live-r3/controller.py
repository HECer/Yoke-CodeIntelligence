from pathlib import Path
import subprocess,json,hashlib,os,time,sys
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence')
out=w/'validation/integration-20261018/explorer-live-r3';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((w/'validation/integration-20261018/full-native-current-20261021-r1/source-before.json').read_text())
for name in ['native/src/explorer_source.html','native/tests/explorer_sources.rs','native/src/explorer_http.rs','native/src/explorer_live.html','native/tests/explorer_http.rs']:inputs[name]=''
inputs={name:sha(w/name) for name in inputs}
(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
source=(w/'native/src/explorer_live.html').read_text(encoding='utf8').split('<script>')[1].split('</script>')[0]
(out/'source-runtime.js').write_text(source,encoding='utf8')
rows=[]
def run(name,argv):
    start=time.monotonic()
    with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
        code=subprocess.run(argv,cwd=w,stdout=stdout,stderr=stderr,timeout=1200).returncode
    assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen input changed'
    row={'name':name,'argv':argv,'exitCode':code,'seconds':round(time.monotonic()-start,3)};rows.append(row)
    (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    return code
assert run('javascript-syntax',[r'C:\Program Files\nodejs\node.exe','--check',str(out/'source-runtime.js')])==0
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe'
for target in ['explorer_http']:
    deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()}
    code=run(target,[cargo,'test','--locked','-j','2','--test',target,'--','--test-threads=1'])
    cleanup=[]
    for p in deps.iterdir():
        if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(target+'-'):continue
        assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink()
        h=sha(p);size=p.stat().st_size;assert sha(p)==h;p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h})
    (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n')
    if code:sys.exit(code)
for name,argv in [('fmt',[cargo,'fmt','--all','--check'])]:
    if run(name,argv):sys.exit(1)
(out/'result.json').write_text(json.dumps({'complete':True,'sourceInputsUnchanged':True,'inputs':len(inputs),'rows':rows},indent=2)+'\n')
