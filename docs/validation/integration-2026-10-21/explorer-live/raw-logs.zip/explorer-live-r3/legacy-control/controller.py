from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018/explorer-live-r3';out=raw/'legacy-control';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
source=Path(r"C:\Users\Lomi\AppData\Local\Temp\yoke-owned-explorer-audit-cv4s7way\source ' π");assert source.is_dir()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-explorer-legacy-'));cwd=jobroot;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
html=out/'published-fixture.html';run('legacy-export',[native,'--root',source,'--snapshot','094655fd46ee7147f670fa4eb1903b8c2e829baa26fb0a4805166b4cd687ce43','export','--format','html','--output',html])
expected=w/'validation/integration-20261018/explorer-current-audit/initial-r1/native-export.html';assert sha(expected)=='c3b4e6bbf9b63ce55a35e5cb2dfaf16237d64723e4aeb0f5051f0ef424a4f4e0';assert html.read_bytes()==expected.read_bytes();assert sha(native)==native_hash
(out/'result.json').write_text(json.dumps({'complete':True,'actualLegacyHtmlByteExact':True,'legacyHtmlSha256':sha(html),'nativeCliSha256':native_hash,'commands':rows},indent=2)+'\n');print('Actual existing legacy HTML byte-exact')
