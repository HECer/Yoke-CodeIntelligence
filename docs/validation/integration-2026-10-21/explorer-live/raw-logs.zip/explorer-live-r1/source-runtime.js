
'use strict';
const token=location.hash.slice(1),state=document.getElementById('state'),frame=document.getElementById('view'),reload=document.getElementById('reload'),rebuild=document.getElementById('rebuild');
let snapshot=null,revision=null,allowed=false,busy=false;
function status(message,error=false){state.textContent=message;state.dataset.error=String(error);}
function controls(){reload.disabled=busy||!/^[a-f0-9]{64}$/.test(token);rebuild.disabled=busy||!allowed||snapshot===null;}
async function request(path,options={}){
  const response=await fetch(path,{...options,headers:{Authorization:'Bearer '+token,...options.headers},cache:'no-store',credentials:'omit',redirect:'error',signal:AbortSignal.timeout(610000)});
  if(!response.ok){let message='Request refused ('+response.status+')';try{message=(await response.json()).error||message;}catch{}throw new Error(message);}
  return response;
}
async function load(){
  const response=await request('/api/view'),nextSnapshot=response.headers.get('X-Yoke-Snapshot'),nextRevision=Number(response.headers.get('X-Yoke-Revision'));
  if(!/^[a-f0-9]{64}$/.test(nextSnapshot)||!Number.isSafeInteger(nextRevision)||nextRevision<0)throw new Error('Invalid captured view binding');
  const html=await response.text();frame.srcdoc=html;snapshot=nextSnapshot;revision=nextRevision;allowed=response.headers.get('X-Yoke-Rebuild')==='true';
  document.getElementById('permission').textContent=allowed?'Host permits manual capture':'Read-only saved view · rebuild not granted';
  status('Snapshot '+snapshot.slice(0,16)+' · revision '+revision+' · disk freshness is not checked until an explicit rebuild.');
}
async function operation(action){
  if(busy)return;busy=true;controls();
  try{await action();}catch(error){status(error.message+' — the displayed view is retained.',true);}finally{busy=false;controls();}
}
reload.addEventListener('click',()=>operation(async()=>{status('Loading the saved server view…');await load();}));
rebuild.addEventListener('click',()=>operation(async()=>{
  status('Capturing files and building a new immutable view…');
  const response=await request('/api/rebuild',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({expectedSnapshotId:snapshot,expectedRevision:revision})});
  const result=await response.json();await load();if(!result.changed)status('Capture completed with unchanged source · snapshot '+snapshot.slice(0,16)+' · revision '+revision+'.');
}));
if(!/^[a-f0-9]{64}$/.test(token)){status('Open the private capability URL announced by the host. Do not share that URL.',true);controls();}
else operation(load);
