from pathlib import Path
import subprocess,hashlib,json,os,shutil,tempfile
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/r5-owner-changes/legacy-before-r1';out.mkdir(parents=True,exist_ok=False)
exe=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();expected='84acd7a916ab541cf1db03807cc11477d20dce355eff6553467ef5333ef90b3d';assert sha(exe)==expected
shutil.copyfile(__file__,out/'controller.py');root=Path(tempfile.mkdtemp(prefix='yoke-owned-owner-changes-'));(root/'src').mkdir()
sources={'src/unchanged.rs':'// owned λ 💡\r\npub fn unchanged()->u32{7}\r\n','src/other.rs':'pub fn other(){}\n','.gitignore':'.yoke/\n'}
for name,text in sources.items():(root/name).write_bytes(text.encode())
(root/'CODEOWNERS').write_bytes(b'* @owned-base\r\n')
git=str(Path(shutil.which('git')).resolve());env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='NUL',GIT_ATTR_NOSYSTEM='1')
rows=[]
def run(name,argv,cwd=root,environment=env,ok=True):
    p=subprocess.run(argv,cwd=cwd,env=environment,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60,creationflags=0x08000000)
    (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);rows.append({'name':name,'command':argv,'exitCode':p.returncode})
    if ok:assert p.returncode==0,(name,p.returncode)
    return p
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','commit.gpgsign=false','-c','user.name=Owned owner changes fixture','-c','user.email=owned-owner-changes@example.invalid']
run('git-init',[*g,'init','-b','main']);run('git-add',[*g,'add','--all']);run('git-commit',[*g,'commit','-m','owned base']);base=run('git-base',[*g,'rev-parse','HEAD']).stdout.decode().strip()
(root/'CODEOWNERS').write_bytes(b'* @owned-head\r\n');options=out/'git-options.json';options.write_text(json.dumps({'baseRef':base,'historyLimit':1,'branchLimit':0})+'\n')
source_hashes={n:sha(root/n) for n in sources};index_hash=sha(root/'.git/index')
common=[str(exe),'--root',str(root),'--max-bytes','4000000','--timeout','30000']
report=json.loads(run('git-analyze',[*common,'--allow-writes','git','analyze','--options',str(options),'--git',git,'--trust-git']).stdout)
ident=report['artifactId'];offline=env.copy();offline['PATH']=str(out)
command=[*common,'git','owners',ident];first=run('owners',command,environment=offline).stdout
assert run('owners-repeat',command,environment=offline).stdout==first
value=json.loads(first);paths=sorted({r['path'] for r in value['ownership']});assert 'src/unchanged.rs' not in paths
assert [s['contentHash'] for s in value['ruleSources']][0]!=[s['contentHash'] for s in value['ruleSources']][1]
before={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
missing=run('owner-changes-unavailable',[*common,'git','owner-changes',ident],environment=offline,ok=False);assert missing.returncode!=0 and not missing.stdout
after={p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()};assert before==after
assert all(sha(root/n)==h for n,h in source_hashes.items()) and sha(root/'.git/index')==index_hash and sha(exe)==expected
result={'ownedRoot':str(root),'reportArtifactId':ident,'cliSha256':expected,'legacyOwnerCommand':command,'legacyRawStdoutRepeatExact':True,'legacyOwnershipPaths':paths,'unchangedSourcePathOmittedByLegacyQuery':True,'capturedRuleSourcesDiffer':True,'newCommandUnavailable':True,'unavailableCommandLeavesAllFilesUnchanged':True,'sourceFiles':source_hashes,'gitIndexUnchanged':True,'analyzedSourceExecuted':False,'commands':rows,'fullStatusCertified':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['commands','sourceFiles','legacyOwnerCommand']}))
