from pathlib import Path
import subprocess,hashlib,json,os,sys,shutil
primary=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=primary/'validation/integration-20261018/r5-owner-changes';guard=json.loads((raw/sys.argv[1]/'result.json').read_text());assert guard['allChecksPassed'] and guard['sourceUnchanged']
w=Path(guard['sourceRoot']);before=json.loads((raw/'legacy-before-r1/result.json').read_text());root=Path(before['ownedRoot']);exe=primary/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();binary=sha(exe);assert binary==guard['cliSha256']
frozen=json.loads((raw/sys.argv[1]/'source-after.json').read_text());assert all(sha(w/n)==h for n,h in frozen.items())
out=raw/sys.argv[2];out.mkdir(parents=True,exist_ok=False);shutil.copyfile(__file__,out/'controller.py');env=os.environ.copy();env['PATH']=str(out)
inventory=lambda:{p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()};state=inventory();rows=[]
def run(name,cmd,ok=True):
    p=subprocess.run(cmd,cwd=w,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45,creationflags=0x08000000)
    (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr);rows.append({'name':name,'command':cmd,'exitCode':p.returncode})
    if ok:assert p.returncode==0,(name,p.returncode)
    else:assert p.returncode!=0 and not p.stdout
    return p.stdout
old=before['legacyOwnerCommand'];assert run('owners',old)==(raw/'legacy-before-r1/owners.stdout').read_bytes()
new=old.copy();new[new.index('git')+1]='owner-changes';first=run('owner-changes',new);value=json.loads(first)
row=next(r for r in value['changes'] if r['path']=='src/unchanged.rs')
assert row['change']=='authored_candidates_changed' and row['sourceContentChanged'] is False
assert row['base']['ownerLabels']==['@owned-base'] and row['head']['ownerLabels']==['@owned-head']
assert row['base']['contentHash']==row['head']['contentHash']
assert all(value[k] is False for k in ['complete','stateWritten','sourceWritten','latestChanged','ownerIdentityVerified','githubPermissionVerified','reviewRequirementEstablished'])
assert all(value[k]==0 for k in ['gitSubprocesses','modelCalls','networkRequests'])
assert value['allCapturedPathsEvaluated'] and value['capturedSourceBodiesVerified']
assert run('owner-changes-repeat',new)==first
exact=new.copy();exact[exact.index('--max-bytes')+1]=str(len(first));assert run('owner-changes-exact-budget',exact)==first
small=new.copy();small[small.index('--max-bytes')+1]=str(len(first)-1);run('owner-changes-short-budget',small,False)
assert inventory()==state
assert all(sha(root/n)==h for n,h in before['sourceFiles'].items())
assert all(sha(w/n)==h for n,h in frozen.items()) and sha(exe)==binary
result={'cliSha256':binary,'legacyOwnersRawStdoutExact':True,'ownerChangesRepeatedRawStdoutExact':True,'unchangedSourceDeclaredCandidatesChanged':True,'originalFileHashPreserved':True,'exactNewlineOutputBudgetPassed':True,'allOwnedSourceStoreAndGitFilesUnchanged':True,'sourceUnchanged':True,'networkGitAndModelOperations':0,'analyzedSourceExecuted':False,'resultId':value['resultId'],'commands':rows,'fullStatusCertified':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='commands'}))
