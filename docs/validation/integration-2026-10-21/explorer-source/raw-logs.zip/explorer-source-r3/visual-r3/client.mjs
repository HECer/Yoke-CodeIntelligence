import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const out=String.raw`C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\validation\integration-20261018\explorer-source-r3\visual-r3`;
fs.copyFileSync(process.argv[1],path.join(out,'client.mjs'));
const ready=JSON.parse(fs.readFileSync(path.join(out,'ready.json'),'utf8'));
const protocol=await (await fetch(`http://127.0.0.1:${ready.debugPort}/json/protocol`)).json();
const commands=Object.fromEntries(protocol.domains.map(d=>[d.domain,d.commands?.map(c=>c.name)||[]]));
assert(commands.Page.includes('captureScreenshot')&&commands.Runtime.includes('evaluate')&&commands.Emulation.includes('setDeviceMetricsOverride'));
fs.writeFileSync(path.join(out,'protocol-summary.json'),JSON.stringify({version:protocol.version,usedDomains:Object.fromEntries(['Page','Runtime','Emulation','Browser','Network'].map(k=>[k,commands[k]]))},null,2));
const targets=await (await fetch(`http://127.0.0.1:${ready.debugPort}/json/list`)).json();
const target=targets.find(t=>t.type==='page'&&t.url==='about:blank');assert(target,'Only own fresh blank page may be used');
const ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
let serial=0;const pending=new Map(),requests=[],exceptions=[];
ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(new Error(JSON.stringify(m.error))):p.resolve(m.result);}}else if(m.method==='Network.requestWillBeSent'){const u=new URL(m.params.request.url);requests.push({origin:u.origin,path:u.pathname,method:m.params.request.method});}else if(m.method==='Runtime.exceptionThrown')exceptions.push(m.params.exceptionDetails);});
function cmd(method,params={},timeout=15000){return new Promise((resolve,reject)=>{const id=++serial;const timer=setTimeout(()=>{pending.delete(id);reject(new Error('Owned CDP deadline '+method));},timeout);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});}
async function evaluate(expression){const r=await cmd('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw new Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
const wait=ms=>new Promise(r=>setTimeout(r,ms));const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const report={app:'Code Intelligence',version:'0.5.0',baseCommit:'cb5dabc048c0a446ed020ea9ee0c6ea56bedaf42',htmlSha256:ready.htmlSha256,temporaryProfileOnly:true,sourceCodeExecuted:false,modelRequested:false,images:[],requests,exceptions};
async function shot(name){const geometryBefore=await evaluate("({viewport:innerHeight,canvas:document.getElementById('graph').height,body:document.documentElement.scrollHeight})");const screen=await cmd('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false});const data=Buffer.from(screen.data,'base64');fs.writeFileSync(path.join(out,name+'.png'),data,{flag:'wx'});const state=await evaluate("({status:document.getElementById('status').textContent,selected:document.querySelector('.symbol[aria-pressed=true]')?.textContent||null,canvas:{width:document.getElementById('graph').width,height:document.getElementById('graph').height},viewport:{width:innerWidth,height:innerHeight},visibility:document.visibilityState})");const geometryAfter=await evaluate("({viewport:innerHeight,canvas:document.getElementById('graph').height,body:document.documentElement.scrollHeight})");assert(Math.abs(geometryAfter.canvas-geometryBefore.canvas)<3,'Capture must not alter canvas geometry');if(await evaluate('innerWidth>1100'))assert(geometryAfter.body<=geometryAfter.viewport+2,'Desktop document must fit viewport');report.images.push({name,bytes:data.length,sha256:sha(data),state,geometryBefore,geometryAfter,captureScope:'actual viewport covering the complete current desktop document'});return state;}
try{
 await cmd('Page.enable');await cmd('Runtime.enable');await cmd('Network.enable');await cmd('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});
 report.browser=await cmd('Browser.getVersion');assert(report.browser.product.includes('156.0.8078.47'));
 await cmd('Page.navigate',{url:ready.url});
 const until=Date.now()+10000;while(!(await evaluate("document.readyState==='complete'&&!!document.getElementById('status')"))){assert(Date.now()<until);await wait(50);}
 await wait(1300);report.initialData=await evaluate("JSON.parse(document.getElementById('data').textContent)");await shot('01-initial-force');

 report.sourcePayload=await evaluate("JSON.parse(document.getElementById('sources').textContent)");
 await evaluate("[...document.querySelectorAll('button.symbol')].find(b=>b.textContent.startsWith('normalizeTotal')).click()");
 report.code=await evaluate("({tabs:[...document.querySelectorAll('[role=tab]')].map(b=>b.textContent),text:document.getElementById('source-code').textContent,selectedText:[...document.querySelectorAll('#source-code mark')].map(m=>m.textContent).join(''),injected:globalThis.INJECTED||false})");
 assert.deepEqual(report.code.tabs,['Code','Context','Outline']);assert(report.code.text.includes('OWNED_SOURCE_BODY'));assert(!report.code.injected);
 const entity=report.initialData.entities.find(e=>e.name==='normalizeTotal');const file=report.sourcePayload.files.find(f=>f.binding.path===entity.path);const sourceBytes=Buffer.from(file.text,'utf8');assert.equal(report.code.selectedText,sourceBytes.subarray(entity.startByte,entity.endByte).toString('utf8'));
 await shot('02-code-selected');
 await evaluate("document.getElementById('source-tab-context').click()");
 report.context=await evaluate("({text:document.getElementById('source-panel').innerText,quotes:[...document.querySelectorAll('#source-panel button')].filter(b=>b.textContent==='Read exact quote').length})");assert(report.context.quotes>0);assert(report.context.text.includes('heuristic')||report.context.text.includes('syntactic'));
 await shot('03-context');
 await evaluate("[...document.querySelectorAll('#source-panel button')].find(b=>b.textContent==='Read exact quote').click()");
 report.quote=await evaluate("({text:document.getElementById('source-panel').innerText,focus:sourceFocus,selectedText:[...document.querySelectorAll('#source-code mark')].map(n=>n.textContent).join('')})");assert(report.quote.text.includes('Exact observation quote'));const quoteFile=report.sourcePayload.files.find(f=>f.binding.path===report.quote.focus.path);assert.equal(report.quote.selectedText,Buffer.from(quoteFile.text,'utf8').subarray(report.quote.focus.startByte,report.quote.focus.endByte).toString('utf8'));await shot('04-exact-quote');
 await evaluate("document.getElementById('source-tab-outline').click()");await shot('05-outline');
 await evaluate("[...document.querySelectorAll('.outlineItem')].find(b=>b.textContent.startsWith('tailPreview')).click()");
 await wait(100);report.tail=await evaluate("({page:[...document.querySelectorAll('#source-code .sourceLine')].map(n=>Number(n.dataset.line)),text:document.getElementById('source-code').textContent,selectedText:[...document.querySelectorAll('#source-code mark')].map(n=>n.textContent).join('')})");assert(report.tail.page[0]>120);assert(report.tail.text.includes('TAIL_CAPTURED_BODY'));await shot('06-paged-code');report.tailGeometry=await evaluate("(()=>{const m=[...document.querySelectorAll('#source-code mark')].map(n=>n.getBoundingClientRect());const c=document.getElementById('source-code').getBoundingClientRect();return {first:m[0].top,last:m.at(-1).bottom,containerTop:c.top,containerBottom:c.bottom,viewport:innerHeight};})()");assert(report.tailGeometry.first>=report.tailGeometry.containerTop&&report.tailGeometry.last<=Math.min(report.tailGeometry.containerBottom,report.tailGeometry.viewport),'Selected tail must actually be visible');
 await evaluate("document.getElementById('source-tab-code').dispatchEvent(new KeyboardEvent('keydown',{key:'ArrowRight',bubbles:true}))");assert.equal(await evaluate("document.activeElement.id"),'source-tab-context');report.keyboardTabs=true;
 await evaluate("[...document.querySelectorAll('.relationChip')].find(b=>b.dataset.relation==='calls').click();document.getElementById('neighbors').click()");await wait(900);assert.equal(await evaluate("document.querySelector('.relationChip[aria-pressed=true]').dataset.relation"),'calls');await shot('07-calls-neighbors');
 await evaluate("document.getElementById('neighbors').click();document.getElementById('relation').value='';document.getElementById('relation').dispatchEvent(new Event('change',{bubbles:true}));document.getElementById('layout').value='radial';document.getElementById('layout').dispatchEvent(new Event('change',{bubbles:true}))");await wait(100);await shot('08-radial');
 await evaluate("document.getElementById('layout').value='force';document.getElementById('layout').dispatchEvent(new Event('change',{bubbles:true}))");await shot('09-force-start');await wait(50);await shot('10-force-middle');await wait(900);await shot('11-force-settled');
 await cmd('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await evaluate("document.getElementById('source-tab-code').click();document.getElementById('detail').scrollIntoView()");await wait(150);await shot('12-mobile-code');
 report.mobile=await evaluate("({width:innerWidth,documentWidth:document.documentElement.scrollWidth,tabs:document.querySelectorAll('[role=tab]').length})");assert(report.mobile.documentWidth<=report.mobile.width+2,'Mobile horizontal overflow');report.mobileSelection=await evaluate("(()=>{const m=[...document.querySelectorAll('#source-code mark')].map(n=>n.getBoundingClientRect());return {first:m[0].top,last:m.at(-1).bottom,viewport:innerHeight};})()");assert(report.mobileSelection.first>=0&&report.mobileSelection.last<=report.mobileSelection.viewport,'Mobile selection must actually be visible');
 await cmd('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false});await evaluate('scrollTo(0,0)');
 report.finalData=await evaluate("JSON.parse(document.getElementById('data').textContent)");assert.deepEqual(report.finalData,report.initialData);report.embeddedGraphExact=true;
 const downloadDir=path.join(out,'downloads');fs.mkdirSync(downloadDir);await cmd('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:downloadDir,eventsEnabled:true});await evaluate("document.getElementById('download').click()");
 let downloaded;const deadline=Date.now()+10000;while(!downloaded){downloaded=fs.readdirSync(downloadDir).find(n=>n.endsWith('.json'));assert(Date.now()<deadline,'Owned download deadline');if(!downloaded)await wait(100);}
 const bytes=fs.readFileSync(path.join(downloadDir,downloaded));assert.deepEqual(JSON.parse(bytes),report.initialData);report.canonicalDownload={name:downloaded,bytes:bytes.length,sha256:sha(bytes),fullGraphExact:true};
 assert(exceptions.length===0);report.completed=true;report.fullFeatureParity=false;
}catch(error){report.completed=false;report.error=error.message;process.exitCode=1;}
finally{
 fs.writeFileSync(path.join(out,'client-result.json'),JSON.stringify(report,null,2)+'\n');
 try{await cmd('Browser.close',{},3000);}catch{}
 fs.writeFileSync(path.join(out,'stop.request'),'owned audit complete\n');ws.close();
 console.log(JSON.stringify({completed:report.completed,error:report.error,images:report.images.length,embeddedGraphExact:report.embeddedGraphExact,canonicalDownloadExact:report.canonicalDownload?.fullGraphExact,exceptions:exceptions.length,fullFeatureParity:false}));
}
