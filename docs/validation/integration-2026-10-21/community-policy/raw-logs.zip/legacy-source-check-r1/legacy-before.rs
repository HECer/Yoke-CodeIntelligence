    let mut excluded = BTreeSet::new();
    if let Some(percentile) = options.exclude_hubs_percentile
        && !nodes.is_empty()
    {
        let mut counts: Vec<_> = degree.values().copied().collect();
        counts.sort();
        let position = if options.source_category_policy.is_some() {
            ((counts.len() as f64 * percentile / 100.0).floor() as usize)
                .saturating_sub(1)
                .min(counts.len() - 1)
        } else {
            ((counts.len() - 1) as f64 * percentile / 100.0).floor() as usize
        };
        let threshold = counts[position];
        excluded.extend(
            degree
                .iter()
                .filter(|(_, n)| **n > threshold)
                .map(|(id, _)| id.clone()),
        );
    }
    let active: Vec<_> = nodes
        .iter()
        .enumerate()
        .filter(|(_, n)| !excluded.contains(&n.id))
        .map(|(i, _)| i)
        .collect();
    let compact: BTreeMap<_, _> = active.iter().enumerate().map(|(a, b)| (*b, a)).collect();
    let mut builder = leiden_rs::GraphDataBuilder::new(active.len());
    for edge in &graph.observations {
        deadline.check()?;
        if let Some(target) = &edge.target {
            let a = index[edge.source.as_str()];
            let b = index[target.as_str()];
            let weight = edge_weight(edge, options);
            if weight > 0.0
                && let (Some(a), Some(b)) = (compact.get(&a), compact.get(&b))
            {
                builder.add_edge(*a, *b, weight)?;
            }
        }
    }
    deadline.check()?;
    let output = leiden_rs::Leiden::new(leiden_rs::LeidenConfig {
        resolution: options.resolution,
        max_iterations: options.max_iterations,
        seed: Some(options.seed),
        max_comm_size: options.max_community_size,
        ..Default::default()
    })
    .run(&builder.build()?)?;
    deadline.check()?;
    let mut groups: BTreeMap<usize, Vec<usize>> = output
        .partition
        .communities()
        .into_iter()
        .map(|(cid, members)| (cid, members.into_iter().map(|i| active[i]).collect()))
        .collect();
    let mut assigned: BTreeMap<usize, usize> = groups
        .iter()
        .flat_map(|(cid, members)| members.iter().map(move |node| (*node, *cid)))
        .collect();
    let mut next = groups.keys().next_back().map_or(0, |c| c + 1);
    for (i, node) in nodes.iter().enumerate() {
        deadline.check()?;
        if !excluded.contains(&node.id) {
            continue;
        }
        let mut votes = BTreeMap::<usize, f64>::new();
        for (neighbor, weight) in &adjacency[i] {
            if let Some(cid) = assigned.get(neighbor) {
                *votes.entry(*cid).or_default() += weight;
            }
        }
        let cid = votes
            .into_iter()
            .max_by(|(a, wa), (b, wb)| wa.total_cmp(wb).then_with(|| b.cmp(a)))
            .map(|(cid, _)| cid)
            .unwrap_or_else(|| {
                let c = next;
                next += 1;
                c
            });
        groups.entry(cid).or_default().push(i);
        assigned.insert(i, cid);
    }
