﻿from pathlib import Path
import subprocess,hashlib,json,os,time,re,sys,shutil
primary=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');work=primary.parent/'Yoke-CI-r3-community';target=primary/'target';deps=(target/'debug/deps').resolve()
base=primary/'validation/integration-20261018/full-native-float-20261021-r1/result.json'
assert base.is_file(),'Primary full Cargo suite must be terminal before any secondary Cargo call'
full=json.loads(base.read_text());assert full['sourceUnchanged'] and full['allRegisteredGroupsAttempted']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=work).decode().strip()=='bcf442b32a6dd03bcd3c6c8e8794eaf3fd929079'
phase=sys.argv[1];mode=sys.argv[2] if len(sys.argv)>2 else 'all';out=primary/'validation/integration-20261018/r3-community-policy'/phase;out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory():
    names=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z','native','workers','src','test','scripts','Cargo.toml','Cargo.lock','package.json','package-lock.json'],cwd=work).decode().split('\0')
    return {n:sha(work/n) for n in sorted(set(names)) if n and (work/n).is_file()}
before=inventory();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,out/'runner.py')
unit_proof=None
if mode=='contracts':
    unit_phase=sys.argv[3];unit_dir=out.parent/unit_phase;unit_proof=json.loads((unit_dir/'result.json').read_text())
    assert unit_proof['allChecksPassed'] and unit_proof['sourceUnchanged']
    assert json.loads((unit_dir/'source-after.json').read_text())==before
    assert next(c for c in unit_proof['checks'] if c['name']=='community_units')['totals']=={'passed':6,'failed':0,'ignored':0}
cargo=str(Path.home()/'.cargo/bin/cargo.exe');common=[cargo,'test','--workspace','--locked','-j','2','--target-dir',str(target)]
commands=[('fmt',[cargo,'fmt','--all','--','--check']),('community_units',[*common,'--lib','graph_extensions::community::tests','--','--test-threads=1'])]
if mode=='contracts':commands=[]
if mode!='units':
    for name in ['community_analysis_policy','graph_analysis_policy','graph_extensions','selected_view_analysis','selected_view_analysis_review','view_comparison_cli','graphify_adapter','graph_view','graph_exports','parity_retention','retention']:
        assert (work/'native/tests'/(name+'.rs')).is_file();commands.append((name,[*common,'--test',name,'--','--test-threads=1']))
    commands.append(('clippy',[cargo,'clippy','--workspace','--all-targets','--locked','-j','2','--target-dir',str(target),'--','-D','warnings']))
env=os.environ.copy();env['PATH']=str(Path.home()/'AppData/Local/YokeValidation/tools/powershell-7.6.7-win-x64')+os.pathsep+env['PATH'];records=[]
for name,cmd in commands:
    assert inventory()==before;assert shutil.disk_usage(target).free>700*1024*1024
    existing={p.name.casefold() for p in deps.iterdir() if p.is_file()};start=time.monotonic();print('COMMUNITY',name,flush=True)
    with (out/(name+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(out/(name+'.log')).read_text(encoding='utf-8',errors='replace');groups=re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw,re.M)
    row={'name':name,'command':cmd,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3),'sourceUnchanged':inventory()==before,'totals':{key:sum(int(g[i]) for g in groups) for i,key in enumerate(['passed','failed','ignored'])},'deletedNewArtifacts':[]}
    for relative in re.findall(r'Running [^\r\n]*\(([^\r\n]+\.exe)\)',raw):
        exe=(work/relative).resolve();assert exe.parent==deps
        for f in [exe,exe.with_suffix('.pdb')]:
            if f.exists() and f.name.casefold() not in existing:
                row['deletedNewArtifacts'].append({'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f)});f.unlink()
    records.append(row);(out/'progress.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(row),flush=True)
    if row['exitCode'] or not row['sourceUnchanged']:break
after=inventory();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');result={'checks':records,'sourceUnchanged':before==after,'allChecksPassed':len(records)==len(commands) and all(r['exitCode']==0 and r['sourceUnchanged'] for r in records),'scope':'explicit versioned community mode, graph/View/retention contracts','primaryFullNativeBaseline':str(base),'baselineAllChecksPassed':full['allChecksPassed'],'retainedNpmChecksRun':False,'fullStatusCertified':False,'cliSha256':sha(target/'debug/yoke.exe'),'separateUnitProof':str(unit_dir/'result.json') if unit_proof else None}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'}),flush=True);sys.exit(0 if result['allChecksPassed'] else 1)
