from pathlib import Path
import subprocess,hashlib,json,os,time,re,sys,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');target=w/'target';deps=(target/'debug/deps').resolve()
raw=w/'validation/integration-20261018/r3-community-policy';secondary=json.loads((raw/sys.argv[1]/'result.json').read_text())
assert secondary['allChecksPassed'] and secondary['sourceUnchanged']
assert 'mod community;' in (w/'native/src/graph_extensions.rs').read_text()
phase=sys.argv[2];out=raw/phase;out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory():
    names=subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z','native','workers','src','test','scripts','Cargo.toml','Cargo.lock','package.json','package-lock.json','tsconfig.json','README.md','SECURITY.md','docs/STATUS.md','docs/ARCHITECTURE.md','docs/REMAINING_WORK.md'],cwd=w).decode().split('\0')
    return {n:sha(w/n) for n in sorted(set(names)) if n and (w/n).is_file()}
before=inventory();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');shutil.copyfile(__file__,out/'runner.py')
cargo=str(Path.home()/'.cargo/bin/cargo.exe');common=[cargo,'test','--workspace','--locked','-j','2','--target-dir',str(target)]
commands=[('fmt',[cargo,'fmt','--all','--','--check']),('community_units',[*common,'--lib','graph_extensions::community::tests','--','--test-threads=1']),('community_analysis_policy',[*common,'--test','community_analysis_policy','--','--test-threads=1']),('clippy',[cargo,'clippy','--workspace','--all-targets','--locked','-j','2','--target-dir',str(target),'--','-D','warnings']),('typecheck',['cmd.exe','/d','/c','npm.cmd','run','typecheck']),('retained',['cmd.exe','/d','/c','npm.cmd','test'])]
env=os.environ.copy();env['PATH']=str(Path.home()/'AppData/Local/YokeValidation/tools/powershell-7.6.7-win-x64')+os.pathsep+env['PATH'];rows=[]
for name,cmd in commands:
    assert inventory()==before
    assert shutil.disk_usage(target).free>700*1024*1024
    existing={p.name.casefold() for p in deps.iterdir() if p.is_file()};start=time.monotonic();print('PRIMARY',name,flush=True)
    with (out/(name+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
    text=(out/(name+'.log')).read_text(encoding='utf-8',errors='replace');groups=re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)
    row={'name':name,'command':cmd,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3),'sourceUnchanged':inventory()==before,'totals':{key:sum(int(g[i]) for g in groups) for i,key in enumerate(['passed','failed','ignored'])},'deletedNewArtifacts':[]}
    for relative in re.findall(r'Running [^\r\n]*\(([^\r\n]+\.exe)\)',text):
        exe=(w/relative).resolve();assert exe.parent==deps
        for f in [exe,exe.with_suffix('.pdb')]:
            if f.exists() and f.name.casefold() not in existing:
                row['deletedNewArtifacts'].append({'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f)});f.unlink()
    rows.append(row);(out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    if p.returncode or not row['sourceUnchanged']:break
after=inventory();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
result={'sourceRoot':str(w),'checks':rows,'sourceUnchanged':before==after,'allChecksPassed':len(rows)==len(commands) and all(r['exitCode']==0 and r['sourceUnchanged'] for r in rows),'secondaryGuard':str(raw/sys.argv[1]/'result.json'),'primaryRecheckReason':'95 line-ending-only checkout differences; primary executable and integration separately validated','cliSha256':sha(target/'debug/yoke.exe'),'fullStatusCertified':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'}),flush=True)
sys.exit(0 if result['allChecksPassed'] else 1)
