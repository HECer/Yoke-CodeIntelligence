from pathlib import Path
import hashlib,json,subprocess,sys,shutil

primary=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence')
work=primary.parent/'Yoke-CI-r3-community'
raw=primary/'validation/integration-20261018/r3-community-policy'
guard=json.loads((raw/sys.argv[1]/'result.json').read_text())
assert guard['allChecksPassed'] and guard['sourceUnchanged']
work=Path(guard.get('sourceRoot',str(work)))
assert any(c['name']=='community_analysis_policy' and c['totals']['passed']>=6 for c in guard['checks'])
base=primary/'validation/integration-20261018/r3-policy-retention/before-r1'
before=json.loads((base/'result.json').read_text())
owned=Path(before['ownedRoot']);exe=primary/'target/debug/yoke.exe'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binary=sha(exe);assert binary==guard['cliSha256']
frozen=json.loads((raw/sys.argv[1]/'source-after.json').read_text())
assert all(sha(work/n)==h for n,h in frozen.items())
assert all(sha(owned/n)==h for n,h in before['sourceFiles'].items())
out=raw/sys.argv[2];out.mkdir(parents=True,exist_ok=False)
shutil.copyfile(__file__,out/'controller.py')
rows=[];reports=[]

def run(name,argv):
    p=subprocess.run(argv,cwd=work,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45,creationflags=0x08000000)
    (out/(name+'.stdout')).write_bytes(p.stdout)
    (out/(name+'.stderr')).write_bytes(p.stderr)
    rows.append({'name':name,'command':argv,'exitCode':p.returncode})
    assert p.returncode==0,(name,p.returncode)
    return p.stdout

for row in before['commands']:
    reply=run(row['name'],row['command'])
    assert reply==(base/(row['name']+'.stdout')).read_bytes(),row['name']+' historical identity changed'
    reports.append(json.loads(reply))

for source_categories in [False,True]:
    name='community-category' if source_categories else 'community'
    options={'communityPolicy':{'kind':'neighbor_majority_v1'},'excludeHubsPercentile':80.0}
    if source_categories:
        category_command=next(r['command'] for r in before['commands'] if r['name']=='category')
        old_options=json.loads(Path(category_command[category_command.index('--options')+1]).read_text())
        options={**old_options,**options}
    options_path=out/(name+'-options.json');options_path.write_text(json.dumps(options,indent=2)+'\n')
    command=[*before['commands'][0]['command'],'--options',str(options_path)]
    first=run(name,command);report=json.loads(first)
    assert report['producer']=='yoke-community-policy-report-1'
    assert report['options']['communityPolicy']=={'kind':'neighbor_majority_v1'}
    assert report['modelCalls']==0 and report['complete'] is False
    assert report['graphHash']==reports[0]['graphHash']
    assert report['sourceBindings']==reports[0]['sourceBindings']
    assert report['evidenceAnchors']==reports[0]['evidenceAnchors']
    assert report['audit']['byResolution']==reports[0]['audit']['byResolution']
    assert report['artifactId'] not in [r['artifactId'] for r in reports]
    assert run(name+'-repeat',command)==first
    reports.append(report)

for name,args in [('retention-plan',['plan']),('retention-purge-plan',['purge-plan'])]:
    reply=json.loads(run(name,[str(exe),'--root',str(owned),'--timeout','30000','--max-bytes','1000000','retention',*args,'--minimum-age-ms','0']))
    assert reply['unknownDependencyKinds']==[]
    if name=='retention-plan':assert reply['snapshotIds']==[]
    else:
        for item in reply['items']:
            assert all(item['blobId'] not in [r['artifactId'],r['markdownArtifactId']] for r in reports)

assert sha(exe)==binary
assert all(sha(owned/n)==h for n,h in before['sourceFiles'].items())
assert all(sha(work/n)==h for n,h in frozen.items())
result={'cliSha256':binary,'legacyAndCategoryV1RawStdoutExact':True,'newCommunityRepeatedRawStdoutExact':True,'originalGraphAndSourceEvidenceExact':True,'savedRootRetentionPlansPassed':True,'sourceUnchanged':True,'analyzedSourceExecuted':False,'sourceFiles':before['sourceFiles'],'commands':rows,'reportIdentities':[{'producer':r['producer'],'artifactId':r['artifactId'],'markdownArtifactId':r['markdownArtifactId']} for r in reports],'fullStatusCertified':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['commands','sourceFiles','reportIdentities']}))
