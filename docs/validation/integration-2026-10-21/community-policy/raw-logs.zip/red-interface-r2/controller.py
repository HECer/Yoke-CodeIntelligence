from pathlib import Path
import hashlib,json,subprocess,shutil,sys
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence')
full=w/'validation/integration-20261018/full-native-float-20261021-r1'
manifest=json.loads((full/'manifest.json').read_text())
exe=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(exe)==manifest['cliSha256']
baseline=json.loads((w/'validation/integration-20261018/r3-policy-retention/before-r1/result.json').read_text())
root=Path(baseline['ownedRoot'])
assert all(sha(root/n)==h for n,h in baseline['sourceFiles'].items())
inventory=lambda:{str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
out=w/'validation/integration-20261018/r3-community-policy'/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
shutil.copyfile(__file__,out/'controller.py')
old_options=out/'legacy-options.json';old_options.write_text('{}\n',encoding='utf-8')
positive_cmd=[*baseline['commands'][0]['command'],'--options',str(old_options)]
positive=subprocess.run(positive_cmd,cwd=w,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40,creationflags=0x08000000)
(out/'legacy.stdout').write_bytes(positive.stdout);(out/'legacy.stderr').write_bytes(positive.stderr)
assert positive.returncode==0
assert positive.stdout==(w/'validation/integration-20261018/r3-policy-retention/before-r1/legacy.stdout').read_bytes()
before=inventory()
options=out/'options.json';options.write_text('{"communityPolicy":{"kind":"neighbor_majority_v1"}}\n',encoding='utf-8')
cmd=[*baseline['commands'][0]['command'],'--options',str(options)]
p=subprocess.run(cmd,cwd=w,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40,creationflags=0x08000000)
(out/'cli.stdout').write_bytes(p.stdout);(out/'cli.stderr').write_bytes(p.stderr)
after=inventory()
result={'command':cmd,'exitCode':p.returncode,'newPolicyRefusedBeforeImplementation':p.returncode!=0 and p.stderr.strip()==b'yoke: Invalid host input schema','positiveLegacyControlRawBytesExact':True,'positiveLegacyCommand':positive_cmd,'ownedSourceAndStoreFilesUnchanged':before==after,'cliUnchanged':sha(exe)==manifest['cliSha256'],'cliSha256':manifest['cliSha256'],'ownedFilesBefore':before,'ownedFilesAfter':after,'analyzedSourceExecuted':False,'acceptancePassed':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['newPolicyRefusedBeforeImplementation'] and result['ownedSourceAndStoreFilesUnchanged'] and result['cliUnchanged']
print(json.dumps({k:v for k,v in result.items() if k not in ['ownedFilesBefore','ownedFilesAfter','command']}))
