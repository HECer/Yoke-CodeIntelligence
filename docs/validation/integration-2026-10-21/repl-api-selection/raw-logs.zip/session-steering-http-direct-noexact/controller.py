from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-steering-http-direct-noexact').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-http-direct-noexact-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';binary=w/'target/debug/deps/mcp_http-03d6e783965609de.exe';assert binary.is_file();binary_hash=sha(binary);outcomes=[]
cases=[('all-tests-direct-noexact',[])]
for name,filters in cases:
 try:
  run(name,[binary,'--nocapture','--test-threads=1',*filters],expected=None,timeout=45);outcomes.append({'name':name,'row':rows[-1]})
 except BaseException:outcomes.append({'name':name,'exception':traceback.format_exc()})
 (out/'result.json').write_text(json.dumps({'completeDiagnostic':True,'binarySha256':binary_hash,'outcomes':outcomes,'commands':rows},indent=2)+'\n')
print(json.dumps(outcomes),flush=True)
