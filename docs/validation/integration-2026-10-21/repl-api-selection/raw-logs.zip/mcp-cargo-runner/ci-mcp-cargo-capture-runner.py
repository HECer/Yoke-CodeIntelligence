import hashlib,json,os,subprocess,sys
from pathlib import Path
out=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\validation\integration-20261018\mcp-cargo-runner')
allowed=['CARGO_MANIFEST_DIR','CARGO_MANIFEST_PATH','CARGO_PKG_NAME','CARGO_PKG_VERSION','CARGO_TARGET_TMPDIR','CARGO_HOME','RUSTUP_HOME','TEMP','TMP','HOME','USERPROFILE','RUST_TEST_THREADS','RUST_TEST_NOCAPTURE']
record={'pid':os.getpid(),'parentPid':os.getppid(),'cwd':os.getcwd(),'argv':sys.argv[1:],'allowedEnvironment':{k:os.environ[k] for k in allowed if k in os.environ},'pathSha256':hashlib.sha256(os.environ.get('PATH','').encode()).hexdigest(),'pathSegments':[{'index':i,'name':Path(v).name} for i,v in enumerate(os.environ.get('PATH','').split(';'))],'cargoMakeflagsPresent':'CARGO_MAKEFLAGS' in os.environ}
(out/'runner-environment.json').write_text(json.dumps(record,indent=2)+'\n')
completed=subprocess.run(sys.argv[1:],close_fds=True);(out/'runner-terminal.json').write_text(json.dumps({'exitCode':completed.returncode})+'\n');sys.exit(completed.returncode)
