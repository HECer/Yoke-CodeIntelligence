from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','mcp-cargo-cached').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-cargo-cached-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';env.pop('CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_RUNNER',None)
try:run('full-cargo-cached',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','test','--locked','-j','2','--test','mcp_http','--','--nocapture','--test-threads=1'],expected=None,timeout=50)
finally:(out/'result.json').write_text(json.dumps({'commands':rows},indent=2)+'\n')
