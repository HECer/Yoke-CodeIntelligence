from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','mcp-cargo-relink').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-cargo-relink-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';env.pop('CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_RUNNER',None)
test_source=w/'native/tests/mcp_http.rs';before_stat=test_source.stat();before_hash=sha(test_source);binary=w/'target/debug/deps/mcp_http-03d6e783965609de.exe';before_binary_hash=sha(binary);os.utime(test_source,None)
try:run('full-cargo-after-relink',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','test','--locked','-j','2','--test','mcp_http','--','--nocapture','--test-threads=1'],expected=None,timeout=50)
finally:
 assert sha(test_source)==before_hash;os.utime(test_source,ns=(before_stat.st_atime_ns,before_stat.st_mtime_ns));(out/'result.json').write_text(json.dumps({'sourceBytesUnchanged':True,'sourceOriginalTimesRestored':True,'binaryBeforeSha256':before_binary_hash,'binaryAfterSha256':sha(binary),'commands':rows},indent=2)+'\n')
