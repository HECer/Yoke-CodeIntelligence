from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,tempfile,time,_winapi,sys,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');aux=w.parent/'Yoke-CI-r1-predicates';raw=w/'validation/integration-20261018/r1-predicate-contexts';out=raw/sys.argv[1];out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';node=Path(r'C:\Program Files\nodejs\node.exe');typescript=w/'node_modules/typescript/lib/typescript.js';tsc=typescript.with_name('tsc.js');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((raw/sys.argv[2]/'result.json').read_text());assert proof['allChecksPassed'] and proof['sourceUnchanged'] and sha(native)==proof['cliSha256']
validated=json.loads((raw/sys.argv[2]/'source-after.json').read_text());source_tree=w if sys.argv[3]=='primary' else aux
assert all(sha(source_tree/n)==h for n,h in validated.items())
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-predicate-cli-'));client=jobroot/'unused-client.exe';configroot=jobroot;cwd=jobroot
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','roaming'),('LOCALAPPDATA','local'),('TEMP','tmp'),('TMP','tmp')]:
    p=jobroot/name;p.mkdir(exist_ok=True);env[key]=str(p)
env.update({'CI':'1','NO_COLOR':'1'})
reviewed=Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py';text=reviewed.read_text();runner=text[text.index("k=ctypes.WinDLL("):text.index("result={'fixtureRoot'")]
original_runner_hash=hashlib.sha256(runner.encode()).hexdigest();assert original_runner_hash=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5'
runner=runner.replace('print(json.dumps(row),flush=True)',"print(name+': exit='+str(row.get('exitCode'))+', jobActive='+str(row['activeAfterCleanup']),flush=True)")
(out/'reviewed-runner.py').write_text(runner,encoding='utf-8');exec(compile(runner,str(reviewed)+'[reviewed runner; print-only change]','exec'))

source="var input:unknown;function helper(value:unknown):value is string{return typeof value==='string';}const ok=helper(input);void ok;\n"
root=jobroot/'owned script';root.mkdir();cwd=root;(root/'main.ts').write_text(source)
(root/'tsconfig.json').write_text(json.dumps({'compilerOptions':{'strict':True,'target':'ES2022','module':'ESNext','moduleResolution':'Bundler','noEmit':True},'files':['main.ts']}))
host=jobroot/'host';host.mkdir();profile=host/'host.json';profile.write_text(json.dumps({'inlineCompiler':{'node':str(node),'typescript':str(typescript),'trusted':True}}))
requests=host/'requests.json';requests.write_text(json.dumps([{'operation':'refactor.prepare','args':{'operation':'inline','arguments':{'relativePath':'main.ts','namePath':'helper','keepDefinition':False}}}]))
response=run('global.prepare',[native,'--root',root,'--timeout','60000','session','--id','owned-global','--host-profile',profile,'--requests',requests],expected=None)
result={'nativeExitCode':rows[-1]['exitCode'],'sourceUnchanged':(root/'main.ts').read_text()==source,'sourceInputsUnchanged':all(sha(source_tree/n)==h for n,h in validated.items()),'commands':rows,'planApplied':False,'analyzedSourceExecuted':False,'ownedLiteralOracleOnly':True}
if rows[-1]['exitCode']==0:
    plan=json.loads(response)['results'][0]['actions'][0]['plan'];diff=plan['diff'];after=''.join(line[1:] for line in diff.splitlines(keepends=True) if line.startswith((' ','+')) and not line.startswith('+++'))
    (out/'derived.ts').write_text(after)
    oracle="const ts=require("+json.dumps(str(typescript))+"),vm=require('node:vm');function read(s){let reads=0;const c=vm.createContext({});Object.defineProperty(c,'input',{configurable:true,get(){reads++;return 'owned';}});vm.runInContext(ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText,c,{timeout:1000});return {reads,ok:vm.runInContext('ok',c)};}process.stdout.write(JSON.stringify({before:read("+json.dumps(source)+"),after:read("+json.dumps(after)+")}));"
    f=host/'oracle.cjs';f.write_text(oracle);result['ownedRuntimeObservation']=json.loads(run('global.owned-oracle',[node,f]));result['commands']=rows
result['allProcessJobsEmpty']=all(r['activeAfterCleanup']==0 and r['assignedBeforeResume'] for r in rows)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
