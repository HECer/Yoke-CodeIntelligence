const events:string[]=[];function mark(tag:string){events.push(tag);return tag;}
const box={get value(){events.push('getter');return {n:3};}};
;
if (void 0 !== void 0) {
var __ci_inline_13 = function(note:string,value:unknown,...tail:string[]):value is {n:number}{events.push(note,tail[0]||'empty');return typeof value==='object'&&value!==null;};void __ci_inline_13;
}
let __ci_inline_14: typeof __ci_inline_13;
let __ci_inline_1: (boolean) | undefined;
{
if (void 0 !== void 0) {
var __ci_inline_6 = function(note:string,value:unknown,...tail:string[]):value is {n:number}{events.push(note,tail[0]||'empty');return typeof value==='object'&&value!==null;};void __ci_inline_6;
var __ci_inline_7 = function(note:string,value:unknown,...tail:string[]): [typeof note,typeof value,...(typeof tail)]{void note;void value;void tail;throw void 0;};void __ci_inline_7;
}
const __ci_inline_8 = ((...__ci_inline_9: unknown[])=>__ci_inline_9) as unknown as typeof __ci_inline_7;
const __ci_inline_10 = __ci_inline_8(mark('first'),box.value,mark('last'));
const __ci_inline_3 = __ci_inline_10[0] as (typeof __ci_inline_10)[0];void __ci_inline_3;
const __ci_inline_4 = __ci_inline_10[1] as (typeof __ci_inline_10)[1];void __ci_inline_4;
const __ci_inline_5 = __ci_inline_10[2] as (typeof __ci_inline_10)[2];void __ci_inline_5;
{
let note:string = __ci_inline_3;

let value:unknown = __ci_inline_4;

let tail:string[] = [__ci_inline_5];
__ci_inline_2: {
if (void 0 === void 0) {events.push(note,tail[0]||'empty');{ __ci_inline_1 = ( typeof value==='object'&&value!==null);; break __ci_inline_2; }}
__ci_inline_1 = void 0;
}
}
__ci_inline_14 = ((...__ci_inline_15: unknown[])=>__ci_inline_1) as unknown as typeof __ci_inline_13;
}
const ok=__ci_inline_14(void 0 as never,void 0 as never,void 0 as never);export const observed=[ok,events];
