;
export function run(input:unknown){{
if (void 0 !== void 0) {
var __ci_inline_4 = function(value:unknown):asserts value is string{if(typeof value!=='string')throw Error('owned refusal');};void __ci_inline_4;
}
let __ci_inline_5: typeof __ci_inline_4;
let __ci_inline_1: (void) | undefined;
{
const __ci_inline_3 = (input);

{
let value:unknown = __ci_inline_3;
{
if (void 0 === void 0) {if(typeof value!=='string')throw Error('owned refusal');}
__ci_inline_1 = void 0;
}
}
__ci_inline_5 = ((...__ci_inline_6: unknown[])=>__ci_inline_1) as unknown as typeof __ci_inline_4;
}
__ci_inline_5(input);
}return input.length;}
let error='';try{run(7);}catch(e){error=e instanceof Error?e.message:'unknown';}
export const observed=[run('owned'),error];
