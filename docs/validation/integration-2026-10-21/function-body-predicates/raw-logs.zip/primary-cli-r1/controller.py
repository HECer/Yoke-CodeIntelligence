from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,tempfile,time,_winapi,sys,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');aux=w.parent/'Yoke-CI-r1-predicates';raw=w/'validation/integration-20261018/r1-predicate-contexts';out=raw/sys.argv[1];out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';node=Path(r'C:\Program Files\nodejs\node.exe');typescript=w/'node_modules/typescript/lib/typescript.js';tsc=typescript.with_name('tsc.js');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((raw/sys.argv[2]/'result.json').read_text());assert proof['allChecksPassed'] and proof['sourceUnchanged'] and sha(native)==proof['cliSha256']
validated=json.loads((raw/sys.argv[2]/'source-after.json').read_text());source_tree=w if sys.argv[3]=='primary' else aux
assert all(sha(source_tree/n)==h for n,h in validated.items())
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-predicate-cli-'));client=jobroot/'unused-client.exe';configroot=jobroot;cwd=jobroot
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','roaming'),('LOCALAPPDATA','local'),('TEMP','tmp'),('TMP','tmp')]:
    p=jobroot/name;p.mkdir(exist_ok=True);env[key]=str(p)
env.update({'CI':'1','NO_COLOR':'1'})
reviewed=Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py';text=reviewed.read_text();runner=text[text.index("k=ctypes.WinDLL("):text.index("result={'fixtureRoot'")]
original_runner_hash=hashlib.sha256(runner.encode()).hexdigest();assert original_runner_hash=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5'
runner=runner.replace('print(json.dumps(row),flush=True)',"print(name+': exit='+str(row.get('exitCode'))+', jobActive='+str(row['activeAfterCleanup']),flush=True)")
(out/'reviewed-runner.py').write_text(runner,encoding='utf-8');exec(compile(runner,str(reviewed)+'[reviewed runner; print-only change]','exec'))
cases=[
 ('predicate',"function helper(value:unknown):value is string{return typeof value==='string';}\nexport function run(input:unknown){const ok=helper(input);return ok?input.length:0;}\nexport const observed=[run('owned'),run(7)];\n"),
 ('inferred',"function helper(value:unknown){return typeof value==='string';}\nexport function run(input:unknown){const ok=helper(input);return ok?input.length:0;}\nexport const observed=[run('owned'),run(7)];\n"),
 ('assertion',"function helper(value:unknown):asserts value is string{if(typeof value!=='string')throw Error('owned refusal');}\nexport function run(input:unknown){helper(input);return input.length;}\nlet error='';try{run(7);}catch(e){error=e instanceof Error?e.message:'unknown';}\nexport const observed=[run('owned'),error];\n"),
 ('dense-getter',"const events:string[]=[];function mark(tag:string){events.push(tag);return tag;}\nconst box={get value(){events.push('getter');return {n:3};}};\nfunction helper(note:string,value:unknown,...tail:string[]):value is {n:number}{events.push(note,tail[0]||'empty');return typeof value==='object'&&value!==null;}\nconst ok=helper(mark('first'),box.value,mark('last'));export const observed=[ok,events];\n"),
]
case_results=[];tools_before={str(p):sha(p) for p in [native,node,typescript,tsc]}
host=jobroot/'host';host.mkdir();profile=host/'host.json';profile.write_text(json.dumps({'inlineCompiler':{'node':str(node),'typescript':str(typescript),'trusted':True}}))
result={'fixtureRoot':str(jobroot),'cliSha256':sha(native),'sourceGuard':str(raw/sys.argv[2]/'result.json'),'validatedInputs':len(validated),'reviewedRunnerSourceSha256':original_runner_hash,'runnerChanges':'Only progress printing; exact commands remain in progress.json','analyzedSourceExecuted':False,'ownedLiteralRuntimeOraclesExecuted':True,'modelRequested':False,'systemSettingsChanged':False}
try:
    for index,(label,source) in enumerate(cases):
        root=jobroot/(str(index)+" source ' \u03c0");root.mkdir();cwd=root
        file=root/'main.ts';before=source.encode();file.write_bytes(before)
        config=root/'tsconfig.json';config_bytes=(json.dumps({'compilerOptions':{'strict':True,'target':'ES2022','module':'ESNext','moduleResolution':'Bundler','noEmit':True,'noUnusedLocals':True,'noUnusedParameters':True,'allowUnreachableCode':False,'allowUnusedLabels':False,'exactOptionalPropertyTypes':True,'noUncheckedIndexedAccess':True},'files':['main.ts']})+'\n').encode();config.write_bytes(config_bytes)
        requests=host/(label+'.requests.json');requests.write_text(json.dumps([{'operation':'refactor.prepare','args':{'operation':'inline','arguments':{'relativePath':'main.ts','namePath':'helper','keepDefinition':False}}}]))
        common=[native,'--root',root,'--timeout','60000','--max-bytes','4000000']
        prepared=run(label+'.prepare',[*common,'session','--id','owned-predicate','--host-profile',profile,'--requests',requests]);prepared_value=json.loads(prepared);report=prepared_value['results'][0]
        assert report['sourceExecuted'] is False and report['complete'] is False and report['verificationRequired'] is True
        assert report['actions'][0]['kind']=='native.inline.function.body';plan=report['actions'][0]['plan']['id'];assert file.read_bytes()==before
        run(label+'.unverified',[*common,'--allow-writes','apply',plan,'--key','owned-before-verification','--mode','workspace'],expected=None);assert rows[-1]['exitCode']!=0 and file.read_bytes()==before
        verification=json.loads(run(label+'.verify',[*common,'verify','--plan',plan,'--trust-project','--command',node,'--arg='+str(tsc),'--arg=--noEmit'],timeout=65));assert verification['status']=='passed' and file.read_bytes()==before
        run(label+'.unapproved',[*common,'--allow-writes','apply',plan,'--key','owned-before-approval','--mode','workspace'],expected=None);assert rows[-1]['exitCode']!=0 and file.read_bytes()==before
        run(label+'.approve',[*common,'approve',plan]);applied=json.loads(run(label+'.apply',[*common,'--allow-writes','apply',plan,'--key','owned-approved-verified','--mode','workspace']));assert applied['status']=='ok'
        after=file.read_bytes();assert after!=before;receipt=applied['data']['receipt']['id'];(out/(label+'.after.ts')).write_bytes(after)
        oracle="const ts=require("+json.dumps(str(typescript))+"),vm=require('node:vm');function read(s){const code=ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText;const context={exports:{}};vm.runInNewContext(code,context,{timeout:1000});return JSON.stringify(context.exports.observed);}const before=read("+json.dumps(source)+"),after=read("+json.dumps(after.decode())+");if(before!==after)throw Error('owned predicate observations changed');process.stdout.write(JSON.stringify({before,after,equal:true}));"
        oracle_file=host/(label+'.oracle.cjs');oracle_file.write_text(oracle,encoding='utf-8');observation=json.loads(run(label+'.runtime',[node,oracle_file]));assert observation['equal']
        foreign=b'// owned foreign writer control\r\n';file.write_bytes(foreign);run(label+'.foreign-recovery',[*common,'--allow-writes','recover',receipt],expected=None);assert rows[-1]['exitCode']!=0 and file.read_bytes()==foreign
        file.write_bytes(after);run(label+'.recover',[*common,'--allow-writes','recover',receipt]);assert file.read_bytes()==before and config.read_bytes()==config_bytes
        case_results.append({'label':label,'planId':plan,'receiptId':receipt,'originalSha256':hashlib.sha256(before).hexdigest(),'derivedSha256':hashlib.sha256(after).hexdigest(),'unverifiedApplyRefused':True,'unapprovedApplyRefused':True,'independentTscPassed':True,'ownedRuntimeObservation':observation,'foreignRecoveryRefusedAndPreserved':True,'conditionalInverseRestoredOriginalBytes':True,'configurationUnchanged':True})
    assert all(sha(Path(p))==h for p,h in tools_before.items()) and all(sha(source_tree/n)==h for n,h in validated.items())
    result.update(completed=True,sourceInputsUnchanged=True,toolsUnchanged=True)
except BaseException as error:
    result.update(completed=False,errorType=type(error).__name__,error=str(error));raise
finally:
    result.update(commands=rows,cases=case_results,allProcessJobsEmpty=all(row['activeAfterCleanup']==0 and row['assignedBeforeResume'] for row in rows))
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['commands','cases']}),flush=True)
