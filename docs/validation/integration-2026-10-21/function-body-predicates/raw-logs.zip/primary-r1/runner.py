from pathlib import Path
import subprocess,json,hashlib,time,sys,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018/r1-predicate-contexts';secondary=json.loads((raw/sys.argv[1]/'result.json').read_text());assert secondary['allChecksPassed'] and secondary['sourceUnchanged']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
validated=json.loads((raw/sys.argv[1]/'source-after.json').read_text());assert all(sha(w/n)==h for n,h in validated.items())
out=raw/sys.argv[2];out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'runner.py')
def inventory():return {n:sha(w/n) for n in validated}
before=inventory();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');cargo=str(Path.home()/'.cargo/bin/cargo.exe')
commands=[('fmt',[cargo,'fmt','--all','--','--check']),('build',[cargo,'build','--workspace','--locked','-j','2','--target-dir',str(w/'target'),'--bin','yoke','--message-format=json-render-diagnostics']),('typecheck',['cmd.exe','/d','/c','npm.cmd','run','typecheck']),('retained',['cmd.exe','/d','/c','npm.cmd','test'])];rows=[]
for name,cmd in commands:
    assert inventory()==before and shutil.disk_usage(w/'target').free>700*1024*1024
    print('PRIMARY PREDICATE CONTEXTS',name,flush=True);start=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:p=subprocess.run(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT)
    row={'name':name,'command':cmd,'exitCode':p.returncode,'seconds':round(time.monotonic()-start,3),'sourceUnchanged':inventory()==before}
    if name=='build' and p.returncode==0:
        artifacts=[]
        for line in (out/'build.log').read_text(encoding='utf-8').splitlines():
            try:v=json.loads(line)
            except json.JSONDecodeError:continue
            if v.get('reason')=='compiler-artifact' and Path(v['target']['src_path']).resolve().is_relative_to((w/'native').resolve()):artifacts.append({'target':v['target']['name'],'kind':v['target']['kind'],'srcPath':v['target']['src_path'],'packageId':v['package_id'],'fresh':v['fresh']})
        assert any(a['kind']==['lib'] for a in artifacts) and any(a['kind']==['bin'] for a in artifacts);row['primaryPackageArtifacts']=artifacts
    rows.append(row);(out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    if p.returncode or not row['sourceUnchanged']:break
after=inventory();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');result={'sourceRoot':str(w),'checks':rows,'sourceUnchanged':before==after,'allChecksPassed':len(rows)==len(commands) and all(r['exitCode']==0 and r['sourceUnchanged'] for r in rows),'allAuxiliaryValidatedInputsByteExact':True,'validatedInputCount':len(validated),'secondaryGuard':str(raw/sys.argv[1]/'result.json'),'rustTestsRepeated':False,'reason':'All validated inputs byte-exact after integration; primary build and actual CLI separately pin executable origin','cliSha256':sha(w/'target/debug/yoke.exe'),'fullStatusCertified':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'}),flush=True);sys.exit(0 if result['allChecksPassed'] else 1)
