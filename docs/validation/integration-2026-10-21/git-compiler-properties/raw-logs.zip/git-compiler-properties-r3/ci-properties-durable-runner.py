from pathlib import Path
import os,sys,json,subprocess,time,hashlib,traceback
p=Path(os.environ['TEMP']);w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018'
marker=p/'ci-properties-r3-terminal.json';assert not marker.exists()
manifest=json.loads((raw/'git-compiler-properties-r2/source-before.json').read_bytes());sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();assert all(sha(w/n)==h for n,h in manifest.items())
(raw/'git-compiler-properties-r2/interrupted.json').write_text(json.dumps({'status':'interrupted','exitCode':None,'terminalGuardResultAbsent':not(raw/'git-compiler-properties-r2/result.json').exists(),'sourceInputsUnchanged':len(manifest),'noMatchingCargoRustOrControllerProcessAtRestart':True,'reason':'Tool handle unknown and authoritative process inventory has no owned validator, Cargo, rustc or test executable. No test result claimed.'},indent=2)+'\n')
source=p/'ci-properties-final.py';controller=p/'ci-properties-final-r3.py';controller.write_text(source.read_text(encoding='utf8').replace('git-compiler-properties-r2','git-compiler-properties-r3'),encoding='utf8')
(p/'ci-properties-r3-owner.json').write_text(json.dumps({'pid':os.getpid(),'startedUnix':time.time(),'controller':str(controller),'sourceInputs':len(manifest)},indent=2)+'\n')
start=time.monotonic()
try:
 with (p/'ci-properties-r3-controller.stdout').open('wb') as stdout,(p/'ci-properties-r3-controller.stderr').open('wb') as stderr:
  child=subprocess.Popen([sys.executable,'-u',str(controller)],cwd=w,stdout=stdout,stderr=stderr)
  (p/'ci-properties-r3-child.json').write_text(json.dumps({'pid':child.pid,'parent':os.getpid(),'startedUnix':time.time()},indent=2)+'\n');code=child.wait()
 result={'terminal':True,'exitCode':code,'seconds':round(time.monotonic()-start,3),'guardComplete':(raw/'git-compiler-properties-r3/result.json').exists()}
except BaseException:
 result={'terminal':True,'exitCode':1,'seconds':round(time.monotonic()-start,3),'exception':traceback.format_exc()}
temporary=marker.with_suffix('.tmp');temporary.write_text(json.dumps(result,indent=2)+'\n');temporary.replace(marker)
