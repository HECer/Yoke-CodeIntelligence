'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const sha=v=>crypto.createHash('sha256').update(v).digest('hex');
const assert=(ok,message)=>{if(!ok)throw new Error(message);};
function boundedRead(file,limit){
 const fd=fs.openSync(file,'r'),chunks=[];let total=0;
 try{const buffer=Buffer.alloc(65536);for(;;){const count=fs.readSync(fd,buffer,0,buffer.length,null);if(!count)break;total+=count;assert(total<=limit,'Trusted compiler file capacity');chunks.push(Buffer.from(buffer.subarray(0,count)));}return Buffer.concat(chunks,total);}finally{fs.closeSync(fd);}
}
let raw=Buffer.alloc(0);
process.stdin.on('data',chunk=>{raw=Buffer.concat([raw,chunk]);assert(raw.length<=16_000_000,'Compiler input bound');});
process.stdin.on('end',()=>{try{process.stdout.write(JSON.stringify(run(JSON.parse(raw.toString('utf8')))));}catch(error){process.stderr.write(String(error.message).slice(0,2000));process.exitCode=1;}});
function run(input){
 const compilerHash=sha(boundedRead(input.compiler,16_000_000));
 const ts=require(input.compiler);
 assert(ts.version==='5.8.3' && typeof ts.matchFiles==='function','Unsupported host TypeScript version');
 assert(input.schema===1 && ['analyze','build','inline','move','inlineBody','hierarchy'].includes(input.operation),'Compiler request contract');
 const slash=p=>p.replaceAll('\\','/'),root=slash(path.resolve(process.cwd(),'virtual'));
 const library=slash(path.dirname(ts.getDefaultLibFilePath({target:ts.ScriptTarget.ES2022})));
 const abs=p=>slash(path.resolve(root,p));
 const rel=p=>{const r=slash(path.relative(root,path.resolve(p)));return !r||r==='..'||r.startsWith('../')||path.isAbsolute(r)?undefined:r;};
 const source=new Map(Object.entries(input.contents).map(([p,t])=>[abs(p),t])),outputs=new Map(),libCache=new Map();
 let directories=new Map(),dirty=true,outputBytes=0;
 const rebuild=()=>{
  if(!dirty)return;directories=new Map([[root,{files:new Set(),directories:new Set()}]]);
  for(const file of [...source.keys(),...[...outputs.keys()].map(abs)]){
   let child=file,dir=slash(path.dirname(child)),isFile=true;
   while(dir===root||dir.startsWith(root+'/')){
    const entry=directories.get(dir)||{files:new Set(),directories:new Set()};
    (isFile?entry.files:entry.directories).add(path.basename(child));directories.set(dir,entry);
    if(dir===root)break;child=dir;dir=slash(path.dirname(child));isFile=false;
   }
  }dirty=false;
 };
 const read=p=>{
  const file=slash(path.resolve(p));if(source.has(file))return source.get(file);
  const r=rel(file);if(r&&outputs.has(r))return outputs.get(r);
  // Never fall through to the repository or arbitrary host files.
  if(slash(path.dirname(file))!==library||!/^lib(?:\.[a-z0-9.-]+)?\.d\.ts$/i.test(path.basename(file)))return undefined;
  if(!libCache.has(file)){try{const data=boundedRead(file,4_000_000).toString('utf8');libCache.set(file,data);}catch(error){if(error.code==='ENOENT')libCache.set(file,undefined);else throw error;}}
  return libCache.get(file);
 };
 const fileExists=p=>read(p)!==undefined;
 const directoryExists=p=>{rebuild();return directories.has(slash(path.resolve(p)))||slash(path.resolve(p))===library;};
 const getDirectories=p=>{rebuild();return [...(directories.get(slash(path.resolve(p)))?.directories||[])].sort();};
 const readDirectory=(p,extensions,excludes,includes,depth)=>{rebuild();return ts.matchFiles(slash(path.resolve(p)),extensions,excludes,includes,true,root,depth,dir=>{const e=directories.get(slash(path.resolve(dir)));return{files:[...(e?.files||[])].sort(),directories:[...(e?.directories||[])].sort()};},p=>slash(path.resolve(p)));};
 const limitations=[],diagnostics=[],projects=new Map();
 const span=(sf,start,end)=>({path:rel(sf.fileName),startByte:Buffer.byteLength(sf.text.slice(0,start)),endByte:Buffer.byteLength(sf.text.slice(0,end)),text:sf.text.slice(start,end)});
 const diagnostic=(d,config)=>{
  const value={config,code:d.code,severity:d.category===ts.DiagnosticCategory.Error?'error':'warning',message:ts.flattenDiagnosticMessageText(d.messageText,'\n').replaceAll(root,'[snapshot]').slice(0,8000)};
  if(d.file&&rel(d.file.fileName)&&source.has(slash(path.resolve(d.file.fileName))))Object.assign(value,span(d.file,d.start||0,(d.start||0)+(d.length||0)));
  else value.path=config;return value;
 };
 const problem=(config,code,message)=>({config,path:config,code,severity:'error',message});
 const names=Object.keys(input.contents).filter(p=>!p.split('/').includes('node_modules')&&/(?:^|\/)(?:tsconfig|jsconfig)\.json$/.test(p)).filter(p=>!p.endsWith('jsconfig.json')||!source.has(abs(p.slice(0,-13)+'tsconfig.json'))).sort();
 const queue=[...names];
 for(let i=0;i<queue.length;i++){
  const name=queue[i];if(projects.has(name))continue;assert(projects.size<128,'Compiler project capacity');
  const errors=[];
  const parsed=ts.getParsedCommandLineOfConfigFile(abs(name),{},{useCaseSensitiveFileNames:true,getCurrentDirectory:()=>root,fileExists,readFile:read,readDirectory,onUnRecoverableConfigFileDiagnostic:d=>errors.push(d)})||{fileNames:[],options:{},errors:[]};
  errors.push(...parsed.errors);const p={name,parsed,problems:errors.map(d=>diagnostic(d,name))};projects.set(name,p);
  if(parsed.options.plugins?.length)limitations.push(name+': compiler plugins are not loaded.');
  parsed.projectReferences=(parsed.projectReferences||[]).filter(ref=>{
   const target=rel(/\.json$/i.test(ref.path)?ref.path:path.resolve(ref.path,'tsconfig.json'));
   if(!target||!source.has(abs(target))){p.problems.push(problem(name,'YOKE_REFERENCE_UNAVAILABLE','Referenced project is outside the immutable snapshot or missing.'));return false;}
   ref.path=abs(target);queue.push(target);return true;
  });
 }
 const active=new Set(),done=new Set();
 const visit=name=>{
  if(done.has(name))return;active.add(name);const p=projects.get(name);
  p.parsed.projectReferences=(p.parsed.projectReferences||[]).filter(ref=>{const target=rel(ref.path);if(active.has(target)){p.problems.push(problem(name,'YOKE_REFERENCE_CYCLE','Circular project reference: '+target));return false;}visit(target);return true;});
  active.delete(name);done.add(name);
 };
 for(const name of projects.keys())visit(name);
 if(input.operation==='inline')return inlineVariable({input,ts,sha,assert,source,projects,read,fileExists,directoryExists,getDirectories,readDirectory,root,abs,rel,slash,span,diagnostic,libCache,compilerHash,limitations});
 if(input.operation==='inlineBody')return inlineFunctionBody({input,ts,sha,assert,source,projects,read,fileExists,directoryExists,getDirectories,readDirectory,root,abs,rel,slash,span,diagnostic,libCache,compilerHash,limitations});
 if(input.operation==='move')return moveSymbolToFile({input,ts,sha,assert,source,projects,read,fileExists,directoryExists,getDirectories,readDirectory,root,abs,rel,slash,span,diagnostic,libCache,compilerHash,limitations});
 const contexts=[];let status='passed',exitCode=null;
 if(input.operation==='analyze'||input.operation==='hierarchy'){
  if(!projects.size){limitations.push('No configured project: inferred context is nonexhaustive.');projects.set('[inferred]',{name:'[inferred]',problems:[],parsed:{fileNames:[...source.keys()].filter(p=>/\.[cm]?[jt]sx?$/.test(p)),options:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,moduleResolution:ts.ModuleResolutionKind.Bundler,allowJs:true,checkJs:true,jsx:ts.JsxEmit.Preserve,noEmit:true},projectReferences:[]}});}
  let count=0;
  for(const p of projects.values()){
   const host=ts.createCompilerHost(p.parsed.options,true);
   host.useSourceOfProjectReferenceRedirect=()=>true;
   Object.assign(host,{readFile:read,fileExists,directoryExists,getDirectories,readDirectory,getCurrentDirectory:()=>root,getCanonicalFileName:p=>slash(path.resolve(p)),realpath:p=>slash(path.resolve(p)),useCaseSensitiveFileNames:()=>true,writeFile:()=>{throw new Error('Analysis cannot emit');},getSourceFile:(file,version)=>{const text=read(file);return text===undefined?undefined:ts.createSourceFile(file,text,version,true);}});
   const program=ts.createProgram({rootNames:p.parsed.fileNames,options:{...p.parsed.options,noEmit:true},projectReferences:p.parsed.projectReferences,host});
   const checker=program.getTypeChecker(),errors=[...p.problems,...ts.getPreEmitDiagnostics(program).map(d=>diagnostic(d,p.name))];diagnostics.push(...errors);
   const bindings=[];
   for(const sf of program.getSourceFiles()){
    if(!source.has(slash(path.resolve(sf.fileName))))continue;
    const walk=node=>{
     assert(++count<=500_000,'Compiler AST capacity');
     if(ts.isIdentifier(node)){
      let symbol=checker.getSymbolAtLocation(node);if(symbol?.flags&ts.SymbolFlags.Alias)symbol=checker.getAliasedSymbol(symbol);
      const definitions=[];
      for(const declaration of symbol?.declarations||[]){
       const target=declaration.getSourceFile();if(!source.has(slash(path.resolve(target.fileName))))continue;
       const named=declaration.name&&typeof declaration.name.getStart==='function'?declaration.name:declaration;
       definitions.push(span(target,named.getStart(target),named.getEnd()));
      }
      bindings.push({...span(sf,node.getStart(sf),node.getEnd()),type:checker.typeToString(checker.getTypeAtLocation(node)).replaceAll(root,'[snapshot]').slice(0,2000),definitions});
      assert(bindings.length<=100_000,'Compiler binding capacity');
     }ts.forEachChild(node,walk);
    };walk(sf);
   }
   const options=JSON.parse(JSON.stringify(p.parsed.options,(key,value)=>key==='configFile'?undefined:typeof value==='string'?value.replaceAll(root,'[snapshot]'):value));
   const files=p.parsed.fileNames.map(rel).filter(Boolean).sort();
   const libraries=Object.fromEntries(program.getSourceFiles().filter(sf=>libCache.has(slash(path.resolve(sf.fileName)))).map(sf=>[path.basename(sf.fileName),sha(sf.text)]).sort(([a],[b])=>a.localeCompare(b)));
   const context={config:p.name,contextId:sha(JSON.stringify([input.snapshotId,p.name,options,files,ts.version,compilerHash,libraries])),options,files,standardLibraryHashes:libraries,status:errors.some(d=>d.severity==='error')?'failed':'passed',diagnostics:errors,bindings};
   if(input.operation==='hierarchy')context.hierarchy=compilerHierarchy({input,ts,checker,program,span,source,slash,rel,root,assert});
   contexts.push(context);
  }
  status=diagnostics.some(d=>d.severity==='error')?'failed':contexts.some(c=>c.files.length)?'passed':'incomplete';
 }else{
  for(const p of projects.values())diagnostics.push(...p.problems);
  if(diagnostics.some(d=>d.severity==='error'))status='failed';
  else if(!projects.size||![...projects.values()].some(p=>p.parsed.fileNames.length))status='incomplete';
  else{
   const local=p=>{const r=rel(p);assert(r,'Build output outside virtual root');return r;};
   const system={args:[],newLine:'\n',useCaseSensitiveFileNames:true,write:()=>{},getCurrentDirectory:()=>root,getExecutingFilePath:()=>input.compiler,readFile:read,fileExists,directoryExists,getDirectories,readDirectory,realpath:p=>slash(path.resolve(p)),createDirectory:p=>{local(p);},writeFile:(file,text)=>{const p=local(file);assert(!source.has(abs(p)),'Build overwrites input');outputBytes-=Buffer.byteLength(outputs.get(p)||'');outputBytes+=Buffer.byteLength(text);assert(outputBytes<=20_000_000&&(outputs.has(p)||outputs.size<20_000),'Build output capacity');outputs.set(p,text);dirty=true;},deleteFile:file=>{const p=local(file);outputBytes-=Buffer.byteLength(outputs.get(p)||'');outputs.delete(p);dirty=true;},getModifiedTime:p=>fileExists(p)?new Date(outputs.has(rel(p))?2000:1000):undefined,setModifiedTime:()=>{},exit:()=>{throw new Error('Compiler process exit denied');}};
   const host=ts.createSolutionBuilderHost(system,undefined,d=>diagnostics.push(diagnostic(d,'[solution-build]')),()=>{},()=>{});
   host.getParsedCommandLine=config=>projects.get(rel(config))?.parsed;
   exitCode=ts.createSolutionBuilder(host,[...projects.keys()].map(abs),{force:true}).build();
   status=exitCode===ts.ExitStatus.Success&&!diagnostics.some(d=>d.severity==='error')?'passed':'failed';
   if(!outputs.size&&status==='passed'){status='incomplete';limitations.push('Solution produced no generated artifacts.');}
  }
 }
 assert(diagnostics.length<=20_000,'Compiler diagnostic capacity');
 const grouped=new Map();
 for(const context of contexts)for(const b of context.bindings){const key=[b.path,b.startByte,b.endByte].join(':');const entries=grouped.get(key)||[];entries.push({contextId:context.contextId,definitions:b.definitions,type:b.type});grouped.set(key,entries);}
 const bindingConflicts=[...grouped].filter(([,entries])=>new Set(entries.map(e=>JSON.stringify([e.definitions,e.type]))).size>1).map(([anchor,contexts])=>({anchor,contexts}));
 limitations.push('Only captured files and trusted standard libraries are visible; unavailable dependencies, dynamic behavior and other build configurations remain outside this report.');
 return{schema:1,operation:input.operation,snapshotId:input.snapshotId,inputHash:process.argv[2],compiler:ts.version,compilerHash,standardLibraryHashes:Object.fromEntries([...libCache].filter(([,text])=>text!==undefined).map(([p,text])=>[path.basename(p),sha(text)]).sort(([a],[b])=>a.localeCompare(b))),sourceBindings:input.sourceBindings,status,exitCode,contexts,diagnostics,bindingConflicts,limitations,outputs:[...outputs].sort(([a],[b])=>a.localeCompare(b)).map(([p,content])=>({path:p,hash:sha(content),bytes:Buffer.byteLength(content),content})),sourceExecuted:false,sourceTreeWritten:false,exhaustive:false};
}

// Own compiler observations over the same immutable program as ordinary analysis.
function compilerHierarchy({input,ts,checker,program,span,source,slash,rel,root,assert}){
 const limits=input.intent;
 for(const [key,max] of [['maxNodes',5000],['maxRelations',20000],['maxPairVisits',200000]])assert(Number.isSafeInteger(limits[key])&&limits[key]>=0&&limits[key]<=max,'Hierarchy capacity contract');
 const nodes=[],relations=[],unavailable=[],unavailableSeen=new Set(),byDecl=new Map(),types=[],calls=[],witnessNodes=new Set(),instances=[],instancesByOwner=new Map(),typesBySymbol=new Map();let ast=0,pairVisits=0,witnessBytes=0;
 const captured=node=>node&&source.has(slash(node.getSourceFile().fileName));
 const isMethod=node=>ts.isMethodDeclaration(node)||ts.isMethodSignature(node);
 const staticMember=node=>!!(ts.getCombinedModifierFlags(node)&ts.ModifierFlags.Static);
 const privateMember=node=>ts.isPrivateIdentifier(node.name)||!!(ts.getCombinedModifierFlags(node)&ts.ModifierFlags.Private);
 function tick(){assert(++pairVisits<=limits.maxPairVisits,'Hierarchy pair capacity');}
 function addNode(node){
  if(!captured(node))return null;
  if(byDecl.has(node))return byDecl.get(node);
  assert(nodes.length<limits.maxNodes,'Hierarchy node capacity');
  const sf=node.getSourceFile(),name=node.name||(ts.isConstructorDeclaration(node)?node.getChildren(node.getSourceFile()).find(token=>token.kind===ts.SyntaxKind.ConstructorKeyword):undefined);
  const declaration=span(sf,ts.isSourceFile(node)?0:node.getStart(sf),node.getEnd());
  const selection=name?span(sf,name.getStart(sf),name.getEnd()):span(sf,declaration.startByte===0?0:node.getStart(sf),declaration.startByte===0?0:node.getStart(sf));
  const id=nodes.length;nodes.push({kind:ts.SyntaxKind[node.kind],name:name?name.getText(sf):ts.isSourceFile(node)?rel(sf.fileName):'(anonymous)',declaration,selection,static:staticMember(node),hasBody:!!node.body});byDecl.set(node,id);return id;
 }
 function unknown(reason,node){const anchor=span(node.getSourceFile(),node.getStart(),node.getEnd()),key=JSON.stringify([reason,anchor.path,anchor.startByte,anchor.endByte]);if(unavailableSeen.has(key))return;assert(unavailable.length<limits.maxRelations,'Hierarchy coverage capacity');unavailableSeen.add(key);unavailable.push({reason,anchor});}
 function edge(relation,from,to,proof,extra={}){
  if(from===null||to===null){unknown('declaration_outside_capture',proof);return;}
  assert(relations.length<limits.maxRelations,'Hierarchy relation capacity');relations.push({relation,source:from,target:to,proof:span(proof.getSourceFile(),proof.getStart(),proof.getEnd()),...extra});
 }
 for(const sf of program.getSourceFiles()){
  if(!source.has(slash(sf.fileName)))continue;
  addNode(sf);
  function walk(node){
   assert(++ast<=500000,'Hierarchy AST capacity');
   if(ts.isClassDeclaration(node)||ts.isInterfaceDeclaration(node)){
    if(node.name){const symbol=checker.getSymbolAtLocation(node.name);if(symbol){const type=checker.getDeclaredTypeOfSymbol(symbol),item={node,symbol,type,id:addNode(node),generic:!!type.typeParameters?.length};types.push(item);if(!typesBySymbol.has(symbol)||ts.isClassDeclaration(node))typesBySymbol.set(symbol,item);}}
    else unknown('anonymous_type_not_enumerated',node);
   }else if(ts.isClassExpression(node))unknown('class_expression_not_enumerated',node);
   if(ts.isFunctionLike(node)&&!ts.isFunctionTypeNode(node))addNode(node);
   if(ts.isCallExpression(node)||ts.isNewExpression(node)||ts.isTaggedTemplateExpression(node))calls.push(node);
   if(ts.isTypeNode(node)||ts.isExpressionWithTypeArguments(node)||ts.isCallExpression(node)||ts.isNewExpression(node)||ts.isTaggedTemplateExpression(node))witnessNodes.add(node);
   if((ts.isVariableDeclaration(node)||ts.isParameter(node)||ts.isPropertyDeclaration(node)||ts.isPropertySignature(node)||ts.isBindingElement(node))&&node.name)witnessNodes.add(node.name);
   ts.forEachChild(node,walk);
  }walk(sf);
 }
 for(const call of calls){const expression=ts.isTaggedTemplateExpression(call)?call.tag:call.expression;if(ts.isPropertyAccessExpression(expression)||ts.isElementAccessExpression(expression))witnessNodes.add(expression.expression);}
 function display(type,node){const text=checker.typeToString(type,node,ts.TypeFormatFlags.NoTruncation|ts.TypeFormatFlags.UseFullyQualifiedType).replaceAll(root,'[snapshot]');assert(text.length&&Buffer.byteLength(text)<=4096,'Hierarchy type display capacity');return text;}
 for(const node of witnessNodes){
  tick();const observed=checker.getTypeAtLocation(node),branches=[observed],recorded=new Map();
  while(branches.length){
   tick();const effective=branches.pop();if(effective.isUnion()){branches.push(...[...effective.types].reverse());continue;}
   const parts=[effective],seenParts=new Set();
   while(parts.length){
    tick();const part=parts.pop();if(seenParts.has(part))continue;seenParts.add(part);
    if(part.isIntersection()){parts.push(...[...part.types].reverse());continue;}
    if(!(part.flags&ts.TypeFlags.Object)||!(part.objectFlags&ts.ObjectFlags.Reference))continue;
    const item=typesBySymbol.get(part.getSymbol());if(!item||!item.generic||!ts.isClassDeclaration(item.node))continue;
    const args=checker.getTypeArguments(part);if(!args.length)continue;
    const seen=recorded.get(effective)||new Set();if(seen.has(part))continue;seen.add(part);recorded.set(effective,seen);
    assert(instances.length<limits.maxNodes&&args.length<=limits.maxNodes,'Hierarchy instance witness capacity');
    const anchor=span(node.getSourceFile(),node.getStart(),node.getEnd());
    const raw={owner:item.id,typeDisplay:display(effective,node),classTypeDisplay:display(part,node),observedTypeDisplay:display(observed,node),arguments:args.map(arg=>{tick();assert(Number.isSafeInteger(arg.flags)&&arg.flags>=0&&arg.flags<=4294967295,'Hierarchy type flags');return{display:display(arg,node),flags:arg.flags};}),anchor,syntaxKind:ts.SyntaxKind[node.kind]};
    witnessBytes+=Buffer.byteLength(JSON.stringify(raw));assert(witnessBytes<=4000000,'Hierarchy instance witness byte capacity');
    const id=instances.length;instances.push(raw);const list=instancesByOwner.get(item.id)||[];list.push({id,type:effective});instancesByOwner.set(item.id,list);
   }
  }
 }
 for(const item of types)if(item.generic&&ts.isClassDeclaration(item.node))unknown('unobserved_generic_instantiations_not_enumerated',item.node);
 for(const item of types){
  for(const member of item.node.members){
   if(isMethod(member))edge('declaresMember',item.id,addNode(member),member.name);
   else if(ts.isConstructorDeclaration(member))edge('declaresMember',item.id,addNode(member),member);
   else if(member.name)unknown('non_method_member_not_override_enumerated',member);
  }
  for(const clause of item.node.heritageClauses||[])for(const heritage of clause.types){
   tick();const baseType=checker.getTypeAtLocation(heritage);let symbol=baseType.getSymbol()||baseType.aliasSymbol;
   if(symbol?.flags&ts.SymbolFlags.Alias)symbol=checker.getAliasedSymbol(symbol);
   const declarations=(symbol?.declarations||[]).filter(d=>ts.isClassDeclaration(d)||ts.isInterfaceDeclaration(d));
   if(!declarations.length)unknown('heritage_type_not_captured_declaration',heritage);
   const implementing=clause.token===ts.SyntaxKind.ImplementsKeyword;
   for(const base of declarations)edge(implementing?'implements':'extends',item.id,addNode(base),heritage);
   for(const member of item.node.members){
    if(!isMethod(member))continue;
    if(privateMember(member)){unknown('private_member_not_override_enumerated',member);continue;}
    const own=checker.getSymbolAtLocation(member.name);if(!own)continue;
    const baseObject=staticMember(member)&&symbol?checker.getTypeOfSymbolAtLocation(symbol,heritage):baseType;
    const inherited=checker.getPropertyOfType(baseObject,own.getName());
    for(const target of inherited?.declarations||[]){
     tick();if(!isMethod(target)||staticMember(target)!==staticMember(member)||privateMember(target))continue;
     edge(implementing||ts.isInterfaceDeclaration(target.parent)?'implementsMember':'overrides',addNode(member),addNode(target),heritage,{owner:item.id});
    }
   }
  }
 }
 for(const [declaration,id] of [...byDecl]){
  if((isMethod(declaration)||ts.isFunctionDeclaration(declaration))&&!declaration.body&&declaration.name){
   const symbol=checker.getSymbolAtLocation(declaration.name);
   for(const implementation of symbol?.declarations||[]){tick();if(implementation!==declaration&&implementation.body&&captured(implementation))edge('signatureImplementation',id,addNode(implementation),declaration.name);}
  }
  if(ts.isConstructorDeclaration(declaration)&&!declaration.body&&declaration.parent.name){
   const symbol=checker.getSymbolAtLocation(declaration.parent.name)?.members?.get(ts.InternalSymbolName.Constructor);
   for(const implementation of symbol?.declarations||[]){tick();if(ts.isConstructorDeclaration(implementation)&&implementation.body&&captured(implementation))edge('signatureImplementation',id,addNode(implementation),declaration,{owner:addNode(declaration.parent)});}
  }
 }
 function fixedClassReference(expression){
  while(ts.isParenthesizedExpression(expression)||ts.isNonNullExpression(expression)||ts.isAsExpression(expression)||ts.isTypeAssertionExpression(expression)||ts.isSatisfiesExpression(expression))expression=expression.expression;
  if(!ts.isIdentifier(expression)&&!ts.isPropertyAccessExpression(expression))return false;
  let symbol=checker.getSymbolAtLocation(expression);if(symbol?.flags&ts.SymbolFlags.Alias)symbol=checker.getAliasedSymbol(symbol);
  return !!(symbol?.flags&ts.SymbolFlags.Class);
 }
 function receiverType(expression,call){
  const type=checker.getNonNullableType(checker.getTypeAtLocation(expression));
  if(type.flags&(ts.TypeFlags.Any|ts.TypeFlags.Unknown|ts.TypeFlags.TypeParameter)){unknown('receiver_type_not_enumerated',call);return null;}return type;
 }
 for(const call of calls){
  const signature=checker.getResolvedSignature(call),target=signature?.declaration;
  let caller=call.parent;while(caller&&!ts.isFunctionLike(caller)&&!ts.isSourceFile(caller))caller=caller.parent;
  const constructing=ts.isNewExpression(call),tagged=ts.isTaggedTemplateExpression(call),expression=tagged?call.tag:call.expression;
  const invocationKind=constructing?'new':tagged?'taggedTemplate':expression.kind===ts.SyntaxKind.SuperKeyword?'super':'call';
  const conditional=!!(ts.isOptionalChain(call)||ts.isOptionalChain(expression)),from=addNode(caller),to=target&&captured(target)?addNode(target):null;
  if(to!==null)edge('calls',from,to,call,{invocationKind,conditional});
  else unknown(constructing&&signature&&!target?'construct_signature_has_no_source_declaration':'call_target_not_captured_declaration',call);
  if(constructing){
   const seen=new Set(),pending=[checker.getTypeAtLocation(call)];let resultTypes=0;
   while(pending.length){
    tick();const type=pending.pop();if(seen.has(type))continue;seen.add(type);
    if(type.isUnionOrIntersection()){pending.push(...type.types);continue;}
    let symbol=type.getSymbol()||type.aliasSymbol;if(symbol?.flags&ts.SymbolFlags.Alias)symbol=checker.getAliasedSymbol(symbol);
    for(const declaration of symbol?.declarations||[]){tick();if(!ts.isClassDeclaration(declaration)||!captured(declaration))continue;resultTypes++;edge('constructResult',from,addNode(declaration),call,{resolvedTarget:to,basis:'compiler_construct_result_type',invocationKind,conditional:false});}
   }
   if(!resultTypes)unknown('construct_result_not_captured_class_type',call);
   if(fixedClassReference(expression))continue;
   const receiver=receiverType(expression,call);if(!receiver)continue;
   for(const candidate of types){
    tick();if(!ts.isClassDeclaration(candidate.node))continue;
    const type=checker.getTypeOfSymbolAtLocation(candidate.symbol,expression);if(!checker.isTypeAssignableTo(type,receiver))continue;
    const signatures=checker.getSignaturesOfType(type,ts.SignatureKind.Construct);
    if(signatures.length)edge('possibleConstructValue',from,candidate.id,call,{resolvedTarget:to,candidateOwner:candidate.id,basis:'compiler_constructor_type_assignability',invocationKind,conditional:false});
    const boundTargets=new Set();
    for(const candidateSignature of signatures){
     tick();const declaration=candidateSignature.declaration;
     if(declaration&&!captured(declaration)){unknown('candidate_constructor_outside_capture',candidate.node);continue;}
     const symbol=declaration&&ts.isConstructorDeclaration(declaration)&&declaration.parent.name?checker.getSymbolAtLocation(declaration.parent.name)?.members?.get(ts.InternalSymbolName.Constructor):undefined;
     const implementation=symbol?.declarations?.find(d=>ts.isConstructorDeclaration(d)&&d.body&&captured(d));
     if(!implementation)unknown(declaration?'candidate_constructor_body_not_captured':'candidate_constructor_has_no_source_declaration',candidate.node);
     const bound=implementation?addNode(implementation):candidate.id;
     if(boundTargets.has(bound))continue;boundTargets.add(bound);
     edge('possibleConstruct',from,bound,call,{resolvedTarget:to,candidateOwner:candidate.id,basis:'compiler_constructor_type_assignability',invocationKind,conditional:false});
    }
   }
   continue;
  }
  if(to===null)continue;
  if(!isMethod(target)||privateMember(target))continue;
  if(!ts.isPropertyAccessExpression(expression)&&!ts.isElementAccessExpression(expression))continue;
  if(expression.expression.kind===ts.SyntaxKind.SuperKeyword)continue;
  if(fixedClassReference(expression.expression))continue;
  const receiver=receiverType(expression.expression,call);if(!receiver)continue;
  const name=checker.getSymbolAtLocation(target.name)?.getName();if(!name){unknown('method_symbol_unavailable',call);continue;}
  for(const candidate of types){
   tick();if(!ts.isClassDeclaration(candidate.node))continue;
   const variants=candidate.generic?(instancesByOwner.get(candidate.id)||[]).map(w=>[false,w.type,'compiler_captured_instance_assignability',w.id]):[[false,candidate.type,'compiler_type_assignability',undefined]];
   variants.push([true,checker.getTypeOfSymbolAtLocation(candidate.symbol,expression),'compiler_constructor_type_assignability',undefined]);
   for(const [staticSide,type,basis,candidateInstance] of variants){
    tick();
    if(!checker.isTypeAssignableTo(type,receiver))continue;
    const property=checker.getPropertyOfType(type,name);
    for(const declaration of property?.declarations||[]){
     tick();if(!ts.isMethodDeclaration(declaration)||!declaration.body||staticMember(declaration)!==staticSide||privateMember(declaration)||(declaration===target&&candidateInstance===undefined))continue;
     edge('possibleDispatch',from,addNode(declaration),call,{resolvedTarget:to,candidateOwner:candidate.id,basis,invocationKind,conditional,...(candidateInstance===undefined?{}:{candidateInstance})});
    }
   }
  }
 }
 compilerProperties({ts,checker,program,source,slash,types,instancesByOwner,addNode,edge,unknown,tick,captured,staticMember,privateMember,fixedClassReference});
 return{schema:1,nodes,instances,relations,unavailable,pairVisits,astNodes:ast,complete:false,runtimeDispatchEstablished:false};
}

// Source-bound property slots and accessor effects, never runtime value inference.
function compilerProperties({ts,checker,program,source,slash,types,instancesByOwner,addNode,edge,unknown,tick,captured,staticMember,privateMember,fixedClassReference}){
 const property=node=>ts.isPropertyDeclaration(node)||ts.isPropertySignature(node)||ts.isGetAccessor(node)||ts.isSetAccessor(node)||ts.isMethodDeclaration(node)||ts.isMethodSignature(node)||(ts.isParameter(node)&&ts.isParameterPropertyDeclaration(node,node.parent));
 const unwrap=node=>{while(ts.isParenthesizedExpression(node)||ts.isNonNullExpression(node)||ts.isAsExpression(node)||ts.isTypeAssertionExpression(node)||ts.isSatisfiesExpression(node))node=node.expression;return node;};
 function byIdentity(type,name){for(const symbol of checker.getPropertiesOfType(type)){tick();if(symbol.escapedName===name)return symbol;}return undefined;}
 function mode(node){
  let current=node;
  for(;;){
   const parent=current.parent;if(!parent)return['read',false];
   if((ts.isParenthesizedExpression(parent)||ts.isNonNullExpression(parent)||ts.isAsExpression(parent)||ts.isTypeAssertionExpression(parent)||ts.isSatisfiesExpression(parent))&&parent.expression===current){current=parent;continue;}
   if(ts.isDeleteExpression(parent))return['delete',false];
   if((ts.isPrefixUnaryExpression(parent)||ts.isPostfixUnaryExpression(parent))&&(parent.operator===ts.SyntaxKind.PlusPlusToken||parent.operator===ts.SyntaxKind.MinusMinusToken))return['readWrite',false];
   if(ts.isBinaryExpression(parent)&&parent.left===current){const op=parent.operatorToken.kind;if(op===ts.SyntaxKind.EqualsToken)return['write',false];if(op>=ts.SyntaxKind.FirstCompoundAssignment&&op<=ts.SyntaxKind.LastCompoundAssignment)return['readWrite',[ts.SyntaxKind.BarBarEqualsToken,ts.SyntaxKind.AmpersandAmpersandEqualsToken,ts.SyntaxKind.QuestionQuestionEqualsToken].includes(op)];}
   if((ts.isForInStatement(parent)||ts.isForOfStatement(parent))&&parent.initializer===current)return['write',false];
   if(ts.isArrayLiteralExpression(parent)||ts.isObjectLiteralExpression(parent)||(ts.isPropertyAssignment(parent)&&parent.initializer===current)||ts.isSpreadElement(parent)||ts.isSpreadAssignment(parent)){current=parent;continue;}
   return['read',false];
  }
 }
 function symbols(access){
  if(ts.isPropertyAccessExpression(access)){const symbol=checker.getSymbolAtLocation(access.name);return symbol?[symbol]:[];}
  const type=checker.getNonNullableType(checker.getTypeAtLocation(access.expression)),pending=[checker.getTypeAtLocation(access.argumentExpression)],found=new Set();
  while(pending.length){tick();const key=pending.pop();if(key.isUnion()){pending.push(...key.types);continue;}let symbol;if(key.flags&(ts.TypeFlags.StringLiteral|ts.TypeFlags.NumberLiteral))symbol=checker.getPropertyOfType(type,String(key.value));else if(key.flags&ts.TypeFlags.UniqueESSymbol)symbol=byIdentity(type,key.escapedName);else{unknown('property_key_not_finite_compiler_literal',access);continue;}if(symbol)found.add(symbol);}
  return[...found];
 }
 function emit(relation,from,declaration,access,extra){
  edge(relation,from,addNode(declaration),access,extra);
  const read=extra.accessMode==='read'||extra.accessMode==='readWrite',write=extra.accessMode==='write'||extra.accessMode==='readWrite';
  if((ts.isGetAccessor(declaration)&&read)||(ts.isSetAccessor(declaration)&&write)){
   const effect=(relation==='accessesProperty'?'':'possible')+(ts.isGetAccessor(declaration)?(relation==='accessesProperty'?'gets':'Gets'):(relation==='accessesProperty'?'sets':'Sets'));
   edge(effect,from,addNode(declaration),access,extra);
   if(!declaration.body)unknown('accessor_body_not_captured',declaration);
  }
 }
 // Keep original hierarchy node/relation ordering intact; additional facts follow it.
 for(const item of types)for(const member of item.node.members){
  if(!property(member)||ts.isMethodDeclaration(member)||ts.isMethodSignature(member))continue;
  edge('declaresProperty',item.id,addNode(member),member.name);
  const callable=checker.getSignaturesOfType(checker.getTypeAtLocation(member.name),ts.SignatureKind.Call).length>0;
  if(ts.isGetAccessor(member)&&callable)unknown('returned_accessor_function_values_not_enumerated',member);
  if(ts.isPropertyDeclaration(member)&&member.initializer){const initializer=unwrap(member.initializer);if(ts.isArrowFunction(initializer)||ts.isFunctionExpression(initializer))edge('propertyInitializer',addNode(member),addNode(initializer),initializer,{basis:'captured_function_initializer'});else if(callable)unknown('callable_property_initializer_not_direct_function',member);}
  if(ts.getCombinedModifierFlags(member)&ts.ModifierFlags.Accessor)unknown('auto_accessor_implicit_bodies_not_enumerated',member);
 }
 for(const sf of program.getSourceFiles()){
  if(!source.has(slash(sf.fileName)))continue;
  function walk(node){
   // Type queries, computed type keys and annotations are not value evaluations.
   if(ts.isTypeNode(node))return;
   if(ts.isObjectBindingPattern(node)||ts.isArrayBindingPattern(node)||ts.isSpreadAssignment(node)||(ts.isBinaryExpression(node)&&node.operatorToken.kind===ts.SyntaxKind.EqualsToken&&(ts.isObjectLiteralExpression(unwrap(node.left))||ts.isArrayLiteralExpression(unwrap(node.left)))))unknown('implicit_destructuring_or_spread_effects_not_enumerated',node);
   if(ts.isForOfStatement(node))unknown('implicit_iteration_effects_not_enumerated',node);
   if(ts.isPropertyAccessExpression(node)||ts.isElementAccessExpression(node)){
    tick();let caller=node.parent;while(caller&&!ts.isFunctionLike(caller)&&!ts.isSourceFile(caller))caller=caller.parent;
    const from=addNode(caller),[accessMode,writeConditional]=mode(node),conditional=ts.isOptionalChain(node),bound=symbols(node);
    if(!bound.length)unknown('property_symbol_not_captured',node);
    for(const symbol of bound){
     const declarations=(symbol.declarations||[]).filter(property);
     if(!declarations.length)unknown('property_declaration_shape_not_enumerated',node);
     for(const declaration of declarations){
      tick();if(!captured(declaration)){unknown('property_declaration_outside_capture',node);continue;}
      const extra={accessMode,conditional,writeConditional};emit('accessesProperty',from,declaration,node,extra);
      if(privateMember(declaration)||node.expression.kind===ts.SyntaxKind.SuperKeyword||fixedClassReference(node.expression))continue;
      const receiver=checker.getNonNullableType(checker.getTypeAtLocation(node.expression));
      if(receiver.flags&(ts.TypeFlags.Any|ts.TypeFlags.Unknown|ts.TypeFlags.TypeParameter)){unknown('property_receiver_type_not_enumerated',node);continue;}
      for(const candidate of types){
       tick();if(!ts.isClassDeclaration(candidate.node))continue;
       const variants=candidate.generic?(instancesByOwner.get(candidate.id)||[]).map(w=>[false,w.type,'compiler_captured_instance_assignability',w.id]):[[false,candidate.type,'compiler_type_assignability',undefined]];
       variants.push([true,checker.getTypeOfSymbolAtLocation(candidate.symbol,node),'compiler_constructor_type_assignability',undefined]);
       for(const [staticSide,type,basis,candidateInstance] of variants){
        tick();if(!checker.isTypeAssignableTo(type,receiver))continue;
        const selected=byIdentity(type,symbol.escapedName);
        for(const target of selected?.declarations||[]){
         tick();if(!property(target)||!captured(target)||privateMember(target)||staticMember(target)!==staticSide||(target===declaration&&candidateInstance===undefined))continue;
         emit('possiblePropertyAccess',from,target,node,{...extra,resolvedTarget:addNode(declaration),candidateOwner:candidate.id,basis,...(candidateInstance===undefined?{}:{candidateInstance})});
        }
       }
      }
     }
    }
   }
   ts.forEachChild(node,walk);
  }walk(sf);
 }
}
