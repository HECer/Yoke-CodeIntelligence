from pathlib import Path
import os,json,hashlib,subprocess
p=Path(os.environ['TEMP']);w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018'
old=json.loads((raw/'git-compiler-properties-r3/source-before.json').read_bytes());sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();changed={n for n,h in old.items() if sha(w/n)!=h};assert changed=={'native/tests/git_compiler_affected.rs'},changed
# Verify the exact test interposer independently before the Cargo preflight.
lines=(w/'native/tests/git_compiler_affected.rs').read_text(encoding='utf8').splitlines();prefix=json.loads(next(line.strip().removesuffix(',') for line in lines if 'const ts=require({});Object.defineProperty' in line)).replace('{}',json.dumps(str(w/'node_modules/typescript/lib/typescript.js')),1).replace('{{','{');suffix='}}return report;}});module.exports=ts;';mutation="const direct=h.nodes.findIndex(n=>n.name==='direct');h.relations=h.relations.filter(e=>e.relation!=='accessesProperty'||e.source!==direct);";host=p/'ci-properties-forgery-probe-host.cjs';host.write_text(prefix+mutation+suffix,encoding='utf8')
driver="function run(){require("+json.dumps(str(host))+");return {schema:1,operation:'hierarchy',contexts:[{hierarchy:{nodes:[{name:'direct'}],relations:[{relation:'accessesProperty',source:0},{relation:'gets',source:0}]}}]};}process.stdout.write(JSON.stringify(run()));"
result=subprocess.run([r'C:\Program Files\nodejs\node.exe','-e',driver],capture_output=True,timeout=30);out=raw/'git-compiler-properties-probes';(out/'forgery-hook.cjs').write_bytes(host.read_bytes());(out/'forgery-hook-driver.cjs').write_text(driver,encoding='utf8');(out/'forgery-hook.stdout.raw').write_bytes(result.stdout);(out/'forgery-hook.stderr.raw').write_bytes(result.stderr);assert result.returncode==0,result.stderr;assert json.loads(result.stdout)['contexts'][0]['hierarchy']['relations']==[{'relation':'gets','source':0}]
s=(p/'ci-properties-final.py').read_text(encoding='utf8').replace('git-compiler-properties-r2','git-compiler-properties-r4')
anchor="cargo=r'C:\\Users\\Lomi\\.cargo\\bin\\cargo.exe'\n";assert s.count(anchor)==1
extra="""focus_before={q.resolve() for q in (w/'target/debug/deps').iterdir() if q.is_file()}
(out/'before-focus-paths.json').write_text(json.dumps(sorted(map(str,focus_before)),indent=2)+'\\n')
if run('property-forgery-focus',[cargo,'test','--locked','-j','2','--test','git_compiler_affected','forged_property_effects_instances_and_initializer_proofs_refuse_without_state_changes','--','--exact','--test-threads=1']):sys.exit(1)
"""
s=s.replace(anchor,anchor+extra).replace("before={p.resolve() for p in deps.iterdir() if p.is_file()}","before=focus_before if target=='git_compiler_affected' else {p.resolve() for p in deps.iterdir() if p.is_file()}")
(p/'ci-properties-final-r4.py').write_text(s,encoding='utf8')
s=(p/'ci-properties-durable-runner.py').read_text(encoding='utf8');start=s.index('manifest=json.loads(');end=s.index("(p/'ci-properties-r3-owner.json')",start);s=s[:start]+"manifest=json.loads((raw/'git-compiler-properties-r3/source-before.json').read_bytes());controller=p/'ci-properties-final-r4.py'\n"+s[end:];s=s.replace('ci-properties-r3-','ci-properties-r4-').replace('git-compiler-properties-r3/result.json','git-compiler-properties-r4/result.json');(p/'ci-properties-durable-runner-r4.py').write_text(s,encoding='utf8')
for name in ['ci-properties-final-r4.py','ci-properties-durable-runner-r4.py']:compile((p/name).read_text(encoding='utf8'),name,'exec')
print('Exact toJSON forgery hook verified; r4 focus/full frozen guard and durable runner prepared.')
