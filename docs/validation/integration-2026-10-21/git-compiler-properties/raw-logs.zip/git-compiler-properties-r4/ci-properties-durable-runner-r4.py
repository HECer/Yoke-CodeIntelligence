from pathlib import Path
import os,sys,json,subprocess,time,hashlib,traceback
p=Path(os.environ['TEMP']);w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018'
marker=p/'ci-properties-r4-terminal.json';assert not marker.exists()
manifest=json.loads((raw/'git-compiler-properties-r3/source-before.json').read_bytes());controller=p/'ci-properties-final-r4.py'
(p/'ci-properties-r4-owner.json').write_text(json.dumps({'pid':os.getpid(),'startedUnix':time.time(),'controller':str(controller),'sourceInputs':len(manifest)},indent=2)+'\n')
start=time.monotonic()
try:
 with (p/'ci-properties-r4-controller.stdout').open('wb') as stdout,(p/'ci-properties-r4-controller.stderr').open('wb') as stderr:
  child=subprocess.Popen([sys.executable,'-u',str(controller)],cwd=w,stdout=stdout,stderr=stderr)
  (p/'ci-properties-r4-child.json').write_text(json.dumps({'pid':child.pid,'parent':os.getpid(),'startedUnix':time.time()},indent=2)+'\n');code=child.wait()
 result={'terminal':True,'exitCode':code,'seconds':round(time.monotonic()-start,3),'guardComplete':(raw/'git-compiler-properties-r4/result.json').exists()}
except BaseException:
 result={'terminal':True,'exitCode':1,'seconds':round(time.monotonic()-start,3),'exception':traceback.format_exc()}
temporary=marker.with_suffix('.tmp');temporary.write_text(json.dumps(result,indent=2)+'\n');temporary.replace(marker)
