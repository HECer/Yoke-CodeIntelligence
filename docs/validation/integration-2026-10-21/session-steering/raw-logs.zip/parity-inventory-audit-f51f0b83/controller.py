from pathlib import Path
import json,hashlib,subprocess,re
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');load=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();pinned=w/'docs/parity/public-contracts-2026-10-14.json';assert sha(pinned.read_bytes())=='993eb15143bf61a1cf64c80ff53d491ee13f7faeecf2ff4b53a6975de9972c3e';original=load(pinned);tracker=w/'docs/parity/native-reconciliation-2026-10-15.json';current=load(tracker);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip();assert head=='f51f0b8335c0211eb20eed001bca9f9646e7e560';out=w/('validation/integration-20261018/parity-inventory-audit-'+head[:8]);out.mkdir(exist_ok=False)
entries=[(category,row) for category,values in current['inventoryLedger'].items() if isinstance(values,list) for row in values if isinstance(row,dict) and 'ref' in row];assert len(entries)==353 and len({r['ref'] for _,r in entries})==353
def pointer(path):
 value=original
 for key in path.split('/')[1:]:
  key=key.replace('~1','/').replace('~0','~');value=value[int(key)] if isinstance(value,list) else value[key]
 return value
replayed=[]
for category,row in entries:
 value=pointer(row['pointer']);variants=[(ascii,sort) for ascii in [False,True] for sort in [False,True] if sha(json.dumps(value,ensure_ascii=ascii,sort_keys=sort,separators=(',',':')).encode())==row['pinnedEntrySha256']];assert variants,('Original identity mismatch',row['ref']);replayed.append({'ref':row['ref'],'pointer':row['pointer'],'entrySha256':row['pinnedEntrySha256'],'category':category,'assessment':row['assessment'],'fullContractCertification':row['fullContractCertification']})
assert all(r['fullContractCertification'] is False for r in replayed)
paths=subprocess.check_output(['rg','--files','native/src','-g','*.rs'],cwd=w).decode().splitlines();assert len(paths)<=2000;source_bytes=sum((w/name).stat().st_size for name in paths);assert source_bytes<=32000000;sources=[(name.replace('\\','/'),(w/name).read_text(encoding='utf8').splitlines()) for name in paths];rows=[]
for category,row in entries:
 if row['assessment']!='unreconciled_review_required':continue
 value=pointer(row['pointer']);keyword=value if isinstance(value,str) else row['label'];tokens=keyword.split('_');camel=tokens[0]+''.join(p[:1].upper()+p[1:] for p in tokens[1:]);keywords=list(dict.fromkeys([keyword,camel]));hits=[];count=0
 if 3<=len(keyword)<=100:
  for name,lines in sources:
   for number,line in enumerate(lines,1):
    if any(key in line for key in keywords):
     count+=1
     if len(hits)<8:hits.append({'path':name,'line':number})
 rows.append({'ref':row['ref'],'pointer':row['pointer'],'originalValue':value,'entrySha256':row['pinnedEntrySha256'],'evidenceProfile':row.get('evidenceProfile'),'remainingReview':current['ledgerEvidenceProfiles'].get(row.get('evidenceProfile'),{}).get('remainingReview'),'sourceKeywords':keywords,'lexicalSourceMatchCount':count,'firstSourceLocations':hits,'behaviorEstablishedByNameMatches':False,'functionalReview':'pending_exact_behavior_and_acceptance_review'})
assert len(rows)==73
result={'schema':'native_parity_requirement_audit_v1','implementationHead':head,'pinnedInventorySha256':sha(pinned.read_bytes()),'currentTrackerSha256':sha(tracker.read_bytes()),'replayedOriginalIdentities':len(replayed),'allOriginalEntryPinsVerified':True,'allFullCertificationsRemainFalse':True,'unreconciledRows':len(rows),'sourceFileCount':len(paths),'sourceBytes':source_bytes,'lexicalMatchesEstablishBehavior':False,'missingLexicalMatchProvesAbsence':False,'functionalReviewComplete':False,'assessmentsChanged':False,'rows':rows};(out/'original-identities.json').write_text(json.dumps(replayed,ensure_ascii=False,indent=2)+'\n',encoding='utf8');(out/'requirements.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');(out/'controller.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'head':head,'originalIdentityPinsVerified':353,'originalFullCertificationsUnchanged':True,'unreconciledRows':73,'sourceFiles':len(paths),'functionalReviewComplete':False}));print(json.dumps([{'ref':r['ref'],'keywords':r['sourceKeywords'],'lexicalMatches':r['lexicalSourceMatchCount']} for r in rows if ':configuration:' in r['ref']],indent=2))
