from pathlib import Path
import subprocess,json,hashlib,time,sys
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/session-steering-r1';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((w/'validation/integration-20261018/git-compiler-supertype-final/source-before.json').read_bytes());names=set(old)|{'native/src/session_steering.rs','native/tests/session_steering.rs','native/docs/session-steering.md'};inputs={n:sha(w/n) for n in sorted(names)};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');(out/'controller.py').write_bytes(Path(__file__).read_bytes())
assert sha(w/'native/tests/fixtures/postgres-catalog-response.jsonl')=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47'
deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()};start=time.monotonic();argv=[r'C:\Users\Lomi\.cargo\bin\cargo.exe','test','--locked','-j','2','--test','session_steering','--','--test-threads=1']
with (out/'session_steering.stdout').open('wb') as stdout,(out/'session_steering.stderr').open('wb') as stderr:code=subprocess.run(argv,cwd=w,stdout=stdout,stderr=stderr,timeout=1200).returncode
unchanged=all(sha(w/n)==h for n,h in inputs.items());assert unchanged,'Frozen source changed';cleanup=[]
for p in deps.iterdir():
 if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith('session_steering-'):continue
 assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h;p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h})
(out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n');row={'name':'session_steering','argv':argv,'exitCode':code,'seconds':round(time.monotonic()-start,3)};(out/'result.json').write_text(json.dumps({'complete':True,'sourceInputsUnchanged':unchanged,'inputs':len(inputs),'exitCode':code,'rows':[row]},indent=2)+'\n');print(json.dumps(row),flush=True);sys.exit(code)
