from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-steering-legacy-before').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-steering-legacy-');exec(compile(prefix,str(script),'exec'))
assert native_hash=='22b9fa34a454c502974c4ed264cf1d78ec5f1b1d264f91d93c98bb45f6e9187d'
(source/'main.rs').write_text('fn legacy() {}\n');profile=jobroot/'host.json';profile.write_text('{}');requests=jobroot/'requests.json';requests.write_text(json.dumps([{'operation':'configuration','args':{}},{'operation':'initialInstructions','args':{}}]));argv=[native,'--root',source,'--max-bytes','4000000','--timeout','60000','session','--id','legacy','--host-profile',profile,'--requests',requests];raw=run('legacy-before',argv)
files={str(p.relative_to(source)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.rglob('*') if p.is_file()}
(out/'result.json').write_text(json.dumps({'complete':True,'cliSha256':native_hash,'sourceRoot':str(source),'profile':str(profile),'requests':str(requests),'argv':[str(a) for a in argv],'files':files,'commands':rows},indent=2)+'\n')
print('Actual old CLI default-agent output and exact source/Store captured.')
