from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-steering-http-diagnostic').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-http-diagnostic-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';outcomes=[]
for name in ['runtime_host_preflight_never_executes_and_other_profiles_cannot_attach_python','stalled_runtime_initialization_obeys_ttl_and_shutdown_cancellation']:
 try:
  run(name,[r'C:\Users\Lomi\.cargo\bin\cargo.exe','test','--locked','-j','2','--test','mcp_http',name,'--','--exact','--nocapture','--test-threads=1'],expected=None,timeout=45);outcomes.append({'name':name,'row':rows[-1]})
 except BaseException:outcomes.append({'name':name,'exception':traceback.format_exc()})
 (out/'result.json').write_text(json.dumps({'completeDiagnostic':True,'outcomes':outcomes,'commands':rows},indent=2)+'\n')
print(json.dumps(outcomes),flush=True)
