from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,re,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-steering-r4').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-steering-final-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
old=json.loads((w/'validation/integration-20261018/session-steering-r1/source-before.json').read_bytes());inputs={n:sha(w/n) for n in old};assert len(inputs)==1017;(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');assert sha(w/'native/tests/fixtures/postgres-catalog-response.jsonl')=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47'
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';targets=['session_steering','project_session','compatibility','compatibility_review','session_mcp','session_review','session_refactor','session_root_aliases','session_epoch_selection','session_collections','session_collections_admission','agent_memory_namespaces','agent_file_options','agent_repl','agent_repl_lifecycle','mcp_http','mcp_http_review','mcp_http_cli','mcp_collection_grants','mcp_collection_grants_review','resource_paging','parity_retention'];complete=False
prior=w/'validation/integration-20261018/session-steering-r3';prior_result=json.loads((prior/'result.json').read_bytes());assert not prior_result['complete'] and prior_result['sourceInputsUnchanged'] and prior_result['allJobsEmpty'];assert inputs==json.loads((prior/'source-before.json').read_bytes())
completed=[r for r in prior_result['rows'] if r['name'] in targets and r.get('exitCode')==0];assert len(completed)==15
for row in completed:
 for ext in ['stdout','stderr']:shutil.copyfile(prior/(row['name']+'.'+ext),out/(row['name']+'.'+ext))
 rows.append({**row,'reusedCheckedPhase':'session-steering-r3','rerun':False})
direct=w/'validation/integration-20261018/session-steering-http-native-cwd';qualified=json.loads((direct/'result.json').read_bytes());assert qualified['completeDiagnostic'] and qualified['commands'][-1]['exitCode']==0 and qualified['commands'][-1]['activeAfterCleanup']==0;assert sha(w/'target/debug/deps/mcp_http-03d6e783965609de.exe')==qualified['binarySha256'];assert re.search(rb'test result: ok\. 18 passed; 0 failed; 0 ignored;', (direct/'all-tests-native-cwd.stdout').read_bytes())
for ext in ['stdout','stderr']:shutil.copyfile(direct/('all-tests-native-cwd.'+ext),out/('mcp_http.'+ext))
rows.append({**qualified['commands'][-1],'name':'mcp_http','reusedCheckedPhase':'session-steering-http-native-cwd','driver':'exact_test_binary_direct_owned_job','rerun':False})
targets=[name for name in targets if name not in {r['name'] for r in completed} and name!='mcp_http']

try:
 for target in targets:
  deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()}
  run(target,[cargo,'test','--locked','-j','2','--test',target,'--','--nocapture','--test-threads=1'],expected=None,timeout=120 if target=='mcp_http' else 300)
  assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed';cleanup=[]
  for p in deps.iterdir():
   if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(target+'-'):continue
   assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h
   try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':True})
   except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
  (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n');assert rows[-1]['exitCode']==0,(target,rows[-1]['exitCode'])
 for name,argv in [('clippy',[cargo,'clippy','--locked','--all-targets','-j','2','--','-D','warnings']),('fmt',[cargo,'fmt','--all','--check']),('build',[cargo,'build','--locked','-j','2','--bin','yoke']),('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:
  run(name,argv,timeout=600);assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed'
 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'cargoMcpFullInvocationQualified':False,'windowsCargoMcpLaunchIssueRemainsOpen':True,'actual18McpFunctionsPassedDirectUnchangedBinary':True,'targets':targets,'rows':rows},indent=2)+'\n')
assert complete
