from pathlib import Path
import subprocess,json,hashlib,os,time,sys,re,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018';narrow=raw/'session-steering-r1';out=raw/'session-steering-final';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
qualified=json.loads((narrow/'result.json').read_bytes());assert qualified['complete'] and qualified['sourceInputsUnchanged'] and qualified['exitCode']==0
inputs=json.loads((narrow/'source-before.json').read_bytes());assert len(inputs)==1017 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');(out/'controller.py').write_bytes(Path(__file__).read_bytes());rows=[]
for name in ['session_steering.stdout','session_steering.stderr']:shutil.copyfile(narrow/name,out/name);assert (out/name).read_bytes()==(narrow/name).read_bytes()
assert re.search(rb'test result: ok\. 11 passed; 0 failed; 0 ignored;', (narrow/'session_steering.stdout').read_bytes())
for row in qualified['rows']:rows.append({**row,'reusedCheckedPhase':'session-steering-r1','rerun':False})
def run(name,argv):
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:code=subprocess.run(argv,cwd=w,stdout=stdout,stderr=stderr,timeout=1200).returncode
 assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen input changed'
 row={'name':name,'argv':argv,'exitCode':code,'seconds':round(time.monotonic()-start,3)};rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);return code
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe'
for target in ['project_session','compatibility','compatibility_review','session_mcp','session_review','session_refactor','session_root_aliases','session_epoch_selection','session_collections','session_collections_admission','agent_memory_namespaces','agent_file_options','agent_repl','agent_repl_lifecycle','mcp_http','mcp_http_review','mcp_http_cli','mcp_collection_grants','mcp_collection_grants_review','resource_paging','parity_retention']:
 deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()};code=run(target,[cargo,'test','--locked','-j','2','--test',target,'--','--test-threads=1']);cleanup=[]
 for p in deps.iterdir():
  if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(target+'-'):continue
  assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h;p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h})
 (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n')
 if code:sys.exit(code)
for name,argv in [('clippy',[cargo,'clippy','--locked','--all-targets','-j','2','--','-D','warnings']),('fmt',[cargo,'fmt','--all','--check']),('build',[cargo,'build','--locked','-j','2','--bin','yoke']),('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:
 if run(name,argv):sys.exit(1)
(out/'result.json').write_text(json.dumps({'complete':True,'sourceInputsUnchanged':True,'inputs':len(inputs),'reusedSteeringQualificationSameExactInputs':True,'steeringPhase':'session-steering-r1','cliSha256':sha(w/'target/debug/yoke.exe'),'rows':rows},indent=2)+'\n')
