from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,collections
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018';before_dir=raw/'git-compiler-constructor-value-audit';baseline=json.loads((before_dir/'result.json').read_text());old=json.loads((before_dir/'compiler-audit.stdout').read_bytes());assert not baseline['callerReachedFromDerivedClassSeed']
out=raw/'git-compiler-constructor-values-green-r2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');original_query_argv=next(row['command'] for row in baseline['commands'] if row['name']=='compiler-audit');source=Path(original_query_argv[original_query_argv.index('--root')+1]);assert source.name=='source' and source.parent.name.startswith('yoke-owned-ctor-value-audit-') and source.resolve().is_relative_to(Path(os.environ['TEMP']).resolve())
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native);jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-ctor-value-green-'));cwd=jobroot;configroot=jobroot;client='';env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
state=lambda:{p.relative_to(source).as_posix():sha(p) for p in source.rglob('*') if p.is_file()};before=state();original_query_argv[0]=str(native);reply=run('same-report-green',original_query_argv,timeout=90);assert reply==run('same-report-green-repeat',original_query_argv,timeout=90);r=json.loads(reply)
assert r['originalChangedSymbols']==old['originalChangedSymbols'] and r['seedMappings']==old['seedMappings']
def facts(context,exclude_values=False):
 result=[]
 for edge in context['relations']:
  if exclude_values and edge['relation']=='possibleConstructValue':continue
  value=edge.copy();value.pop('id');result.append(json.dumps(value,sort_keys=True))
 return collections.Counter(result)
for side in ['base','head']:
 for key in ['snapshotId','graphHash','sourceBindings','captureOmissions','captureConsistency','compilerHash','standardLibraryHashes']:assert r[side][key]==old[side][key],(side,key)
 assert len(r[side]['contexts'])==len(old[side]['contexts'])
 for current,previous in zip(r[side]['contexts'],old[side]['contexts']):assert current['contextId']==previous['contextId'] and current['nodes']==previous['nodes'] and facts(current,True)==facts(previous)
c=r['head']['contexts'][0];selected=next(n['id'] for n in c['nodes'] if n['name']=='selected');derived=next(n['id'] for n in c['nodes'] if n['name']=='Derived');changed=next(i for i,row in enumerate(r['originalChangedSymbols']) if row['side']=='head' and row['kind']=='class' and row['name']=='Derived');value=next(e for e in c['relations'] if e['relation']=='possibleConstructValue' and e['source']==selected and e['target']==derived)
assert any(s['changedRow']==changed and s['side']=='head' and s['nodeId']==selected for s in r['states']);assert any(p['changedRow']==changed and p['side']=='head' and p['relationId']==value['id'] and p['targetNodeId']==derived for p in r['incomingProofs']);assert state()==before and sha(native)==native_hash
result={'complete':True,'cliSha256':native_hash,'sameOriginalReportAndSeedMappings':True,'sameAllSourceBindingsGraphsNodesAndPriorFacts':True,'repeatedRawBytesExact':True,'callerReachedFromDerivedClassSeed':True,'separateClassValueProofObserved':True,'allOwnedSourceGitStoreBytesUnchanged':True,'runtimeExecutionObserved':False,'commands':rows};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='commands'}))
