from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018/git-compiler-affected-legacy';before=json.loads((raw/'before.json').read_text());out=raw/sys.argv[1];out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native);jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-compiler-legacy-after-'));cwd=jobroot;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
args=before['args'].copy();args[0]=str(native);args[1:1]=['--snapshot',before['snapshotId']];reply=run('legacy-after',args,timeout=60);assert reply==(raw/'legacy-before.stdout').read_bytes();assert sha(native)==native_hash
(out/'result.json').write_text(json.dumps({'legacyRawBytesExact':True,'artifactId':before['artifactId'],'nativeCliSha256':native_hash,'commands':rows},indent=2)+'\n');print(json.dumps({'legacyCompilerRawBytesExact':True,'artifactId':before['artifactId']}))
