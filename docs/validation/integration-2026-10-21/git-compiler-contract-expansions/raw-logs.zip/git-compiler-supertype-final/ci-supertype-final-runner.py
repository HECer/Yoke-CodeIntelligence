from pathlib import Path
import os,sys,json,subprocess,time,traceback
p=Path(os.environ['TEMP']);w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');marker=p/'ci-supertype-final-terminal.json';assert not marker.exists();(p/'ci-supertype-final-owner.json').write_text(json.dumps({'pid':os.getpid(),'startedUnix':time.time()},indent=2)+'\n');start=time.monotonic()
try:
 with (p/'ci-supertype-final-controller.stdout').open('wb') as stdout,(p/'ci-supertype-final-controller.stderr').open('wb') as stderr:
  child=subprocess.Popen([sys.executable,'-u',str(p/'ci-supertype-final.py')],cwd=w,stdout=stdout,stderr=stderr);(p/'ci-supertype-final-child.json').write_text(json.dumps({'pid':child.pid,'parent':os.getpid(),'startedUnix':time.time()},indent=2)+'\n');code=child.wait()
 result={'terminal':True,'exitCode':code,'seconds':round(time.monotonic()-start,3),'guardComplete':(w/'validation/integration-20261018/git-compiler-supertype-final/result.json').exists()}
except BaseException:result={'terminal':True,'exitCode':1,'exception':traceback.format_exc()}
temporary=marker.with_suffix('.tmp');temporary.write_text(json.dumps(result,indent=2)+'\n');temporary.replace(marker)
