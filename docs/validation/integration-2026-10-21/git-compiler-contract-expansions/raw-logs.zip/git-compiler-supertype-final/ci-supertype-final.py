from pathlib import Path
import subprocess,json,hashlib,os,time,sys,re,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018';narrow=raw/'git-compiler-supertype-r1';out=raw/'git-compiler-supertype-final';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
qualified=json.loads((narrow/'result.json').read_bytes());assert qualified['complete'] and qualified['sourceInputsUnchanged'] and qualified['exitCode']==0
inputs=json.loads((narrow/'source-before.json').read_bytes());assert len(inputs)==1014 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');(out/'controller.py').write_bytes(Path(__file__).read_bytes());rows=[]
for name in ['git_compiler_affected.stdout','git_compiler_affected.stderr']:shutil.copyfile(narrow/name,out/name);assert (out/name).read_bytes()==(narrow/name).read_bytes()
assert re.search(rb'test result: ok\. 26 passed; 0 failed; 0 ignored;', (narrow/'git_compiler_affected.stdout').read_bytes())
for row in qualified['rows']:rows.append({**row,'reusedCheckedPhase':'git-compiler-supertype-r1','rerun':False})
green=json.loads((raw/'git-compiler-supertype-green/result.json').read_bytes());assert green['complete'] and green['sameOriginalReportRowsSeedsAndCompleteHierarchy'] and green['callerReachedFromExactChangedMethodRow'];native=w/'target/debug/yoke.exe';assert sha(native)==green['cliSha256']
def run(name,argv):
 start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:code=subprocess.run(argv,cwd=w,stdout=stdout,stderr=stderr,timeout=1200).returncode
 assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen input changed'
 row={'name':name,'argv':argv,'exitCode':code,'seconds':round(time.monotonic()-start,3)};rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True);return code
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe'
for target in ['projects','git_affected_details','git_affected_qualification','git_impact_details']:
 deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()};code=run(target,[cargo,'test','--locked','-j','2','--test',target,'--','--test-threads=1']);cleanup=[]
 for p in deps.iterdir():
  if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(target+'-'):continue
  assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h;p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h})
 (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n')
 if code:sys.exit(code)
for name,argv in [('clippy',[cargo,'clippy','--locked','--all-targets','-j','2','--','-D','warnings']),('build',[cargo,'build','--locked','-j','2','--bin','yoke']),('fmt',[cargo,'fmt','--all','--check']),('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:
 if run(name,argv):sys.exit(1)
for name,argv in [('class-value-regression',[r'C:\Python314\python.exe',str(Path(os.environ['TEMP'])/'ci-supertype-class-value-regression.py')]),('legacy-compiler',[r'C:\Python314\python.exe',str(Path(os.environ['TEMP'])/'ci-git-compiler-legacy-after.py'),'after-supertype-final'])]:
 if run(name,argv):sys.exit(1)
assert sha(native)==green['cliSha256']
(out/'result.json').write_text(json.dumps({'complete':True,'sourceInputsUnchanged':True,'inputs':len(inputs),'reusedQueryQualificationSameExactInputs':True,'queryPhase':'git-compiler-supertype-r1','sameOriginalReportGreen':'git-compiler-supertype-green','cliSha256':sha(native),'rows':rows},indent=2)+'\n')
