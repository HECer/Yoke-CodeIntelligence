from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/git-compiler-affected-cli-final';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
native=w/'target/debug/yoke.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native_hash=sha(native)
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-compiler-git-cli-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
git=Path(shutil.which('git'));node=Path(r'C:\Program Files\nodejs\node.exe');compiler=w/'node_modules/typescript/lib/typescript.js'
g=[git,'-c','init.templateDir=','-c','core.autocrlf=false','-c','core.hooksPath=','-c','user.name=Owned CLI fixture','-c','user.email=owned@example.invalid']
run('git-init',[*g,'init','-b','main'])
path=source/'main.ts';base="\ufeff// original π 😀 e\u0301\r\nexport interface I { go(v:string):string; }\r\nexport class Base implements I { go(v:string) { return v; } }\r\nexport class Derived extends Base { override go(v:string) { return 'BEFORE'+v; } }\r\nexport function caller(x:Base) { x.go('a'); x.go('b'); }\r\n"
path.write_bytes(base.encode());(source/'tsconfig.json').write_text('{"compilerOptions":{"strict":true,"target":"ES2022","module":"CommonJS","noEmit":true},"files":["main.ts"]}');(source/'.gitignore').write_text('.yoke/\n')
run('git-add',[*g,'add','--all']);run('git-commit',[*g,'commit','-m','owned base']);commit=run('git-head',[*g,'rev-parse','HEAD']).decode().strip();path.write_bytes(base.replace('BEFORE','AFTER').encode())
options=jobroot/'options.json';options.write_text(json.dumps({'baseRef':commit,'headRef':None,'mergeBase':False,'impactDepth':2,'ownerLimit':3,'historyLimit':1,'branchLimit':0}))
report=json.loads(run('git-analyze',[native,'--root',source,'--max-bytes','4000000','--timeout','60000','git','analyze','--git',git,'--trust-git','--options',options],timeout=90));report_id=report['artifactId']
def state():return {p.relative_to(source).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source.rglob('*') if p.is_file()}
before=state();common=[native,'--root',source,'--timeout','60000'];tail=['git','compiler-affected',report_id,'--node',node,'--typescript',compiler,'--trust-compiler']
reply=run('compiler-affected',[*common,'--max-bytes','4000000',*tail],timeout=90);result=json.loads(reply);assert result['schema']=='git_compiler_affected_v1' and result['compilerBindingEstablished'] and not result['complete'] and not result['runtimeDispatchEstablished'];assert reply.endswith(b'\n') and not reply.endswith(b'\n\n')
repeat=run('compiler-affected-repeat',[*common,'--max-bytes','4000000',*tail],timeout=90);assert reply==repeat
c=result['head']['contexts'][0];nodes={n['id']:n for n in c['nodes']};possible=[e for e in c['relations'] if e['relation']=='possibleDispatch' and nodes[e['target']]['name']=='go' and "'AFTER'" in nodes[e['target']]['declaration']['text']];assert len(possible)==2 and possible[0]['id']!=possible[1]['id']
budget=len(reply)
for i in range(4):
    exact=run('budget-converge-'+str(i),[*common,'--max-bytes',str(budget),*tail],timeout=90)
    if len(exact)==budget:break
    assert len(exact)<budget;budget=len(exact)
else:raise AssertionError('Output envelope did not converge')
refusal=run('one-byte-short',[*common,'--max-bytes',str(budget-1),*tail],expected=None,timeout=90);assert rows[-1]['exitCode']!=0 and not refusal;assert b'git_compiler_affected_capacity_exceeded' in (out/'one-byte-short.stderr').read_bytes()
untrusted=run('untrusted',[*common,'--max-bytes','4000000',*tail[:-1]],expected=None);assert rows[-1]['exitCode']!=0 and not untrusted
assert state()==before and sha(native)==native_hash
(out/'source-state-before.json').write_text(json.dumps(before,indent=2)+'\n')
(out/'result.json').write_text(json.dumps({'complete':True,'fixtureRoot':str(source),'cliSha256':native_hash,'nodeSha256':sha(node),'compilerSha256':sha(compiler),'reportId':report_id,'resultId':result['resultId'],'repeatRawBytesExact':True,'parallelDispatchProofs':len(possible),'outputIncludesOneLF':True,'exactEnvelopeBytes':budget,'oneByteShortRefusedWithoutStdout':True,'untrustedRefusedWithoutStdout':True,'allSourceGitAndStoreFileBytesUnchanged':True,'analyzedSourceExecuted':False,'commands':rows},indent=2)+'\n');print(json.dumps({'complete':True,'parallelDispatchProofs':len(possible),'exactEnvelopeBytes':budget,'allSourceGitAndStoreFileBytesUnchanged':True}))
