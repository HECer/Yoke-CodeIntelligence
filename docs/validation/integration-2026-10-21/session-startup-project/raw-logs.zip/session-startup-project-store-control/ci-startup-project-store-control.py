from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-startup-project-store-control').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-startup-store-control-');exec(compile(prefix,str(script),'exec'))
raw=w/'validation/integration-20261018';red=json.loads((raw/'session-startup-project-red/result.json').read_bytes());root=Path(red['sourceRoot']);profile=Path(red['profile']);original=profile.read_bytes();host=json.loads(original);host.pop('startupProject')
def dump():
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(db.iterdump())+'\n').encode('utf8')
 finally:db.close()
def files():return {str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in root.rglob('*') if p.is_file()}
before=dump();(out/'full-sql-before.sql').write_bytes(before);before_files=files();(out/'before-files.json').write_text(json.dumps(before_files,indent=2)+'\n',encoding='utf8');metadata=jobroot/'metadata.json';metadata.write_text(json.dumps([{'operation':'configuration','args':{}}]),encoding='utf8');argv=list(red['argv']);argv[argv.index('--requests')+1]=str(metadata);profile.write_text(json.dumps(host,ensure_ascii=False),encoding='utf8')
try:
 reply=json.loads(run('legacy-session-full-sql-control',[*argv,'--id','positive']));assert reply['results'][0]==json.loads((raw/'session-startup-project-red/old-explicit-activation.stdout').read_bytes())['results'][1]
finally:profile.write_bytes(original)
after=dump();(out/'full-sql-after.sql').write_bytes(after);after_files=files();(out/'after-files.json').write_text(json.dumps(after_files,indent=2)+'\n',encoding='utf8');assert before==after;assert {k:v for k,v in before_files.items() if '.yoke' not in Path(k).parts}=={k:v for k,v in after_files.items() if '.yoke' not in Path(k).parts}
result={'complete':True,'cliSha256':native_hash,'fullLogicalSchemaAndEveryTableRowExact':True,'sqlDumpBytes':len(before),'sqlDumpSha256':hashlib.sha256(before).hexdigest(),'physicalFilesExact':before_files==after_files,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'commands':rows};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in result.items() if k!='commands'}))
