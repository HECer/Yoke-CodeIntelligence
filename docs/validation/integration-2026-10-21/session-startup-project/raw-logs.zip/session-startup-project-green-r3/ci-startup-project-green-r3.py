from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-startup-project-green-r3').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-startup-project-green-r3-');exec(compile(prefix,str(script),'exec'))
raw=w/'validation/integration-20261018';prior=raw/'session-startup-project-green-r2';old_progress=json.loads((prior/'progress.json').read_bytes());assert len(old_progress)==10 and all(r['activeAfterCleanup']==0 for r in old_progress)
for row in old_progress:
 if row['name']=='git-init':continue
 for ext in ['stdout','stderr']:shutil.copyfile(prior/(row['name']+'.'+ext),out/(row['name']+'.'+ext))
 rows.append({**row,'reusedCheckedPhase':'session-startup-project-green-r2','rerun':False})
def files(root):return {str(p.relative_to(root)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in root.rglob('*') if p.is_file()}
def records(root):
 db=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return [{'kind':k,'id':i,'value':v} for k,i,v in db.execute('select kind,id,value from records order by kind,id')]
 finally:db.close()
api=json.loads((raw/'repl-api-selection-red/result.json').read_bytes());api_root=Path(api['sourceRoot']);api_profile=Path(api['profile']);original=api_profile.read_bytes();api_records=records(api_root);before=files(api_root)
(out/'legacy-api-before-files.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf8');(out/'legacy-api-before-records.json').write_text(json.dumps(api_records,indent=2)+'\n',encoding='utf8')
api_profile.write_text(json.dumps({'steering':{}}),encoding='utf8')
try:
 result=run('legacy-api-bytes-diagnostic',[*api['argv'],'--id','positive']);assert result==(raw/'repl-api-selection-red/old-positive.stdout').read_bytes()
finally:api_profile.write_bytes(original)
after_records=records(api_root);after=files(api_root);(out/'legacy-api-after-files.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf8');(out/'legacy-api-after-records.json').write_text(json.dumps(after_records,indent=2)+'\n',encoding='utf8')
diff=[{'path':n,'before':before.get(n),'after':after.get(n)} for n in sorted(before.keys()|after.keys()) if before.get(n)!=after.get(n)];assert api_records==after_records;assert all('.yoke' in Path(d['path']).parts for d in diff)
red=json.loads((raw/'session-startup-project-red/result.json').read_bytes());root=Path(red['sourceRoot']);target=Path(red['targetRoot']);assert {n:v for n,v in files(root).items() if '.yoke' not in Path(n).parts}=={n:v for n,v in red['sourceFiles'].items() if '.yoke' not in Path(n).parts};assert files(target)==red['targetFiles']
profile=Path(red['profile']);original=profile.read_bytes();host=json.loads(original);host.pop('startupProject');metadata=jobroot/'metadata.json';metadata.write_text(json.dumps([{'operation':'configuration','args':{}}]),encoding='utf8');common=list(red['argv']);common[common.index('--requests')+1]=str(metadata);old_records=records(root);before_root=files(root)
(out/'legacy-session-before-files.json').write_text(json.dumps(before_root,indent=2)+'\n',encoding='utf8');(out/'legacy-session-before-records.json').write_text(json.dumps(old_records,indent=2)+'\n',encoding='utf8');profile.write_text(json.dumps(host,ensure_ascii=False),encoding='utf8')
try:
 c=json.loads(run('old-session-stable-byte-control',[*common,'--id','positive']));assert c['results'][0]==json.loads((raw/'session-startup-project-red/old-explicit-activation.stdout').read_bytes())['results'][1]
finally:profile.write_bytes(original)
after_root=files(root);after_root_records=records(root);(out/'legacy-session-after-files.json').write_text(json.dumps(after_root,indent=2)+'\n',encoding='utf8');(out/'legacy-session-after-records.json').write_text(json.dumps(after_root_records,indent=2)+'\n',encoding='utf8');assert old_records==after_root_records
root_diff=[{'path':n,'before':before_root.get(n),'after':after_root.get(n)} for n in sorted(before_root.keys()|after_root.keys()) if before_root.get(n)!=after_root.get(n)];assert all('.yoke' in Path(d['path']).parts for d in root_diff)
result={'complete':True,'cliSha256':native_hash,'sameOriginalRedSourceRoot':str(root),'sameOriginalHostRequestsAdmittedThenActivationRefused':True,'oldNoSettingSessionConfigurationExact':True,'legacySessionRecordsExact':True,'legacySessionPhysicalFilesExact':not root_diff,'legacySessionPhysicalFileDiff':root_diff,'legacyApiOriginalRawResultExact':True,'legacyApiRecordsExact':True,'legacyApiPhysicalFilesExact':not diff,'legacyApiPhysicalFileDiff':diff,'actualMcpConcreteProjectCatalogAndDispatchQualified':True,'explicitPrimaryStartupQualified':True,'multiProjectStartupAndResumeQualified':True,'unknownSelectionNoPublication':True,'originalSourceGitBytesExact':True,'registeredUnicodeTargetAndExistingStoreEntireBytesExact':True,'metadataWithoutExecutionGrant':True,'initialTargetStoreAbsenceOracleCorrected':True,'priorFunctionalAssertionsPassedBeforePhysicalStoreDiagnostic':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'modelCalled':False,'analyzedSourceExecuted':False,'commands':rows}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps({'complete':True,'legacySessionPhysicalFilesExact':not root_diff,'legacyApiPhysicalFilesExact':not diff,'legacyApiDiff':diff,'legacySessionDiff':root_diff}))
