from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,re,traceback
script=Path(os.environ['TEMP'])/'ci-git-invocations-cli-final.py';prefix=script.read_text(encoding='utf8').split("path=source/'main.ts';base=",1)[0].replace('git-compiler-invocations-cli-final','session-startup-project-final').replace('yoke-owned-compiler-invocations-cli-','yoke-owned-startup-project-final-');exec(compile(prefix,str(script),'exec'))
cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup'
old=json.loads((w/'validation/integration-20261018/session-startup-project-r2/source-before.json').read_bytes());inputs={n:sha(w/n) for n in old};assert len(inputs)==1019;(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');assert sha(w/'native/tests/fixtures/postgres-catalog-response.jsonl')=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47'
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';targets=['session_steering','project_session','compatibility','compatibility_review','session_mcp','session_review','session_refactor','session_root_aliases','session_epoch_selection','session_collections','session_collections_admission','agent_memory_namespaces','agent_file_options','agent_repl','agent_repl_lifecycle','mcp_http','mcp_http_review','mcp_http_cli','mcp_collection_grants','mcp_collection_grants_review','resource_paging','parity_retention'];complete=False
prior=w/'validation/integration-20261018/session-startup-project-r2';narrow=json.loads((prior/'result.json').read_bytes());assert narrow['complete'] and narrow['sourceInputsUnchanged'] and narrow['allJobsEmpty'];assert inputs==json.loads((prior/'source-before.json').read_bytes())
for row in narrow['rows']:
 if row['name'] not in ['session_startup_project','agent_repl_api_selection','session_steering','project_session']:continue
 for ext in ['stdout','stderr']:shutil.copyfile(prior/(row['name']+'.'+ext),out/(row['name']+'.'+ext))
 rows.append({**row,'reusedCheckedPhase':'session-startup-project-r2','rerun':False})
targets=[name for name in targets if name not in ['session_steering','project_session']]

try:
 for target in targets:
  deps=w/'target/debug/deps';before={p.resolve() for p in deps.iterdir() if p.is_file()}
  run(target,[cargo,'test','--locked','-j','2','--test',target,'--','--nocapture','--test-threads=1'],expected=None,timeout=90 if target=='mcp_http' else 300)
  assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed';cleanup=[]
  for p in deps.iterdir():
   if p.resolve() in before or p.suffix.lower() not in ['.exe','.pdb'] or not p.name.startswith(target+'-'):continue
   assert p.resolve().parent==deps.resolve() and p.is_file() and not p.is_symlink();h=sha(p);size=p.stat().st_size;assert sha(p)==h
   try:p.unlink();cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':True})
   except PermissionError:cleanup.append({'name':p.name,'bytes':size,'sha256':h,'deleted':False,'reason':'completed output held; preserved'})
  (out/(target+'-cleanup.json')).write_text(json.dumps(cleanup,indent=2)+'\n');assert rows[-1]['exitCode']==0,(target,rows[-1]['exitCode'])
 for name,argv in [('clippy',[cargo,'clippy','--locked','--all-targets','-j','2','--','-D','warnings']),('fmt',[cargo,'fmt','--all','--check']),('build',[cargo,'build','--locked','-j','2','--bin','yoke']),('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:
  run(name,argv,timeout=600);assert all(sha(w/n)==h for n,h in inputs.items()),'Frozen source changed'
 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'inputs':len(inputs),'cliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':targets,'rows':rows},indent=2)+'\n')
assert complete
