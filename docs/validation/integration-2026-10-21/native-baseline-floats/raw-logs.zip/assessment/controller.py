from pathlib import Path
import hashlib,json,re,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence')
raw=w/'validation/integration-20261018/full-native-float-20261021-r1'
result=json.loads((raw/'result.json').read_text())
manifest=json.loads((raw/'manifest.json').read_text())
assert result['sourceCommit']==manifest['sourceCommit']=='bcf442b32a6dd03bcd3c6c8e8794eaf3fd929079'
assert result['sourceUnchanged'] and result['cliUnchanged'] and result['toolsUnchanged']
assert result['allRegisteredGroupsAttempted'] and result['registeredGroups']==316
assert result['examplesBuild']['exitCode']==0
before=json.loads((raw/'source-before.json').read_text())
after=json.loads((raw/'source-after.json').read_text())
assert before==after and len(before)==result['frozenInputs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(w/n)==h for n,h in after.items())
expected=json.loads((w/'validation/integration-20261018/full-status-preflight/full-native-assessment-20261021-r1/report.json').read_text())
expected_failures={g['group']:g['failedTests'] for g in expected['runtimeFailureGroups']}
failures=[];compile_failures=[];ignored=[];junctions=[];unknown=[];unexplained_commands=[]
for group in result['groups']:
    folder=raw/(str(group['index']).zfill(3)+'-'+group['group'])
    assert json.loads((folder/'result.json').read_text())==group
    for command in group['commands']:
        if command['name']=='compile' and command['exitCode']:
            compile_failures.append({'group':group['group'],'exitCode':command['exitCode']})
        elif command['exitCode'] and (command['name']!='test' or not group.get('failures') or len(group['failures'])!=group.get('totals',{}).get('failed',0)):
            unexplained_commands.append({'group':group['group'],'command':command['name'],'exitCode':command['exitCode']})
    log=(folder/'test.log').read_text(encoding='utf-8',errors='replace') if (folder/'test.log').is_file() else ''
    for name,reason in re.findall(r'^test (\S+) \.\.\. ignored(?:, ([^\r\n]+))?$',log,re.M):
        ignored.append({'group':group['group'],'test':name,'reason':reason})
    if group.get('totals',{}).get('failed',0):
        sections=re.findall(r'^---- (\S+) stdout ----\r?\n(.*?)(?=^---- |^failures:|^test result:|\Z)',log,re.M|re.S)
        by_name=dict(sections)
        for name in group['failures']:
            panic=by_name.get(name,'')
            is_old=expected_failures.get(group['group'])==group['failures']
            row={'group':group['group'],'test':name,'originalFixtureCase':is_old,'os1314':bool(re.search(r'\bcode: 1314\b',panic))}
            failures.append(row)
            if not(row['originalFixtureCase'] and row['os1314']):unknown.append(row)
    for name in ['windows_junction_parents_cannot_redirect_import_or_export','an_actual_unprivileged_junction_refuses_before_provider_start']:
        if re.search(r'^test '+re.escape(name)+r' \.\.\. ok$',log,re.M):junctions.append({'group':group['group'],'test':name})
out=w/'validation/integration-20261018/full-status-preflight/full-native-float-assessment-20261021-r1';out.mkdir(parents=True,exist_ok=False)
shutil.copyfile(__file__,out/'controller.py')
report={k:result[k] for k in ['sourceCommit','registeredGroups','completedGroups','frozenInputs','sourceUnchanged','cliUnchanged','toolsUnchanged','totals','examplesBuild']}
report.update({'runtimeFailures':failures,'compileFailures':compile_failures,'unexplainedRuntimeFailures':unknown,'unexplainedCommandFailures':unexplained_commands,'allRuntimeFailuresMatchPriorOs1314Fixtures':bool(failures) and not unknown and not unexplained_commands,'ignoredCases':len(ignored),'actualJunctionSecurityCasesPassed':junctions,'userSettingDecision':'continue_without_enabling_developer_mode','symlinkProbe':'C:/Users/Lomi/AppData/Local/Temp/yoke-owned-link-probe-60352f6b5c4e48eab9cae956e55d6e92/probe.json','rawLogsUnmodified':True,'fullWindowsCertified':False,'fullStatusCertified':False})
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'ignored-cases.json').write_text(json.dumps(ignored,indent=2)+'\n')
assert len(ignored)==result['totals']['ignored']
assert len(failures)==result['totals']['failed']
print(json.dumps(report,indent=2))
assert not compile_failures and not unknown and not unexplained_commands,'Inspect unexpected failures; no acceptance or automatic waiver'
