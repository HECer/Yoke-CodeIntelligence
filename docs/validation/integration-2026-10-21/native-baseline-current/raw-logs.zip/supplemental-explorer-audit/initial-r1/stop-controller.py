from pathlib import Path
import json,urllib.request
root=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\validation\integration-20261018\explorer-current-audit\initial-r1')
b=json.loads((root/'bootstrap.json').read_text());assert b['controllerPid']==31152 and b['url']=='http://127.0.0.1:65114/explorer.html'
request=urllib.request.Request('http://127.0.0.1:65114/__stop',data=b'',method='POST')
with urllib.request.urlopen(request,timeout=5) as response:assert response.read()==b'stopping'
print('Owned loopback fixture server shutdown requested')
