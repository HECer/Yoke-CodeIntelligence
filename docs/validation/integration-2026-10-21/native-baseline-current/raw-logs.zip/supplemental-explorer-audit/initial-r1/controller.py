from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,tempfile,time,_winapi,shutil,http.server,urllib.parse
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');out=w/'validation/integration-20261018/explorer-current-audit/initial-r1';out.mkdir(parents=True,exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native=w/'target/debug/yoke.exe';assert sha(native)=='204c369a3f53b3674dc481e42f9d1f4dab842a2b513ba6a4646c930097d2057a'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()=='98ffa7824a696c53cfa8b4bdb9ecc49cf60bcb9a'
inputs=json.loads((w/'validation/integration-20261018/full-native-current-20261021-r1/source-before.json').read_text());assert len(inputs)==1002 and all(sha(w/n)==h for n,h in inputs.items())
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-explorer-audit-'));cwd=jobroot/"source ' \u03c0";cwd.mkdir();configroot=jobroot;client=jobroot/'unused-client.exe';public=jobroot/'public';public.mkdir()
files={'invoice.ts':'''export class Invoice {
  constructor(public amount:number) {}
  total(tax:number):number {
    return normalizeTotal(this.amount)*(1+tax);
  }
}
export function normalizeTotal(value:number):number {
  // OWNED_BODY_NOT_A_DECLARATION_HEADER
  return Math.max(0,value);
}
''','preview.ts':'''import {Invoice} from './invoice';
export function preview():number {
  const invoice=new Invoice(12);
  return invoice.total(0.19);
}
export function compare():number {
  return preview()+preview();
}
''','README.md':'# Code Intelligence 0.5.0 owned explorer audit\n\nSynthetic examples only. No application code is executed.\n'}
for name,text in files.items():(cwd/name).write_text(text,encoding='utf-8',newline='\n')
fixture_hashes={name:sha(cwd/name) for name in files};(out/'fixture-inputs.json').write_text(json.dumps(files,indent=2)+'\n')
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','roaming'),('LOCALAPPDATA','local'),('TEMP','tmp'),('TMP','tmp')]:
    p=jobroot/name;p.mkdir(exist_ok=True);env[key]=str(p)
reviewed=Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py';text=reviewed.read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")]
reviewed_hash=hashlib.sha256(runner.encode()).hexdigest();assert reviewed_hash=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5'
runner=runner.replace('print(json.dumps(row),flush=True)',"print(name+': exit='+str(row.get('exitCode'))+', jobActive='+str(row['activeAfterCleanup']),flush=True)")
(out/'reviewed-runner.py').write_text(runner);exec(compile(runner,str(reviewed)+'[reviewed print-only change]','exec'))
html=public/'explorer.html';export=json.loads(run('native-export',[native,'--root',cwd,'--timeout','60000','export','--format','html','--output',html]));assert html.is_file() and export['format']=='html'
html_hash=sha(html);shutil.copyfile(html,out/'native-export.html');requests=[]
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def allowed(self):return self.headers.get('Host') in [f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}']
    def do_GET(self):
        path=urllib.parse.urlsplit(self.path).path;requests.append({'method':'GET','path':path});assert len(requests)<=100
        if not self.allowed() or path not in ['/','/explorer.html']:self.send_error(404);return
        data=html.read_bytes();assert hashlib.sha256(data).hexdigest()==html_hash
        self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(data)
    def do_POST(self):
        if not self.allowed() or self.path!='/__stop':self.send_error(405);return
        self.send_response(200);self.end_headers();self.wfile.write(b'stopping');self.server.stop_requested=True
server=http.server.HTTPServer(('127.0.0.1',0),Handler);server.timeout=.5;server.stop_requested=False
bootstrap={'controllerPid':os.getpid(),'fixtureRoot':str(jobroot),'sourceRoot':str(cwd),'publicHtml':str(html),'url':f'http://127.0.0.1:{server.server_port}/explorer.html','appVersion':'0.5.0','sourceCommit':'98ffa7824a696c53cfa8b4bdb9ecc49cf60bcb9a','cliSha256':sha(native),'htmlSha256':html_hash,'nativeExport':export,'reviewedRunnerSourceSha256':reviewed_hash,'sourceCodeExecuted':False,'modelRequested':False,'publicDataOnly':True,'commands':rows}
(out/'bootstrap.json').write_text(json.dumps(bootstrap,indent=2)+'\n');print(json.dumps(bootstrap),flush=True);start=time.monotonic()
try:
    while not server.stop_requested and time.monotonic()-start<900:server.handle_request()
finally:
    server.server_close();result={**bootstrap,'servedRequests':requests,'explicitlyStopped':server.stop_requested,'deadlineExpired':not server.stop_requested,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'fixtureSourcesUnchanged':all(sha(cwd/n)==h for n,h in fixture_hashes.items()),'cliUnchanged':sha(native)==bootstrap['cliSha256'],'htmlUnchanged':sha(html)==html_hash,'allCliProcessJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'serverClosed':True};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['sourceInputsUnchanged','fixtureSourcesUnchanged','cliUnchanged','htmlUnchanged','allCliProcessJobsEmpty','serverClosed']}),flush=True)
