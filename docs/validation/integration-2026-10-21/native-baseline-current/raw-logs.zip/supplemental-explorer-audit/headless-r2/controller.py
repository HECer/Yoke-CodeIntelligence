from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,tempfile,time,_winapi,shutil,http.server,urllib.parse,threading
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018/explorer-current-audit';out=raw/'headless-r2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native=w/'target/debug/yoke.exe';browser=Path(r'C:\Program Files\Google\Chrome\Application\chrome.exe');assert browser.is_file()
inputs=json.loads((w/'validation/integration-20261018/full-native-current-20261021-r1/source-before.json').read_text());assert all(sha(w/n)==h for n,h in inputs.items()) and sha(native)=='204c369a3f53b3674dc481e42f9d1f4dab842a2b513ba6a4646c930097d2057a'
html=raw/'initial-r1/native-export.html';html_hash=sha(html);assert html_hash=='c3b4e6bbf9b63ce55a35e5cb2dfaf16237d64723e4aeb0f5051f0ef424a4f4e0'
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-headless-explorer-'));profile=jobroot/'profile';profile.mkdir();browser_hash=sha(browser);requests=[]
class Handler(http.server.BaseHTTPRequestHandler):
    def setup(self):super().setup();self.connection.settimeout(2)
    def log_message(self,*args):pass
    def do_GET(self):
        path=urllib.parse.urlsplit(self.path).path;requests.append({'method':'GET','path':path})
        if self.headers.get('Host') not in [f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'] or path not in ['/','/explorer.html']:self.send_error(404);return
        data=html.read_bytes();assert hashlib.sha256(data).hexdigest()==html_hash
        self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('Connection','close');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(data)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url=f'http://127.0.0.1:{server.server_port}/explorer.html'
reviewed=Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py';text=reviewed.read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5'
definitions=runner[:runner.index('rows=[]')];exec(compile(definitions,'reviewed Windows job definitions','exec'));(out/'reviewed-job-definitions.py').write_text(definitions)
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
    p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
for name in ['Desktop','Documents','Downloads']:(jobroot/'home'/name).mkdir(exist_ok=True)
argv=[str(browser),'--headless=new','--user-data-dir='+str(profile),'--remote-debugging-address=127.0.0.1','--remote-debugging-port=0','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-default-apps','--disable-features=MediaRouter,Translate','--window-size=1440,900','about:blank']
job=k.CreateJobObjectW(None,None);assert job;limits=Extended();limits.basic.flags=0x2000;assert k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits));hp=ht=None;row={'startedSuspended':True,'assignedBeforeResume':False,'command':argv};result={'fixtureRoot':str(jobroot),'htmlSha256':html_hash,'browserSha256':browser_hash,'appVersion':'0.5.0','controllerPid':os.getpid(),'sourceCodeExecuted':False,'modelRequested':False,'temporaryProfileOnly':True,'osNetworkIsolationAttested':False}
def active():
    info=ctypes.create_string_buffer(48);assert k.QueryInformationJobObject(job,1,info,48,None);return int.from_bytes(info.raw[40:44],'little')
start=time.monotonic()
try:
    with open(os.devnull,'rb') as inp,(out/'browser.stdout').open('wb') as stdout,(out/'browser.stderr').open('wb') as stderr:
        handles=[msvcrt.get_osfhandle(f.fileno()) for f in [inp,stdout,stderr]]
        for handle in handles:os.set_handle_inheritable(handle,True)
        si=subprocess.STARTUPINFO();si.dwFlags=subprocess.STARTF_USESTDHANDLES;si.hStdInput,si.hStdOutput,si.hStdError=handles;si.lpAttributeList={'handle_list':handles}
        hp,ht,pid,tid=_winapi.CreateProcess(None,subprocess.list2cmdline(argv),None,None,True,subprocess.CREATE_NO_WINDOW|0x00000004,env,str(jobroot),si);row['pid']=pid;assert k.AssignProcessToJobObject(job,hp);row['assignedBeforeResume']=True;assert k.ResumeThread(ht)!=0xffffffff
        port_file=profile/'DevToolsActivePort'
        while not port_file.is_file():
            assert _winapi.WaitForSingleObject(hp,0)==258,'Owned browser exited before readiness'
            assert time.monotonic()-start<25,'Owned browser startup deadline';time.sleep(.05)
        port=int(port_file.read_text().splitlines()[0]);assert 0<port<65536
        ready={**result,'browserPid':pid,'debugPort':port,'url':url,'profileRoot':str(profile),'out':str(out)};(out/'ready.json').write_text(json.dumps(ready,indent=2)+'\n');print(json.dumps({k:ready[k] for k in ['controllerPid','browserPid','debugPort','url','out']}),flush=True)
        while _winapi.WaitForSingleObject(hp,100)==258:
            if (out/'stop.request').exists():row['explicitCleanupRequested']=True;break
            assert time.monotonic()-start<900,'Owned audit deadline'
        if _winapi.WaitForSingleObject(hp,0)!=258:row['exitCode']=_winapi.GetExitCodeProcess(hp)
except BaseException as error:
    result.update(errorType=type(error).__name__,error=str(error));raise
finally:
    if hp is not None and not row['assignedBeforeResume']:_winapi.TerminateProcess(hp,124)
    assert k.TerminateJobObject(job,125);until=time.monotonic()+10
    while active() and time.monotonic()<until:time.sleep(.05)
    row['activeAfterCleanup']=active();row['seconds']=round(time.monotonic()-start,3)
    for handle in [ht,hp,job]:
        if handle is not None:k.CloseHandle(handle)
    server.shutdown();server.server_close();thread.join(3)
    result.update(browser=row,serverClosed=True,servedRequests=requests,sourceInputsUnchanged=all(sha(w/n)==h for n,h in inputs.items()),nativeCliUnchanged=sha(native)=='204c369a3f53b3674dc481e42f9d1f4dab842a2b513ba6a4646c930097d2057a',browserUnchanged=sha(browser)==browser_hash,htmlUnchanged=sha(html)==html_hash,allOwnBrowserProcessesGone=row['activeAfterCleanup']==0)
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['serverClosed','sourceInputsUnchanged','nativeCliUnchanged','browserUnchanged','htmlUnchanged','allOwnBrowserProcessesGone']}),flush=True)
