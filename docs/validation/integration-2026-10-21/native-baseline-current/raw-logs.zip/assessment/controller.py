from pathlib import Path
import hashlib,json,re,shutil,subprocess
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');raw=w/'validation/integration-20261018/full-native-current-20261021-r1'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=read(raw/'result.json');manifest=read(raw/'manifest.json')
assert result['sourceCommit']==manifest['sourceCommit']=='98ffa7824a696c53cfa8b4bdb9ecc49cf60bcb9a'
assert result['sourceUnchanged'] and result['cliUnchanged'] and result['toolsUnchanged']
assert result['allRegisteredGroupsAttempted'] and result['registeredGroups']==len(manifest['groups'])==320
assert result['examplesBuild']['exitCode']==0
before=read(raw/'source-before.json');after=read(raw/'source-after.json');assert before==after and len(before)==result['frozenInputs']==1002
assert all(sha(w/n)==h for n,h in after.items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==result['sourceCommit']
old=read(w/'docs/validation/integration-2026-10-21/native-baseline-floats/checkpoint.json')
assert old['sourceCommit']=='bcf442b32a6dd03bcd3c6c8e8794eaf3fd929079'
expected={}
for row in old['runtimeFailures']:
    assert row['originalFixtureCase'] and row['os1314'];expected.setdefault(row['group'],set()).add(row['test'])
assert sum(map(len,expected.values()))==10
fixture_sources=[]
for group in sorted(expected):
    path='native/tests/'+group+'.rs'
    original=subprocess.check_output(['git','show',old['sourceCommit']+':'+path],cwd=w)
    current=subprocess.check_output(['git','show',result['sourceCommit']+':'+path],cwd=w)
    assert original==current,'Original failing fixture source changed: '+path
    fixture_sources.append({'path':path,'gitBlobBytes':len(current),'sha256':hashlib.sha256(current).hexdigest(),'byteExactBetweenSourceCommits':True})
failures=[];compile_failures=[];ignored=[];junctions=[];unknown=[];unexplained_commands=[]
for group in result['groups']:
    folder=raw/(str(group['index']).zfill(3)+'-'+group['group']);assert read(folder/'result.json')==group
    for command in group['commands']:
        if command['name']=='compile' and command['exitCode']:compile_failures.append({'group':group['group'],'exitCode':command['exitCode']})
        elif command['exitCode'] and (command['name']!='test' or not group.get('failures') or len(group['failures'])!=group.get('totals',{}).get('failed',0)):
            unexplained_commands.append({'group':group['group'],'command':command['name'],'exitCode':command['exitCode']})
    log=(folder/'test.log').read_text(encoding='utf-8',errors='replace') if (folder/'test.log').is_file() else ''
    for name,reason in re.findall(r'^test (\S+) \.\.\. ignored(?:, ([^\r\n]+))?$',log,re.M):ignored.append({'group':group['group'],'test':name,'reason':reason})
    if group.get('totals',{}).get('failed',0):
        sections=dict(re.findall(r'^---- (\S+) stdout ----\r?\n(.*?)(?=^---- |^failures:|^test result:|\Z)',log,re.M|re.S))
        for name in group['failures']:
            panic=sections.get(name,'');row={'group':group['group'],'test':name,'originalFixtureCase':name in expected.get(group['group'],set()),'os1314':bool(re.search(r'\bcode: 1314\b',panic))};failures.append(row)
            if not(row['originalFixtureCase'] and row['os1314']):unknown.append(row)
    for name in ['windows_junction_parents_cannot_redirect_import_or_export','an_actual_unprivileged_junction_refuses_before_provider_start']:
        if re.search(r'^test '+re.escape(name)+r' \.\.\. ok$',log,re.M):junctions.append({'group':group['group'],'test':name})
out=w/'validation/integration-20261018/full-status-preflight/full-native-current-assessment-20261021-r1';out.mkdir(parents=True,exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
report={k:result[k] for k in ['sourceCommit','registeredGroups','completedGroups','frozenInputs','sourceUnchanged','cliUnchanged','toolsUnchanged','totals','examplesBuild']}
report.update({'runtimeFailures':failures,'originalFixtureSourceFiles':fixture_sources,'compileFailures':compile_failures,'unexplainedRuntimeFailures':unknown,'unexplainedCommandFailures':unexplained_commands,'allRuntimeFailuresMatchPriorOs1314Fixtures':bool(failures) and not unknown and not unexplained_commands,'ignoredCases':len(ignored),'actualJunctionSecurityCasesPassed':junctions,'userSettingDecision':'continue_without_enabling_developer_mode','rawLogsUnmodified':True,'fullWindowsCertified':False,'fullStatusCertified':False})
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');(out/'ignored-cases.json').write_text(json.dumps(ignored,indent=2)+'\n')
assert len(ignored)==result['totals']['ignored'] and len(failures)==result['totals']['failed']
print(json.dumps(report,indent=2))
assert not compile_failures and not unknown and not unexplained_commands,'Inspect unexpected failures; no automatic waiver'
