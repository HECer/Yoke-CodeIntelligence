from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,tempfile,time,_winapi,threading,http.server,sys,shutil
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence')
out=w/'validation/integration-20261018/r6-session-hooks'/sys.argv[1];out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
client=Path(r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\claude-2.1.306-win32-x64\claude.exe');native=w/'target/debug/yoke.exe'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(client)=='f6bc9de38f507c36c9a3bb0085a59a27e32156e2208252bf1707c4e3ef309114'
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-native-hooks-'));source=jobroot/"source space ' \u03c0";settingsroot=jobroot/'client-settings';state=jobroot/'host-state';cwd=jobroot/'installer-cwd';configroot=source
for p in [source,settingsroot,state,cwd]:p.mkdir()
source_bytes=b'fn owned_source_is_never_executed() {}\r\n';(source/'owned.rs').write_bytes(source_bytes);(source/'.env').write_bytes(b'');(cwd/'.env').write_bytes(b'')
policy=jobroot/'policy.json';policy.write_bytes(b'{}\n');selection=jobroot/'selection.json';selection.write_text(json.dumps({'installation':'owned-hooks-live','targetRoots':[str(settingsroot)],'executable':str(native),'policy':str(policy),'stateRoot':str(state),'adapter':{'kind':'claude_session_hooks_v1','sourceRoot':str(source)}}))
settings=settingsroot/'yoke-claude-hooks.json'
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','roaming'),('LOCALAPPDATA','local'),('TEMP','tmp'),('TMP','tmp'),('CLAUDE_CONFIG_DIR','private-client-state')]:
    p=jobroot/name;p.mkdir(exist_ok=True);env[key]=str(p)
requests=[]
class Handler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        requests.append({'method':'POST','path':self.path.split('?')[0]});self.send_response(503);self.end_headers()
    def do_GET(self):
        requests.append({'method':'GET','path':self.path.split('?')[0]});self.send_response(503);self.end_headers()
    def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
env.update({'DISABLE_TELEMETRY':'1','DISABLE_ERROR_REPORTING':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','DO_NOT_TRACK':'1','CI':'1','NO_COLOR':'1','ANTHROPIC_API_KEY':'invalid-owned-fixture-no-real-key','ANTHROPIC_BASE_URL':f'http://127.0.0.1:{server.server_port}'})
reviewed=Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py';text=reviewed.read_text();runner=text[text.index("k=ctypes.WinDLL("):text.index("result={'fixtureRoot'")];(out/'reviewed-runner.py').write_text(runner,encoding='utf-8');exec(compile(runner,str(reviewed)+'[reviewed runner only]','exec'))
def manifest(root):return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
result={'fixtureRoot':str(jobroot),'clientSha256':sha(client),'cliSha256':sha(native),'modelTurnRequested':False,'accountLoginRequested':False,'userConfigurationSelected':False,'analyzedSourceExecuted':False,'osNetworkIsolationAttested':False}
try:
    plan=run('install-plan',[native,'--timeout','60000','host-install','plan','--selection',selection]);planfile=jobroot/'plan.json';planfile.write_bytes(plan)
    assert json.loads(plan)['profile']=='claude-session-hooks-v1' and not settings.exists() and list(state.iterdir())==[]
    run('install-apply',[native,'--timeout','60000','host-install','apply','--selection',selection,'--plan',planfile,'--allow-host-writes'])
    installed=settings.read_bytes();(out/'installed-settings.json').write_bytes(installed);entry=json.loads(installed)['hooks']['SessionStart'][0]['hooks'][0];assert entry['command']==str(native) and isinstance(entry['args'],list) and 'shell' not in entry
    before_source=manifest(source);before_state=manifest(state)
    flags=[client,'--setting-sources','','--settings',settings,'--strict-mcp-config','--mcp-config','{"mcpServers":{}}']
    debug=out/'actual-client.debug.log';run('actual-init-only',[*flags,'--debug-file',debug,'--init-only'],timeout=60)
    logs=debug.read_text(encoding='utf-8',errors='replace');stdout=(out/'actual-init-only.stdout').read_text(encoding='utf-8',errors='replace')
    result['nativeContextObservedInActualClient']=('yoke-claude-session-scope-1' in logs+stdout)
    result['hookRefusalObservedInSuccessRun']=('claude_session_start_refused' in logs+stdout)
    result['ownedSourceUnchanged']=manifest(source)==before_source
    result['hostStateUnchangedDuringCallback']=manifest(state)==before_state
    result['managedSettingsUnchanged']=settings.read_bytes()==installed
    assert result['nativeContextObservedInActualClient'] and not result['hookRefusalObservedInSuccessRun'], 'Actual native hook result not observed; inspect owned debug evidence'
    assert result['ownedSourceUnchanged'] and result['hostStateUnchangedDuringCallback'] and result['managedSettingsUnchanged']
    policy.write_bytes(b'{"changed":true}\n');debug_bad=out/'stale-client.debug.log'
    run('actual-stale-init-only',[*flags,'--debug-file',debug_bad,'--init-only'],expected=None,timeout=60)
    badlogs=debug_bad.read_text(encoding='utf-8',errors='replace')+(out/'actual-stale-init-only.stdout').read_text(encoding='utf-8',errors='replace')
    result['stalePolicyHookRefusalObservedInActualClient']='claude_session_start_refused' in badlogs
    result['stalePolicyContextNotEmitted']='yoke-claude-session-scope-1' not in badlogs
    result['staleClientParentExitCode']=rows[-1]['exitCode']
    assert result['stalePolicyHookRefusalObservedInActualClient'] and result['stalePolicyContextNotEmitted']
    assert manifest(source)==before_source and manifest(state)==before_state and settings.read_bytes()==installed
    policy.write_bytes(b'{}\n')
    unplan=run('uninstall-plan',[native,'--timeout','60000','host-install','uninstall-plan','--selection',selection]);unfile=jobroot/'remove.json';unfile.write_bytes(unplan)
    run('uninstall-apply',[native,'--timeout','60000','host-install','apply','--selection',selection,'--plan',unfile,'--allow-host-writes'])
    assert not settings.exists() and not(source/'.yoke').exists() and sha(native)==result['cliSha256'] and manifest(source)==before_source and requests==[]
    result.update(completed=True,uninstalledOnlyOwnedSettings=True,noSourceStoreCreated=True)
except BaseException as error:
    result.update(completed=False,errorType=type(error).__name__,error=str(error));raise
finally:
    server.shutdown();server.server_close();thread.join(timeout=5);result.update(commands=rows,providerRequests=requests)
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result),flush=True)
