from pathlib import Path
import subprocess,shutil,hashlib,json
p=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');w=p.parent/'Yoke-CI-r6-session-hooks'
out=p/'validation/integration-20261018/r6-session-hooks/baseline-bytecopy-r1';out.mkdir(exist_ok=False)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=p).strip() and not w.exists()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p).decode().strip()=='6bd1b67c06ea8204521d32a7f9a571b6491dc9c3'
subprocess.run(['git','worktree','add','--no-checkout','-b','work/r6-session-hooks-20261021',str(w),'HEAD'],cwd=p,check=True)
subprocess.run(['git','sparse-checkout','init','--cone'],cwd=w,check=True)
roots=['native','workers','scripts','src','test','extensions','examples','benchmarks','.github','docs/parity']
subprocess.run(['git','sparse-checkout','set',*roots],cwd=w,check=True)
subprocess.run(['git','-c','core.autocrlf=false','read-tree','-mu','HEAD'],cwd=w,check=True)
names=subprocess.check_output(['git','ls-files','-z'],cwd=p).decode().split('\0');copied={}
for n in names:
    if n and (w/n).is_file():
        shutil.copyfile(p/n,w/n);copied[n]=hashlib.sha256((p/n).read_bytes()).hexdigest()
paths=out/'copied-paths.nul';paths.write_bytes(b'\0'.join(n.encode() for n in copied)+b'\0')
subprocess.run(['git','-c','core.autocrlf=true','add','--pathspec-from-file='+str(paths),'--pathspec-file-nul'],cwd=w,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=w).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
assert all(hashlib.sha256((w/n).read_bytes()).hexdigest()==v for n,v in copied.items())
(out/'source.json').write_text(json.dumps(copied,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'sourceRoot':str(w),'copiedTrackedInputs':len(copied),'allSourceBytesExact':True,'cleanIndex':True,'head':'6bd1b67c06ea8204521d32a7f9a571b6491dc9c3'},indent=2)+'\n');shutil.copyfile(__file__,out/'controller.py');print(len(copied))
