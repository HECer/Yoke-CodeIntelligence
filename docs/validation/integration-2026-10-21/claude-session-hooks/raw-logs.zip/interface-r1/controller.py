from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,tempfile,time,_winapi,threading,http.server
w=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence')
out=w/'validation/integration-20261018/r6-session-hooks/interface-r1';out.mkdir(parents=True,exist_ok=False)
client=Path(r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\claude-2.1.306-win32-x64\claude.exe')
node=Path(r'C:\Program Files\nodejs\node.exe')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(client)=='f6bc9de38f507c36c9a3bb0085a59a27e32156e2208252bf1707c4e3ef309114'
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-hooks-'));configroot=jobroot/"source space ' \u03c0";configroot.mkdir();cwd=configroot
source=configroot/'owned.rs';source_bytes=b'fn owned_fixture() {}\r\n';source.write_bytes(source_bytes);(cwd/'.env').write_bytes(b'')
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','roaming'),('LOCALAPPDATA','local'),('TEMP','tmp'),('TMP','tmp'),('CLAUDE_CONFIG_DIR','private-client-state')]:
    p=jobroot/name;p.mkdir(exist_ok=True);env[key]=str(p)
requests=[]
class Handler(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        requests.append({'method':'POST','path':self.path.split('?')[0]});self.send_response(503);self.end_headers()
    def do_GET(self):
        requests.append({'method':'GET','path':self.path.split('?')[0]});self.send_response(503);self.end_headers()
    def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
env.update({'DISABLE_TELEMETRY':'1','DISABLE_ERROR_REPORTING':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','DO_NOT_TRACK':'1','CI':'1','NO_COLOR':'1','ANTHROPIC_API_KEY':'invalid-owned-fixture-no-real-key','ANTHROPIC_BASE_URL':f'http://127.0.0.1:{server.server_port}'})
callback=jobroot/"callback space ' \u03c0.cjs"
callback.write_text('''const fs=require('node:fs'); let b=[];let n=0;process.stdin.on('data',x=>{n+=x.length;if(n>65536)process.exit(9);b.push(x)});process.stdin.on('end',()=>{const v=JSON.parse(Buffer.concat(b));const r={event:v.hook_event_name,source:v.source,trigger:v.trigger,cwd:v.cwd,keys:Object.keys(v).sort(),argv:process.argv.slice(2)};fs.writeFileSync(process.argv[3],JSON.stringify(r));});''',encoding='utf-8')
settings=jobroot/'settings.json';markers={}
hooks={}
for event,matcher,label in [('Setup','init','setup'),('SessionStart','startup','session-start')]:
    marker=jobroot/(label+'.json');markers[label]=marker
    hooks[event]=[{'matcher':matcher,'hooks':[{'type':'command','command':str(node),'args':[str(callback),label,str(marker)],'timeout':10}]}]
settings.write_text(json.dumps({'hooks':hooks}),encoding='utf-8');(out/'settings.json').write_bytes(settings.read_bytes())
reviewed=Path(os.environ['TEMP'])/'ci-r6-claude-file-live.py';text=reviewed.read_text();start=text.index("k=ctypes.WinDLL(");end=text.index("result={'fixtureRoot'")
runner=text[start:end];(out/'reviewed-runner.py').write_text(runner,encoding='utf-8');exec(compile(runner,str(reviewed)+'[reviewed runner only]','exec'))
result={'fixtureRoot':str(jobroot),'clientSha256':sha(client),'nodeSha256':sha(node),'reviewedRunnerSha256':hashlib.sha256(runner.encode()).hexdigest(),'modelTurnRequested':False,'accountLoginRequested':False,'userConfigurationSelected':False,'settingsSha256':sha(settings)}
try:
    run('actual-init-only',[client,'--setting-sources','','--settings',settings,'--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--init-only'],timeout=60)
    result['markers']={label:json.loads(path.read_bytes()) for label,path in markers.items()}
    for label,marker in result['markers'].items():
        assert marker['cwd']==str(cwd) and marker['argv']==[label,str(markers[label])]
    assert result['markers']['setup']['event']=='Setup' and result['markers']['setup']['trigger']=='init'
    assert result['markers']['session-start']['event']=='SessionStart' and result['markers']['session-start']['source']=='startup'
    assert source.read_bytes()==source_bytes and sha(settings)==result['settingsSha256']
    assert requests==[]
    result['completed']=True
except BaseException as error:
    result.update(completed=False,errorType=type(error).__name__,error=str(error));raise
finally:
    server.shutdown();server.server_close();thread.join(timeout=5)
    result.update(commands=rows,providerRequests=requests,sourceBytesUnchanged=source.read_bytes()==source_bytes)
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result),flush=True)
