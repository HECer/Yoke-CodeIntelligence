from pathlib import Path
import subprocess,json,hashlib,shutil
p=Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence');w=p.parent/'Yoke-CI-r6-session-hooks';raw=p/'validation/integration-20261018/r6-session-hooks';read=lambda f:json.loads(f.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
c=read(raw/'contracts-r1/result.json');assert c['allChecksPassed'] and c['sourceUnchanged'];v=read(raw/'contracts-r1/source-after.json');assert all(sha(w/n)==h for n,h in v.items());assert read(raw/'secondary-cli-r1/result.json')['completed']
run=lambda root,*args:subprocess.check_output(['git',*args],cwd=root).decode().strip()
assert not run(p,'status','--porcelain');assert run(p,'rev-parse','HEAD')=='6bd1b67c06ea8204521d32a7f9a571b6491dc9c3'==run(w,'rev-parse','HEAD')
out=raw/'cross-checkout-r1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
names=['native/src/host_config.rs','native/src/host_install.rs','native/src/host_install_adapter.rs','native/src/host_install_cli.rs','native/src/host_output_recovery_tests.rs','native/src/main.rs','native/src/host_config_claude_hooks.rs','native/src/host_install_claude_hooks.rs','native/src/claude_session_start_cli.rs','native/tests/claude_session_hooks.rs','native/docs/claude-session-hooks.md']
changed=set(subprocess.check_output(['git','diff','--name-only','-z'],cwd=w).decode().strip('\0').split('\0'))|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=w).decode().strip('\0').split('\0'));assert changed==set(names),(changed,set(names))
paths=out/'exact-paths.nul';paths.write_bytes(b'\0'.join(n.encode() for n in names)+b'\0')
subprocess.run(['git','-c','core.autocrlf=false','add','-f','--pathspec-from-file='+str(paths),'--pathspec-file-nul'],cwd=w,check=True)
subprocess.run(['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=w,check=True)
subprocess.run(['git','commit','-m','feat: add explicit Claude SessionStart host settings'],cwd=w,check=True);commit=run(w,'rev-parse','HEAD');assert not run(w,'status','--porcelain')
subprocess.run(['git','-c','core.autocrlf=false','cherry-pick','--ff',commit],cwd=p,check=True)
assert all(sha(p/n)==h for n,h in v.items());assert run(p,'rev-parse','HEAD')==commit and not run(p,'status','--porcelain')
fixture=p/'native/tests/fixtures/postgres-catalog-response.jsonl';assert fixture.stat().st_size==2779 and sha(fixture)=='f67a05349a6cedf55222afd3bb3231c169d382dd4b078d76544daac517530b47'
result={'sourceCommit':commit,'auxiliaryInputs':len(v),'allValidatedInputsByteExact':True,'changedPaths':names,'primaryClean':True,'secondaryClean':True,'protectedFixtureUnchanged':True,'mainMerged':False,'releasePublished':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
