const ts=require('C:/Users/Lomi/Documents/NN-Developed/Yoke-CodeIntelligence/node_modules/typescript/lib/typescript.js');
const texts={'probe.ts':`interface Service {run(v:string):string;} interface Extra extends Service {extra:true;}
class Box<T>{constructor(public value:T){}run(v:T):T{return v;}clone():Box<T>{return this;}}
type Text=Box<string>;type Both=Box<string>|Box<number>;type Extended=Box<string>&{extra:true};
const a=new Box('x');const b:Box<number>=new Box(1);let text!:Text;let both!:Both;let extended!:Extended;
class Phantom<T>{run(v:string){return v;}}let phantom!:Phantom<number>;
function typed(x:Text){return x.run('x');}
`, 'probe.js':`/** @template T */
class JsBox {
/** @param {T} value */
constructor(value){this.value=value;}
/**
 * @param {T} v
 * @returns {T}
 */
run(v){return v;}
}
const jsbox=new JsBox('j');
`};
const options={strict:true,types:[],noEmit:true,allowJs:true,checkJs:true,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS};const host=ts.createCompilerHost(options),get=host.getSourceFile.bind(host),sources=new Map(Object.entries(texts).map(([name,text])=>[name,ts.createSourceFile(name,text,ts.ScriptTarget.Latest,true,name.endsWith('.js')?ts.ScriptKind.JS:ts.ScriptKind.TS)]));host.getSourceFile=(name,v,...rest)=>sources.get(name)||get(name,v,...rest);const program=ts.createProgram([...sources.keys()],options,host),checker=program.getTypeChecker();
const diagnostics=ts.getPreEmitDiagnostics(program).map(d=>ts.flattenDiagnosticMessageText(d.messageText,' '));console.log(JSON.stringify({version:ts.version,diagnostics}));if(diagnostics.length)process.exitCode=1;
const classes=new Map();let service,extra;
for(const sf of sources.values()){function walk(n){if(ts.isClassDeclaration(n)&&n.name){const s=checker.getSymbolAtLocation(n.name),t=checker.getDeclaredTypeOfSymbol(s);classes.set(s,n);console.log(JSON.stringify({class:n.name.text,declaredParameters:t.typeParameters?.map(t=>checker.typeToString(t)),syntaxParameters:n.typeParameters?.length}));}if(ts.isInterfaceDeclaration(n)){if(n.name.text==='Service')service=checker.getTypeAtLocation(n);if(n.name.text==='Extra')extra=checker.getTypeAtLocation(n);}ts.forEachChild(n,walk);}walk(sf);}
for(const sf of sources.values()){function walk(n){if(ts.isTypeNode(n)||ts.isNewExpression(n)||(ts.isVariableDeclaration(n)&&ts.isIdentifier(n.name))){const node=ts.isVariableDeclaration(n)?n.name:n,type=checker.getTypeAtLocation(node),parts=[];function part(t){if(t.isUnionOrIntersection()){for(const x of t.types)part(x);}else if((t.flags&ts.TypeFlags.Object)&&(t.objectFlags&ts.ObjectFlags.Reference)&&classes.has(t.getSymbol()))parts.push(t);}part(type);for(const t of parts){const args=checker.getTypeArguments(t);if(args.length)console.log(JSON.stringify({anchor:node.getText(),syntax:ts.SyntaxKind[node.kind],observed:checker.typeToString(type),classType:checker.typeToString(t),owner:classes.get(t.getSymbol()).name.text,args:args.map(a=>({display:checker.typeToString(a),flags:a.flags})),assignableService:checker.isTypeAssignableTo(type,service),assignableExtra:checker.isTypeAssignableTo(type,extra)}));}}ts.forEachChild(n,walk);}walk(sf);}
