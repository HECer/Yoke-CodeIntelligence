// Standalone comparison peer, not the application HTTP implementation.
// This fixture tests only the copied test's stimulus and wall-clock logic.
use std::{
    io::{Read, Write},
    net::{SocketAddr, TcpListener, TcpStream},
    sync::{Arc, atomic::{AtomicBool, AtomicUsize, Ordering}},
    thread::{self, JoinHandle},
    time::{Duration, Instant},
};

struct Config { request_timeout_ms: u64 }
fn config() -> Config { Config { request_timeout_ms: 120 } }
fn options() {}

struct Fixture {
    address: SocketAddr,
    stop: Arc<AtomicBool>,
    handle: Option<JoinHandle<()>>,
}
impl Fixture {
    fn new(config: Config, _: ()) -> Self {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let address = listener.local_addr().unwrap();
        listener.set_nonblocking(true).unwrap();
        let stop = Arc::new(AtomicBool::new(false));
        let stopping = stop.clone();
        let handle = thread::spawn(move || {
            let mode = std::env::var("OWNED_PEER_MODE").unwrap();
            let mut requests = Vec::new();
            while !stopping.load(Ordering::SeqCst) {
                match listener.accept() {
                    Ok((mut socket, _)) => {
                        socket.set_nonblocking(false).unwrap();
                        assert!(requests.len() < 3);
                        let mode = mode.clone();
                        let timeout = Duration::from_millis(config.request_timeout_ms);
                        requests.push(thread::spawn(move || {
                            let started = Instant::now();
                            let deadline = if mode == "early" { Duration::from_millis(80) } else { timeout };
                            if mode == "reply" {
                                socket.write_all(b"HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\n\r\n").unwrap();
                                return;
                            }
                            loop {
                                let remaining = if mode == "renewed" { timeout } else { deadline.saturating_sub(started.elapsed()) };
                                if remaining.is_zero() { break; }
                                socket.set_read_timeout(Some(remaining)).unwrap();
                                let mut byte = [0];
                                match socket.read(&mut byte) {
                                    Ok(0) | Err(_) => break,
                                    Ok(_) => {},
                                }
                            }
                        }));
                    }
                    Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => thread::sleep(Duration::from_millis(1)),
                    Err(error) => panic!("owned peer accept failed: {error}"),
                }
            }
            for request in requests { request.join().unwrap(); }
        });
        Self { address, stop, handle: Some(handle) }
    }
    fn address(&self) -> SocketAddr { self.address }
    // This standalone peer has no database. This placeholder does not qualify
    // the application's durable-record assertion.
    fn records(&self) -> Vec<()> { Vec::new() }
    fn stop(&mut self) {
        self.stop.store(true, Ordering::SeqCst);
        if let Some(handle) = self.handle.take() { handle.join().unwrap(); }
    }
}
impl Drop for Fixture { fn drop(&mut self) { self.stop(); } }

fn owned_drip_pause() {
    static PAUSES: AtomicUsize = AtomicUsize::new(0);
    let first = PAUSES.fetch_add(1, Ordering::SeqCst) == 0;
    let requested = std::env::var("OWNED_FIRST_PAUSE_MS").unwrap();
    let millis = match (first, requested.as_str()) {
        (true, "170") => 170,
        (true, "900") => 900,
        (_, "25" | "170" | "900") => 25,
        _ => panic!("unknown owned pause"),
    };
    thread::sleep(Duration::from_millis(millis));
}

fn continuously_paced_partial_headers(
    successes: &[Option<Duration>; 60],
    connected_at: Duration,
    closed_at: Duration,
    maximum_gap: Duration,
) -> bool {
    let mut previous = connected_at;
    let mut count = 0;
    for &success in successes.iter().flatten() {
        if success > closed_at {
            break;
        }
        let Some(gap) = success.checked_sub(previous) else {
            return false;
        };
        if gap >= maximum_gap {
            return false;
        }
        previous = success;
        count += 1;
    }
    count >= 2
        && closed_at
            .checked_sub(previous)
            .is_some_and(|gap| gap < maximum_gap)
}

#[test]
fn partial_header_stimulus_requires_live_pacing_through_peer_close() {
    let samples = |times: &[u64]| {
        let mut result = [None; 60];
        for (slot, micros) in result.iter_mut().zip(times) {
            *slot = Some(Duration::from_micros(*micros));
        }
        result
    };
    let closed_at = Duration::from_micros(134_255);
    let gap = Duration::from_millis(60);
    assert!(continuously_paced_partial_headers(
        &samples(&[214, 25_000, 50_000, 75_000, 100_000]),
        Duration::from_micros(105),
        closed_at,
        gap,
    ));
    // Retained Darwin trace: the first 25 ms sleep woke at 168.9 ms, after
    // the peer had already closed at 134.3 ms. It proves no continuous peer.
    for times in [
        vec![],
        vec![214],
        vec![214, 168_899],
        vec![214, 25_000, 50_000],
        vec![214, 25_000, 100_000],
        vec![214, 25_000, 85_000, 100_000],
        vec![214, 50_000, 25_000, 100_000],
        vec![70_000, 100_000],
    ] {
        assert!(
            !continuously_paced_partial_headers(
                &samples(&times),
                Duration::from_micros(105),
                closed_at,
                gap,
            ),
            "unproved partial-header pacing: {times:?}"
        );
    }
}

#[test]
fn absolute_request_deadline_stops_a_peer_which_keeps_sending_partial_headers() {
    use std::sync::{
        Arc,
        atomic::{AtomicBool, AtomicUsize, Ordering},
    };
    let request_timeout = Duration::from_millis(120);
    let acceptance_bound = Duration::from_millis(750);
    let mut c = config();
    c.request_timeout_ms = 120;
    let mut f = Fixture::new(c, options());
    // One total acceptance timer covers every connection, writer and join.
    // It starts earlier than the old single-attempt timer and never resets.
    let now = Instant::now();
    let observed_from = now;
    let mut attempts = Vec::with_capacity(3);
    let mut proved = false;
    for attempt in 0..3 {
        let mut read = TcpStream::connect(f.address()).unwrap();
        let connected_at = observed_from.elapsed();
        let remaining = acceptance_bound.saturating_sub(now.elapsed());
        assert!(
            !remaining.is_zero(),
            "acceptance budget exhausted: {attempts:?}"
        );
        read.set_read_timeout(Some(remaining)).unwrap();
        let mut write = read.try_clone().unwrap();
        let stop = Arc::new(AtomicBool::new(false));
        let stopping = stop.clone();
        let sent = Arc::new(AtomicUsize::new(0));
        let count = sent.clone();
        let spawn_started_at = observed_from.elapsed();
        let drip = std::thread::spawn(move || {
            // Fixed thread-owned observations; no observer lock or I/O.
            let entered_at = observed_from.elapsed();
            let mut first_two_writes = [(None, None, None); 2];
            let mut successes = [None; 60];
            let mut write_error = None;
            let mut stop_observed = None;
            let mut last_wake_at = None;
            for (write_attempt, success_slot) in successes.iter_mut().enumerate() {
                if stopping.load(Ordering::SeqCst) {
                    stop_observed = Some((write_attempt + 1, observed_from.elapsed()));
                    break;
                }
                if let Some((attempt_at, _, _)) = first_two_writes.get_mut(write_attempt) {
                    *attempt_at = Some(observed_from.elapsed());
                }
                if let Err(error) = write.write_all(b"P") {
                    write_error = Some((write_attempt + 1, observed_from.elapsed(), error.kind()));
                    break;
                }
                count.fetch_add(1, Ordering::SeqCst);
                let success_at = observed_from.elapsed();
                *success_slot = Some(success_at);
                if let Some((_, first_success_at, _)) = first_two_writes.get_mut(write_attempt) {
                    *first_success_at = Some(success_at);
                }
                owned_drip_pause();
                let woke_at = observed_from.elapsed();
                last_wake_at = Some(woke_at);
                if let Some((_, _, wake)) = first_two_writes.get_mut(write_attempt) {
                    *wake = Some(woke_at);
                }
            }
            (
                successes,
                (
                    ("entry", entered_at),
                    ("first-two-attempt-success-wake", first_two_writes),
                    ("write-error-attempt-time-kind", write_error),
                    ("stop-attempt-time", stop_observed),
                    ("last-wake", last_wake_at),
                    ("return", observed_from.elapsed()),
                ),
            )
        });
        let mut wire = Vec::new();
        let read_started_at = observed_from.elapsed();
        let read_outcome = read.read_to_end(&mut wire).map_err(|error| error.kind());
        let read_completed_at = observed_from.elapsed();
        stop.store(true, Ordering::SeqCst);
        let stop_requested_at = observed_from.elapsed();
        let join_started_at = observed_from.elapsed();
        let joined = drip.join();
        let join_completed_at = observed_from.elapsed();
        let client_phases = [
            ("connect-return", connected_at),
            ("spawn-entry", spawn_started_at),
            ("read-entry", read_started_at),
            ("read-return", read_completed_at),
            ("stop-request", stop_requested_at),
            ("join-entry", join_started_at),
            ("join-return", join_completed_at),
        ];
        assert!(
            joined.is_ok(),
            "writer panicked; elapsed={:?}; response_bytes={}; read_outcome={read_outcome:?}; client_phases={client_phases:?}; attempts={attempts:?}",
            now.elapsed(),
            wire.len()
        );
        let (successes, writer) = joined.unwrap();
        let sent = sent.load(Ordering::SeqCst);
        let stimulated = continuously_paced_partial_headers(
            &successes,
            connected_at,
            read_completed_at,
            request_timeout / 2,
        );
        let clean_close = read_outcome == Ok(0) && wire.is_empty();
        let request_age = read_completed_at.saturating_sub(connected_at);
        attempts.push((
            sent,
            read_outcome,
            wire.len(),
            client_phases,
            writer,
            successes,
        ));
        // Retry only a clean, non-early close whose writer failed to provide
        // continuous traffic. No functional failure or exhausted wall budget
        // can retry. At most one writer exists at a time; all joins count.
        if !stimulated
            && clean_close
            && request_age >= request_timeout
            && attempt < 2
            && now.elapsed() + request_timeout < acceptance_bound
        {
            continue;
        }
        assert!(clean_close, "partial-header close failed: {attempts:?}");
        assert!(sent >= 2, "insufficient writes: {attempts:?}");
        assert!(
            stimulated,
            "continuous peer was not established: {attempts:?}"
        );
        assert!(
            now.elapsed() < acceptance_bound,
            "elapsed={:?}; attempts={attempts:?}",
            now.elapsed()
        );
        proved = true;
        break;
    }
    assert!(proved, "no qualified partial-header attempt: {attempts:?}");
    assert!(
        f.records().is_empty(),
        "unexpected durable ingress: {attempts:?}"
    );
    f.stop();
}
