"""Local owned Edge startup diagnostic only; no Yoke image or dashboard.

Reuse the browser parent's exact Job runner, shortening its worker deadline
from 180 to 20 seconds. Every original link/output/disk/cleanup guard remains.
The companion driver is the unchanged CDP class plus a fixed about:blank trial.
"""
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
CONTROL = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("owned_browser", ROOT / "scripts/host_history_browser.py")
BROWSER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BROWSER)


def runner():
    tree = ast.parse((ROOT / "scripts/host_history_browser.py").read_text(encoding="utf-8"))
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "bounded_worker")
    changed = copy.deepcopy(function)
    slots = [node for node in ast.walk(changed) if isinstance(node, ast.Constant) and node.value == 180]
    BROWSER.require(len(slots) == 1, "Original worker deadline changed")
    slots[0].value = 20
    check = copy.deepcopy(changed)
    next(node for node in ast.walk(check) if isinstance(node, ast.Constant) and node.value == 20).value = 180
    BROWSER.require(ast.dump(function) == ast.dump(check), "Unexpected runner difference")
    namespace = dict(vars(BROWSER), __file__=str(Path(__file__).resolve()))
    exec(compile(ast.Module(body=[changed], type_ignores=[]), "owned shortened runner", "exec"), namespace)
    return namespace["bounded_worker"]


def inventory(root):
    """Metadata only, never follow a junction or inspect any target."""
    stack, count, total, links = [root], 0, 0, []
    end = time.monotonic() + 5
    while stack:
        BROWSER.require(time.monotonic() < end, "Metadata inventory deadline")
        with os.scandir(stack.pop()) as entries:
            for entry in entries:
                count += 1
                BROWSER.require(count <= 1024 and time.monotonic() < end, "Metadata inventory capacity")
                path = Path(entry.path)
                if path.is_symlink() or path.is_junction():
                    reason = BROWSER.LIVE.EvidenceLinkRefusal(root, path,
                              "symlink" if path.is_symlink() else "junction")
                    links.append({"kind": reason.kind, "depth": reason.depth, "area": reason.area,
                                  "route": reason.route, "componentSha256": reason.component_sha256})
                elif entry.is_dir(follow_symlinks=False):
                    stack.append(path)
                elif entry.is_file(follow_symlinks=False):
                    total += entry.stat(follow_symlinks=False).st_size
                    BROWSER.require(total <= BROWSER.MAX_OUTPUT, "Metadata byte capacity")
    return {"entries": count, "fileBytes": total, "links": links}


def worker(path):
    spec = BROWSER.read_json(path)
    BROWSER.require(set(spec) == {"job", "node", "edge", "fixture", "output"}, "Closed probe spec")
    BROWSER.LIVE.require_worker_job(spec["job"])
    fixture, output = (BROWSER.plain_path(spec[key]) for key in ("fixture", "output"))
    BROWSER.require(path == fixture / "spec.json" and output == CONTROL / "evidence", "Probe layout")
    node = BROWSER.preflight_node_path(spec["node"])
    edge = BROWSER.plain_path(spec["edge"])
    BROWSER.require(edge in BROWSER.EDGES and edge.is_file(), "Fixed installed Edge required")
    with (output / "driver.stdout").open("xb") as stdout, (output / "driver.stderr").open("xb") as stderr:
        process = subprocess.Popen([str(node), str(CONTROL / "driver.cjs"), str(edge)],
                                   cwd=fixture, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        code = process.wait(timeout=16)
    BROWSER.require(code == 0, "Owned Edge startup failed")


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "--worker":
        return worker(Path(sys.argv[2]))
    BROWSER.require(len(sys.argv) == 1 and os.name == "nt", "Local fixed Windows probe only")
    BROWSER.require(shutil.disk_usage(ROOT).free >= BROWSER.MIN_FREE, "Original disk reserve")
    output = CONTROL / "evidence"
    BROWSER.plain_path(output, exists=False).mkdir()
    fixture = Path(tempfile.mkdtemp(prefix="yoke-owned-history-browser-startup-")).resolve()
    node = BROWSER.preflight_node_path(Path(shutil.which("node.exe")))
    edge = next(path for path in BROWSER.EDGES if path.is_file())
    environment = {key: os.environ[key] for key in ("PATH", "SystemRoot", "SystemDrive", "WINDIR")}
    environment.update(BROWSER.private_profile_environment(fixture))
    environment.update(PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1", DO_NOT_TRACK="1")
    job = "Local\\YokeHistoryCI-" + os.urandom(32).hex()
    spec = fixture / "spec.json"
    BROWSER.write_json(spec, {"job": job, "node": str(node), "edge": str(edge),
                             "fixture": str(fixture), "output": str(output)})
    report = {"diagnosticOnly": True, "nativeAcceptance": False, "dashboardAcceptance": False,
              "nativeYokeImageReadOrExecuted": False, "fixture": str(fixture),
              "runnerOnlyDifference": "180-second worker deadline shortened to 20 seconds",
              "driverSha256": hashlib.sha256((CONTROL / "driver.cjs").read_bytes()).hexdigest()}
    try:
        runner()(spec, fixture, output, environment, job)
        report["startupComplete"] = True
    except Exception as error:
        report.update(startupComplete=False, errorType=type(error).__name__)
    # Mandatory runner cleanup has already completed or refused. Never traverse
    # a still-active tree, even for metadata-only observations.
    receipt = BROWSER.read_json(output / "job.json")
    report["job"] = receipt
    if receipt.get("activeAfterCleanup") == 0:
        try:
            report["metadata"] = inventory(fixture)
        except RuntimeError as error:
            report["inventoryRefusal"] = str(error)
    BROWSER.write_json(output / "result.json", report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
