// Standalone comparison peer, not the application HTTP implementation.
// This fixture tests only the copied test's stimulus and wall-clock logic.
use std::{
    io::{Read, Write},
    net::{SocketAddr, TcpListener, TcpStream},
    sync::{Arc, atomic::{AtomicBool, AtomicUsize, Ordering}},
    thread::{self, JoinHandle},
    time::{Duration, Instant},
};

struct Config { request_timeout_ms: u64 }
fn config() -> Config { Config { request_timeout_ms: 120 } }
fn options() {}

struct Fixture {
    address: SocketAddr,
    stop: Arc<AtomicBool>,
    handle: Option<JoinHandle<()>>,
}
impl Fixture {
    fn new(config: Config, _: ()) -> Self {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let address = listener.local_addr().unwrap();
        listener.set_nonblocking(true).unwrap();
        let stop = Arc::new(AtomicBool::new(false));
        let stopping = stop.clone();
        let handle = thread::spawn(move || {
            let mode = std::env::var("OWNED_PEER_MODE").unwrap();
            let mut requests = Vec::new();
            while !stopping.load(Ordering::SeqCst) {
                match listener.accept() {
                    Ok((mut socket, _)) => {
                        socket.set_nonblocking(false).unwrap();
                        assert!(requests.len() < 3);
                        let mode = mode.clone();
                        let timeout = Duration::from_millis(config.request_timeout_ms);
                        requests.push(thread::spawn(move || {
                            let started = Instant::now();
                            let deadline = if mode == "early" { Duration::from_millis(80) } else { timeout };
                            if mode == "reply" {
                                socket.write_all(b"HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\n\r\n").unwrap();
                                return;
                            }
                            loop {
                                let remaining = if mode == "renewed" { timeout } else { deadline.saturating_sub(started.elapsed()) };
                                if remaining.is_zero() { break; }
                                socket.set_read_timeout(Some(remaining)).unwrap();
                                let mut byte = [0];
                                match socket.read(&mut byte) {
                                    Ok(0) | Err(_) => break,
                                    Ok(_) => {},
                                }
                            }
                        }));
                    }
                    Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => thread::sleep(Duration::from_millis(1)),
                    Err(error) => panic!("owned peer accept failed: {error}"),
                }
            }
            for request in requests { request.join().unwrap(); }
        });
        Self { address, stop, handle: Some(handle) }
    }
    fn address(&self) -> SocketAddr { self.address }
    // This standalone peer has no database. This placeholder does not qualify
    // the application's durable-record assertion.
    fn records(&self) -> Vec<()> { Vec::new() }
    fn stop(&mut self) {
        self.stop.store(true, Ordering::SeqCst);
        if let Some(handle) = self.handle.take() { handle.join().unwrap(); }
    }
}
impl Drop for Fixture { fn drop(&mut self) { self.stop(); } }

fn owned_drip_pause() {
    static PAUSES: AtomicUsize = AtomicUsize::new(0);
    let first = PAUSES.fetch_add(1, Ordering::SeqCst) == 0;
    let requested = std::env::var("OWNED_FIRST_PAUSE_MS").unwrap();
    let millis = match (first, requested.as_str()) {
        (true, "170") => 170,
        (true, "900") => 900,
        (_, "25" | "170" | "900") => 25,
        _ => panic!("unknown owned pause"),
    };
    thread::sleep(Duration::from_millis(millis));
}
