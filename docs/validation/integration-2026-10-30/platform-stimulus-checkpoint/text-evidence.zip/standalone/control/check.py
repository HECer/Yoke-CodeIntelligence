"""Fresh std-only Rust comparison, never a Yoke producer or acceptance run."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
CONTROL = Path(__file__).resolve().parent
LOADER = importlib.util.spec_from_file_location("owned_edge_probe", ROOT / "validation/browser-profile-startup-probe-20261030/probe.py")
PROBE = importlib.util.module_from_spec(LOADER)
LOADER.loader.exec_module(PROBE)
BROWSER = PROBE.BROWSER
TOOLCHAIN = Path("C:/Users/Lomi/.rustup/toolchains/1.94.1-x86_64-pc-windows-msvc/bin")
OUTPUT = CONTROL / "evidence-content-ie5-lld"


def worker(spec_path):
    spec = BROWSER.read_json(spec_path)
    BROWSER.require(set(spec) == {"job", "fixture", "output"}, "Closed comparison spec")
    BROWSER.LIVE.require_worker_job(spec["job"])
    fixture, output = (BROWSER.plain_path(spec[key]) for key in ("fixture", "output"))
    BROWSER.require(spec_path == fixture / "spec.json" and output == OUTPUT, "Comparison layout")
    source = fixture / "src/lib.rs"
    source_hash = BROWSER.sha(source)
    environment = dict(os.environ)
    environment.update(PATH=str(TOOLCHAIN) + os.pathsep + os.environ["PATH"],
                       RUSTC=str(TOOLCHAIN / "rustc.exe"), CARGO_HOME=str(fixture / "cargo-home"),
                       CARGO_TARGET_DIR=str(fixture / "target"), CARGO_NET_OFFLINE="true")
    linker = TOOLCHAIN.parent / "lib/rustlib/x86_64-pc-windows-msvc/bin/rust-lld.exe"
    BROWSER.require(linker.is_file(), "Pinned owned-trial LLD linker unavailable")
    environment["CARGO_ENCODED_RUSTFLAGS"] = "\x1f".join(["-C", "linker=" + str(linker), "-C", "link-arg=/DEBUG:NONE"])
    command = [str(TOOLCHAIN / "cargo.exe"), "test", "--no-run", "--offline", "--message-format=json"]
    with (output / "compile.stdout").open("xb") as stdout, (output / "compile.stderr").open("xb") as stderr:
        process = subprocess.Popen(command, cwd=fixture, env=environment,
                                   stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        BROWSER.require(process.wait(timeout=12) == 0, "Owned standalone compilation failed")
    raw = (output / "compile.stdout").read_bytes()
    BROWSER.require(len(raw) <= 1_000_000, "Compiler metadata capacity")
    artifacts = [row for row in map(json.loads, raw.splitlines())
                 if row.get("reason") == "compiler-artifact" and row.get("executable")]
    BROWSER.require(len(artifacts) == 1 and artifacts[0]["target"]["name"] == "owned_ingress_stimulus"
                    and artifacts[0]["profile"]["test"] is True, "Fresh owned producer required")
    image = BROWSER.plain_path(artifacts[0]["executable"])
    BROWSER.require(image.parent == fixture / "target/debug/deps" and image.name.startswith("owned_ingress_stimulus-")
                    and image.suffix == ".exe" and 0 < image.stat().st_size <= 16_000_000,
                    "Only this fresh standalone image may run")
    image_hash = BROWSER.sha(image)
    rows = []
    for label, mode, pause, expected in [("paced", "absolute", "25", 0),
            ("rescheduled", "absolute", "170", 0), ("renewed-deadline", "renewed", "25", 101),
            ("exhausted-wall-budget", "absolute", "900", 101),
            ("invalid-response", "reply", "170", 101), ("early-unpaced-close", "early", "170", 101)]:
        environment.update(OWNED_PEER_MODE=mode, OWNED_FIRST_PAUSE_MS=pause)
        with (output / (label + ".stdout")).open("xb") as stdout, (output / (label + ".stderr")).open("xb") as stderr:
            process = subprocess.Popen([str(image), "--test-threads=1"], cwd=fixture, env=environment,
                                       stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                       creationflags=subprocess.CREATE_NO_WINDOW)
            code = process.wait(timeout=3)
        text = (output / (label + ".stdout")).read_text(encoding="utf-8")
        BROWSER.require(code == expected and ("2 passed; 0 failed" if expected == 0 else "1 passed; 1 failed") in text,
                        "Standalone comparison outcome differs: " + label)
        rows.append({"trial": label, "exitCode": code, "expectedExitCode": expected})
    BROWSER.require(BROWSER.sha(image) == image_hash and BROWSER.sha(source) == source_hash, "Owned inputs changed")
    BROWSER.write_json(output / "comparison.json", {"diagnosticOnly": True,
                      "nativeYokeImageReadOrExecuted": False, "nativeAcceptance": False,
                      "ownedStandaloneRustImageExecuted": True, "sourceSha256": source_hash,
                      "imageSha256": image_hash, "trials": rows})


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "--worker":
        return worker(Path(sys.argv[2]))
    BROWSER.require(len(sys.argv) == 1 and os.name == "nt", "Fixed Windows comparison only")
    BROWSER.require(shutil.disk_usage(ROOT).free >= BROWSER.MIN_FREE, "Original disk reserve")
    output = OUTPUT
    BROWSER.plain_path(output, exists=False).mkdir()
    fixture = Path(tempfile.mkdtemp(prefix="yoke-owned-history-browser-stimulus-")).resolve()
    for ancestor in fixture.parents:
        BROWSER.require(not (ancestor / ".cargo/config").exists() and not (ancestor / ".cargo/config.toml").exists(),
                        "Ambient Cargo configuration refused")
    original = (ROOT / "native/tests/github_app_ingress.rs").read_text(encoding="utf-8")
    copied = original[original.index("fn continuously_paced_partial_headers("):original.index("#[test]\nfn unsigned_event_label_cannot_turn_pr_body_into_ping_or_ping_into_pr()")]
    pause = "std::thread::sleep(Duration::from_millis(25));"
    BROWSER.require(copied.count(pause) == 1, "Copied fixture pause changed")
    copied = copied.replace(pause, "owned_drip_pause();")
    (fixture / "src").mkdir()
    (fixture / "src/lib.rs").write_text((CONTROL / "peer.rs").read_text(encoding="utf-8") + "\n" + copied,
                                        encoding="utf-8", newline="\n")
    (fixture / "Cargo.toml").write_text('[package]\nname="owned-ingress-stimulus"\nversion="0.0.0"\nedition="2024"\n[profile.test]\ndebug=0\nincremental=false\n',encoding="utf-8")
    environment = {key: os.environ[key] for key in ("PATH", "SystemRoot", "SystemDrive", "WINDIR")}
    environment.update(BROWSER.private_profile_environment(fixture))
    environment.update(PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1")
    job = "Local\\YokeHistoryCI-" + os.urandom(32).hex()
    spec_path = fixture / "spec.json"
    BROWSER.write_json(spec_path, {"job": job, "fixture": str(fixture), "output": str(output)})
    # The already checked extractor uses this control's __file__ for its child.
    namespace = PROBE.runner().__globals__
    namespace["__file__"] = str(Path(__file__).resolve())
    namespace["bounded_worker"](spec_path, fixture, output, environment, job)
    print(json.dumps(BROWSER.read_json(output / "comparison.json"), indent=2))
    print(json.dumps(BROWSER.read_json(output / "job.json"), indent=2))


if __name__ == "__main__":
    main()
