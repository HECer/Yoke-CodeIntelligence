
from pathlib import Path
import hashlib,json,re,shutil,subprocess
w=Path.cwd();raw=w/'validation/integration-20261018';out=raw/'git-repository-projects-final-audit1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parts=['git-repository-projects-test3','git-repository-projects-qualified1'];results=[json.loads((raw/p/'result.json').read_bytes()) for p in parts];live=json.loads((raw/'git-repository-projects-live1/result.json').read_bytes());assert all(r['complete'] and r['allJobsEmpty'] and r['sourceInputsUnchanged'] for r in results+[live])
inputs=json.loads((raw/parts[0]/'source-before.json').read_bytes());assert len(inputs)==1096 and all(json.loads((raw/p/'source-before.json').read_bytes())==inputs for p in parts);assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
groups=[]
for part in parts:
 for row in json.loads((raw/part/'progress.json').read_bytes()):
  assert row['exitCode']==0 or row['name']=='cargo-fmt-all';assert row['activeAfterCleanup']==0
  if row['name'].startswith('cargo-test-'):
   args=row['command'];group='lib' if '--lib' in args else args[args.index('--test')+1];text=(raw/part/(row['name']+'.stdout')).read_text(encoding='utf8');m=re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(m)==1 and int(m[0][1])==0;groups.append({'group':group,'passed':int(m[0][0]),'failed':int(m[0][1]),'ignored':int(m[0][2]),'evidence':part+'/'+row['name']+'.stdout'})
assert len(groups)==len({r['group'] for r in groups})==40;assert next(r for r in groups if r['group']=='lib')['passed']==578
profiles=json.loads((raw/'git-repository-projects-live1/actual-project-http-and-client.stdout').read_bytes());preceding=json.loads((raw/'git-repository-http-live1/actual-http-all-profiles-and-client.stdout').read_bytes())
for profile in profiles:
 old=next(p for p in preceding if p['profile']==profile['profile']);assert profile['catalogNames']==old['catalogNames'];assert profile['actualSourceCallSucceeded']
first=json.loads((raw/'git-repository-projects-test1/source-before.json').read_bytes());changes=[n for n in first if first[n]!=inputs[n]];assert set(changes)=={'native/tests/git_repository_projects.rs'}
result={**results[-1],'nativeGroupResults':groups,'nativePassed':sum(r['passed'] for r in groups),'nativeFailed':0,'nativeExistingIgnored':sum(r['ignored'] for r in groups),'qualificationParts':parts,'nativeGroups':len(groups),'test1ToFinalChangedInputs':changes,'precedingAllSixProfileCatalogNamesExact':True,'actualClientHealthCalls':12,'liveSourceInputsExact':True,'ordinaryRegisteredSessionStablePayloadAndRecordsExact':live['ordinaryRegisteredSessionStablePayloadAndRecordsExact'],'fullContractCertification':False,'wholeNativeRerun':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['nativeGroupResults','testGroups']}))
