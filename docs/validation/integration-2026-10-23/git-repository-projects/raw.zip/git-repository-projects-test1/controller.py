from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/git-repository-projects-test1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-repository-discovery-check-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe'
prior=json.loads((w/'validation/integration-20261018/git-repository-http-final-audit1/source-before.json').read_bytes())
new=['native/src/git_repository_projects.rs','native/tests/git_repository_projects.rs']
preserved=jobroot/'preceding-yoke.exe';shutil.copyfile(w/'target/debug/yoke.exe',preserved);assert sha(preserved)=='4483d2e3f3fc93d12cb921a4360fcd0d6588e657a38fc10d52c6acc74ffe5713'
run('rustfmt-changed',[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','native/src/lib.rs','native/src/main.rs','native/tests/git_repository_projects.rs'],timeout=120)
inputs={n:sha(w/n) for n in sorted(set(prior)|set(new))};assert len(inputs)==1096
(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());complete=False
groups=['git_repository_projects','git_repository_http','mcp_http','mcp_http_cli','git_repository_profiles','project_session','git_repository_host','git_repository_preferences','git_repository_scope']
try:
 for group in groups:
  run('cargo-test-'+group,[cargo,'test','--locked','-j','2','--test',group,'--','--test-threads=1'],timeout=900)
  assert all(sha(w/n)==h for n,h in inputs.items())
 complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'preservedPublishedCli':str(preserved),'testGroups':groups};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
