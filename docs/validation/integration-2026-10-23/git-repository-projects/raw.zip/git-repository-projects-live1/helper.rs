
use serde_json::{json,Value};
use std::{path::PathBuf,fs,process::Command,io::{Read,Write},net::{SocketAddr,TcpStream},time::Duration};
use yoke::{capture::Deadline,git_workflows::{HostGit,repository_host::Host,repository_projects::Hosts,repository_preferences::Resolved,repository_scope::Options},mcp_http::{self,Target,Principal,Config},project_session::{HostProfile,HostProject},protocol::Profile};
fn post(address:SocketAddr, token:&str, sid:Option<&str>, message:Value)->(u16,std::collections::BTreeMap<String,String>,Value){
 let bytes=serde_json::to_vec(&message).unwrap();let mut stream=TcpStream::connect(address).unwrap();stream.set_read_timeout(Some(Duration::from_secs(60))).unwrap();
 let session=sid.map(|s|format!("Mcp-Session-Id: {s}\r\nMcp-Protocol-Version: 2025-11-25\r\n")).unwrap_or_default();
 write!(stream,"POST /mcp HTTP/1.1\r\nHost: {address}\r\nAuthorization: Bearer {token}\r\nAccept: application/json, text/event-stream\r\nContent-Type: application/json\r\nContent-Length: {}\r\n{session}\r\n",bytes.len()).unwrap();stream.write_all(&bytes).unwrap();
 let mut response=Vec::new();loop{let mut chunk=[0;8192];let n=stream.read(&mut chunk).unwrap();assert!(n>0);response.extend_from_slice(&chunk[..n]);assert!(response.len()<=16_001_000);if let Some(end)=response.windows(4).position(|v|v==b"\r\n\r\n"){let header=std::str::from_utf8(&response[..end]).unwrap();let length:usize=header.split("\r\n").filter_map(|v|v.split_once(':')).find(|(k,_)|k.eq_ignore_ascii_case("content-length")).unwrap().1.trim().parse().unwrap();assert!(length<=16_000_000);if response.len()==end+4+length{break}}}
 let end=response.windows(4).position(|v|v==b"\r\n\r\n").unwrap();let header=std::str::from_utf8(&response[..end]).unwrap();let status=header.split_whitespace().nth(1).unwrap().parse().unwrap();let headers=header.split("\r\n").filter_map(|v|v.split_once(':')).map(|(k,v)|(k.to_ascii_lowercase(),v.trim().to_owned())).collect();let body=serde_json::from_slice(&response[end+4..]).unwrap_or(Value::Null);(status,headers,body)
}
fn main(){
 let a:Vec<_>=std::env::args().skip(1).collect();let root=PathBuf::from(&a[0]);let secondary=PathBuf::from(&a[5]);let git=HostGit{executable:PathBuf::from(&a[1])};let token=fs::read(&a[2]).unwrap();assert_eq!(token.len(),32);let bearer=token.iter().map(|b|format!("{b:02x}")).collect::<String>();let client=PathBuf::from(&a[3]);let config=PathBuf::from(&a[4]);let d=||Deadline::new(30_000);let mut result=Vec::new();
 for (name,profile,count) in [("native",Profile::Native,8),("session",Profile::Session,9),("serena",Profile::Serena,53),("trail",Profile::Trail,6),("graft",Profile::Graft,6),("graphify",Profile::Graphify,10)]{

  let primary=Host::new(&root,git.clone(),Options{allow_index_read:true,..Default::default()},Resolved::current(&root,None,Some(false),&d()).unwrap(),&d()).unwrap();let other=Host::new(&secondary,git.clone(),Options{allow_index_read:true,..Default::default()},Resolved::current(&secondary,None,Some(true),&d()).unwrap(),&d()).unwrap();
  let mut host=HostProfile::default();host.projects.push(HostProject{name:"secondary".into(),root:secondary.clone(),read_only:true,query_only:false});host.source_exclusions=Some(serde_json::from_value(json!({"global":[["excluded.rs"]]})).unwrap());if name=="trail" || name=="graft" {host.startup_project=Some("secondary".into());}
  let selected=Hosts::new(&root,&host,std::collections::BTreeMap::from([("default".into(),primary),("secondary".into(),other)]),&d()).unwrap();let mut target=Target::new(&root,profile,host);target.git_repository_projects=Some(selected);
  let principal=Principal::new("owned-http",token.clone().into(),target).unwrap();let server=mcp_http::serve(Config{request_timeout_ms:30_000,..Default::default()},vec![principal]).unwrap();let address=server.local_addr();
  let initialized=post(address,&bearer,None,json!({"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"owned-http-validation","version":"1"}}}));assert_eq!(initialized.0,200);assert!(initialized.2.get("error").is_none());let sid=initialized.1["mcp-session-id"].clone();assert_eq!(post(address,&bearer,Some(&sid),json!({"jsonrpc":"2.0","method":"notifications/initialized"})).0,202);
  let tools=post(address,&bearer,Some(&sid),json!({"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}));assert_eq!(tools.0,200);assert_eq!(tools.2["result"]["tools"].as_array().unwrap().len(),count);let names:Vec<_>=tools.2["result"]["tools"].as_array().unwrap().iter().map(|t|t["name"].clone()).collect();

  let tool=|id:u64,name:&str,arguments:Value| -> Value {let reply=post(address,&bearer,Some(&sid),json!({"jsonrpc":"2.0","id":id,"method":"tools/call","params":{"name":name,"arguments":arguments}}));assert_eq!(reply.0,200);assert!(reply.2.get("error").is_none());assert_ne!(reply.2["result"]["isError"],true);let payload:Value=serde_json::from_str(reply.2["result"]["content"][0]["text"].as_str().unwrap()).unwrap();assert_eq!(payload["status"],"ok");payload};
  let source_call=match name {
   "native"=>tool(3,"ci_read",json!({"path":"main.rs"})),
   "session"=>tool(3,"ci_session",json!({"operation":"queryProject","args":{"project":"secondary","tool":"ci_read","arguments":{"path":"nested \u{df}/child.rs"}}})),
   "serena"=>{let config=tool(3,"get_current_config",json!({}));let label=config["data"]["sessionId"].as_str().unwrap();let activated=tool(4,"activate_project",json!({"project":"secondary","session_id":label}));assert_eq!(activated["data"]["activeProject"],"secondary");tool(5,"read_file",json!({"relative_path":"nested \u{df}/child.rs"}))},
   "trail"=>tool(3,"trail_find_code",json!({"query":"child_owned","in":"nested \u{df}"})),
   "graft"=>tool(3,"graft_file_api",json!({"file":"nested \u{df}/child.rs"})),
   "graphify"=>{let node=tool(3,"get_node",json!({"label":"child_owned","project_path":secondary}));assert_eq!(node["data"]["found"],true);node},
   _=>unreachable!()
  };assert!(serde_json::to_string(&source_call).unwrap().contains(if name=="native"{"parent_owned"}else{"child_owned"}));
  fs::write(config.join(".mcp.json"),serde_json::to_vec(&json!({"mcpServers":{"yoke_owned_git_http":{"type":"http","url":format!("http://{address}/mcp"),"headers":{"Authorization":format!("Bearer {bearer}")}}}})).unwrap()).unwrap();
  // Client output can contain private HTTP headers. Hold it in memory, record only booleans.
  let get=Command::new(&client).args(["mcp","get","yoke_owned_git_http"]).current_dir(&config).output().unwrap();let text=String::from_utf8_lossy(&get.stdout);let connected=get.status.success()&&text.contains("Connected")&&!text.contains("Failed to connect");assert!(connected,"Actual client did not connect for {name}");
  let list=Command::new(&client).args(["mcp","list"]).current_dir(&config).output().unwrap();assert!(list.status.success());assert!(String::from_utf8_lossy(&list.stdout).contains("Connected"));
  server.shutdown().unwrap();result.push(json!({"profile":name,"catalogCount":count,"actualSourceCallSucceeded":true,"catalogNames":names,"actualPinnedClaudeGetConnected":connected,"actualPinnedClaudeListConnected":true,"clientStdoutAndStderrRetained":false}));
 }
 println!("{}",serde_json::to_string(&result).unwrap());
}
