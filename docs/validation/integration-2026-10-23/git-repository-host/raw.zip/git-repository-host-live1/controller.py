from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/git-repository-host-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-hooks-check-'));source=jobroot/'source';source.mkdir();cwd=w;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','DO_NOT_TRACK':'1','PIP_NO_INPUT':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
import sqlite3
native=w/'target/debug/yoke.exe';git=Path(r'C:\Program Files\Git\cmd\git.exe')
old=Path(json.loads((w/'validation/integration-20261018/git-repository-host-test1/result.json').read_bytes())['preservedPublishedCli'])
assert sha(old)=='337d98b1cbca49d0d5b33587fd8d41927c29438ae1db54c0677d01f5109145a6'
inputs=json.loads((w/'validation/integration-20261018/git-repository-host-test1/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items())
client=Path(r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\claude-2.1.306-win32-x64\claude.exe');assert sha(client)=='f6bc9de38f507c36c9a3bb0085a59a27e32156e2208252bf1707c4e3ef309114'
source=jobroot/("source \u03c0 '");source.mkdir();nested=source/'nested \u00df';nested.mkdir();hooks=jobroot/'empty-hooks';hooks.mkdir()
(source/'main.rs').write_bytes(b'pub fn parent(){}\r\n');(nested/'child.rs').write_bytes(b'pub fn child(){}\r\n')
worker=jobroot/'protocol-worker.py';worker.write_bytes((Path(os.environ['TEMP'])/'ci-git-repository-host-protocol-worker.py').read_bytes());shutil.copyfile(worker,out/'protocol-worker.py')
messages=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25'}},{'jsonrpc':'2.0','method':'notifications/initialized'},{'jsonrpc':'2.0','id':2,'method':'tools/list'},{'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'ci_status','arguments':{'mode':'index','maxBytes':65536,'timeoutMs':60000}}}]
def args(exe=native):return [str(exe),'--root',str(source),'--timeout','60000','--max-bytes','65536']
scoped=[*args(),'git','repository-scope','--capture','--serve','--allow-index-read','--trust-git','--git',str(git)]
def setup(name,root,*values):return run(name,[git,'-C',root,'-c','core.hooksPath='+str(hooks),'-c','user.name=Owned Validation','-c','user.email=owned@example.invalid','-c','commit.gpgSign=false',*values])
def protocol(name,argv):
 spec={'args':argv,'messages':messages,'stdout':str(out/(name+'.native.stdout')),'stderr':str(out/(name+'.native.stderr')),'result':str(out/(name+'.reply.json'))}
 file=jobroot/(name+'.json');file.write_bytes(json.dumps(spec).encode());run(name,[r'C:\Python314\python.exe','-I',worker,file],timeout=120)
 return json.loads((out/(name+'.reply.json')).read_bytes())
def sql():
 with sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True) as db:
  return {n:sorted(db.execute('SELECT * FROM '+n).fetchall(),key=repr) for n in ['snapshots','graphs','records']}
def raw_files():return {p.relative_to(source).as_posix():sha(p) for p in source.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(source).parts}
complete=False;legacy_exact=False;rows_exact=False;files_exact=False;catalog_exact=False;client_connected=False;selected_scope=False
try:
 for name,root,file in [('parent',source,'main.rs'),('nested',nested,'child.rs')]:
  setup('git-init-'+name,root,'init','--quiet','--template=');setup('git-add-'+name,root,'add','--',file);setup('git-commit-'+name,root,'commit','--quiet','-m','Owned fixture')
 original_files=raw_files()
 protocol('old-cold-default',args(old)+['serve']);warm=protocol('old-warm-default',args(old)+['serve']);current=protocol('new-warm-default',args()+['serve']);assert warm['index']['data']==current['index']['data'];legacy_exact=True
 original_rows=sql()
 run('save-nested-choice',args()+['git','repository-preferences','set','--allow-host-writes','--expect','absent','--follow-nested-repositories','true'])
 captured=protocol('explicit-scoped-native',scoped);assert warm['catalog']==current['catalog']==captured['catalog'];catalog_exact=True
 snap=captured['index']['data']['snapshot']['id']
 with sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True) as db:
  record=json.loads(db.execute('SELECT value FROM records WHERE kind=? AND id=?',('native_capture_options_v1',snap)).fetchone()[0])
 assert record['options']['repositoryScope']['readOnlyRoots']==['nested \u00df'];selected_scope=True
 configroot=jobroot/'client-config';configroot.mkdir();(configroot/'.env').write_bytes(b'')
 (configroot/'.mcp.json').write_bytes(json.dumps({'mcpServers':{'yoke_owned_git_scope':{'command':str(native),'args':scoped[1:]}}}).encode())
 private=jobroot/'private-claude';private.mkdir();env['CLAUDE_CONFIG_DIR']=str(private)
 (private/'settings.json').write_bytes(json.dumps({'enabledMcpjsonServers':['yoke_owned_git_scope']}).encode())
 env.update({'DISABLE_TELEMETRY':'1','DISABLE_ERROR_REPORTING':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','CI':'1','NO_COLOR':'1','MCP_TIMEOUT':'20000'})
 reply=run('actual-claude-get',[client,'mcp','get','yoke_owned_git_scope'],expected=None,timeout=60);client_connected=b'Connected' in reply and b'Failed to connect' not in reply;assert client_connected
 run('actual-claude-list',[client,'mcp','list'],expected=None,timeout=60)
 final=protocol('new-final-default',args()+['serve']);assert final['index']['data']==warm['index']['data'] and final['catalog']==warm['catalog']
 now=sql();assert all(row in now[n] for n,rr in original_rows.items() for row in rr);rows_exact=True
 assert raw_files()==original_files;files_exact=True;assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'fixtureRoot':str(jobroot),'nativeSha256':sha(native),'precedingSha256':sha(old),'clientVersion':'2.1.306','clientSha256':sha(client),'frozenInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'ownedParentProcessCalls':len(rows),'nativeProtocolWorkerChildrenInheritAssignedJob':True,'oldAndNewWarmDefaultDataExact':legacy_exact,'allCatalogsExact':catalog_exact,'originalSnapshotGraphControlRowsExact':rows_exact,'actualPinnedClaudeHealthConnected':client_connected,'capturedChildReadonlyPolicyObserved':selected_scope,'allSourceAndGitFilesExact':files_exact,'realModelCalls':0,'projectCodeAutomaticallyExecuted':False,'systemSettingsChanged':False}
 (out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
