from pathlib import Path
import json,subprocess,sys
spec=json.loads(Path(sys.argv[1]).read_bytes())
message=''.join(json.dumps(v)+'\n' for v in spec['messages']).encode()
result=subprocess.run(spec['args'],input=message,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
Path(spec['stdout']).write_bytes(result.stdout);Path(spec['stderr']).write_bytes(result.stderr)
assert result.returncode==0,(result.returncode,result.stderr.decode('utf8','replace'))
replies=[json.loads(line) for line in result.stdout.splitlines()]
assert len(replies)==3 and [v.get('id') for v in replies]==[1,2,3],replies
assert replies[0]['result']['protocolVersion']=='2025-11-25'
assert replies[1]['result']['tools']
index=json.loads(replies[2]['result']['content'][0]['text']);assert index['status']=='ok',index
Path(spec['result']).write_bytes(json.dumps({'catalog':replies[1]['result']['tools'],'index':index},indent=2).encode())
print(json.dumps({'nativeExitCode':result.returncode,'receivedReplies':len(replies),'snapshotId':index['data']['snapshot']['id']}))
