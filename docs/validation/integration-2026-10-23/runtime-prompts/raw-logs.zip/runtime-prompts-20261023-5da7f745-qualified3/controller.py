from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/runtime-prompts-20261023-5da7f745-qualified3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')

green=w/'validation/integration-20261018/runtime-prompts-20261023-5da7f745-green2';oldinputs=json.loads((green/'source-before.json').read_bytes());inputs={n:sha(w/n) for n in oldinputs};assert inputs==oldinputs;prior=json.loads((green/'result.json').read_bytes());assert prior['complete'] and prior['allJobsEmpty'] and prior['sourceInputsUnchanged'];(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());assert shutil.disk_usage(w).free>1_200_000_000
native=w/'target/debug/yoke.exe';complete=False;compression=[];commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
env['PATH']=r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\powershell-7.6.7-win-x64'+os.pathsep+env['PATH']
targets=['session_config_discovery', 'session_config_cli', 'session_primary_read_only', 'session_optional_defaults', 'session_steering', 'session_startup_project', 'session_mcp', 'session_memory_patterns', 'server_catalog', 'server_selection', 'server_settings', 'server_workspace_settings', 'lsp_resource_settings', 'source_line_endings', 'source_exclusions', 'project_session', 'session_agent_interface', 'session_inclusions', 'session_review', 'session_refactor', 'session_root_aliases', 'session_epoch_selection', 'session_dashboard', 'session_collections', 'session_collections_admission', 'agent_repl', 'agent_repl_api_selection', 'agent_repl_lifecycle', 'mcp_http', 'mcp_http_cli', 'mcp_http_review', 'mcp_collection_grants', 'mcp_collection_grants_review', 'compatibility', 'compatibility_review', 'graphify_adapter', 'graphify_cli', 'graphify_selected_queries', 'trail_adapter', 'trail_bodies', 'trail_review', 'semantic_mcp', 'host_mcp_config', 'editor_http']

def owned(name,args,**options):
 with contextlib.redirect_stdout(commandlog):data=run(name,args,**options)
 print(json.dumps({'name':name,'exitCode':rows[-1].get('exitCode'),'activeAfterCleanup':rows[-1]['activeAfterCleanup']}),flush=True);return data
def compact_passed(path,label):
 assert path.is_file() and not path.is_symlink() and path.resolve()!=native.resolve() and path.name not in ['capture_options-784339a4da3fe379.exe','session_fixed_tools-0671ac4d8f474009.exe']
 record={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)};assert shutil.disk_usage(w).free>record['bytes']+64_000_000
 owned('compact-passed-'+label,[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(path)],timeout=90);assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256'];compression.append({**record,'logicalBytesAndSha256Unchanged':True});(out/'compression.json').write_bytes((json.dumps(compression,indent=2)+'\n').encode())
def harness(data,target,kind):
 result=[]
 for line in data.splitlines():
  try:m=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if m.get('reason')=='compiler-artifact' and Path(m['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and m['target']['name']==target and kind in m['target']['kind'] and m['profile']['test'] and m.get('executable'):result.append(Path(m['executable']))
 assert len(result)==1 and result[0].parent.resolve()==(w/'target/debug/deps').resolve();return result[0]

try:
 cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';python=r'C:\Python314\python.exe';helper=[python,'-X','utf8',str(w/'scripts/run_native_tests.py'),'--controlled-test-runner','--locked','--offline']
 def qualify(data,target,kind):
  import re
  result=re.findall(rb'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; 0 filtered out;',data);assert len(result)==1,(target,result)
  if int(result[0][0])==0:return
  exe=harness(data,target,kind);compact_passed(exe,kind+'-'+target)
  for line in data.splitlines():
   try:m=json.loads(line)
   except ValueError:continue
   if m.get('reason')!='compiler-artifact' or Path(m['manifest_path']).resolve()!=(w/'native/Cargo.toml').resolve() or m.get('executable')!=str(exe) or not m['profile']['test']:continue
   for filename in m['filenames']:
    path=Path(filename)
    if path.suffix=='.pdb':
     exe_hash=sha(exe);compact_passed(path,kind+'-'+target+'-pdb');assert sha(exe)==exe_hash;compression[-1].update({'associatedPassedExecutable':str(exe),'associatedPassedExecutableSha256':exe_hash,'explicitCargoPdbArtifactAndPositiveWholeHarness':True});(out/'compression.json').write_text(json.dumps(compression,indent=2)+'\n')
 priorq=w/'validation/integration-20261018/runtime-prompts-20261023-5da7f745-qualified1';old=json.loads((priorq/'result.json').read_bytes());assert not old['complete'] and old['allJobsEmpty'] and old['sourceInputsUnchanged'];assert inputs==json.loads((priorq/'source-before.json').read_bytes())
 for target in targets[:5]:
  data=(priorq/('test-'+target+'.stdout')).read_bytes();import re
  assert re.search(rb'test result: ok\. \d+ passed; 0 failed; \d+ ignored; 0 measured; 0 filtered out;',data)
 prior2=w/'validation/integration-20261018/runtime-prompts-20261023-5da7f745-qualified2';prior2result=json.loads((prior2/'result.json').read_bytes());assert not prior2result['complete'] and prior2result['allJobsEmpty'] and prior2result['sourceInputsUnchanged'];assert inputs==json.loads((prior2/'source-before.json').read_bytes())
 for label in ['test-'+target for target in targets[5:]]+['library-all','main-all']:
  data=(prior2/(label+'.stdout')).read_bytes();assert re.search(rb'test result: ok\. \d+ passed; 0 failed; \d+ ignored; 0 measured; 0 filtered out;',data)
 # Explicit fresh output avoids both protected default session_fixed_tools files.
 fresh=w/'target/debug/deps/session_fixed_tools-runtime-prompts-20261023-5da7f745.exe';assert not fresh.exists() and not fresh.with_suffix('.pdb').exists()
 protected_paths=[w/'target/debug/deps'/n for n in ['capture_options-784339a4da3fe379.exe','capture_options-784339a4da3fe379.pdb','session_fixed_tools-0671ac4d8f474009.exe','session_fixed_tools-0671ac4d8f474009.pdb']]
 def metadata_only(path):
  if not path.exists():return None
  st=path.stat();return [st.st_size,st.st_mtime_ns,getattr(st,'st_file_attributes',0)]
 protected={str(p):metadata_only(p) for p in protected_paths};(out/'protected-default-output-before.json').write_text(json.dumps(protected,indent=2)+'\n')
 owned('compile-fixed-tools-fresh',[cargo,'rustc','--manifest-path',str(w/'native/Cargo.toml'),'--profile','test','--locked','--offline','--test','session_fixed_tools','-j','1','--message-format','json','--','-C','extra-filename=-runtime-prompts-20261023-5da7f745'],timeout=600)
 assert fresh.is_file();assert all(metadata_only(Path(p))==m for p,m in protected.items())
 oldcwd=cwd;cwd=w/'native'
 try:data=owned('fixed-tools-fresh',[fresh,'--test-threads=1'],timeout=600)
 finally:cwd=oldcwd
 import re
 summary=re.findall(rb'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; 0 filtered out;',data);assert len(summary)==1 and int(summary[0][0])>0
 assert all(metadata_only(Path(p))==m for p,m in protected.items())
 (out/'protected-default-output-metadata.json').write_text(json.dumps({'beforeAndAfterMetadataExact':True,'defaultContentNeverReadOrHashed':True,'paths':protected,'freshExecutable':str(fresh),'freshWholeHarnessSummary':list(map(int,summary[0]))},indent=2)+'\n')
 owned('format-complete',[python,'-X','utf8','scripts/native_fmt.py','--check'],timeout=600)
 owned('debug-build',[cargo,'build','--workspace','--locked','--offline','-j','1','--message-format','json'],timeout=600)
 owned('cli-version',[native,'--version'],timeout=30)
 owned('python-all',[python,'-X','utf8','-m','unittest','discover','-s','scripts/tests','-v'],timeout=300)
 npm=shutil.which('npm.cmd');assert npm
 owned('npm-typecheck',[os.environ['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
 owned('npm-test',[os.environ['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'sourceCommitBeforeFeature':'5da7f7453b5c39946efb6617f4f52fe5cf8d423f','reusedExactSourceWholeGroups':['session_prompt_runtime','session_config_prompt_catalogs','session_config_templates'],'clippyAllTargetsReusedExactSourceFromGreen2':True,'reusedExactSourceWholeGroupsFromQualified1':targets[:5],'sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'currentCliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'reusedExactSourceWholeGroupsFromQualified2':targets[5:]+['library-all','main-all'],'targets':targets,'freeBytes':shutil.disk_usage(w).free};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
