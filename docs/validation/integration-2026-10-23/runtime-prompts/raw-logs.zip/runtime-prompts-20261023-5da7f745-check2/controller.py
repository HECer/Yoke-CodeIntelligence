from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/runtime-prompts-20261023-5da7f745-check2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))



inputs=json.loads((w/'validation/integration-20261018/catalogs-20261023-6d04f481-qualified1/source-before.json').read_bytes())
for n in ['native/src/session_prompt.rs','native/src/session_prompt_catalog.rs','native/src/session_prompt_markers.json']:inputs[n]=''
inputs={n:sha(w/n) for n in inputs};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');complete=False;native=w/'target/debug/yoke.exe';backup=w/'target/runtime-prompts-20261023-5da7f745-before/yoke.exe'
try:
 assert sha(native)=='acc1da83befe9dc686015f94dbb002a05fc6b0337b44982739298f304cbc5dd0' and shutil.disk_usage(w).free>1_200_000_000
 assert backup.is_file() and sha(backup)==sha(native)
 run('check-bin',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','check','--locked','--offline','--bin','yoke','-j','1'],timeout=600)
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'currentCliSha256':sha(native),'freeBytes':shutil.disk_usage(w).free};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
