import ctypes,hashlib,hmac,http.client,json,os,queue,subprocess,sys,threading,time
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_bytes());out=Path(spec['out']);native=Path(spec['native']);root=Path(spec['root']);catalog=Path(spec['catalog']);config=Path(spec['config']);target='yoke-code-intelligence/service/token/'+spec['credentialName'];expected=spec['tokenHash'];adv=ctypes.WinDLL('Advapi32',use_last_error=True)
class Cred(ctypes.Structure):
 _fields_=[('Flags',ctypes.c_ulong),('Type',ctypes.c_ulong),('TargetName',ctypes.c_wchar_p),('Comment',ctypes.c_wchar_p),('LastWritten',ctypes.c_ulonglong),('CredentialBlobSize',ctypes.c_ulong),('CredentialBlob',ctypes.POINTER(ctypes.c_ubyte)),('Persist',ctypes.c_ulong),('AttributeCount',ctypes.c_ulong),('Attributes',ctypes.c_void_p),('TargetAlias',ctypes.c_wchar_p),('UserName',ctypes.c_wchar_p)]
adv.CredReadW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.POINTER(ctypes.POINTER(Cred))];adv.CredReadW.restype=ctypes.c_int;adv.CredFree.argtypes=[ctypes.c_void_p];adv.CredDeleteW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong];adv.CredDeleteW.restype=ctypes.c_int
def own_token():
 ptr=ctypes.POINTER(Cred)();assert adv.CredReadW(target,1,0,ctypes.byref(ptr)),'Owned synthetic credential unavailable'
 try:
  assert ptr.contents.CredentialBlobSize==32 and ptr.contents.TargetName==target
  value=ctypes.string_at(ptr.contents.CredentialBlob,32);assert hmac.compare_digest(hashlib.sha256(value).hexdigest(),expected),'Owned credential generation changed';return value
 finally:adv.CredFree(ptr)
secret=own_token();proc=None;sid=None;results=[];complete=False;deleted=False;error=None;stderr=None;ready=None
canonical=lambda v:json.dumps(v,separators=(',',':'),sort_keys=True,ensure_ascii=False).encode()
def root_data(text):
 start=text.index('{');end=text.find('\n\n[host steering:',start);return json.loads(text[start:end if end>=0 else None])
def rpc_payload(raw,content_type):
 if content_type.startswith('text/event-stream'):return [json.loads(line[5:].strip()) for line in raw.decode().splitlines() if line.startswith('data:')]
 return [json.loads(raw)] if raw else []
try:
 stderr=(out/'service.stderr').open('wb');proc=subprocess.Popen([str(native),'--root',str(root),'--timeout','30000','--max-bytes','4000000','--allow-session-templates','serve-http','--config',str(config),'--trust-service','--duration-ms','20000'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=stderr,creationflags=0x08000000)
 ready_queue=queue.Queue();reader=threading.Thread(target=lambda:ready_queue.put(proc.stdout.readline()));reader.start();ready_bytes=ready_queue.get(timeout=10);reader.join(timeout=1);assert not reader.is_alive();ready=json.loads(ready_bytes);assert ready['status']=='listening';address=ready['address'];hostname,port=address.rsplit(':',1);assert hostname=='127.0.0.1';port=int(port);endpoint=ready['endpoint'];original_catalog=catalog.read_bytes();write_refused=False
 try:
  with catalog.open('wb') as f:f.write(b'forbidden catalog mutation')
 except PermissionError:write_refused=True
 assert write_refused and catalog.read_bytes()==original_catalog,'Live catalog guard failed'
 def request(method,body=None,authenticated=True):
  global sid
  connection=http.client.HTTPConnection(hostname,port,timeout=20);headers={'Accept':'application/json, text/event-stream','Content-Type':'application/json','MCP-Protocol-Version':'2025-06-18'}
  if authenticated:headers['Authorization']='Bearer '+secret.hex()
  if sid:headers['Mcp-Session-Id']=sid
  connection.request(method,endpoint,body=canonical(body) if body is not None else None,headers=headers);response=connection.getresponse();status=response.status;content_type=response.getheader('Content-Type','');new_sid=response.getheader('Mcp-Session-Id');raw=response.read(16_000_001);connection.close();assert len(raw)<=16_000_000
  if new_sid:sid=new_sid
  frames=rpc_payload(raw,content_type) if status==200 else []
  results.append({'method':method,'requestId':body.get('id') if isinstance(body,dict) else None,'status':status,'contentType':content_type,'hasSessionHeader':new_sid is not None,'frames':frames})
  return status,frames
 status,_=request('POST',{'jsonrpc':'2.0','id':0,'method':'initialize'},authenticated=False);assert status==401 and not (root/'.yoke').exists()
 def call(i,method,params=None):
  status,frames=request('POST',{'jsonrpc':'2.0','id':i,'method':method,'params':params or {}});assert status==200;reply=next(v for v in frames if v.get('id')==i);assert 'error' not in reply;return reply
 initial=call(1,'initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'owned-runtime-template-acceptance','version':'0.5.0'}});assert sid;before_tools=call(2,'tools/list')['result']['tools']
 def instructions(i):
  reply=call(i,'tools/call',{'name':'ci_session','arguments':{'operation':'initialInstructions','args':{}}});assert reply['result']['isError'] is False;value=json.loads(reply['result']['content'][0]['text']);assert value['status']=='ok';return value['data']
 before=instructions(3);change=call(4,'tools/call',{'name':'ci_session','arguments':{'operation':'switchModes','args':{'modes':['closed']}}});assert change['result']['isError'] is False;after_tools=call(5,'tools/list')['result']['tools'];after=instructions(6)
 for data,tools in [(before,before_tools),(after,after_tools)]:
  rendered=root_data(data['instructions']);assert rendered['tools']==sorted(v['name'] for v in tools);assert data['promptRendering']['binding']['catalog']['selectedCatalogSha256']==hashlib.sha256(canonical(tools)).hexdigest();assert rendered['subject']=='http-owned';assert all(v['rendering']['schema']=='native_session_prompt_jinja_v3' for v in data['promptRendering']['fragments'])
 assert 'ci_find' in root_data(before['instructions'])['tools'] and 'ci_find' not in root_data(after['instructions'])['tools'];assert before['promptRendering']['binding']['revision']!=after['promptRendering']['binding']['revision'];assert any(v.get('method')=='notifications/tools/list_changed' for r in results for v in r['frames']);status,_=request('DELETE');assert status==204
 rest=proc.communicate(timeout=20)[0];assert proc.returncode==0;(out/'service.stdout').write_bytes(ready_bytes+rest);assert json.loads(rest)['status']=='stopped';assert catalog.read_bytes()==original_catalog;complete=True
except BaseException as exc:error=type(exc).__name__+': '+str(exc);raise
finally:
 if proc is not None and proc.poll() is None:
  proc.terminate();proc.wait(timeout=10)
 if stderr is not None:stderr.close()
 try:
  assert hmac.compare_digest(own_token(),secret);assert adv.CredDeleteW(target,1,0);deleted=True
 finally:
  secret=b'';sid=None
 (out/'http-results.json').write_text(json.dumps(results,indent=2)+'\n');result={'complete':complete,'serviceExited':proc is not None and proc.poll() is not None,'onlyNewSyntheticCredentialAccessed':True,'syntheticCredentialDeleted':deleted,'transportSecretsExcludedFromLogs':True,'httpRequests':len(results),'actualModeChangeCatalogAndCanonicalShaBindings':complete,'sourceCatalogWriteRefused':complete,'modelCalls':0,'analyzedSourceExecuted':False,'error':error};(out/'http-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='error'}),flush=True)