from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/runtime-prompts-20261023-5da7f745-http1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-live-'));cwd=configroot=jobroot;client=''
env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for name,relative in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/relative;p.mkdir(parents=True,exist_ok=True);env[name]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))


q=w/'validation/integration-20261018/runtime-prompts-20261023-5da7f745-green2';qualification=json.loads((q/'result.json').read_bytes());assert qualification['complete'] and qualification['allJobsEmpty'];inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());native=w/'target/debug/yoke.exe';assert sha(native)==qualification['currentCliSha256']
import uuid
source=jobroot/'source';source.mkdir();(source/'main.rs').write_bytes('// own é 🦀\r\nfn visible() {}\r\n'.encode());(source/'.env').write_bytes(b'OWNED_PROTECTED_CANARY=not-readable\n');original={str(p):sha(p) for p in source.iterdir()}
catalog=jobroot/'catalog.yml';template="{{ {'tools': available_tools, 'markers': available_markers, 'names': tool_names, 'subject': subject}|tojson }}";catalog.write_text(json.dumps({'prompts':{'system_prompt':template}}),encoding='utf8');catalog_hash=sha(catalog)
name='runtime-http-'+uuid.uuid4().hex;config=jobroot/'http.json';config.write_text(json.dumps({'bind':'127.0.0.1:0','requestTimeoutMs':15000,'principals':[{'id':'owned','profile':'session','root':str(source),'tokenCredentialName':name,'hostProfile':{'context':'desktop-app','modes':['open'],'promptTemplates':{'context':{'variables':{'subject':'http-owned'},'catalogs':[{'path':str(catalog),'sha256':catalog_hash}]},'systemPrompt':'system_prompt'},'steering':{'modes':{'open':{'instructions':'OPEN {{ subject }}'},'closed':{'instructions':'CLOSED {{ subject }}','excludedTools':['ci_find']}}}}}]}),encoding='utf8')
worker=jobroot/'http-worker.py';shutil.copyfile(Path(os.environ['TEMP'])/'runtime-prompts-http-worker-20261023.py',worker);shutil.copyfile(worker,out/'http-worker.py')
created=None;complete=False;cleanup=False
try:
 result=json.loads(run('create-owned-synthetic-token',[native,'credentials','token',name],timeout=30));created=result.get('data',result);assert created['credentialName']==name and len(created['tokenHash'])==64
 spec={'out':str(out),'native':str(native),'root':str(source),'catalog':str(catalog),'config':str(config),'credentialName':name,'tokenHash':created['tokenHash']};p=jobroot/'spec.json';p.write_text(json.dumps(spec),encoding='utf8');(out/'synthetic-credential-receipt.json').write_text(json.dumps(created,indent=2)+'\n')
 run('actual-http-session',[r'C:\Python314\python.exe','-I',worker,p],timeout=75);accepted=json.loads((out/'http-result.json').read_bytes());assert accepted['complete'] and accepted['syntheticCredentialDeleted'];complete=True
finally:
 if created is not None:
  # Only this invocation's create-only synthetic entry; verify its content hash before cleanup.
  import hmac
  class Cred(ctypes.Structure):
   _fields_=[('Flags',ctypes.c_ulong),('Type',ctypes.c_ulong),('TargetName',ctypes.c_wchar_p),('Comment',ctypes.c_wchar_p),('LastWritten',ctypes.c_ulonglong),('CredentialBlobSize',ctypes.c_ulong),('CredentialBlob',ctypes.POINTER(ctypes.c_ubyte)),('Persist',ctypes.c_ulong),('AttributeCount',ctypes.c_ulong),('Attributes',ctypes.c_void_p),('TargetAlias',ctypes.c_wchar_p),('UserName',ctypes.c_wchar_p)]
  adv=ctypes.WinDLL('Advapi32',use_last_error=True);adv.CredReadW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.POINTER(ctypes.POINTER(Cred))];adv.CredReadW.restype=ctypes.c_int;adv.CredFree.argtypes=[ctypes.c_void_p];adv.CredDeleteW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong];adv.CredDeleteW.restype=ctypes.c_int;ptr=ctypes.POINTER(Cred)();target='yoke-code-intelligence/service/token/'+name
  if adv.CredReadW(target,1,0,ctypes.byref(ptr)):
   try:assert ptr.contents.TargetName==target and ptr.contents.CredentialBlobSize==32;assert hmac.compare_digest(hashlib.sha256(ctypes.string_at(ptr.contents.CredentialBlob,32)).hexdigest(),created['tokenHash'])
   finally:adv.CredFree(ptr)
   assert adv.CredDeleteW(target,1,0)
  else:assert ctypes.get_last_error()==1168
  cleanup=True
 result={'complete':complete,'onlyNewSyntheticCredentialAccessed':True,'syntheticCredentialAbsentAfter':cleanup,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'currentCliSha256':sha(native),'originalOwnedSourceBytesExact':all(sha(Path(n))==h for n,h in original.items()),'catalogRawShaExact':sha(catalog)==catalog_hash,'existingCredentialsAccessed':False,'systemSettingsChanged':False,'modelCalls':0,'analyzedSourceExecuted':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
