from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-final-gates1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import contextlib
preflight=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-preflight1';runphase=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-run13';pre=json.loads((preflight/'result.json').read_bytes());trial=json.loads((runphase/'result.json').read_bytes());assert trial['complete'] and trial['completedGroups']==trial['registeredGroups']==358 and trial['allJobsEmpty'] and trial['sourceInputsUnchanged'];inputs=json.loads((preflight/'source-before.json').read_bytes());assert len(inputs)==1100 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';complete=False;commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
def owned(name,args,**kw):
 with contextlib.redirect_stdout(commandlog):result=run(name,args,**kw)
 print(json.dumps({'check':name,'exitCode':rows[-1]['exitCode'],'allJobsEmpty':rows[-1]['activeAfterCleanup']==0}),flush=True);return result
env['PATH']=r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\powershell-7.6.7-win-x64'+os.pathsep+env['PATH']
try:
 owned('powershell-authenticode',[env['SystemRoot']+'\\System32\\WindowsPowerShell\\v1.0\\powershell.exe','-NoProfile','-NonInteractive','-Command',"$s=Get-AuthenticodeSignature -LiteralPath 'C:\\Users\\Lomi\\AppData\\Local\\YokeValidation\\tools\\powershell-7.6.7-win-x64\\pwsh.exe'; if ([string]$s.Status -ne 'Valid') { throw 'PowerShell signature invalid' }; [PSCustomObject]@{Status=[string]$s.Status;Subject=$s.SignerCertificate.Subject} | ConvertTo-Json -Compress"],timeout=90)
 owned('cargo-clippy',[cargo,'clippy','--workspace','--all-targets','--locked','--keep-going','-j','2','--','-D','warnings'],timeout=900)
 metadata=json.loads(owned('cargo-metadata',[cargo,'metadata','--no-deps','--format-version','1','--locked'],timeout=90));roots=sorted({t['src_path'] for p in metadata['packages'] if p['id'] in metadata['workspace_members'] for t in p['targets']});assert len(roots)==360;(out/'format-roots.json').write_bytes((json.dumps(roots,indent=2)+'\n').encode());owned('cargo-fmt-all',[cargo,'fmt','--all','--','--check'],expected=None,timeout=120)
 if rows[-1]['exitCode']!=0:assert b'206' in (out/'cargo-fmt-all.stderr').read_bytes()
 for i in range(0,len(roots),20):owned(f'rustfmt-roots-{i:03}',[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','--check',*roots[i:i+20]],timeout=120)
 npm=shutil.which('npm.cmd');assert npm
 owned('npm-typecheck',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
 owned('npm-test',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 owned('python-packaging-and-test-runner',[r'C:\Python314\python.exe','-X','utf8','-m','unittest','discover','-s','scripts/tests','-v'],timeout=240)
 assert all(sha(w/n)==h for n,h in inputs.items()) and sha(w/'target/debug/yoke.exe')==pre['cliSha256'];complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'formatRoots':360,'cliSha256':sha(w/'target/debug/yoke.exe'),'wholeNativeTrial':'native-full-current-20261023-89a277f8-run13','noOriginalFixtureOrIgnoreChanges':True,'noArtifactDeletion':True};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
