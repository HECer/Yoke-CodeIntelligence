from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-run13';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import contextlib,re
preflight=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-preflight1';pre=json.loads((preflight/'result.json').read_bytes());assert pre['complete'] and pre['allJobsEmpty'];inputs=json.loads((preflight/'source-before.json').read_bytes());assert len(inputs)==1100 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';build=(w/'target/debug/deps').resolve();assert build.is_relative_to(w.resolve());protected=pre['protectedDefaultMetadataOnly'];cli=w/'target/debug/yoke.exe';assert sha(cli)==pre['cliSha256'];groups=pre['groups'];expected_failures={(r['group'],r['test']) for r in json.loads((w/'docs/validation/integration-2026-10-21/native-baseline-current/checkpoint.json').read_bytes())['runtimeFailures']};previous=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-run12';
prior_path=previous/'result.json'
if prior_path.exists():
 prior_result=json.loads(prior_path.read_bytes());assert prior_result['allJobsEmpty'] and prior_result['sourceInputsUnchanged']
else:
 recovery=json.loads((w/'validation/integration-20261018/native-full-current-20261023-89a277f8-run4-recovery1/result.json').read_bytes());assert previous.name=='native-full-current-20261023-89a277f8-run4' and recovery['complete'] and recovery['globalCompilerAndOwnedHostInventoryClear'] and recovery['sourceInputsUnchanged']
assert json.loads((previous/'source-before.json').read_bytes())==inputs;results=json.loads((previous/'groups.json').read_bytes());assert len(results)==len({r['name'] for r in results})<358 and {r['name'] for r in results}.issubset({g['name'] for g in groups})
for item in results:item.setdefault('evidencePhase',previous.name)
initial=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-run4';superseded=json.loads((initial/'superseded-prerequisite-attempts.json').read_bytes());assert len(superseded)==4;(out/'superseded-prerequisite-attempts.json').write_bytes((json.dumps(superseded,indent=2)+'\n').encode());candidates=json.loads((previous/'successful-artifacts.json').read_bytes());compression=json.loads((previous/'compression.json').read_bytes())
for item in compression:item.setdefault('originPhase',previous.name)
for item in candidates:
 if any(c.get('path')==item['path'] and c.get('bytes')==item['bytes'] and c.get('sha256')==item['sha256'] and c.get('logicalBytesAndHashExact') for c in compression):item['optimizationAttempted']=True;item['optimized']=True
complete=False;batch_complete=False;retained=len(results);pending=[g for g in groups if g['name'] not in {r['name'] for r in results}];remaining=pending[:20]
powershell=Path(r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\powershell-7.6.7-win-x64\pwsh.exe');assert sha(powershell)=='fa2c8bb1e35cdd62ad15cd06a1d8f2c5961e9725a9bfa1e7cfd2c322f49e9619';env['PATH']=str(powershell.parent)+os.pathsep+env['PATH'];(out/'environment-prerequisite.json').write_bytes((json.dumps({'program':str(powershell),'sha256':sha(powershell),'version':'7.6.7','signatureStatus':'Valid','signer':'Microsoft Corporation','scope':'private child PATH only','systemSettingsChanged':False,'initialPrerequisiteFailedTests':145,'wholeHarnessRetries':['github_app_auth','github_app_history_bridge','github_app_publication','github_app_worker_run']},indent=2)+'\n').encode())
(out/'inventory.json').write_bytes((json.dumps({'groups':groups,'examples':pre['examples'],'originalOs1314Cases':sorted(expected_failures)},indent=2)+'\n').encode());commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
def owned(name,args,**kw):
 with contextlib.redirect_stdout(commandlog):return run(name,args,**kw)
def protected_exact():
 for name,expected in protected.items():
  p=build/name
  if expected.get('absent'):assert not p.exists(),('Protected absent output appeared',name)
  else:
   s=p.stat();assert {'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'attributes':getattr(s,'st_file_attributes',None)}==expected,('Protected metadata changed',name)
def artifacts(name,kind,target):
 found=[]
 for line in (out/(name+'.stdout')).read_bytes().splitlines():
  try:m=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if m.get('reason')=='compiler-artifact' and m.get('executable') and m.get('profile',{}).get('test') and m['target']['name']==target and kind in m['target']['kind']:found.append(Path(m['executable']))
 return found

def remember(paths):
 for p in paths:
  assert p.resolve().parent==build and p.name not in protected and p!=cli
  for q in [p,p.with_suffix('.pdb')]:
   if q.exists():
    s=q.stat()
    if not q.is_file() or q.is_symlink() or s.st_nlink!=1 or getattr(s,'st_file_attributes',0)&0x400:continue
    entry={'path':str(q),'bytes':s.st_size,'sha256':sha(q),'compressed':bool(getattr(s,'st_file_attributes',0)&0x800)};candidates.append(entry)

def disk_headroom():
 if shutil.disk_usage(w).free<4_000_000_000:
  for item in candidates:
   if item.get('optimized') or item.get('optimizationAttempted'):continue
   if item['bytes']>shutil.disk_usage(w).free//2:continue
   p=Path(item['path']);s=p.stat();assert p.resolve().parent==build and p.name not in protected and s.st_size==item['bytes'] and sha(p)==item['sha256'];command='compact-'+str(len(compression));owned(command,[env['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(p)],expected=None,timeout=300);assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'];item['optimizationAttempted']=True;item['optimized']=rows[-1]['exitCode']==0;item['compressed']=bool(getattr(p.stat(),'st_file_attributes',0)&0x800);compression.append({**item,'command':command,'exitCode':rows[-1]['exitCode'],'logicalBytesAndHashExact':True});(out/'compression.json').write_bytes((json.dumps(compression,indent=2)+'\n').encode());print(json.dumps({'phase':'lossless-owned-output-compression','files':len(compression),'freeBytes':shutil.disk_usage(w).free}),flush=True)
   if shutil.disk_usage(w).free>6_000_000_000:break
 assert shutil.disk_usage(w).free>1_500_000_000,'Stop before another compile: insufficient non-destructive disk headroom'
try:
 assert owned('powershell-version',[str(powershell),'-NoProfile','-NonInteractive','-Command','$PSVersionTable.PSVersion.ToString()'],timeout=60).decode().strip()=='7.6.7'
 rustc=Path(owned('rustup-which-rustc',[r'C:\Users\Lomi\.cargo\bin\rustup.exe','which','rustc'],timeout=90).decode().strip());version=owned('rustc-version',[str(rustc),'-vV'],timeout=90).decode();host=re.search(r'(?m)^host: (.+)$',version).group(1).strip();runtime_path=os.pathsep.join([str(build),str(w/'target/debug'),str(rustc.parent),str(rustc.parent.parent/'lib/rustlib'/host/'lib'),env['PATH']]);package=json.loads((preflight/'cargo-metadata.stdout').read_bytes())['packages'][0]
 for group in remaining:
  assert not (out/'stop-requested').exists(),'Owned stop requested between test groups';disk_headroom();protected_exact();kind=group['kind'];target=group['target'];name=group['name'];paths=[]
  if kind=='test' and target in ['capture_options','session_fixed_tools']:
   suffix='-current-windows-20261023-89a277f8';exe=build/(target+suffix+'.exe');assert not exe.exists() and not exe.with_suffix('.pdb').exists();owned('compile-'+name,[cargo,'rustc','-p','yoke-code-intelligence','--locked','--profile','test','-j','2','--test',target,'--message-format','json','--','-C','extra-filename='+suffix],timeout=900);assert exe.is_file();protected_exact();prior_env,prior_cwd=env.copy(),cwd
   try:
    env.update({'PATH':runtime_path,'CARGO':cargo,'CARGO_MANIFEST_DIR':str(w/'native'),'CARGO_MANIFEST_PATH':str(w/'native/Cargo.toml'),'CARGO_PKG_NAME':package['name'],'CARGO_PKG_VERSION':package['version'],'CARGO_PKG_VERSION_MAJOR':'0','CARGO_PKG_VERSION_MINOR':'5','CARGO_PKG_VERSION_PATCH':'0','CARGO_PKG_VERSION_PRE':'','CARGO_PKG_AUTHORS':':'.join(package['authors']),'CARGO_PKG_DESCRIPTION':package.get('description') or '', 'CARGO_PKG_HOMEPAGE':package.get('homepage') or '', 'CARGO_PKG_REPOSITORY':package.get('repository') or '', 'CARGO_PKG_LICENSE':package.get('license') or '', 'CARGO_PKG_LICENSE_FILE':package.get('license_file') or '', 'CARGO_PKG_README':package.get('readme') or '', 'CARGO_PKG_RUST_VERSION':package.get('rust_version') or '', 'CARGO_TARGET_TMPDIR':str(w/'target/tmp')});cwd=w/'native';owned(name,[str(exe),'--test-threads=1'],expected=None,timeout=900)
   finally:env,cwd=prior_env,prior_cwd
   paths=[exe]
  else:
   selection=['--lib'] if kind=='lib' else ['--doc'] if kind=='doc' else ['--'+kind,target];owned(name,[cargo,'test','--locked','-j','2','--message-format','json',*selection,'--','--test-threads=1'],expected=None,timeout=900)
   if kind!='doc':paths=artifacts(name,'lib' if kind=='lib' else kind,target);assert len(paths)==1,('Missing normal test executable artifact',name,paths)
  text=(out/(name+'.stdout')).read_text(encoding='utf8');m=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text);assert m,('No completed normal test harness; preserve failed build output',name,rows[-1]['exitCode']);passed,failed,ignored,measured,filtered=map(int,m[-1]);assert measured==filtered==0;code=rows[-1]['exitCode'];assert code==(101 if failed else 0),('Unexpected harness/exit relation',name,code,m[-1]);failed_names=[];classifications=[]
  if failed:
   tail=text[text.rfind('\nfailures:\n'):];failed_names=re.findall(r'(?m)^    ([A-Za-z0-9_:]+)$',tail);assert len(failed_names)==failed
   for test in failed_names:
    start=text.index('---- '+test+' stdout ----');end=text.find('\n---- ',start+5);block=text[start:end if end>=0 else len(text)];known=(target,test) in expected_failures;classifications.append({'test':test,'originalOs1314Fixture':known,'actualOs1314':bool(re.search(r'code: 1314|os error 1314',block))})
  assert all(sha(w/n)==h for n,h in inputs.items());protected_exact();assert sha(cli)==pre['cliSha256'];entry={**group,'evidencePhase':out.name,'passed':passed,'failed':failed,'ignored':ignored,'exitCode':code,'unfilteredNormalHarness':True,'alternateOutputOnly':kind=='test' and target in ['capture_options','session_fixed_tools'],'failures':classifications};results.append(entry)
  if code==0 and paths:remember(paths)
  (out/'groups.json').write_bytes((json.dumps(results,indent=2)+'\n').encode());(out/'successful-artifacts.json').write_bytes((json.dumps(candidates,indent=2)+'\n').encode());print(json.dumps({'completed':len(results),'registered':len(groups),'group':name,'passed':passed,'failed':failed,'ignored':ignored,'totalPassed':sum(r['passed'] for r in results),'totalFailed':sum(r['failed'] for r in results),'freeBytes':shutil.disk_usage(w).free}),flush=True)
 if len(results)==len(groups):
  disk_headroom();owned('build-examples',[cargo,'build','--workspace','--locked','-j','2','--examples','--message-format','json'],timeout=900);assert all(sha(w/n)==h for n,h in inputs.items());protected_exact();assert sha(cli)==pre['cliSha256'];complete=True
 else:batch_complete=True
finally:
 commandlog.flush();result={'complete':complete,'batchComplete':batch_complete,'retainedCompletedGroups':retained,'registeredGroups':len(groups),'completedGroups':len(results),'totals':{key:sum(r[key] for r in results) for key in ['passed','failed','ignored']},'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'cliSha256':sha(cli) if cli.is_file() else None,'protectedDefaultMetadataOnly':protected,'noArtifactDeletion':True,'compressionCount':len(compression),'normalTestThreads':1,'fixtureRoot':str(jobroot),'sourceCommit':pre['sourceCommit'],'supersededPrerequisiteGroups':4,'supersededPrerequisiteFailedTests':145,'privatePowerShellPathCorrected':True,'unexpectedRuntimeFailures':[{'group':r['target'],**f} for r in results for f in r['failures'] if not(f['originalOs1314Fixture'] and f['actualOs1314'])]};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete or batch_complete
