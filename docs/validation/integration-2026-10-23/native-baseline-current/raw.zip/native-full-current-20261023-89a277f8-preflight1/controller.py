from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-preflight1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='89a277f88248f9aec7becfe992a38af99d81e51f';assert not subprocess.check_output(['git','status','--porcelain']);cargo=Path(r'C:\Users\Lomi\.cargo\bin\cargo.exe');native=w/'target/debug/yoke.exe';assert sha(native)=='8d66415f2af983ff2d8639f6dc50324f3b5d6722631401454897e52c90f7925e'
prior=json.loads((w/'validation/integration-20261018/server-workspace-settings-final-audit1/source-before.json').read_bytes());inputs={n:sha(w/n) for n in sorted(prior)};assert len(inputs)==1100;(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());old_inputs={n:{'before':prior[n],'after':inputs[n]} for n in inputs if prior[n]!=inputs[n]};post=json.loads((w/'docs/validation/integration-2026-10-23/server-workspace-settings/post-review-docs.json').read_bytes());assert old_inputs==post['changedFrozenInputs']
protected=['capture_options-784339a4da3fe379.exe','capture_options-784339a4da3fe379.pdb','session_fixed_tools-0671ac4d8f474009.exe','session_fixed_tools-0671ac4d8f474009.pdb'];build=w/'target/debug/deps'
def protected_metadata():
 data={}
 for name in protected:
  p=build/name
  if p.exists():
   s=p.stat();data[name]={'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'attributes':getattr(s,'st_file_attributes',None)}
  else:data[name]={'absent':True}
 return data
before_protected=protected_metadata();metadata=json.loads(run('cargo-metadata',[str(cargo),'metadata','--no-deps','--format-version','1','--locked'],timeout=90));packages=[p for p in metadata['packages'] if p['id'] in metadata['workspace_members']];assert len(packages)==1 and packages[0]['name']=='yoke-code-intelligence';targets=packages[0]['targets'];groups=[];examples=[]
for target in targets:
 kind=target['kind'];path=Path(target['src_path']);assert path.resolve().is_relative_to(w.resolve())
 if kind==['example']:examples.append(target['name']);continue
 if kind==['lib']:
  assert target['test'] and target['doctest'];groups.extend([{'name':'lib-'+target['name'],'kind':'lib','target':target['name'],'source':str(path)},{'name':'doc-'+target['name'],'kind':'doc','target':target['name'],'source':str(path)}])
 elif kind==['bin']:
  assert target['test'];groups.append({'name':'bin-'+target['name'],'kind':'bin','target':target['name'],'source':str(path)})
 elif kind==['test']:
  assert target['test'];groups.append({'name':'test-'+target['name'],'kind':'test','target':target['name'],'source':str(path)})
 else:raise AssertionError(('Unclassified Cargo target',target))
assert len(examples)==3 and len({g['name'] for g in groups})==len(groups);assert {g['target'] for g in groups if g['kind']=='test'}>={'capture_options','session_fixed_tools','server_workspace_settings','git_repository_collections'}
for group in ['capture_options','session_fixed_tools']:
 for extension in ['.exe','.pdb']:
  assert not (build/(group+'-current-windows-20261023-89a277f8'+extension)).exists()
assert all(sha(w/n)==h for n,h in inputs.items()) and protected_metadata()==before_protected;result={'complete':True,'sourceCommit':'89a277f88248f9aec7becfe992a38af99d81e51f','allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':True,'frozenInputs':len(inputs),'groups':sorted(groups,key=lambda g:(g['kind']!='lib',g['name'])),'examples':examples,'formatRoots':len(targets),'protectedDefaultMetadataOnly':before_protected,'cliSha256':sha(native),'fixtureRoot':str(jobroot),'sourceDocumentationReconciliation':old_inputs,'deleteArtifacts':False,'alterOriginalTestsOrIgnores':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['groups','sourceDocumentationReconciliation']}),flush=True)
