from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-storage3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import contextlib
base=w/'validation/integration-20261018';positive={};copies={};selected=[];excluded=[];commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1);complete=False
for result_path in base.glob('*/result.json'):
 try:r=json.loads(result_path.read_bytes())
 except (ValueError,UnicodeDecodeError):continue
 if r.get('precedingCliSha256') and (result_path.parent/'progress.json').exists():
  proof=json.loads((result_path.parent/'progress.json').read_bytes());old=[x for x in proof if x['name'].startswith('old-') and x['exitCode']==0 and x['activeAfterCleanup']==0]
  if old:positive[r['precedingCliSha256']]={'phase':result_path.parent.name,'completedOldCliCommands':[x['name'] for x in old]}
 if r.get('preservedPublishedCli'):copies.setdefault(r['preservedPublishedCli'],[]).append(result_path.parent.name)
try:
 for location,origins in copies.items():
  p=Path(location)
  if not p.exists():excluded.append({'origins':origins,'reason':'no longer exists'});continue
  st=p.stat();assert p.name in ['preceding-yoke.exe','published-yoke.exe'] and p.parent.name.startswith('yoke-owned-repository-discovery-check-') and p.parent.parent.resolve()==Path(tempfile.gettempdir()).resolve();assert p.is_file() and not p.is_symlink() and st.st_nlink==1 and not getattr(st,'st_file_attributes',0)&0x400;h=sha(p)
  if h not in positive:excluded.append({'origins':origins,'reason':'no independent successful old-CLI exact hash match'});continue
  entry={'path':str(p),'bytes':st.st_size,'sha256':h,'preservedByPhases':origins,'successfulExactCliProof':positive[h]};selected.append(entry)
 (out/'selected.json').write_bytes((json.dumps(selected,indent=2)+chr(10)).encode());initial_free=shutil.disk_usage(w).free
 for index,item in enumerate(selected):
  p=Path(item['path']);assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
  with contextlib.redirect_stdout(commandlog):run('compact-preserved-'+str(index),[env['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(p)],timeout=300)
  assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'];item['logicalBytesAndHashExactAfter']=True;print(json.dumps({'successfulOwnedCliCopiesOptimized':index+1,'freeBytes':shutil.disk_usage(w).free}),flush=True)
 complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'selected':selected,'excluded':excluded,'candidateCount':len(selected),'candidateLogicalBytes':sum(r['bytes'] for r in selected),'noArtifactDeletion':True,'noExecutableRun':True,'noPrimaryCliOrProtectedOutputSelected':True,'onlyTaskOwnedPreservedSuccessfulCopies':True,'noSystemSettingsChanged':True,'finalFreeBytes':shutil.disk_usage(w).free};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps({k:v for k,v in result.items() if k not in ['selected','excluded']}),flush=True)
assert complete
