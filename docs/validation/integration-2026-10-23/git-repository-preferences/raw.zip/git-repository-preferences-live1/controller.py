from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/git-repository-preferences-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-hooks-check-'));source=jobroot/'source';source.mkdir();cwd=w;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','DO_NOT_TRACK':'1','PIP_NO_INPUT':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))

import sqlite3
native=w/'target/debug/yoke.exe';git=Path(r'C:\Program Files\Git\cmd\git.exe')
old=Path(json.loads((w/'validation/integration-20261018/git-repository-preferences-test1/result.json').read_bytes())['preservedPublishedCli'])
assert sha(old)=='cc966819bd52c79cd26b0d33580c6674e6a0204f85721d768e73470a26ce20c7'
inputs=json.loads((w/'validation/integration-20261018/git-repository-preferences-qualified1/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items())
source=jobroot/("source \u03c0 ' \u0130");source.mkdir();nested=source/'nested \u00df';nested.mkdir();hooks=jobroot/'empty-hooks';hooks.mkdir()
(source/'main.rs').write_bytes(('// owned \u03c0\r\npub fn parent(){}\r\n').encode());(nested/'child.rs').write_bytes(b'pub fn child(){}\r\n')
def setup(name,root,*values):return run(name,[git,'-C',root,'-c','core.hooksPath='+str(hooks),'-c','user.name=Owned Validation','-c','user.email=owned@example.invalid','-c','commit.gpgSign=false',*values])
def args(exe=native):return [exe,'--root',source,'--timeout','60000','--max-bytes','65536']
def prefs(*values):return [*args(),'git','repository-preferences',*values]
def capture(*values):return [*args(),'git','repository-scope','--capture','--allow-index-read','--trust-git','--git',git,*values]
def sql():
 with sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True) as db:
  tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
  return {n:sorted(db.execute('SELECT * FROM "'+n.replace('"','""')+'"').fetchall(),key=repr) for n in tables}
def refuse(name,command,message,cold=False):
 before=None if cold else sql();run(name,command,expected=1,timeout=120)
 assert message in (out/(name+'.stderr')).read_bytes(),name
 if cold:assert not (source/'.yoke').exists()
 else:assert sql()==before,name

def raw_files():return {p.relative_to(source).as_posix():sha(p) for p in source.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(source).parts}
complete=False;source_exact=False;legacy_exact=False;no_state=False;original_rows_exact=False;scope_exact=False;capture_override=False;stale_preserved=False;aba_refused=False
try:
 for name,root,file in [('parent',source,'main.rs'),('nested',nested,'child.rs')]:
  setup('git-init-'+name,root,'init','--quiet','--template=');setup('git-add-'+name,root,'add','--',file);setup('git-commit-'+name,root,'commit','--quiet','-m','Owned fixture')
 original_files=raw_files()
 assert json.loads(run('cold-show',prefs('show')))['selection'] is None and not (source/'.yoke').exists()
 refuse('cold-set-denied',prefs('set','--expect','absent','--follow-submodules','true'),b'host_write_permission_required',True);no_state=True
 run('old-cold-default-index',[*args(old),'index']);warm=json.loads(run('old-warm-default-index',[*args(old),'index']))
 current=json.loads(run('new-warm-default-index',[*args(),'index']));assert current['data']==warm['data']
 legacy_rows={n:r for n,r in sql().items() if n in ['snapshots','graphs','records']}
 preceding=json.loads(run('old-explicit-follow-capture',[*args(old),'git','repository-scope','--capture','--allow-index-read','--trust-git','--git',git,'--follow-nested-repositories']))
 absent=json.loads(run('new-explicit-follow-capture',capture('--follow-nested-repositories')));assert absent['snapshotId']==preceding['snapshotId'] and 'hostSelection' not in absent;scope_exact=True
 first=json.loads(run('set-nested-choice',prefs('set','--allow-host-writes','--expect','absent','--follow-nested-repositories','true')))['selection']
 assert json.loads(run('show-first-choice',prefs('show')))['selection']==first
 refuse('saved-choice-grants-no-git-trust',[*args(),'git','repository-scope','--capture','--allow-index-read'],b'index_permission_required')
 refuse('saved-choice-grants-no-index-permission',[*args(),'git','repository-scope','--capture','--trust-git'],b'index_permission_required')
 selected=json.loads(run('capture-reuses-choice',capture()));assert selected['snapshotId']==preceding['snapshotId'] and selected['hostSelection']['id']==first['id']
 disabled=json.loads(run('capture-invocation-disable',capture('--no-follow-nested-repositories')));assert disabled['snapshotId']!=selected['snapshotId'];capture_override=True
 assert json.loads(run('capture-reuses-choice-again',capture()))['snapshotId']==selected['snapshotId']
 second=json.loads(run('cas-patch-submodules',prefs('set','--allow-host-writes','--expect',first['id'],'--follow-submodules','true')))['selection']
 assert second['revision']==2 and second['choice']=={'followSubmodules':True,'followNestedRepositories':True} and second['incarnation']==first['incarnation']
 refuse('stale-cas-update',prefs('set','--allow-host-writes','--expect',first['id'],'--follow-submodules','false'),b'repository_selection_stale')
 refuse('stale-cas-clear',prefs('clear','--allow-host-writes','--expect',first['id']),b'repository_selection_stale');stale_preserved=True
 run('clear-current',prefs('clear','--allow-host-writes','--expect',second['id']));assert json.loads(run('show-cleared',prefs('show')))['selection'] is None
 third=json.loads(run('recreate-same-choice',prefs('set','--allow-host-writes','--expect','absent','--follow-nested-repositories','true')))['selection'];assert third['id']!=first['id'] and third['incarnation']!=first['incarnation']
 refuse('recreated-choice-refuses-old-id',prefs('clear','--allow-host-writes','--expect',first['id']),b'repository_selection_stale');aba_refused=True
 run('clear-recreated',prefs('clear','--allow-host-writes','--expect',third['id']))
 assert json.loads(run('new-final-default-index',[*args(),'index']))['data']==warm['data'];legacy_exact=True
 now=sql();assert all(row in now[n] for n,rr in legacy_rows.items() for row in rr);original_rows_exact=True
 assert raw_files()==original_files;source_exact=True
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'fixtureRoot':str(jobroot),'nativeSha256':sha(native),'precedingSha256':sha(old),'frozenInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'processCalls':len(rows),'coldLookupAndDeniedSetCreateNoState':no_state,'oldAndNewWarmDefaultDataExact':legacy_exact,'originalSnapshotGraphControlRowsExact':original_rows_exact,'absentPreferenceExplicitCaptureIdentityExact':scope_exact,'perInvocationDisableDoesNotChangeSavedChoice':capture_override,'staleUpdatesAndClearPreserveSQL':stale_preserved,'clearRecreateRejectsOldIdentity':aba_refused,'allSourceAndGitFilesExact':source_exact,'realModelCalls':0,'projectCodeAutomaticallyExecuted':False,'systemSettingsChanged':False}
 (out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
