from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/catalogs-20261023-6d04f481-bootstrap1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))


inputs=json.loads((w/'validation/integration-20261018/jinja-20261023-fc442787-qualified1/source-before.json').read_bytes())
for n in ['native/src/session_config_catalog.rs','native/src/session_config_prompt_catalog_cli.rs']:inputs[n]=''
inputs={n:sha(w/n) for n in inputs};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');complete=False
native=w/'target/debug/yoke.exe';backup=w/'target/catalogs-20261023-6d04f481-before/yoke.exe'
try:
 assert not any(p for p in []);assert sha(native)=='d06d1c80a4e178cb0bdb3793503d1d1ea6944ba6689d066ffa90180c1607c6ca'
 assert shutil.disk_usage(w).free>1_200_000_000
 backup.parent.mkdir(exist_ok=False);shutil.copyfile(native,backup);assert sha(backup)==sha(native)
 run('compact-qualified-backup',[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(backup)],timeout=90);assert sha(backup)==sha(native)
 run('before-new-command-red',[backup,'session-config','render-prompt','--help'],expected=2)
 run('format-changed',[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024',*[str(w/n) for n in ['native/src/session_config_cli.rs','native/src/session_config.rs']]],timeout=120)
 inputs={n:sha(w/n) for n in inputs};(out/'source-after-format.json').write_text(json.dumps(inputs,indent=2)+'\n')
 run('check-bin',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','check','--locked','--offline','--bin','yoke','-j','1'],timeout=600)
 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputs':len(inputs),'freeBytes':shutil.disk_usage(w).free},indent=2)+'\n')
