
from pathlib import Path
import hashlib,json,re,shutil,subprocess
w=Path.cwd();raw=w/'validation/integration-20261018';out=raw/'git-repository-collections-final-audit2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parts=['git-repository-collections-test2','git-repository-collections-qualified1','git-repository-collections-qualified2'];results=[json.loads((raw/p/'result.json').read_bytes()) for p in parts];live=json.loads((raw/'git-repository-collections-live1/result.json').read_bytes());assert all(r['allJobsEmpty'] and r['sourceInputsUnchanged'] for r in results+[live]);assert results[0]['complete'] and not results[1]['complete'] and results[2]['complete'] and live['complete']
inputs=json.loads((raw/parts[0]/'source-before.json').read_bytes());assert len(inputs)==1098 and all(json.loads((raw/p/'source-before.json').read_bytes())==inputs for p in parts);assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
groups=[]
for part in parts:
 for row in json.loads((raw/part/'progress.json').read_bytes()):
  assert row['exitCode']==0 or row['name'] in ['cargo-fmt-all','cargo-test-graph_collections'];assert row['activeAfterCleanup']==0
  if row['name'].startswith('cargo-test-'):
   args=row['command'];group='lib' if '--lib' in args else args[args.index('--test')+1];text=(raw/part/(row['name']+'.stdout')).read_text(encoding='utf8');m=re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert len(m)==1;assert int(m[0][1])==0 or (group=='graph_collections' and int(m[0][1])==1 and 'code: 1314' in text and 'collection_sqlite_sidecars_cannot_write_through_links' in text);groups.append({'group':group,'passed':int(m[0][0]),'failed':int(m[0][1]),'ignored':int(m[0][2]),'evidence':part+'/'+row['name']+'.stdout'})
assert len(groups)==len({r['group'] for r in groups})==38;assert next(r for r in groups if r['group']=='lib')['passed']==578
for profile in ['native','serena','trail','graft','graphify']:
 current=json.loads((raw/'git-repository-collections-live1'/('new-selected-'+profile+'.reply.json')).read_bytes())
 old_name='old-warm-session' if profile=='native' else 'old-profile-'+profile
 old=json.loads((raw/'git-repository-profiles-live2'/(old_name+'.reply.json')).read_bytes())
 assert current['catalog']==old['catalog']
assert live['explicitPythonRuntimeAndSourceCallbackQualified']
first=json.loads((raw/'git-repository-collections-test1/source-before.json').read_bytes());changes=[n for n in first if first[n]!=inputs[n]];assert set(changes)=={'native/tests/git_repository_collections.rs'}
result={**results[-1],'allTestGroupsPassed':all(r['failed']==0 for r in groups),'nativeGroupResults':groups,'nativePassed':sum(r['passed'] for r in groups),'nativeFailed':sum(r['failed'] for r in groups),'allRustTestsPassed':False,'unchangedWindowsOs1314Failures':['graph_collections::collection_sqlite_sidecars_cannot_write_through_links'],'nativeExistingIgnored':sum(r['ignored'] for r in groups),'qualificationParts':parts,'nativeGroups':len(groups),'test1ToFinalChangedInputs':changes,'precedingAllFiveStdioProfileCatalogsExact':True,'explicitPythonRuntimeAndSourceCallbackQualified':True,'nativeCollectionRegisteredAndReadWithoutLiveGitOrOriginalSource':live['nativeCollectionRegisteredAndReadWithoutLiveGitOrOriginalSource'],'nativeArchiveFilesExactAfterRead':live['nativeArchiveFilesExactAfterRead'],'actualClientHealthCalls':2,'liveSourceInputsExact':True,'ordinaryRegisteredSessionStablePayloadAndRecordsExact':live['ordinaryRegisteredSessionStablePayloadAndRecordsExact'],'fullContractCertification':False,'wholeNativeRerun':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({k:v for k,v in result.items() if k not in ['nativeGroupResults','testGroups']}))
