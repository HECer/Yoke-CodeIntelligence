import json,subprocess,sys
r=subprocess.run([sys.argv[1],'mcp',sys.argv[2],'yoke_owned_git_stdio'],cwd=sys.argv[3],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)
ok=r.returncode==0 and b'Connected' in r.stdout and b'Failed to connect' not in r.stdout
print(json.dumps({'connected':ok,'exitCode':r.returncode,'rawOutputArchived':False}))
sys.exit(0 if ok else 1)
