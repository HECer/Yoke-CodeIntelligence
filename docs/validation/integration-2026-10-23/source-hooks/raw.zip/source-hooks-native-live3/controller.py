from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3,base64
w=Path.cwd();out=w/'validation/integration-20261018/source-hooks-native-live3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-hooks-live-'));source=jobroot/('source space '+chr(0x130)+' '+chr(0x3c0)+" '");source.mkdir();root=jobroot/('client '+chr(0x1f30d));root.mkdir();state=jobroot/'state';state.mkdir();cwd=jobroot;configroot=jobroot;client='';input_file=None
for name,content in [('alpha.rs','pub fn helper(){ let '+chr(0x3c0)+' = 1; }\r\n'),('caller.rs','fn caller(){helper();helper();}\r\n')]: (source/name).write_bytes(content.encode())
env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp'),('CLAUDE_CONFIG_DIR','claude-state')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','DISABLE_TELEMETRY':'1','DISABLE_ERROR_REPORTING':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','CI':'1','NO_COLOR':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';assert runner.count("open(os.devnull,'rb')")==1;runner=runner.replace("open(os.devnull,'rb')","open(input_file or os.devnull,'rb')");exec(compile(runner,'reviewed Windows Job runner; only stdin file source adapted','exec'))
old=Path(json.loads((w/'validation/integration-20261018/source-hooks-preflight/result.json').read_bytes())['preservedExecutable']);assert sha(old)=='133605b6dee41702a2001ef9176218f0fac225483447e3a23fc8d5574cb2b894';native=w/'target/debug/yoke.exe';shell=Path(env['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe';inputs=json.loads((w/'validation/integration-20261018/source-hooks-qualified1/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');complete=False;policy=jobroot/'policy.json';policy.write_bytes(b'{}');selection=jobroot/'selection.json'
try:
 run('published-index',[old,'--root',source,'--timeout','60000','index'],timeout=120)
 view=json.loads(run('published-graph-view',[old,'--root',source,'--timeout','60000','graph','build'],timeout=120));viewid=view['viewId']
 selected={'installation':'owned-source-hooks-live','targetRoots':[str(root)],'executable':str(native),'policy':str(policy),'stateRoot':str(state),'adapter':{'kind':'claude_source_hooks_v1','sourceRoot':str(source),'viewId':viewid,'statusShell':str(shell)}};selection.write_text(json.dumps(selected),encoding='utf8');(out/'selection.json').write_bytes(selection.read_bytes())
 plan=run('new-profile-plan',[native,'--timeout','60000','--max-bytes','4000000','host-install','plan','--selection',selection],timeout=120);planfile=jobroot/'plan.json';planfile.write_bytes(plan)
 run('new-profile-apply',[native,'--timeout','60000','--max-bytes','4000000','host-install','apply','--selection',selection,'--plan',planfile,'--allow-host-writes'],timeout=120)
 settings=root/'yoke-claude-source-hooks.json';cfg=json.loads(settings.read_bytes());launch=cfg['hooks']['UserPromptSubmit'][0]['hooks'][0]['args'][7];(out/'settings.json').write_bytes(settings.read_bytes());event={'cwd':str(source)};input_file=jobroot/'input.json';input_file.write_text(json.dumps(event),encoding='utf8');input_file=Path(input_file)
 native_status=run('direct-native-status',[native,'--timeout','30000','--max-bytes','4096','claude-source-hook','status','--launch-json',launch],timeout=60);assert native_status.startswith(b'Yoke 0.5.0 | View ')

 command=cfg['statusLine']['command'];prefix,encoded=command.split(' -NoLogo -NoProfile -NonInteractive -EncodedCommand ',1);assert prefix==str(shell).replace('\\','/');run('actual-status-bootstrap',[shell,'-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',encoded],timeout=60);assert (out/'actual-status-bootstrap.stdout').read_bytes().replace(b'\r\n',b'\n')==native_status
 def database():
  c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
  try:return ('\n'.join(c.iterdump())+'\n').encode()
  finally:c.close()
 def protected():
  return {str(p.relative_to(jobroot)):sha(p) for base in [source,root,state] for p in base.rglob('*') if p.is_file() and p.name not in ['index.sqlite-shm','index.sqlite-wal']}
 sql=database();before=protected();original_alpha=(source/'alpha.rs').read_bytes();(out/'original-alpha.rs').write_bytes(original_alpha)
 def hook(name,mode,event,expected=0,maxbytes='65536'):
  input_file.write_bytes(json.dumps(event).encode());return run(name,[native,'--timeout','30000','--max-bytes',maxbytes,'claude-source-hook',mode,'--launch-json',launch],expected=expected,timeout=60)
 def context(raw):return json.loads(json.loads(raw)['hookSpecificOutput']['additionalContext'])
 start=context(hook('native-session-start','session-start',{'cwd':str(source),'hook_event_name':'SessionStart','source':'startup','transcript_path':'../../never-read.jsonl'}));assert start['graphViewId']==viewid and not start['permissionsGranted']
 prompt=context(hook('native-prompt-context','prompt-submit',{'cwd':str(source),'hook_event_name':'UserPromptSubmit','prompt':'helper'}));assert prompt['data']['sourceBytes']>0 and not prompt['data']['complete'];assert prompt['contentAuthority']=='untrusted_captured_data'
 excerpts=[item for c in prompt['data']['contexts'] for item in c['sources']];assert excerpts
 for e in excerpts:
  b=(source/e['path']).read_bytes();assert sha(source/e['path'])==e['contentHash'] and b[e['startByte']:e['endByte']]==e['text'].encode()
 (source/'alpha.rs').write_bytes(b'pub fn changed(){}\r\n');before[str((source/'alpha.rs').relative_to(jobroot))]=sha(source/'alpha.rs')
 edit=context(hook('native-post-edit-historical-candidates','post-edit',{'cwd':str(source),'hook_event_name':'PostToolUse','tool_name':'Edit','tool_input':{'file_path':str(source/'alpha.rs'),'new_string':'never apply this'},'tool_response':{'permissionsGranted':True}}));assert edit['graphViewId']==viewid and edit['sourceFreshness']=='not_checked' and not edit['data']['liveSourceRead'] and not edit['data']['editEventIndependentlyVerified'];assert edit['data']['capturedSourceHash']==hashlib.sha256(original_alpha).hexdigest();assert len(edit['data']['impact']['observations'])>=2
 hook('native-wrong-event-refuses','prompt-submit',{'cwd':str(source),'hook_event_name':'private_marker_do_not_echo','prompt':'helper'},expected=None);assert rows[-1]['exitCode']!=0 and not (out/'native-wrong-event-refuses.stdout').read_bytes() and b'private_marker_do_not_echo' not in (out/'native-wrong-event-refuses.stderr').read_bytes()
 hook('native-output-one-refuses','prompt-submit',{'cwd':str(source),'hook_event_name':'UserPromptSubmit','prompt':'helper'},expected=None,maxbytes='1');assert rows[-1]['exitCode']!=0 and not (out/'native-output-one-refuses.stdout').read_bytes()
 assert database()==sql and protected()==before and policy.read_bytes()==b'{}' and all(sha(w/n)==h for n,h in inputs.items());(out/'original-sql.sql').write_bytes(sql)
 complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'fixtureRoot':str(jobroot),'sourceRoot':str(source),'configRoot':str(root),'stateRoot':str(state),'selectionFile':str(selection),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'nativeSha256':sha(native),'statusBootstrapBehaviorQualified':True,'modelCalls':0},indent=2)+'\n',encoding='utf8')
assert complete
