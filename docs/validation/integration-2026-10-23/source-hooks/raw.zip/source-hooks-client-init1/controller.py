from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3,base64,http.server,threading
w=Path.cwd();out=w/'validation/integration-20261018/source-hooks-client-init1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-hooks-live-'));source=jobroot/('source space '+chr(0x130)+' '+chr(0x3c0)+" '");source.mkdir();root=jobroot/('client '+chr(0x1f30d));root.mkdir();state=jobroot/'state';state.mkdir();cwd=jobroot;configroot=jobroot;client='';input_file=None
for name,content in [('alpha.rs','pub fn helper(){ let '+chr(0x3c0)+' = 1; }\r\n'),('caller.rs','fn caller(){helper();helper();}\r\n')]: (source/name).write_bytes(content.encode())
env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp'),('CLAUDE_CONFIG_DIR','claude-state')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','DISABLE_TELEMETRY':'1','DISABLE_ERROR_REPORTING':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','CI':'1','NO_COLOR':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';assert runner.count("open(os.devnull,'rb')")==1;runner=runner.replace("open(os.devnull,'rb')","open(input_file or os.devnull,'rb')");exec(compile(runner,'reviewed Windows Job runner; only stdin file source adapted','exec'))

prior=json.loads((w/'validation/integration-20261018/source-hooks-native-live2/result.json').read_bytes());assert prior['complete'] and prior['allJobsEmpty'];source=Path(prior['sourceRoot']);root=Path(prior['configRoot']);state=Path(prior['stateRoot']);settings=root/'yoke-claude-source-hooks.json';native=w/'target/debug/yoke.exe';assert sha(native)==prior['nativeSha256'];client=Path(r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\claude-2.1.306-win32-x64\claude.exe');assert sha(client)=='f6bc9de38f507c36c9a3bb0085a59a27e32156e2208252bf1707c4e3ef309114';cwd=source;configroot=source;input_file=None;inputs=json.loads((w/'validation/integration-20261018/source-hooks-test6/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');policy=Path(json.loads(Path(prior['selectionFile']).read_bytes())['policy']);assert policy.read_bytes()==b'{}';original=(w/'validation/integration-20261018/source-hooks-native-live2/original-alpha.rs').read_bytes();alpha=source/'alpha.rs';assert alpha.resolve().parent==source.resolve() and alpha.read_bytes()==b'pub fn changed(){}\r\n';alpha.write_bytes(original)
requests=[]
class Handler(http.server.BaseHTTPRequestHandler):
 def do_POST(self):requests.append({'method':'POST','path':self.path.split('?')[0]});self.send_response(503);self.end_headers()
 def do_GET(self):requests.append({'method':'GET','path':self.path.split('?')[0]});self.send_response(503);self.end_headers()
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();env.update({'ANTHROPIC_API_KEY':'invalid-owned-fixture-no-real-key','ANTHROPIC_BASE_URL':f'http://127.0.0.1:{server.server_port}'})
def database():
 c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(c.iterdump())+'\n').encode()
 finally:c.close()
def protected():return {str(p):sha(p) for base in [source,root,state] for p in base.rglob('*') if p.is_file() and p.name not in ['index.sqlite-shm','index.sqlite-wal']}
sql=database();before=protected();flags=[client,'--setting-sources','','--settings',settings,'--strict-mcp-config','--mcp-config','{"mcpServers":{}}'];complete=False
try:
 debug=out/'actual-client.debug.log';run('actual-init-only',[*flags,'--debug-file',debug,'--init-only'],timeout=90);logs=debug.read_text(encoding='utf8',errors='replace');assert 'yoke-native-source-hook-1' in logs and json.loads(Path(prior['selectionFile']).read_bytes())['adapter']['viewId'] in logs;assert not requests and database()==sql and protected()==before
 policy.write_bytes(b'{"ownedChangedPolicy":true}')
 try:
  debug_bad=out/'actual-stale-client.debug.log';run('actual-stale-init-only',[*flags,'--debug-file',debug_bad,'--init-only'],expected=None,timeout=90);bad=debug_bad.read_text(encoding='utf8',errors='replace');assert 'claude_source_hook_refused' in bad and 'yoke-native-source-hook-1' not in bad
 finally:policy.write_bytes(b'{}')
 assert not requests and database()==sql and protected()==before and all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 server.shutdown();server.server_close();thread.join(timeout=2);(out/'result.json').write_text(json.dumps({'complete':complete,'fixtureRoot':str(jobroot),'sourceFixtureRoot':prior['fixtureRoot'],'sourceRoot':str(source),'configRoot':str(root),'stateRoot':str(state),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'serverThreadStopped':not thread.is_alive(),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'nativeSha256':sha(native),'clientSha256':sha(client),'actualClientVersion':'2.1.306','providerRequestsObserved':requests,'modelTurnRequested':False,'userConfigurationSelected':False,'osNetworkIsolationAttested':False,'sourceSqlAndDataSettingsReceiptsExact':complete,'sessionStartContextObserved':complete,'stalePolicyRefusalObserved':complete,'promptPostEditClientDispatchQualified':False,'interactiveStatusRenderQualified':False},indent=2)+'\n',encoding='utf8')
assert complete
