from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/source-hooks-cli-boundaries1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-hooks-boundary-'));configroot=jobroot;cwd=jobroot;client='';input_file=None;stalled_fd=None
for name in ['source','old-config','old-state']:(jobroot/name).mkdir()
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';assert runner.count("open(os.devnull,'rb')")==1;runner=runner.replace("open(os.devnull,'rb')","(os.fdopen(os.dup(stalled_fd),'rb') if stalled_fd is not None else open(input_file or os.devnull,'rb'))");exec(compile(runner,'reviewed Windows Job runner, selected stdin file or owned pipe only','exec'))
prior=json.loads((w/'validation/integration-20261018/source-hooks-native-live3/result.json').read_bytes());assert prior['complete'] and prior['allJobsEmpty'];source=Path(prior['sourceRoot']);root=Path(prior['configRoot']);state=Path(prior['stateRoot']);settings=root/'yoke-claude-source-hooks.json';native=w/'target/debug/yoke.exe';assert sha(native)==prior['nativeSha256'];cfg=json.loads(settings.read_bytes());launch=cfg['hooks']['UserPromptSubmit'][0]['hooks'][0]['args'][7];input_file=jobroot/'input.json';inputs=json.loads((w/'validation/integration-20261018/source-hooks-qualified1/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
def database():
 c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(c.iterdump())+'\n').encode()
 finally:c.close()
def protected():return {str(p):sha(p) for base in [source,root,state] for p in base.rglob('*') if p.is_file() and p.name not in ['index.sqlite-shm','index.sqlite-wal']}
sql=database();before=protected();complete=False;old_exact=False
try:
 event={'cwd':str(source),'hook_event_name':'UserPromptSubmit','prompt':'helper'}
 cases=[('duplicate-event',b'{"cwd":"private_owned_marker","cwd":"again"}','prompt-submit','65536'),('oversized-event',b' '*65537,'prompt-submit','65536'),('invalid-utf8',b'\xff','prompt-submit','65536'),('tiny-output',json.dumps(event).encode(),'prompt-submit','1'),('outside-path',json.dumps({'cwd':str(source),'hook_event_name':'PostToolUse','tool_name':'Edit','tool_input':{'file_path':str(jobroot/'outside.rs')}}).encode(),'post-edit','65536')]
 for name,raw,mode,budget in cases:
  input_file.write_bytes(raw);run(name,[native,'--timeout','30000','--max-bytes',budget,'claude-source-hook',mode,'--launch-json',launch],expected=None,timeout=45)
  assert rows[-1]['exitCode']!=0 and not (out/(name+'.stdout')).read_bytes() and b'private_owned_marker' not in (out/(name+'.stderr')).read_bytes()
 read_fd,write_fd=os.pipe();stalled_fd=read_fd
 try:
  run('stalled-native-stdin',[native,'--timeout','100','--max-bytes','4096','claude-source-hook','status','--launch-json',launch],expected=None,timeout=5);assert rows[-1]['exitCode']!=0 and rows[-1]['seconds']<5 and not (out/'stalled-native-stdin.stdout').read_bytes()
  encoded=cfg['statusLine']['command'].split(' -NoLogo -NoProfile -NonInteractive -EncodedCommand ',1)[1];shell=Path(env['SystemRoot'])/'System32/WindowsPowerShell/v1.0/powershell.exe'
  run('stalled-status-shell-stdin',[shell,'-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',encoded],expected=None,timeout=40);assert rows[-1]['exitCode']!=0 and not (out/'stalled-status-shell-stdin.stdout').read_bytes() and b'yoke_status_shell_refused' in (out/'stalled-status-shell-stdin.stderr').read_bytes()
 finally:os.close(write_fd);os.close(read_fd);stalled_fd=None
 old=Path(json.loads((w/'validation/integration-20261018/source-hooks-preflight/result.json').read_bytes())['preservedExecutable']);assert sha(old)=='133605b6dee41702a2001ef9176218f0fac225483447e3a23fc8d5574cb2b894';policy=jobroot/'policy.json';policy.write_bytes(b'{}');selection=jobroot/'selection.json';selection.write_text(json.dumps({'installation':'legacy-equivalence','targetRoots':[str(jobroot/'old-config')],'executable':str(native),'policy':str(policy),'stateRoot':str(jobroot/'old-state'),'adapter':{'kind':'claude_session_hooks_v1','sourceRoot':str(jobroot/'source')}}),encoding='utf8');input_file=None
 old_plan=json.loads(run('published-legacy-session-plan',[old,'--max-bytes','4000000','host-install','plan','--selection',selection],timeout=90));new_plan=json.loads(run('new-legacy-session-plan',[native,'--max-bytes','4000000','host-install','plan','--selection',selection],timeout=90))
 for p in [old_plan,new_plan]:
  for name in ['id','createdMs','expiresMs']:p.pop(name)
 assert old_plan==new_plan and not list((jobroot/'old-state').iterdir()) and not list((jobroot/'old-config').iterdir()) and not (jobroot/'source/.yoke').exists();old_exact=True
 assert protected()==before and database()==sql and all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'nativeSha256':sha(native),'cases':len(rows),'legacyPlanAndOutputBytesExactExceptWallClockAndId':old_exact,'protectedSourceSqlAndHostBytesUnchanged':protected()==before and database()==sql},indent=2)+'\n',encoding='utf8')
assert complete