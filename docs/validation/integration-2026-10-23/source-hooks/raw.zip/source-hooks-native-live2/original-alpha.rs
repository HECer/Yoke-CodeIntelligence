pub fn helper(){ let π = 1; }
