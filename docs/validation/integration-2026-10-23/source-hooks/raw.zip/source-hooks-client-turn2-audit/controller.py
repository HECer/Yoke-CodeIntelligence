from pathlib import Path
import hashlib,json,re,shutil
w=Path.cwd();raw=w/'validation/integration-20261018/source-hooks-client-turn2';out=w/'validation/integration-20261018/source-hooks-client-turn2-audit';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();messages=json.loads((raw/'owned-message-requests.json').read_bytes());prior=json.loads((w/'validation/integration-20261018/source-hooks-native-live3/result.json').read_bytes());original=(w/'validation/integration-20261018/source-hooks-native-live3/original-alpha.rs').read_bytes();source=Path(prior['sourceRoot']);original_sources={'alpha.rs':original,'caller.rs':(source/'caller.rs').read_bytes()};inputs=json.loads((w/'validation/integration-20261018/source-hooks-qualified1/source-before.json').read_bytes())
def strings(v):
 if isinstance(v,str):yield v
 elif isinstance(v,list):
  for x in v:yield from strings(x)
 elif isinstance(v,dict):
  for x in v.values():yield from strings(x)
def contexts(v):
 for s in strings(v):
  if 'yoke-native-source-hook-1' not in s:continue
  for m in re.finditer(r'\{',s):
   try:x,_=json.JSONDecoder().raw_decode(s[m.start():])
   except ValueError:continue
   if isinstance(x,dict) and x.get('producer')=='yoke-native-source-hook-1':yield x
complete=False;count=0;summary=[]
try:
 progress=json.loads((raw/'progress.json').read_bytes());assert len(progress)==1 and progress[0]['exitCode']==0 and progress[0]['activeAfterCleanup']==0
 result=json.loads((raw/'result.json').read_bytes());assert not result['complete'] and result['clientFileEditIndependentlyObserved'] and result['nativeHookSourceSqlUnchanged'] and result['sourceInputsUnchanged'] and result['allJobsEmpty'] and result['serverThreadStopped'];assert result['controlledMessageStages']==['read','write','final'];assert (source/'alpha.rs').read_bytes()==b'pub fn owned_client_changed(){}\r\n'
 prompt_evidence=[x for x in contexts(messages) if x['data'].get('retrieval')=='bounded_prompt_identifier_substrings'];assert prompt_evidence and all(x['data']['sourceBytes']>0 for x in prompt_evidence)
 for x in prompt_evidence:
  assert not x['data']['complete'] and x['sourceFreshness']=='not_checked' and not x['permissionsGranted']
  for c in x['data']['contexts']:
   for excerpt in c['sources']:
    assert excerpt['path'] in original_sources;captured=original_sources[excerpt['path']];assert captured[excerpt['startByte']:excerpt['endByte']]==excerpt['text'].encode() and excerpt['contentHash']==hashlib.sha256(captured).hexdigest();count+=1
  summary.append({'graphViewId':x['graphViewId'],'sourceFreshness':x['sourceFreshness'],'retrieval':x['data']['retrieval'],'sourceBytes':x['data']['sourceBytes'],'evaluatedTerms':x['data']['evaluatedTerms'],'complete':x['data']['complete']})
 assert count>0
 post_evidence=[x for x in contexts(messages) if x['data'].get('scope')=='incoming_dependency_candidates_in_pinned_preexisting_view'];assert post_evidence
 for x in post_evidence:
  data=x['data'];assert data['capturedSourceHash']==hashlib.sha256(original).hexdigest() and not data['liveSourceRead'] and not data['editEventIndependentlyVerified'] and len(data['impact']['observations'])>=2
 assert all(sha(w/n)==h for n,h in inputs.items());assert sha(w/'target/debug/yoke.exe')==result['nativeSha256'];complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'auditOfRawClientRun':'source-hooks-client-turn2','rawResultPreservedFalse':True,'rawFailure':'NameError: re not imported in offline evidence extraction','newClientOrModelCalls':0,'actualClientExitCode':progress[0]['exitCode'],'clientStages':result['controlledMessageStages'],'receivedExactAnchoredExcerptsChecked':count,'receivedPromptContexts':summary,'postEditHistoricalParallelObservationsChecked':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'originalClientOwnedJobsEmpty':result['allJobsEmpty'],'originalServerThreadStopped':result['serverThreadStopped'],'promptPostEditClientDispatchQualified':complete,'interactiveStatusRenderQualified':False,'modelQualityEstablished':False,'nativeSha256':result['nativeSha256'],'inputProofs':{p.name:sha(p) for p in [raw/'controller.py',raw/'progress.json',raw/'result.json',raw/'owned-message-requests.json',raw/'actual-client.debug.log']}},indent=2)+'\n',encoding='utf8')
assert complete
print((out/'result.json').read_text())