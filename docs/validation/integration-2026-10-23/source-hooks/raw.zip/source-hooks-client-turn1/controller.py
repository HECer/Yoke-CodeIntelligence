from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3,base64,http.server,threading
w=Path.cwd();out=w/'validation/integration-20261018/source-hooks-client-turn1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-hooks-live-'));source=jobroot/('source space '+chr(0x130)+' '+chr(0x3c0)+" '");source.mkdir();root=jobroot/('client '+chr(0x1f30d));root.mkdir();state=jobroot/'state';state.mkdir();cwd=jobroot;configroot=jobroot;client='';input_file=None
for name,content in [('alpha.rs','pub fn helper(){ let '+chr(0x3c0)+' = 1; }\r\n'),('caller.rs','fn caller(){helper();helper();}\r\n')]: (source/name).write_bytes(content.encode())
env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp'),('CLAUDE_CONFIG_DIR','claude-state')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','DISABLE_TELEMETRY':'1','DISABLE_ERROR_REPORTING':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','CI':'1','NO_COLOR':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';assert runner.count("open(os.devnull,'rb')")==1;runner=runner.replace("open(os.devnull,'rb')","open(input_file or os.devnull,'rb')");exec(compile(runner,'reviewed Windows Job runner; only stdin file source adapted','exec'))


prior=json.loads((w/'validation/integration-20261018/source-hooks-native-live2/result.json').read_bytes());assert prior['complete'] and prior['allJobsEmpty'];source=Path(prior['sourceRoot']);root=Path(prior['configRoot']);state=Path(prior['stateRoot']);settings=root/'yoke-claude-source-hooks.json';native=w/'target/debug/yoke.exe';assert sha(native)==prior['nativeSha256'];client=Path(r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\claude-2.1.306-win32-x64\claude.exe');assert sha(client)=='f6bc9de38f507c36c9a3bb0085a59a27e32156e2208252bf1707c4e3ef309114';cwd=source;configroot=source;input_file=None;inputs=json.loads((w/'validation/integration-20261018/source-hooks-test6/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');alpha=source/'alpha.rs';original=(w/'validation/integration-20261018/source-hooks-native-live2/original-alpha.rs').read_bytes();assert alpha.read_bytes()==original;changed=b'pub fn owned_client_changed(){}\r\n';marker='Owned source-hook protocol fixture: inspect helper, then complete the owned file edit.';requests=[];messages=[];lock=threading.Lock()
class Handler(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def do_POST(self):
  self.connection.settimeout(5);length=int(self.headers.get('Content-Length','0'))
  if not 0<length<=2000000:self.send_error(413);return
  raw=self.rfile.read(length)
  try:body=json.loads(raw)
  except Exception:self.send_error(400);return
  path=self.path.split('?')[0]
  with lock:
   requests.append({'method':'POST','path':path,'bytes':len(raw)})
   if len(requests)>16:self.send_error(429);return
  if path=='/v1/messages/count_tokens':self.reply_json({'input_tokens':64});return
  if path!='/v1/messages':self.send_error(503);return
  rendered=json.dumps(body,ensure_ascii=False)
  if marker not in rendered:stage='auxiliary';content=[{'type':'text','text':'owned auxiliary protocol response'}];stop='end_turn'
  else:
   results=[b for m in body.get('messages',[]) for b in (m.get('content',[]) if isinstance(m.get('content'),list) else []) if b.get('type')=='tool_result'];read=next((b for b in results if b.get('tool_use_id')=='toolu_owned_read'),None);write=next((b for b in results if b.get('tool_use_id')=='toolu_owned_write'),None)
   if read is None:stage='read';content=[{'type':'tool_use','id':'toolu_owned_read','name':'Read','input':{'file_path':str(alpha)}}];stop='tool_use'
   elif read.get('is_error'):stage='read_refused';content=[{'type':'text','text':'owned fixture read refused'}];stop='end_turn'
   elif write is None:stage='write';content=[{'type':'tool_use','id':'toolu_owned_write','name':'Write','input':{'file_path':str(alpha),'content':changed.decode()}}];stop='tool_use'
   else:stage='write_refused' if write.get('is_error') else 'final';content=[{'type':'text','text':'owned protocol fixture complete'}];stop='end_turn'
  with lock:
   number=len(messages)+1;messages.append({'stage':stage,'body':body});(out/'owned-message-requests.json').write_text(json.dumps(messages,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
  message={'id':'msg_owned_fixture_'+str(number),'type':'message','role':'assistant','model':body.get('model','owned-fixture-model'),'content':content,'stop_reason':stop,'stop_sequence':None,'usage':{'input_tokens':64,'output_tokens':8,'cache_creation_input_tokens':0,'cache_read_input_tokens':0}}
  if not body.get('stream'):self.reply_json(message);return
  events=[]
  def event(name,value):events.append('event: '+name+'\ndata: '+json.dumps(value,ensure_ascii=False,separators=(',',':'))+'\n\n')
  start={**message,'content':[],'stop_reason':None,'usage':{'input_tokens':64,'output_tokens':0,'cache_creation_input_tokens':0,'cache_read_input_tokens':0}};event('message_start',{'type':'message_start','message':start})
  block=content[0]
  if block['type']=='tool_use':
   event('content_block_start',{'type':'content_block_start','index':0,'content_block':{**block,'input':{}}});event('content_block_delta',{'type':'content_block_delta','index':0,'delta':{'type':'input_json_delta','partial_json':json.dumps(block['input'],ensure_ascii=False,separators=(',',':'))}})
  else:
   event('content_block_start',{'type':'content_block_start','index':0,'content_block':{'type':'text','text':''}});event('content_block_delta',{'type':'content_block_delta','index':0,'delta':{'type':'text_delta','text':block['text']}})
  event('content_block_stop',{'type':'content_block_stop','index':0});event('message_delta',{'type':'message_delta','delta':{'stop_reason':stop,'stop_sequence':None},'usage':{'output_tokens':8}});event('message_stop',{'type':'message_stop'});data=''.join(events).encode();self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Content-Length',str(len(data)));self.send_header('Connection','close');self.end_headers();self.wfile.write(data);self.wfile.flush();self.close_connection=True
 def reply_json(self,value):
  data=json.dumps(value).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.send_header('Connection','close');self.end_headers();self.wfile.write(data);self.wfile.flush();self.close_connection=True
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler);server.daemon_threads=True;thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();env.update({'ANTHROPIC_API_KEY':'invalid-owned-fixture-no-real-key','ANTHROPIC_BASE_URL':f'http://127.0.0.1:{server.server_port}'})
def database():
 c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(c.iterdump())+'\n').encode()
 finally:c.close()
def protected():return {str(p):sha(p) for base in [source,root,state] for p in base.rglob('*') if p.is_file() and p.name not in ['index.sqlite-shm','index.sqlite-wal']}
sql=database();before=protected();complete=False
try:
 flags=[client,'--setting-sources','','--settings',settings,'--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--model','sonnet','--tools','Read,Write','--allowedTools','Read(./alpha.rs)','Edit(./alpha.rs)','--max-turns','5','--no-session-persistence','--output-format','json','--debug-file',out/'actual-client.debug.log','--print',marker]
 run('actual-owned-client-turn',flags,expected=None,timeout=120);assert rows[-1]['exitCode']==0
 assert [m['stage'] for m in messages if m['stage']!='auxiliary']==['read','write','final'];assert alpha.read_bytes()==changed;after=protected();before[str(alpha)]=sha(alpha);assert after==before and database()==sql
 rendered=json.dumps(messages,ensure_ascii=False);assert 'bounded_prompt_identifier_substrings' in rendered and 'incoming_dependency_candidates_in_pinned_preexisting_view' in rendered and 'yoke-native-source-hook-1' in rendered;assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 server.shutdown();server.server_close();thread.join(timeout=2);(out/'result.json').write_text(json.dumps({'complete':complete,'fixtureRoot':str(jobroot),'sourceFixtureRoot':prior['fixtureRoot'],'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'serverThreadStopped':not thread.is_alive(),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'nativeSha256':sha(native),'clientSha256':sha(client),'actualClientVersion':'2.1.306','requests':requests,'controlledMessageStages':[m['stage'] for m in messages],'modelResponsesAreOwnedProtocolFixtures':True,'paidOrRealModelInferencePerformed':False,'modelQualityEstablished':False,'clientFileEditIndependentlyObserved':alpha.read_bytes()==changed,'nativeHookSourceSqlUnchanged':database()==sql,'permissionModeBypassUsed':False,'explicitFileToolGrant':'Read(./alpha.rs), Edit(./alpha.rs)','promptPostEditClientDispatchQualified':complete,'interactiveStatusRenderQualified':False},indent=2)+'\n',encoding='utf8')
assert complete
