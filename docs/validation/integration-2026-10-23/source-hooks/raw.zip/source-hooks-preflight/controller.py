from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/source-hooks-preflight';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-asr-runtime-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','DO_NOT_TRACK':'1','PIP_NO_INPUT':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))


inputs={name:sha(w/name) for name in json.loads((w/'validation/integration-20261018/asr-qualified1/source-before.json').read_bytes())};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');native=w/'target/debug/yoke.exe';assert sha(native)=='133605b6dee41702a2001ef9176218f0fac225483447e3a23fc8d5574cb2b894';old=jobroot/'old-yoke.exe';shutil.copyfile(native,old);assert sha(old)==sha(native);complete=False
try:
 version=run('published-version',[old,'--version']);assert b'0.5.0' in version
 run('published-source-hooks-unavailable',[old,'claude-source-hook','--launch-json','{}'],expected=None);assert rows[-1]['exitCode']!=0 and b'unrecognized subcommand' in (out/'published-source-hooks-unavailable.stderr').read_bytes();assert not (source/'.yoke').exists();assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'publishedSourceCommit':'dd462925450c77965418261cf46aca5cf9ea6859','publishedDocsCommit':'adf160c7d6a8e1aa18f212848d3e9e9533b1bf3d','publishedCliSha256':sha(old),'preservedExecutable':str(old),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'sourceStoreCreated':(source/'.yoke').exists()},indent=2)+'\n',encoding='utf8')
assert complete
