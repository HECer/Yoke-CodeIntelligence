from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3,base64
w=Path.cwd();out=w/'validation/integration-20261018/source-hooks-status-shell-probe2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-hooks-live-'));source=jobroot/('source space '+chr(0x130)+' '+chr(0x3c0)+" '");source.mkdir();root=jobroot/('client '+chr(0x1f30d));root.mkdir();state=jobroot/'state';state.mkdir();cwd=jobroot;configroot=jobroot;client='';input_file=None
for name,content in [('alpha.rs','pub fn helper(){ let '+chr(0x3c0)+' = 1; }\r\n'),('caller.rs','fn caller(){helper();helper();}\r\n')]: (source/name).write_bytes(content.encode())
env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp'),('CLAUDE_CONFIG_DIR','claude-state')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','DISABLE_TELEMETRY':'1','DISABLE_ERROR_REPORTING':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','CI':'1','NO_COLOR':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';assert runner.count("open(os.devnull,'rb')")==1;runner=runner.replace("open(os.devnull,'rb')","open(input_file or os.devnull,'rb')");exec(compile(runner,'reviewed Windows Job runner; only stdin file source adapted','exec'))

prior=json.loads((w/'validation/integration-20261018/source-hooks-native-live1/result.json').read_bytes());assert prior['complete'] and prior['allJobsEmpty'];fixture=Path(prior['fixtureRoot']);settings=Path(prior['configRoot'])/'yoke-claude-source-hooks.json';cfg=json.loads(settings.read_bytes());prefix,encoded=cfg['statusLine']['command'].split(' -NoLogo -NoProfile -NonInteractive -EncodedCommand ',1);shell=Path(prefix);original=base64.b64decode(encoded).decode('utf-16-le');input_file=jobroot/'input.json';input_file.write_text(json.dumps({'cwd':prior['sourceRoot']}),encoding='utf8');complete=False
cases={
 'console-encoding-setter':"[Console]::Error.WriteLine('before-setter'); $OutputEncoding=[System.Text.UTF8Encoding]::new($false); [Console]::OutputEncoding=$OutputEncoding; [Console]::Error.WriteLine('after-setter'); [Console]::Out.WriteLine('after-setter-output'); exit 0",
 'original-with-markers':original.replace('; & ',"; [Console]::Error.WriteLine('before-native'); & ").replace('; exit $LASTEXITCODE',"; [Console]::Error.WriteLine('after-native:'+ $LASTEXITCODE); exit $LASTEXITCODE"),
 'without-console-setter':original.replace("$OutputEncoding=[System.Text.UTF8Encoding]::new($false); [Console]::OutputEncoding=$OutputEncoding; ",""),
}
try:
 for name,script in cases.items():
  (out/(name+'.ps1')).write_text(script,encoding='utf8');run(name,[shell,'-NoLogo','-NoProfile','-NonInteractive','-EncodedCommand',base64.b64encode(script.encode('utf-16-le')).decode()],expected=None,timeout=60)
 complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'fixtureRoot':str(fixture),'paidOrRemoteModelCalls':0},indent=2)+'\n',encoding='utf8')
assert complete
