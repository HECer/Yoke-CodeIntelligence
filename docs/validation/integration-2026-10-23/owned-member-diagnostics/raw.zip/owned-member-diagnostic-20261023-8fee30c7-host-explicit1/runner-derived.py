k=ctypes.WinDLL('kernel32',use_last_error=True)
class Basic(ctypes.Structure):_fields_=[('processTime',ctypes.c_int64),('jobTime',ctypes.c_int64),('flags',ctypes.c_uint32),('minWorking',ctypes.c_size_t),('maxWorking',ctypes.c_size_t),('activeLimit',ctypes.c_uint32),('affinity',ctypes.c_size_t),('priority',ctypes.c_uint32),('scheduling',ctypes.c_uint32)]
class Extended(ctypes.Structure):_fields_=[('basic',Basic),('io',ctypes.c_uint64*6),('processMemory',ctypes.c_size_t),('jobMemory',ctypes.c_size_t),('peakProcessMemory',ctypes.c_size_t),('peakJobMemory',ctypes.c_size_t)]
for name,args,result in [('CreateJobObjectW',[ctypes.c_void_p,ctypes.c_wchar_p],ctypes.c_void_p),('SetInformationJobObject',[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32],ctypes.c_int),('AssignProcessToJobObject',[ctypes.c_void_p,ctypes.c_void_p],ctypes.c_int),('QueryInformationJobObject',[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_void_p],ctypes.c_int),('TerminateJobObject',[ctypes.c_void_p,ctypes.c_uint32],ctypes.c_int),('ResumeThread',[ctypes.c_void_p],ctypes.c_uint32),('CloseHandle',[ctypes.c_void_p],ctypes.c_int)]:
    f=getattr(k,name);f.argtypes=args;f.restype=result
assert ctypes.sizeof(Extended)==144
rows=[]
def run(name,args,expected=0,timeout=60):
    argv=[str(x) for x in args];job=k.CreateJobObjectW(None,None);assert job
    limits=Extended();limits.basic.flags=0x2000;assert k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits))
    hp=ht=None;start=time.monotonic();row={'name':name,'command':argv,'startedSuspended':True,'assignedBeforeResume':False}
    def active():
        info=ctypes.create_string_buffer(48);assert k.QueryInformationJobObject(job,1,info,48,None);return int.from_bytes(info.raw[40:44],'little')
    try:
        with open(os.devnull,'rb') as inp,(out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
            handles=[msvcrt.get_osfhandle(f.fileno()) for f in [inp,stdout,stderr]]
            for handle in handles:os.set_handle_inheritable(handle,True)
            si=subprocess.STARTUPINFO();si.dwFlags=subprocess.STARTF_USESTDHANDLES|subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0;si.hStdInput,si.hStdOutput,si.hStdError=handles;si.lpAttributeList={'handle_list':handles}
            hp,ht,pid,tid=_winapi.CreateProcess(None,subprocess.list2cmdline(argv),None,None,True,subprocess.CREATE_NO_WINDOW|0x00000004,env,str(configroot if argv[0]==str(client) else cwd),si)
            row['pid']=pid;assert k.AssignProcessToJobObject(job,hp);row['assignedBeforeResume']=True;assert k.ResumeThread(ht)!=0xffffffff
            while _winapi.WaitForSingleObject(hp,100)==258:
                if time.monotonic()-start>timeout:raise TimeoutError(name)
                if sum((out/(name+suffix)).stat().st_size for suffix in ['.stdout','.stderr'])>16_000_000:raise RuntimeError('Owned output capacity')
            row['exitCode']=_winapi.GetExitCodeProcess(hp);row['activeAtParentExit']=active()
    finally:
        if hp is not None and not row['assignedBeforeResume']:_winapi.TerminateProcess(hp,124)
        assert k.TerminateJobObject(job,125);until=time.monotonic()+10
        while active() and time.monotonic()<until:time.sleep(.05)
        row['activeAfterCleanup']=active();row['seconds']=round(time.monotonic()-start,3)
        for handle in [ht,hp,job]:
            if handle is not None:k.CloseHandle(handle)
        rows.append(row);(out/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
    assert row['activeAfterCleanup']==0
    if expected is not None:assert row['exitCode']==expected,(name,row['exitCode'])
    return (out/(name+'.stdout')).read_bytes()
