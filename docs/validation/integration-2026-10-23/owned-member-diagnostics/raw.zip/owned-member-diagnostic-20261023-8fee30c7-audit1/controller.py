from pathlib import Path
import hashlib,json,re,subprocess
w=Path.cwd();base=w/'validation/integration-20261018';prefix='owned-member-diagnostic-20261023-8fee30c7-';out=base/(prefix+'audit1');out.mkdir(exist_ok=False);(out/'controller.py').write_bytes(Path(__file__).read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();dump=lambda p,v:p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
q=base/(prefix+'qualified2');inputs=json.loads((q/'source-before.json').read_bytes());assert len(inputs)==1109 and all(sha(w/n)==h for n,h in inputs.items());dump(out/'source-before.json',inputs)
for phase in ['red1','green1','qualified2','live1','host-explicit1','storage1']:
 p=base/(prefix+phase);result=json.loads((p/'result.json').read_bytes());assert result['complete'] and result['allJobsEmpty']
 if (p/'source-before.json').exists():assert json.loads((p/'source-before.json').read_bytes())==inputs if phase!='red1' else True
 progress=json.loads((p/'progress.json').read_bytes());assert all(row['activeAfterCleanup']==0 for row in progress)
groups=json.loads((q/'native-groups.json').read_bytes());assert len(groups)==11 and sum(row['passed'] for row in groups)==697 and sum(row['ignored'] for row in groups)==8 and all(row['failed']==row['measured']==row['filtered']==0 for row in groups)
assert b'Ran 47 tests' in (q/'python-all.stderr').read_bytes() and (q/'python-all.stderr').read_bytes().rstrip().endswith(b'OK')
npm=(q/'npm-test.stdout').read_bytes();assert b'pass 260' in npm and b'fail 0' in npm and b'skipped 3' in npm
assert b'Native format check: 361 roots, 0 failed' in (q/'format-complete.stdout').read_bytes()
source_name='native/src/process_windows_job.rs';before=subprocess.check_output(['git','show','HEAD:'+source_name]).replace(b'\r\n',b'\n');after=(w/source_name).read_bytes().replace(b'\r\n',b'\n')
for marker in [b'    pub(super) fn terminate_until',b'        for id in &info.ids[..info.listed as usize]']:
 if marker.startswith(b'    pub'):
  assert before[before.index(marker):]==after[after.index(marker):]
 else:
  end=b'        Ok(handles)';assert before[before.index(marker):before.index(end,before.index(marker))]==after[after.index(marker):after.index(end,after.index(marker))]
assert 'info.assigned == info.listed && info.listed as usize <= MAX_MEMBERS' in after.decode()
test_prefix=json.loads((q/'test-prefix-audit.json').read_bytes());assert test_prefix['originalTestGitBytesExactPrefix'] and test_prefix['exactCRLFReconstructionMatchesOriginalWorkingHash'];dump(out/'test-prefix-audit.json',test_prefix)
protected={'capture_options-784339a4da3fe379.exe':193232184,'capture_options-784339a4da3fe379.pdb':1431552,'session_fixed_tools-0671ac4d8f474009.pdb':28612608}
assert all((w/'target/debug/deps'/name).stat().st_size==size for name,size in protected.items());assert not (w/'target/debug/deps/session_fixed_tools-0671ac4d8f474009.exe').exists()
host=base/(prefix+'host-explicit1');proof=json.loads((host/'host-result.json').read_bytes());assert proof['passed'] and all(proof[n] for n in ['unsavedSourceBound','workspaceExecutableIgnored','protectedOpenBufferExcluded','savedSourceUnchanged'])
omissions=[]
for name in ['actual-vscode-host.stdout','actual-vscode-host.stderr']:
 p=host/name;omissions.append({'path':name,'bytes':p.stat().st_size,'sha256':sha(p),'omittedFromPublishedArchive':True,'reason':'Private application diagnostics remain local; structured host proof/status/hash records retained.'})
dump(host/'private-log-omissions.json',omissions)
native_sha=sha(w/'target/debug/yoke.exe');assert native_sha=='c84be740e8c03bd02c02fa82c4e478f5025b9de49e94f805a5fe1d16347b3221'
result={'complete':True,'sourceInputs':1109,'sourceInputsUnchanged':True,'nativeGroups':groups,'nativePassed':697,'nativeFailed':0,'nativeExistingIgnored':8,'libraryPassed':580,'originalSixJobTestsGitPrefixExact':True,'originalWorkingCRLFCheckoutNormalizationDisclosed':True,'unchangedTerminationAndMemberSynchronizationCode':True,'unchangedListEqualityCapacityAndDeadlines':True,'pythonPassed':47,'typecheckPassed':True,'npmPassed':260,'npmExistingSkipped':3,'allTargetClippyWarningsDenied':True,'formatRoots':361,'actualProtocolParentCalls':7,'actualCodeHostVersion':'1.143.1','actualCodeHostAllFourProofs':True,'nativeCliSha256':native_sha,'allJobsEmpty':True,'protectedArtifactsCheckedMetadataOnly':protected,'privateApplicationLogsOmitted':omissions,'currentNaturalMismatchRecurrenceObserved':False,'historicalGitFixtureCauseProven':False,'successfulCaptureCleanupPropagationFixed':False,'wholeCurrentWindowsOrHostedAcceptance':False,'fullStatusComplete':False}
dump(out/'result.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['nativeGroups','protectedArtifactsCheckedMetadataOnly','privateApplicationLogsOmitted']}))
