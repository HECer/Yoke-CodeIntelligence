from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/owned-member-diagnostic-20261023-8fee30c7-storage1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';env=os.environ.copy()
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
q=w/'validation/integration-20261018/owned-member-diagnostic-20261023-8fee30c7-qualified2';assert json.loads((q/'result.json').read_bytes())['complete'];inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items())
artifacts=[]
for line in (q/'test-process.stdout').read_bytes().splitlines():
 try:message=json.loads(line)
 except (ValueError,UnicodeDecodeError):continue
 if message.get('reason')=='compiler-artifact' and Path(message['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and 'lib' in message['target']['kind'] and not message['profile']['test']:
  artifacts.extend(Path(p) for p in message['filenames'] if p.endswith('.rlib'))
assert len(artifacts)==1;path=artifacts[0];assert path.parent.resolve()==(w/'target/debug/deps').resolve() and path.name.startswith('libyoke-') and not path.is_symlink()
size=path.stat().st_size;digest=sha(path);assert shutil.disk_usage(w).free>size+64_000_000
allocation=ctypes.WinDLL('kernel32',use_last_error=True).GetCompressedFileSizeW;allocation.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)];allocation.restype=ctypes.c_uint32
def allocated():
 high=ctypes.c_uint32();ctypes.set_last_error(0);low=allocation(str(path),ctypes.byref(high));assert low!=0xffffffff or ctypes.get_last_error()==0;return (high.value<<32)+low
before=allocated();run('compact-passed-native-library',[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(path)],timeout=90);after=allocated();assert path.stat().st_size==size and sha(path)==digest and all(sha(w/n)==h for n,h in inputs.items())
result={'complete':True,'path':str(path),'logicalBytes':size,'sha256':digest,'allocatedBefore':before,'allocatedAfter':after,'logicalBytesAndSha256Unchanged':True,'qualifiedPassedNativeLibraryOnly':True,'selectedByExactNativeManifestNotAmbiguousYokeTargetName':True,'sourceInputsUnchanged':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'deletedAnything':False,'globalCompressionPolicyChanged':False}
(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
