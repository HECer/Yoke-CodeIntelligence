from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/owned-member-diagnostic-20261023-8fee30c7-qualified1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-member-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'})
env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+r'C:\Program Files\PowerShell\7'+os.pathsep+env['PATH'];assert Path(r'C:\Program Files\PowerShell\7\pwsh.exe').is_file()
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")]
assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)")
exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))
green=w/'validation/integration-20261018/owned-member-diagnostic-20261023-8fee30c7-green1';inputs=json.loads((green/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items()) and json.loads((green/'result.json').read_bytes())['complete']
(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());assert shutil.disk_usage(w).free>1_200_000_000
native=w/'target/debug/yoke.exe';native_before=sha(native);assert native_before=='aa391752ae06896894e0610e65f7a006ac8757dccf32eb19428882e5cf72f7c7'
backup=w/'target/owned-member-diagnostic-20261023-8fee30c7-before/yoke.exe';backup.parent.mkdir(exist_ok=False);shutil.copyfile(native,backup);assert sha(backup)==native_before
targets=['process','agent_repl_lifecycle','lsp_lifecycle','google_workspace_process','git_affected_details','git_impact_details','git_workflows','git_repository_host','github_app_worker_run','github_app_history_bridge'];(out/'targets.json').write_bytes((json.dumps(targets,indent=2)+'\n').encode())
complete=False;commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1);compression=[]
def owned(name,args,**options):
 with contextlib.redirect_stdout(commandlog):data=run(name,args,**options)
 print(json.dumps({'name':name,'exitCode':rows[-1].get('exitCode'),'activeAfterCleanup':rows[-1]['activeAfterCleanup']}),flush=True);return data
def compact_passed(path,label):
 assert path.is_file() and not path.is_symlink() and path.resolve()!=native.resolve() and path.name not in ['capture_options-784339a4da3fe379.exe','session_fixed_tools-0671ac4d8f474009.exe']
 before={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)};assert shutil.disk_usage(w).free>before['bytes']+64_000_000
 owned('compact-passed-'+label,[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',path],timeout=90)
 assert path.stat().st_size==before['bytes'] and sha(path)==before['sha256'];compression.append({**before,'logicalBytesAndSha256Exact':True});(out/'compression.json').write_bytes((json.dumps(compression,indent=2)+'\n').encode())
try:
 compact_passed(backup,'prior-cli')
 lib_artifacts=[]
 for line in (green/'library-all.stdout').read_bytes().splitlines():
  try:message=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if message.get('reason')=='compiler-artifact' and message['target']['name']=='yoke' and 'lib' in message['target']['kind'] and message.get('profile',{}).get('test') and message.get('executable'):lib_artifacts.append(Path(message['executable']))
 assert len(lib_artifacts)==1;compact_passed(lib_artifacts[0],'library580')
 cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';python=r'C:\Python314\python.exe';helper=[python,'-X','utf8',str(w/'scripts/run_native_tests.py'),'--controlled-test-runner','--locked','--offline']
 owned('clippy-all-targets',[cargo,'clippy','--workspace','--all-targets','--locked','--offline','--keep-going','-j','2','--','-D','warnings'],timeout=900)
 owned('format-complete',[python,'-X','utf8','scripts/native_fmt.py','--check'],timeout=600)
 for target in targets:
  data=owned('test-'+target,[*helper,'--test',target,'-j','2','--message-format','json','--','--test-threads=1'],timeout=360)
  artifacts=[]
  for line in data.splitlines():
   try:message=json.loads(line)
   except (ValueError,UnicodeDecodeError):continue
   if message.get('reason')=='compiler-artifact' and message['target']['name']==target and message.get('profile',{}).get('test') and message.get('executable'):artifacts.append(Path(message['executable']))
  assert len(artifacts)==1 and artifacts[0].parent.resolve()==(w/'target/debug/deps').resolve();compact_passed(artifacts[0],target)
 owned('debug-build',[cargo,'build','--workspace','--locked','--offline','-j','2','--message-format','json'],timeout=900)
 owned('cli-version',[native,'--version'],timeout=30)
 owned('python-all',[python,'-X','utf8','-m','unittest','discover','-s','scripts/tests','-v'],timeout=300)
 npm=shutil.which('npm.cmd');assert npm
 owned('npm-typecheck',[os.environ['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
 owned('npm-test',[os.environ['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 assert all(sha(w/n)==h for n,h in inputs.items()) and sha(backup)==native_before;complete=True
finally:
 result={'complete':complete,'sourceCommit':'8fee30c70abf8258c32087d2ee142e41fdaad437','sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'green580LibraryUsesExactSameInputs':True,'nativeCliBefore':native_before,'nativeCliCurrent':sha(native),'priorCliBackupSha256':sha(backup),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':targets,'formatRoots':361,'privatePwshPathOnly':True,'noFixtureIgnoreDeadlineProfileChanges':True}
 (out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
