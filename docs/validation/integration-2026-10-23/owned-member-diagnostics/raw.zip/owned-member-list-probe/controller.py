﻿from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/owned-member-list-probe';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-member-probe-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
old=json.loads((w/'validation/integration-20261018/parameter-contract-final3/source-before.json').read_bytes());inputs={name:sha(w/name) for name in old};assert len(inputs)==1065;(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');git=Path(shutil.which('git'));git_hash=sha(git)
child='from pathlib import Path\nimport ctypes,json,msvcrt,os,subprocess,sys,time,_winapi\n'+runner[:runner.index('rows=[]')]+r'''
class ProcessIds(ctypes.Structure):_fields_=[('assigned',ctypes.c_uint32),('listed',ctypes.c_uint32),('ids',ctypes.c_size_t*4096)]
git=sys.argv[1];root=sys.argv[2];mismatches=[];snapshots=0;iterations=0;all_empty=True;all_roots_signaled=True;query_errors=[];start=time.monotonic();peak_assigned=0;peak_listed=0

def accounting(job):
 b=ctypes.create_string_buffer(48);assert k.QueryInformationJobObject(job,1,b,48,None);return {'total':int.from_bytes(b.raw[36:40],'little'),'active':int.from_bytes(b.raw[40:44],'little')}

def sample(job,phase,hp):
 global snapshots,peak_assigned,peak_listed
 b=ProcessIds();ok=k.QueryInformationJobObject(job,3,ctypes.byref(b),ctypes.sizeof(b),None);snapshots+=1
 if not ok:query_errors.append({'phase':phase,'error':ctypes.get_last_error()});return
 peak_assigned=max(peak_assigned,b.assigned);peak_listed=max(peak_listed,b.listed)
 if b.assigned!=b.listed and len(mismatches)<32:mismatches.append({'iteration':iterations,'phase':phase,'assigned':b.assigned,'listed':b.listed,'capacity':4096,'rootSignaledAfterSnapshot':_winapi.WaitForSingleObject(hp,0)==0,'accountingAfterSnapshot':accounting(job),'returnedBytes':None})

with open(os.devnull,'r+b') as null:
 nh=msvcrt.get_osfhandle(null.fileno());os.set_handle_inheritable(nh,True)
 for index in range(300):
  if time.monotonic()-start>60:break
  jobs=[];hp=ht=None;attached=False;iterations=index
  try:
   for _ in range(2):
    job=k.CreateJobObjectW(None,None);assert job;jobs.append(job);limits=Extended();limits.basic.flags=0x2000;assert k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits))
   si=subprocess.STARTUPINFO();si.dwFlags=subprocess.STARTF_USESTDHANDLES;si.hStdInput=si.hStdOutput=si.hStdError=nh;si.lpAttributeList={'handle_list':[nh]}
   hp,ht,pid,tid=_winapi.CreateProcess(None,subprocess.list2cmdline([git,'--version']),None,None,True,subprocess.CREATE_NO_WINDOW|0x4,dict(os.environ),root,si)
   assert k.AssignProcessToJobObject(jobs[0],hp);attached=True;assert k.AssignProcessToJobObject(jobs[1],hp);assert k.ResumeThread(ht)!=0xffffffff
   until=time.monotonic()+2
   while _winapi.WaitForSingleObject(hp,0)==258 and time.monotonic()<until:
    sample(jobs[0],'root-running-outer',hp);sample(jobs[1],'root-running-inner',hp);_winapi.WaitForSingleObject(hp,1)
   assert _winapi.WaitForSingleObject(hp,0)==0,'Owned benign git exceeded2seconds'
   assert _winapi.GetExitCodeProcess(hp)==0
   sample(jobs[0],'root-signaled-outer',hp);sample(jobs[1],'root-signaled-inner',hp)
  finally:
   if hp is not None and not attached:_winapi.TerminateProcess(hp,124)
   for job in reversed(jobs):assert k.TerminateJobObject(job,125)
   if hp is not None:all_roots_signaled=all_roots_signaled and _winapi.WaitForSingleObject(hp,2000)==0
   until=time.monotonic()+2
   while any(accounting(job)['active'] for job in jobs) and time.monotonic()<until:time.sleep(.005)
   assert all(accounting(job)['active']==0 for job in jobs);all_empty=all_empty and all(accounting(job)['active']==0 for job in jobs)
   for handle in [ht,hp,*reversed(jobs)]:
    if handle is not None:k.CloseHandle(handle)
  iterations=index+1
print(json.dumps({'attempts':iterations,'snapshots':snapshots,'mismatchSamples':mismatches,'queryErrors':query_errors,'peakAssigned':peak_assigned,'peakListed':peak_listed,'allKnownRootsSignaled':all_roots_signaled,'allNestedJobAccountingEmpty':all_empty,'seconds':round(time.monotonic()-start,3),'scope':'Bounded benign git --version nested-job sampling; accounting samples are non-atomic. No claim of reproducing the analyzed Git fixture or proving every descendant object signaled.'}))
'''
script=jobroot/'owned-probe.py';script.write_text(child,encoding='utf8');(out/'owned-probe.py').write_bytes(script.read_bytes());complete=False
try:
 observed=json.loads(run('actual-owned-nested-job-git-probe',[sys.executable,'-X','utf8',script,git,source],timeout=90));assert observed['allKnownRootsSignaled'] and observed['allNestedJobAccountingEmpty'];assert sha(git)==git_hash and all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allOuterJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'gitSha256':git_hash,'frozenInputs':len(inputs),'observation':observed if complete else None,'productionChanges':False,'systemChanges':False},indent=2)+'\n',encoding='utf8')
print(json.dumps(observed))
