from pathlib import Path
import ctypes,json,msvcrt,os,subprocess,sys,time,_winapi
k=ctypes.WinDLL('kernel32',use_last_error=True)
class Basic(ctypes.Structure):_fields_=[('processTime',ctypes.c_int64),('jobTime',ctypes.c_int64),('flags',ctypes.c_uint32),('minWorking',ctypes.c_size_t),('maxWorking',ctypes.c_size_t),('activeLimit',ctypes.c_uint32),('affinity',ctypes.c_size_t),('priority',ctypes.c_uint32),('scheduling',ctypes.c_uint32)]
class Extended(ctypes.Structure):_fields_=[('basic',Basic),('io',ctypes.c_uint64*6),('processMemory',ctypes.c_size_t),('jobMemory',ctypes.c_size_t),('peakProcessMemory',ctypes.c_size_t),('peakJobMemory',ctypes.c_size_t)]
for name,args,result in [('CreateJobObjectW',[ctypes.c_void_p,ctypes.c_wchar_p],ctypes.c_void_p),('SetInformationJobObject',[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32],ctypes.c_int),('AssignProcessToJobObject',[ctypes.c_void_p,ctypes.c_void_p],ctypes.c_int),('QueryInformationJobObject',[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_void_p],ctypes.c_int),('TerminateJobObject',[ctypes.c_void_p,ctypes.c_uint32],ctypes.c_int),('ResumeThread',[ctypes.c_void_p],ctypes.c_uint32),('CloseHandle',[ctypes.c_void_p],ctypes.c_int)]:
    f=getattr(k,name);f.argtypes=args;f.restype=result
assert ctypes.sizeof(Extended)==144

class ProcessIds(ctypes.Structure):_fields_=[('assigned',ctypes.c_uint32),('listed',ctypes.c_uint32),('ids',ctypes.c_size_t*4096)]
git=sys.argv[1];root=sys.argv[2];mismatches=[];snapshots=0;iterations=0;all_empty=True;all_roots_signaled=True;query_errors=[];start=time.monotonic();peak_assigned=0;peak_listed=0

def accounting(job):
 b=ctypes.create_string_buffer(48);assert k.QueryInformationJobObject(job,1,b,48,None);return {'total':int.from_bytes(b.raw[36:40],'little'),'active':int.from_bytes(b.raw[40:44],'little')}

def sample(job,phase,hp):
 global snapshots,peak_assigned,peak_listed
 b=ProcessIds();ok=k.QueryInformationJobObject(job,3,ctypes.byref(b),ctypes.sizeof(b),None);snapshots+=1
 if not ok:query_errors.append({'phase':phase,'error':ctypes.get_last_error()});return
 peak_assigned=max(peak_assigned,b.assigned);peak_listed=max(peak_listed,b.listed)
 if b.assigned!=b.listed and len(mismatches)<32:mismatches.append({'iteration':iterations,'phase':phase,'assigned':b.assigned,'listed':b.listed,'capacity':4096,'rootSignaledAfterSnapshot':_winapi.WaitForSingleObject(hp,0)==0,'accountingAfterSnapshot':accounting(job),'returnedBytes':None})

with open(os.devnull,'r+b') as null:
 nh=msvcrt.get_osfhandle(null.fileno());os.set_handle_inheritable(nh,True)
 for index in range(300):
  if time.monotonic()-start>60:break
  jobs=[];hp=ht=None;attached=False;iterations=index
  try:
   for _ in range(2):
    job=k.CreateJobObjectW(None,None);assert job;jobs.append(job);limits=Extended();limits.basic.flags=0x2000;assert k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits))
   si=subprocess.STARTUPINFO();si.dwFlags=subprocess.STARTF_USESTDHANDLES;si.hStdInput=si.hStdOutput=si.hStdError=nh;si.lpAttributeList={'handle_list':[nh]}
   hp,ht,pid,tid=_winapi.CreateProcess(None,subprocess.list2cmdline([git,'--version']),None,None,True,subprocess.CREATE_NO_WINDOW|0x4,dict(os.environ),root,si)
   assert k.AssignProcessToJobObject(jobs[0],hp);attached=True;assert k.AssignProcessToJobObject(jobs[1],hp);assert k.ResumeThread(ht)!=0xffffffff
   until=time.monotonic()+2
   while _winapi.WaitForSingleObject(hp,0)==258 and time.monotonic()<until:
    sample(jobs[0],'root-running-outer',hp);sample(jobs[1],'root-running-inner',hp);_winapi.WaitForSingleObject(hp,1)
   assert _winapi.WaitForSingleObject(hp,0)==0,'Owned benign git exceeded2seconds'
   assert _winapi.GetExitCodeProcess(hp)==0
   sample(jobs[0],'root-signaled-outer',hp);sample(jobs[1],'root-signaled-inner',hp)
  finally:
   if hp is not None and not attached:_winapi.TerminateProcess(hp,124)
   for job in reversed(jobs):assert k.TerminateJobObject(job,125)
   if hp is not None:all_roots_signaled=all_roots_signaled and _winapi.WaitForSingleObject(hp,2000)==0
   until=time.monotonic()+2
   while any(accounting(job)['active'] for job in jobs) and time.monotonic()<until:time.sleep(.005)
   assert all(accounting(job)['active']==0 for job in jobs);all_empty=all_empty and all(accounting(job)['active']==0 for job in jobs)
   for handle in [ht,hp,*reversed(jobs)]:
    if handle is not None:k.CloseHandle(handle)
  iterations=index+1
print(json.dumps({'attempts':iterations,'snapshots':snapshots,'mismatchSamples':mismatches,'queryErrors':query_errors,'peakAssigned':peak_assigned,'peakListed':peak_listed,'allKnownRootsSignaled':all_roots_signaled,'allNestedJobAccountingEmpty':all_empty,'seconds':round(time.monotonic()-start,3),'scope':'Bounded benign git --version nested-job sampling; accounting samples are non-atomic. No claim of reproducing the analyzed Git fixture or proving every descendant object signaled.'}))
