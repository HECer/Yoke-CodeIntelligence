from pathlib import Path
import json,subprocess,sys
spec=json.loads(Path(sys.argv[1]).read_bytes())
messages=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25'}},{'jsonrpc':'2.0','method':'notifications/initialized'},{'jsonrpc':'2.0','id':2,'method':'tools/list'},{'jsonrpc':'2.0','id':3,'method':'tools/call','params':spec['call']}]
result=subprocess.run(spec['args'],input=''.join(json.dumps(v)+'\n' for v in messages).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
Path(spec['stdout']).write_bytes(result.stdout);Path(spec['stderr']).write_bytes(result.stderr)
assert result.returncode==0,(result.returncode,result.stderr.decode('utf8','replace'))
replies=[json.loads(line) for line in result.stdout.splitlines()];assert len(replies)==3 and [v.get('id') for v in replies]==[1,2,3],replies
assert replies[0]['result']['protocolVersion']=='2025-11-25'
catalog=replies[1]['result']['tools'];assert len(catalog)==spec['toolCount']
assert 'error' not in replies[2] and not replies[2]['result'].get('isError'),replies[2]
payload=json.loads(replies[2]['result']['content'][0]['text']);assert payload is not None
if isinstance(payload,dict) and all(key in payload for key in ['requestId','metrics','data']):
 assert len(payload['requestId'])==64 and all(c in '0123456789abcdef' for c in payload['requestId'])
 size=len(replies[2]['result']['content'][0]['text'].encode('utf8'));metrics=payload['metrics'];assert metrics['serializedBytes']==size
 assert metrics['estimatedTokens']==(size+2)//3 and metrics['tokenMethod']=='utf8_bytes_div_3' and metrics['tokenCount']=='estimated'
 assert isinstance(metrics['durationMs'],int) and metrics['durationMs']>=0
 assert metrics['modelCalls']==0 and metrics['languageServerAttempts']==1 and not metrics['localOnly'] and metrics['externalUsage']=='unknown'
if isinstance(payload,dict) and 'status' in payload:assert payload['status']=='ok',payload
if spec.get('contains'):assert spec['contains'] in json.dumps(payload,ensure_ascii=False),payload
Path(spec['result']).write_bytes(json.dumps({'catalog':catalog,'payload':payload},indent=2).encode())
print(json.dumps({'nativeExitCode':result.returncode,'receivedReplies':len(replies),'toolCount':len(catalog)}))
