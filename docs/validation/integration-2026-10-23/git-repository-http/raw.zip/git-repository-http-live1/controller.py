from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/git-repository-http-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-repository-discovery-check-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import sqlite3
inputs=json.loads((w/'validation/integration-20261018/git-repository-http-test2/source-before.json').read_bytes());assert len(inputs)==1094 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
client=Path(r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\claude-2.1.306-win32-x64\claude.exe');assert sha(client)=='f6bc9de38f507c36c9a3bb0085a59a27e32156e2208252bf1707c4e3ef309114'
git=Path(shutil.which('git.exe'));assert git.is_absolute()
source=jobroot/'source π';source.mkdir();nested=source/'nested ß';nested.mkdir();(source/'main.rs').write_bytes(b'pub fn parent_owned(){}\r\n');(source/'excluded.rs').write_bytes(b'pub fn must_be_excluded(){}\n');(nested/'child.rs').write_bytes(b'pub fn child_owned(){}\n')
configroot=jobroot/'private-client';configroot.mkdir();(configroot/'.env').write_bytes(b'');private=jobroot/'claude-state';private.mkdir();env['CLAUDE_CONFIG_DIR']=str(private);(private/'settings.json').write_bytes(json.dumps({'enabledMcpjsonServers':['yoke_owned_git_http']}).encode());env.update({'DISABLE_TELEMETRY':'1','DISABLE_ERROR_REPORTING':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','CI':'1','NO_COLOR':'1','MCP_TIMEOUT':'20000'})
# Never archive the generated token or header-bearing private client files.
token=jobroot/'ephemeral-token.bin';token.write_bytes(os.urandom(32));helper=Path(tempfile.gettempdir())/'ci-git-http-live-helper.rs';shutil.copyfile(helper,out/'helper.rs');exe=jobroot/'http-owned-helper.exe';complete=False
try:
 for name,root,files in [('parent',source,['main.rs','excluded.rs']),('nested',nested,['child.rs'])]:
  fixed=[git,'-C',root,'-c','core.hooksPath=','-c','user.name=Owned Validation','-c','user.email=owned@example.invalid','-c','commit.gpgSign=false']
  run('git-init-'+name,[*fixed,'init','--quiet','--template=']);run('git-add-'+name,[*fixed,'add','--',*files]);run('git-commit-'+name,[*fixed,'commit','--quiet','-m','Owned fixture'])
 original={p.relative_to(source).as_posix():sha(p) for p in source.rglob('*') if p.is_file()}
 deps=w/'target/debug/deps';lib=deps/'libyoke-baa04a776fa3c0c3.rlib';serde=deps/'libserde_json-16f5fa87d8ed4414.rlib'
 # Pin the already selected package's current serde_json artifact, with a unique exact filename.
 assert serde.is_file()
 assert lib.is_file();native_inputs={str(p):sha(p) for p in [lib,serde]};(out/'helper-link-inputs.json').write_bytes(json.dumps(native_inputs,indent=2).encode())
 run('rustc-owned-helper',[r'C:\Users\Lomi\.cargo\bin\rustc.exe','--edition','2024','--crate-name','owned_git_http_live',helper,'--extern','yoke='+str(lib),'--extern','serde_json='+str(serde),'-L','dependency='+str(deps),'-C','debuginfo=0','-o',exe],timeout=300)
 reply=run('actual-http-all-profiles-and-client',[exe,source,git,token,client,configroot],timeout=240);profiles=json.loads(reply);assert len(profiles)==6 and all(p['actualPinnedClaudeGetConnected'] and p['actualPinnedClaudeListConnected'] for p in profiles)
 now={p.relative_to(source).as_posix():sha(p) for p in source.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(source).parts};assert now==original
 with sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True) as db:
  snapshots=[json.loads(r[0]) for r in db.execute('SELECT value FROM snapshots ORDER BY id')];proofs=[json.loads(r[0]) for r in db.execute("SELECT value FROM records WHERE kind='native_capture_options_v1' ORDER BY id")]
 assert len(snapshots)==1;assert sorted(f['path'] for f in snapshots[0]['files'])==['main.rs','nested ß/child.rs'];assert proofs and all(p['options']['repositoryScope']['readOnlyRoots']==['nested ß'] for p in proofs)
 (out/'saved-source-proof.json').write_bytes((json.dumps({'snapshots':snapshots,'proofs':proofs},indent=2)+'\n').encode());assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'fixtureRoot':str(jobroot),'frozenInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'ownedParentProcessCalls':len(rows),'actualClientVersion':'2.1.306','actualClientSha256':sha(client),'sixProfilesOverActualHttp':complete,'actualClientHealthCalls':12 if complete else None,'privateCredentialAndClientOutputArchived':False,'realModelCalls':0,'projectCodeAutomaticallyExecuted':False,'systemSettingsChanged':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
