import json,subprocess,sys
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_bytes())
requests=[{"jsonrpc":"2.0","id":1,"method":"initialize"},{"jsonrpc":"2.0","id":2,"method":"tools/list"},{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"get_current_config","arguments":{}}},{"jsonrpc":"2.0","id":4,"method":"tools/call","params":{"name":"find_symbol","arguments":{"name_path_pattern":"visible","include_body":True}}}]
result=subprocess.run(spec["args"],input=("\n".join(json.dumps(m) for m in requests)+"\n").encode(),capture_output=True,timeout=90,creationflags=0x08000000)
Path(spec["stdout"]).write_bytes(result.stdout);Path(spec["stderr"]).write_bytes(result.stderr)
assert result.returncode==0,(result.returncode,result.stderr.decode(errors="replace"))
messages=[json.loads(line) for line in result.stdout.splitlines()]
assert all("error" not in m and not m.get("result",{}).get("isError",False) for m in messages),messages
assert any(m.get("id")==4 and "visible" in json.dumps(m) for m in messages),messages
