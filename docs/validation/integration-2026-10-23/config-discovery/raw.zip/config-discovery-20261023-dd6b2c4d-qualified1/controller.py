from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/config-discovery-20261023-dd6b2c4d-qualified1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))
old=json.loads((w/'validation/integration-20261018/config-discovery-20261023-dd6b2c4d-green1/source-before.json').read_bytes());inputs={n:sha(w/n) for n in old};assert len(inputs)==1112;(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());assert {n for n,h in old.items() if inputs[n]!=h}=={'native/src/session_config_cli.rs'}
native=w/'target/debug/yoke.exe';backup=w/'target/config-discovery-20261023-dd6b2c4d-before/yoke.exe';assert sha(backup)=='c84be740e8c03bd02c02fa82c4e478f5025b9de49e94f805a5fe1d16347b3221';assert shutil.disk_usage(w).free>1_200_000_000
targets=['session_config_discovery','session_config_cli','session_primary_read_only','session_optional_defaults','session_steering','session_startup_project','session_mcp','session_memory_patterns','server_catalog','server_selection','server_settings','server_workspace_settings','lsp_resource_settings','source_line_endings','source_exclusions','project_session'];(out/'targets.json').write_bytes((json.dumps(targets,indent=2)+'\n').encode());complete=False;compression=[];commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
def owned(name,args,**options):
 with contextlib.redirect_stdout(commandlog):data=run(name,args,**options)
 print(json.dumps({'name':name,'exitCode':rows[-1].get('exitCode'),'activeAfterCleanup':rows[-1]['activeAfterCleanup']}),flush=True);return data
def compact_passed(path,label):
 assert path.is_file() and not path.is_symlink() and path.resolve()!=native.resolve() and path.name not in ['capture_options-784339a4da3fe379.exe','session_fixed_tools-0671ac4d8f474009.exe']
 record={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)};assert shutil.disk_usage(w).free>record['bytes']+64_000_000
 owned('compact-passed-'+label,[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(path)],timeout=90);assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256'];compression.append({**record,'logicalBytesAndSha256Unchanged':True});(out/'compression.json').write_bytes((json.dumps(compression,indent=2)+'\n').encode())
def harness(data,target,kind):
 result=[]
 for line in data.splitlines():
  try:m=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if m.get('reason')=='compiler-artifact' and Path(m['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and m['target']['name']==target and kind in m['target']['kind'] and m['profile']['test'] and m.get('executable'):result.append(Path(m['executable']))
 assert len(result)==1 and result[0].parent.resolve()==(w/'target/debug/deps').resolve();return result[0]
try:
 compact_passed(backup,'prior-c84-cli')
 cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';python=r'C:\Python314\python.exe';helper=[python,'-X','utf8',str(w/'scripts/run_native_tests.py'),'--controlled-test-runner','--locked','--offline']
 data=owned('main-all',[*helper,'--bin','yoke','-j','2','--message-format','json','--','--test-threads=1'],timeout=600);compact_passed(harness(data,'yoke','bin'),'main-units')
 owned('clippy-all-targets',[cargo,'clippy','--workspace','--all-targets','--locked','--offline','--keep-going','-j','2','--','-D','warnings'],timeout=900)
 owned('format-complete',[python,'-X','utf8','scripts/native_fmt.py','--check'],timeout=600)
 for target in targets:
  data=owned('test-'+target,[*helper,'--test',target,'-j','2','--message-format','json','--','--test-threads=1'],timeout=360);compact_passed(harness(data,target,'test'),target)
 owned('debug-build',[cargo,'build','--workspace','--locked','--offline','-j','2','--message-format','json'],timeout=600)
 owned('cli-version',[native,'--version'],timeout=30)
 owned('python-all',[python,'-X','utf8','-m','unittest','discover','-s','scripts/tests','-v'],timeout=300)
 npm=shutil.which('npm.cmd');assert npm
 owned('npm-typecheck',[os.environ['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
 owned('npm-test',[os.environ['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 assert all(sha(w/n)==h for n,h in inputs.items()) and sha(backup)=='c84be740e8c03bd02c02fa82c4e478f5025b9de49e94f805a5fe1d16347b3221';complete=True
finally:
 result={'complete':complete,'sourceCommit':'dd6b2c4dfcb3d86e395643d14073ab12987bdc39','sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'nativeCliCurrent':sha(native),'priorCliBackup':str(backup),'priorCliBackupSha256':sha(backup),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'targets':targets,'coreLibraryRerun':False,'coreLibrarySourceChanged':False,'originalFixturesIgnoreDeadlinesProfilesUnchanged':True};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
