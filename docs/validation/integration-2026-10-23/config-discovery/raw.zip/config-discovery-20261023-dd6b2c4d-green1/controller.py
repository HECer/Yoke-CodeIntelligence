from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();phase=sys.argv[1];out=w/('validation/integration-20261018/config-discovery-20261023-dd6b2c4d-'+phase);out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))
prior=json.loads((w/'validation/integration-20261018/owned-member-diagnostic-20261023-8fee30c7-qualified2/source-before.json').read_bytes());names=[*prior,'native/docs/windows-process-cleanup.md','native/tests/session_config_discovery.rs'];new='native/src/session_config_discovery_cli.rs'
if (w/new).exists():names.append(new)
inputs={n:sha(w/n) for n in names};(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());assert shutil.disk_usage(w).free>1_200_000_000
native=w/'target/debug/yoke.exe';native_before=sha(native);complete=False
try:
 args=[r'C:\Python314\python.exe','-X','utf8',str(w/'scripts/run_native_tests.py'),'--controlled-test-runner','--locked','--offline','--test','session_config_discovery','-j','2','--message-format','json','--','--test-threads=1']
 run('new-discovery-contract',args,expected=101 if phase=='red1' else 0,timeout=600)
 if phase=='red1':assert b'0 passed; 12 failed' in (out/'new-discovery-contract.stdout').read_bytes()
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'phase':phase,'sourceCommit':'dd6b2c4dfcb3d86e395643d14073ab12987bdc39','sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'nativeCliBefore':native_before,'nativeCliAfter':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'originalFixturesIgnoreDeadlinesProfilesUnchanged':True};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
