from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/ci-tls-boundary-20261023-2095792b-green1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import contextlib
old=json.loads((w/'validation/integration-20261018/vsix-current-20261023-2095792b-build1/source-before.json').read_bytes());inputs={n:sha(w/n) for n in old};assert {n for n in old if old[n]!=inputs[n]}=={'scripts/tests/test_native_test_runner.py','scripts/run_native_tests.py','.github/workflows/rust.yml'};(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+chr(10)).encode());env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH'];commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
try:
 with contextlib.redirect_stdout(commandlog):run('runner-boundary-green',[r'C:\Python314\python.exe','-X','utf8','-m','unittest','discover','-s','scripts/tests','-p','test_native_test_runner.py','-v'],expected=None,timeout=240)
 assert rows[-1]['exitCode']==0
finally:
 result={'greenExpected':True,'observedExitCode':rows[-1].get('exitCode') if rows else None,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'privateCargoPathOnlyCorrected':True,'productionHelperUnchanged':sha(w/'scripts/run_native_tests.py')==old['scripts/run_native_tests.py'],'sourceCommit':'2095792b5a74ed2a6a86533a91bfa445ae9e2eca'};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps(result),flush=True)
