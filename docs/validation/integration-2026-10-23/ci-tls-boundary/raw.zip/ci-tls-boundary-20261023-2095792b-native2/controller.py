from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/ci-tls-boundary-20261023-2095792b-native2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import contextlib,re
base=w/'validation/integration-20261018';qualified=base/'ci-tls-boundary-20261023-2095792b-qualified3';q=json.loads((qualified/'result.json').read_bytes());assert q['allChecksExpectedPass'] and q['observedExitCode']==0 and q['allJobsEmpty'] and q['sourceInputsUnchanged'];inputs=json.loads((qualified/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+chr(10)).encode());full=base/'native-full-current-20261023-89a277f8-run13';trial=json.loads((full/'result.json').read_bytes());assert trial['complete'];group=next(g for g in json.loads((full/'groups.json').read_bytes()) if g['target']=='google_workspace_http_cli');assert group['passed']==4 and group['failed']==0;found=[]
for line in (base/group['evidencePhase']/(group['name']+'.stdout')).read_bytes().splitlines():
 try:m=json.loads(line)
 except (ValueError,UnicodeDecodeError):continue
 if m.get('reason')=='compiler-artifact' and m['target']['name']=='google_workspace_http_cli' and m.get('executable'):found.append(Path(m['executable']))
assert len(found)==1;exe=found[0];proof=next(c for c in json.loads((full/'successful-artifacts.json').read_bytes()) if c['path']==str(exe));assert sha(exe)==proof['sha256'];native=w/'target/debug/yoke.exe';assert sha(native)==trial['cliSha256'];commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1);complete=False;results=[]
def owned(name,args,**kw):
 with contextlib.redirect_stdout(commandlog):v=run(name,args,**kw)
 print(json.dumps({'command':name,'exitCode':rows[-1]['exitCode'],'allJobsEmpty':rows[-1]['activeAfterCleanup']==0}),flush=True);return v
try:
 rustc=Path(owned('rustup-which-rustc',[r'C:\Users\Lomi\.cargo\bin\rustup.exe','which','rustc'],timeout=60).decode().strip());host='x86_64-pc-windows-msvc';env['PATH']=os.pathsep.join([str(w/'target/debug/deps'),str(w/'target/debug'),str(rustc.parent),str(rustc.parent.parent/'lib/rustlib'/host/'lib'),r'C:\Users\Lomi\.cargo\bin',env['PATH']]);env.update({'CARGO':r'C:\Users\Lomi\.cargo\bin\cargo.exe','CARGO_MANIFEST_DIR':str(w/'native'),'CARGO_MANIFEST_PATH':str(w/'native/Cargo.toml'),'CARGO_PKG_NAME':'yoke-code-intelligence','CARGO_PKG_VERSION':'0.5.0','CARGO_TARGET_TMPDIR':str(w/'target/tmp')});env.update({name:str(jobroot/'owned-ambient-tls') for name in ['SSL_CERT_FILE','SSL_CERT_DIR','SSLKEYLOGFILE']});cwd=w/'native'
 for label,args,expected in [('raw-original-harness',[str(exe),'--test-threads=1'],[1,3,0,0,0]),('controlled-original-harness',[r'C:\Python314\python.exe',str(w/'scripts/run_native_tests.py'),'--test-executable',str(exe),'--test-threads=1'],[4,0,0,0,0])]:
  text=owned(label,args,expected=None,timeout=180).decode('utf8');m=re.findall(r'(?m)^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text);assert m and list(map(int,m[-1]))==expected;assert rows[-1]['exitCode']==(101 if expected[1] else 0)
  if expected[1]:assert 'google_workspace_http_ambient_tls_settings_refused' in text
  results.append({'label':label,'passed':expected[0],'failed':expected[1],'ignored':expected[2],'measured':0,'filtered':0,'originalNormalHarness':True,'noCompileOrTestChanges':True})
 libgroup=next(g for g in json.loads((full/'groups.json').read_bytes()) if g['kind']=='lib');libpaths=[]
 for line in (base/libgroup['evidencePhase']/(libgroup['name']+'.stdout')).read_bytes().splitlines():
  try:message=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if message.get('reason')=='compiler-artifact' and message['target']['name']==libgroup['target'] and message.get('profile',{}).get('test') and message.get('executable'):libpaths.append(Path(message['executable']))
 assert len(libpaths)==1;libexe=libpaths[0];libproof=next(c for c in json.loads((full/'successful-artifacts.json').read_bytes()) if c['path']==str(libexe));assert sha(libexe)==libproof['sha256'] and libgroup['failed']==0;text=owned('controlled-original-library',[r'C:\Python314\python.exe',str(w/'scripts/run_native_tests.py'),'--test-executable',str(libexe),'--test-threads=1'],timeout=900).decode('utf8');matches=re.findall(r'(?m)^test result: (?:ok|FAILED). (d+) passed; (d+) failed; (d+) ignored; (d+) measured; (d+) filtered out;',text);assert matches and list(map(int,matches[-1]))==[libgroup['passed'],0,libgroup['ignored'],0,0];assert sha(libexe)==libproof['sha256'];results.append({'label':'controlled-original-library','passed':libgroup['passed'],'failed':0,'ignored':libgroup['ignored'],'measured':0,'filtered':0,'originalNormalHarness':True,'noCompileOrTestChanges':True,'harnessSha256':libproof['sha256']})
 assert all(sha(w/n)==h for n,h in inputs.items()) and sha(exe)==proof['sha256'] and sha(native)==trial['cliSha256'];complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'harness':str(exe),'harnessSha256':sha(exe),'nativeCliSha256':sha(native),'results':results,'deliberateInnerAmbientTlsRefusalTestRetained':complete,'productionRustSourceUnchanged':True,'noCargoCompile':True,'noLiveGoogleDocumentOrCredentialUsed':True,'systemSettingsChanged':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps(result),flush=True)
assert complete
