from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/vsix-current-20261023-2095792b-vscode-import1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import contextlib,urllib.request,zipfile,re
metadata={'source':'https://update.code.visualstudio.com/api/update/win32-x64-archive/stable/latest','url':'https://vscode.download.prss.microsoft.com/dbazure/download/stable/e646868227c3e3a9e3f24277c8c7220be42c0be7/VSCode-win32-x64-1.143.1.zip','name':'1.143.1','version':'e646868227c3e3a9e3f24277c8c7220be42c0be7','sha256hash':'b4f9643b8a549ca2c85a1bbc9063fc76f1e08fc0036a7f6a1a181cdc05235eca'};(out/'official-release-metadata.json').write_bytes((json.dumps(metadata,indent=2)+chr(10)).encode());base=Path(r'C:\Users\Lomi\AppData\Local\YokeValidation\tools').resolve();root=base/'vscode-1.143.1-win32-x64';archive=base/'VSCode-win32-x64-1.143.1-import1.zip';assert root.parent==base and not root.exists();assert not archive.exists();complete=False;members=[];downloaded=0;commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
try:
 assert shutil.disk_usage(base).free>3_000_000_000
 with urllib.request.urlopen(urllib.request.Request(metadata['url'],headers={'User-Agent':'Yoke-CodeIntelligence-validation/0.5.0'}),timeout=45) as response,archive.open('xb') as dst:
  declared=response.headers.get('Content-Length');assert declared is None or int(declared)<=700_000_000;(out/'download-headers.json').write_bytes((json.dumps({'finalUrl':response.url,'contentLength':declared,'status':response.status},indent=2)+chr(10)).encode());assert response.url.startswith('https://vscode.download.prss.microsoft.com/');start=time.monotonic();next_progress=64*1024*1024
  while True:
   chunk=response.read(1024*1024)
   if not chunk:break
   downloaded+=len(chunk);assert downloaded<=700_000_000 and time.monotonic()-start<900 and shutil.disk_usage(base).free>1_500_000_000;dst.write(chunk)
   if downloaded>=next_progress:print(json.dumps({'downloadedBytes':downloaded}),flush=True);next_progress+=64*1024*1024
 assert sha(archive)==metadata['sha256hash'];root.mkdir(exist_ok=False);reserved={'con','prn','aux','nul',*['com'+str(i) for i in range(1,10)],*['lpt'+str(i) for i in range(1,10)]};seen=set()
 with zipfile.ZipFile(archive) as z:
  infos=z.infolist();assert len(infos)<=100000 and sum(i.file_size for i in infos)<=3_000_000_000
  for i in infos:
   name=i.filename;parts=Path(name).parts;assert name and not name.startswith(('/','\\')) and '\\' not in name and ':' not in name and all(p not in ['.','..'] and p.rstrip('. ')==p and p.split('.')[0].lower() not in reserved for p in parts);assert (i.external_attr>>16)&0o170000!=0o120000 and i.file_size<=512_000_000;canonical=name.rstrip('/').casefold();assert canonical not in seen;seen.add(canonical);target=(root/name).resolve();assert target.is_relative_to(root.resolve())
   if i.is_dir():target.mkdir(parents=True,exist_ok=True);continue
   target.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();written=0
   with z.open(i) as src,target.open('xb') as dst:
    while True:
     chunk=src.read(1024*1024)
     if not chunk:break
     assert shutil.disk_usage(base).free>1_500_000_000;h.update(chunk);dst.write(chunk);written+=len(chunk)
   assert written==i.file_size;members.append({'path':name,'bytes':written,'sha256':h.hexdigest()})
 (out/'extracted-members.json').write_bytes((json.dumps(members,indent=2)+chr(10)).encode());exe=root/'Code.exe';assert exe.is_file();script="$p='"+str(exe)+"'; $s=Get-AuthenticodeSignature -LiteralPath $p; [PSCustomObject]@{Status=[string]$s.Status;Signer=$s.SignerCertificate.Subject;ProductVersion=(Get-Item -LiteralPath $p).VersionInfo.ProductVersion} | ConvertTo-Json -Compress"
 with contextlib.redirect_stdout(commandlog):raw=run('code-authenticode',[env['SystemRoot']+'\\System32\\WindowsPowerShell\\v1.0\\powershell.exe','-NoProfile','-NonInteractive','-Command',script],timeout=90)
 signature=json.loads(raw);assert signature['Status']=='Valid' and 'CN=Microsoft Corporation' in signature['Signer'] and signature['ProductVersion'].startswith('1.143.1');complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'officialMetadata':metadata,'archive':str(archive),'downloadedBytes':downloaded,'root':str(root),'extractedFiles':len(members),'code':{'path':str(exe),'sha256':sha(exe),'signature':signature} if complete else None,'noProgramInstalledOrExecuted':True,'onlyTaskOwnedCacheChanged':True,'systemSettingsChanged':False,'noArtifactDeletion':True};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps(result),flush=True)
assert complete
