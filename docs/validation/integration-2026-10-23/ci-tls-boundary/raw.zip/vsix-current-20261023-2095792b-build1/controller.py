from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/vsix-current-20261023-2095792b-build1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import contextlib
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='2095792b5a74ed2a6a86533a91bfa445ae9e2eca' and not subprocess.check_output(['git','status','--porcelain']);prior=w/'validation/integration-20261018/native-full-current-20261023-89a277f8-preflight1';old_inputs=json.loads((prior/'source-before.json').read_bytes());review=json.loads((w/'docs/validation/integration-2026-10-23/native-baseline-current/post-review-docs.json').read_bytes());inputs={n:sha(w/n) for n in old_inputs};changes={n for n,h in old_inputs.items() if inputs[n]!=h};assert changes==set(review['changedFrozenInputs']) and all(inputs[n]==v['after'] and old_inputs[n]==v['before'] for n,v in review['changedFrozenInputs'].items());assert len(inputs)==1100;(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+chr(10)).encode());pre=json.loads((prior/'result.json').read_bytes());protected=pre['protectedDefaultMetadataOnly'];cli=w/'target/debug/yoke.exe';assert sha(cli)==pre['cliSha256'];cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';complete=False;commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
def owned(name,args,**kw):
 with contextlib.redirect_stdout(commandlog):v=run(name,args,**kw)
 print(json.dumps({'command':name,'exitCode':rows[-1]['exitCode'],'allJobsEmpty':rows[-1]['activeAfterCleanup']==0}),flush=True);return v
def protected_exact():
 for name,expected in protected.items():
  p=w/'target/debug/deps'/name
  if expected.get('absent'):assert not p.exists()
  else:
   st=p.stat();assert {'bytes':st.st_size,'mtimeNs':st.st_mtime_ns,'attributes':getattr(st,'st_file_attributes',None)}==expected
try:
 protected_exact();free=shutil.disk_usage(w).free;assert free>4_000_000_000,'Stop before release compile: insufficient disk headroom';(out/'preflight.json').write_bytes((json.dumps({'sourceCommit':head,'frozenInputs':1100,'oldFrozenDocumentationChangesExactlyReconciled':sorted(changes),'debugCliSha256':sha(cli),'debugCliBytes':cli.stat().st_size,'packagePerEntryLimit':128000000,'releaseBuildRequiredForCanonicalVsix':cli.stat().st_size>128000000,'initialFreeBytes':free,'profileUnchanged':True,'cargoBuildOffline':True,'timeoutSeconds':3600},indent=2)+chr(10)).encode());print(json.dumps({'phase':'release-build-start','sourceCommit':head,'frozenInputs':1100,'freeBytes':free}),flush=True);owned('rustc-version',[r'C:\Users\Lomi\.cargo\bin\rustc.exe','-vV'],timeout=90);owned('cargo-build-release',[cargo,'build','--workspace','--release','--locked','--offline','-j','2','--message-format','json'],timeout=3600);assert all(sha(w/n)==h for n,h in inputs.items()) and sha(cli)==pre['cliSha256'];protected_exact();release=w/'target/release/yoke.exe';assert release.is_file();version=owned('release-version',[str(release),'--version'],timeout=30).decode().strip();assert version=='yoke 0.5.0';artifacts=[]
 for line in (out/'cargo-build-release.stdout').read_bytes().splitlines():
  try:v=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if v.get('reason')=='compiler-artifact' and v['target']['name']=='yoke' and v['target']['src_path'].startswith(str(w/'native')):artifacts.append(v)
 assert any(a.get('executable') and Path(a['executable']).resolve()==release.resolve() for a in artifacts);(out/'own-release-artifacts.json').write_bytes((json.dumps(artifacts,indent=2)+chr(10)).encode());complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceCommit':head,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':1100,'debugCliSha256':sha(cli),'protectedDefaultMetadataUnchanged':True,'release':{'path':str(release),'bytes':release.stat().st_size,'sha256':sha(release),'version':version} if complete else None,'noSourceProfileOrSystemChanges':True,'noArtifactDeletion':True};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps(result),flush=True)
assert complete
