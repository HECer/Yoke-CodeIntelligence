from pathlib import Path
import ast,hashlib,json,subprocess,shutil
w=Path.cwd();base=w/'validation/integration-20261018';prefix='ci-tls-boundary-20261023-2095792b-';out=base/(prefix+'final-audit4');out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((base/(prefix+'final-audit3')/'result.json').read_bytes());assert old['complete']
q=base/(prefix+'qualified4');result=json.loads((q/'result.json').read_bytes());assert result['observedExitCode']==0 and result['allJobsEmpty'] and result['sourceInputsUnchanged']
rows=json.loads((q/'progress.json').read_bytes());assert len(rows)==3 and all(r['exitCode']==0 and r['activeAfterCleanup']==0 for r in rows)
inputs=json.loads((q/'source-before.json').read_bytes());assert len(inputs)==1100 and all(sha(w/n)==h for n,h in inputs.items())
before=json.loads((base/(prefix+'qualified3')/'source-before.json').read_bytes())
assert {n for n in inputs if inputs[n]!=before[n]}=={'scripts/run_native_tests.py','scripts/tests/test_native_test_runner.py','docs/STATUS.md','docs/REMAINING_WORK.md','docs/parity/native-reconciliation-2026-10-15.json'}
prior_helper=ast.parse(subprocess.check_output(['git','show','527d692d:scripts/run_native_tests.py']).decode());helper=ast.parse((w/'scripts/run_native_tests.py').read_text())
for name in ['main','controlled_environment']:
 pick=lambda tree:next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name==name)
 assert ast.dump(pick(prior_helper))==ast.dump(pick(helper))
prior_tests=ast.parse(subprocess.check_output(['git','show','2095792b:scripts/tests/test_native_test_runner.py']).decode());tests=ast.parse((w/'scripts/tests/test_native_test_runner.py').read_text())
pickclass=lambda tree:next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name=='NativeTestEnvironment')
assert ast.dump(pickclass(prior_tests))==ast.dump(pickclass(tests))
python=(q/'python-all.stderr').read_text(encoding='utf8');assert [int(line.split()[1]) for line in python.splitlines() if line.startswith('Ran ')]==[24] and any(line.strip()=='OK' for line in python.splitlines())
npm=(q/'npm-test.stdout').read_text(encoding='utf8');assert all(text in npm for text in ['pass 260','fail 0','skipped 3'])
changes={n:{'before':item['before'],'after':inputs[n]} for n,item in old['qualifiedWorkingSourceChanges'].items()}
final={**old,'qualifiedWorkingSourceChanges':changes,'qualificationPhase':q.name,'nativeExecutableAndCleanupAstExactFromCompletedOriginalTrials':True,'windowsCaseInsensitiveConfiguredEnvironmentPolicyRefused':True,'followupScope':'Only runner/target authority inspection and its cases changed after native trials; actual executable-boundary main and cleanup AST remain exact. No native test repeated or recompiled.'}
(out/'result.json').write_bytes((json.dumps(final,indent=2)+'\n').encode());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
print(json.dumps({'complete':True,'allCompletedJobsEmpty':True,'pythonPassed':24,'typescriptPassed':260,'existingSkipped':3,'nativeBoundaryAstExact':True,'frozenInputs':len(inputs)}))
