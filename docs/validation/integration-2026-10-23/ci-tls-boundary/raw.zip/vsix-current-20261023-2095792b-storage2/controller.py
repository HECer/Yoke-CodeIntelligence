from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/vsix-current-20261023-2095792b-storage2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import contextlib
base=w/'validation/integration-20261018';trial=json.loads((base/'native-full-current-20261023-89a277f8-run13/result.json').read_bytes());assert trial['complete'] and trial['allJobsEmpty'];candidates=json.loads((base/'native-full-current-20261023-89a277f8-run13/successful-artifacts.json').read_bytes());ledger=json.loads((base/'native-full-current-20261023-89a277f8-run12/compression.json').read_bytes());done={(r['path'],r['sha256']) for r in ledger};protected=trial['protectedDefaultMetadataOnly'];build=(w/'target/debug/deps').resolve();unique={}
for item in candidates:
 p=Path(item['path'])
 if p.suffix.lower() not in ['.exe','.pdb'] or item.get('optimized') or item.get('optimizationAttempted') or (item['path'],item['sha256']) in done:continue
 assert p.resolve().parent==build and p.name not in protected;unique[item['path']]=item
selected=sorted(unique.values(),key=lambda r:r['bytes']);(out/'selected.json').write_bytes((json.dumps(selected,indent=2)+chr(10)).encode());completed=[];complete=False;commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
try:
 for index,item in enumerate(selected):
  if shutil.disk_usage(w).free>4_000_000_000:break
  p=Path(item['path']);st=p.stat();assert p.is_file() and not p.is_symlink() and st.st_nlink==1 and not getattr(st,'st_file_attributes',0)&0x400 and st.st_size==item['bytes'] and item['bytes']<shutil.disk_usage(w).free//2 and sha(p)==item['sha256']
  with contextlib.redirect_stdout(commandlog):run('compact-debug-passed-'+str(index),[env['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(p)],timeout=300)
  assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'];completed.append({**item,'logicalBytesAndHashExactAfter':True});(out/'completed.json').write_bytes((json.dumps(completed,indent=2)+chr(10)).encode());print(json.dumps({'passedDebugArtifactsOptimized':len(completed),'freeBytes':shutil.disk_usage(w).free}),flush=True)
 assert sha(w/'target/debug/yoke.exe')==trial['cliSha256']
 for name,expected in protected.items():
  p=build/name
  if expected.get('absent'):assert not p.exists()
  else:
   st=p.stat();assert {'bytes':st.st_size,'mtimeNs':st.st_mtime_ns,'attributes':getattr(st,'st_file_attributes',None)}==expected
 complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'candidateCount':len(selected),'completedArtifacts':len(completed),'allLogicalBytesAndHashesExact':all(r['logicalBytesAndHashExactAfter'] for r in completed),'onlyPreviouslyPassedDebugArtifacts':True,'separateFromConcurrentReleaseOutputs':True,'protectedOutputsAndPrimaryCliUnchanged':complete,'noArtifactDeletion':True,'systemSettingsChanged':False,'freeBytes':shutil.disk_usage(w).free};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps(result),flush=True)
assert complete
