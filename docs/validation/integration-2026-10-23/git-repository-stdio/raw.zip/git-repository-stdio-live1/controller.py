from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/git-repository-stdio-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-git-projects-live-'));cwd=w;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
inputs=json.loads((w/'validation/integration-20261018/git-repository-stdio-test1/source-before.json').read_bytes());assert len(inputs)==1097 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
client=Path(r'C:\Users\Lomi\AppData\Local\YokeValidation\tools\claude-2.1.306-win32-x64\claude.exe');assert sha(client)=='f6bc9de38f507c36c9a3bb0085a59a27e32156e2208252bf1707c4e3ef309114';git=Path(shutil.which('git.exe'));assert git.is_absolute()
primary=jobroot/'primary \u03c0';secondary=jobroot/'secondary \u00df';nested=secondary/'nested \u00df';source=primary
for root in [primary,secondary,nested]:root.mkdir(parents=True,exist_ok=True)
(primary/'main.rs').write_bytes(b'pub fn parent_owned(){}\r\n');(primary/'excluded.rs').write_bytes(b'pub fn parent_excluded(){}\n');(secondary/'main.rs').write_bytes(b'pub fn secondary_owned(){}\r\n');(secondary/'excluded.rs').write_bytes(b'pub fn secondary_excluded(){}\n');(nested/'child.rs').write_bytes(b'pub fn child_owned(){}\n')
legacy=jobroot/'ordinary-primary';reference=jobroot/'ordinary-reference';legacy.mkdir();reference.mkdir();(legacy/'main.rs').write_bytes(b'pub fn legacy_parent(){}\n');(reference/'main.rs').write_bytes(b'pub fn legacy_reference(){}\r\n')
legacy_host=jobroot/'ordinary-host.json';legacy_host.write_bytes(json.dumps({'projects':[{'name':'reference','root':str(reference),'readOnly':True,'queryOnly':True}]}).encode());worker=jobroot/'protocol-worker.py';shutil.copyfile(Path(tempfile.gettempdir())/'ci-git-repository-profiles-protocol-worker.py',worker);shutil.copyfile(worker,out/'protocol-worker.py')
old=Path(json.loads((w/'validation/integration-20261018/git-repository-stdio-test1/result.json').read_bytes())['preservedPublishedCli']);assert sha(old)=='aea3fa92cec5c3294ce838f99ef09909e255ca83c57fbce5aef05e3b128e987b';native=w/'target/debug/yoke.exe';qualified=json.loads((w/'validation/integration-20261018/git-repository-stdio-qualified1/result.json').read_bytes());assert qualified['complete'] and sha(native)==qualified['cliSha256']
def files():
 return {str(root.relative_to(jobroot)): {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file() and '.yoke' not in p.relative_to(root).parts} for root in [primary,secondary,legacy,reference]}
def sql(root):
 with sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True) as db:return {n:sorted(db.execute('SELECT * FROM '+n).fetchall(),key=repr) for n in ['snapshots','graphs','records']}
def protocol(name,exe):
 argv=[str(exe),'--root',str(legacy),'--timeout','60000','--max-bytes','65536','serve-session','--id','owned-ordinary-registered','--host-profile',str(legacy_host),'--profile','native']
 spec={'args':argv,'call':{'name':'ci_session','arguments':{'operation':'queryProject','args':{'project':'reference','tool':'ci_read','arguments':{'path':'main.rs'}}}},'toolCount':9,'contains':'legacy_reference','stdout':str(out/(name+'.native.stdout')),'stderr':str(out/(name+'.native.stderr')),'result':str(out/(name+'.reply.json'))};file=jobroot/(name+'.json');file.write_bytes(json.dumps(spec).encode());run(name,[r'C:\Python314\python.exe','-I',worker,file],timeout=120);return json.loads((out/(name+'.reply.json')).read_bytes())
def stable(reply):
 value=json.loads(json.dumps(reply));payload=value['payload']
 if isinstance(payload,dict) and all(key in payload for key in ['requestId','metrics','data']):
  payload.pop('requestId')
  for key in ['durationMs','serializedBytes','estimatedTokens']:payload['metrics'].pop(key)
 return value

configroot=jobroot/'private-client';configroot.mkdir();(configroot/'.env').write_bytes(b'');private=jobroot/'claude-state';private.mkdir();env['CLAUDE_CONFIG_DIR']=str(private);(private/'settings.json').write_bytes(json.dumps({'enabledMcpjsonServers':['yoke_owned_git_stdio']}).encode());env.update({'DISABLE_TELEMETRY':'1','DISABLE_ERROR_REPORTING':'1','CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC':'1','CI':'1','NO_COLOR':'1','MCP_TIMEOUT':'20000'})
host=jobroot/'selected-host.json';host.write_bytes(json.dumps({'startupProject':'secondary','projects':[{'name':'secondary','root':str(secondary),'readOnly':True,'queryOnly':False}],'sourceExclusions':{'global':[['excluded.rs']]}}).encode());selection=jobroot/'git-projects.json';selection.write_bytes(json.dumps({'default':{},'secondary':{'followNestedRepositories':True}}).encode());shutil.copyfile(host,out/'owned-host.json');shutil.copyfile(selection,out/'owned-selection.json')
complete=False;legacy_exact=False;files_exact=False;runtime_ok=False;source_profiles=[]
python=Path(r'C:\Python314\python.exe');assert python.is_file()
health=jobroot/'client-health.py';health.write_bytes(b"import json,subprocess,sys\nr=subprocess.run([sys.argv[1],'mcp',sys.argv[2],'yoke_owned_git_stdio'],cwd=sys.argv[3],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45,creationflags=subprocess.CREATE_NO_WINDOW)\nok=r.returncode==0 and b'Connected' in r.stdout and b'Failed to connect' not in r.stdout\nprint(json.dumps({'connected':ok,'exitCode':r.returncode,'rawOutputArchived':False}))\nsys.exit(0 if ok else 1)\n");shutil.copyfile(health,out/'client-health.py')
def scoped(profile,label,extra=()):return [str(native),'--root',str(primary),'--timeout','60000','--max-bytes','65536','serve-session','--id',label,'--profile',profile,'--host-profile',str(host),'--git-projects',str(selection),'--allow-git-index-read','--trust-git',*extra]
def selected(name,profile,call,count,contains,extra=()):
 spec={'args':scoped(profile,'owned-'+name,extra),'call':call,'toolCount':count,'contains':contains,'stdout':str(out/(name+'.native.stdout')),'stderr':str(out/(name+'.native.stderr')),'result':str(out/(name+'.reply.json'))};file=jobroot/(name+'.json');file.write_bytes(json.dumps(spec).encode());run(name,[python,'-I',worker,file],timeout=120);return json.loads((out/(name+'.reply.json')).read_bytes())
try:
 for name,root,chosen in [('parent',primary,['main.rs','excluded.rs']),('secondary',secondary,['main.rs','excluded.rs']),('nested',nested,['child.rs'])]:
  fixed=[git,'-C',root,'-c','core.hooksPath=','-c','user.name=Owned Validation','-c','user.email=owned@example.invalid','-c','commit.gpgSign=false'];run('git-init-'+name,[*fixed,'init','--quiet','--template=']);run('git-add-'+name,[*fixed,'add','--',*chosen]);run('git-commit-'+name,[*fixed,'commit','--quiet','-m','Owned fixture'])
 original=files();protocol('old-cold-ordinary-registered',old);warm=protocol('old-warm-ordinary-registered',old);before={str(root.relative_to(jobroot)):sql(root) for root in [legacy,reference]};(out/'legacy-sql-before.json').write_bytes(json.dumps(before,indent=2).encode());current=protocol('new-warm-ordinary-registered',native);after={str(root.relative_to(jobroot)):sql(root) for root in [legacy,reference]};(out/'legacy-sql-after.json').write_bytes(json.dumps(after,indent=2).encode());assert stable(warm)==stable(current) and before==after;legacy_exact=True
 calls={'native':(9,{'name':'ci_read','arguments':{'path':'nested \u00df/child.rs'}}),'serena':(53,{'name':'read_file','arguments':{'relative_path':'nested \u00df/child.rs'}}),'trail':(6,{'name':'trail_find_code','arguments':{'query':'child_owned','in':'nested \u00df'}}),'graft':(6,{'name':'graft_file_api','arguments':{'file':'nested \u00df/child.rs'}}),'graphify':(10,{'name':'get_node','arguments':{'label':'child_owned','project_path':str(secondary)}})}
 for profile,(count,call) in calls.items():
  reply=selected('new-selected-'+profile,profile,call,count,'child_owned');source_profiles.append(profile)
 runtime=selected('explicit-runtime','serena',{'name':'serena_repl','arguments':{'session_id':'owned-explicit-runtime','code':"(s.cfg.get_current_config()['activeProject'],len(s.fs.list_dir('',recursive=True)['files']))"}},53,'secondary',['--python',str(python),'--trust-python']);assert runtime['payload']['data']['result']==['secondary',2];runtime_ok=True
 (configroot/'.mcp.json').write_bytes(json.dumps({'mcpServers':{'yoke_owned_git_stdio':{'command':str(native),'args':scoped('serena','owned-claude-stdio')[1:]}}}).encode())
 for mode in ['get','list']:assert json.loads(run('actual-claude-'+mode,[python,'-I',health,client,mode,configroot],timeout=60))['connected']
 proof={}
 for root in [primary,secondary]:
  with sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True) as db:
   snapshots=[json.loads(r[0]) for r in db.execute('SELECT value FROM snapshots ORDER BY id')];receipts=[json.loads(r[0]) for r in db.execute("SELECT value FROM records WHERE kind='native_capture_options_v1' ORDER BY id")]
  if root==primary:assert not snapshots and not receipts
  else:assert len(snapshots)==1 and sorted(f['path'] for f in snapshots[0]['files'])==['main.rs','nested \u00df/child.rs'] and len(receipts)==1 and receipts[0]['options']['repositoryScope']['readOnlyRoots']==['nested \u00df']
  proof[str(root.relative_to(jobroot))]={'snapshots':snapshots,'proofs':receipts}
 (out/'saved-source-proofs.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode());assert files()==original;files_exact=True;assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'fixtureRoot':str(jobroot),'frozenInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'ownedParentProcessCalls':len(rows),'actualClientVersion':'2.1.306','actualClientSha256':sha(client),'cliSha256':sha(native),'precedingCliSha256':sha(old),'actualSourceProfiles':source_profiles,'actualClientHealthCalls':2 if complete else None,'ordinaryRegisteredSessionStablePayloadAndRecordsExact':legacy_exact,'allSourceAndGitFilesExact':files_exact,'explicitPythonRuntimeAndSourceCallbackQualified':runtime_ok,'selectedPythonProgramSha256':sha(python),'clientRawOutputArchived':False,'realModelCalls':0,'projectCodeAutomaticallyExecuted':False,'systemSettingsChanged':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
