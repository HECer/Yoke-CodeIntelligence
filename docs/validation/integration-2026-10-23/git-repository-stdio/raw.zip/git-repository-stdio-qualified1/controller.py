from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/git-repository-stdio-qualified1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-repository-discovery-check-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe'
inputs=json.loads((w/'validation/integration-20261018/git-repository-stdio-test1/source-before.json').read_bytes());assert len(inputs)==1097 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
complete=False;format_roots=0
# These groups cover the changed host preparation, HTTP admission, source policies and shared session binding.
groups=['mcp_http_review','mcp_collection_grants','mcp_collection_grants_review','source_exclusions','capture_policy','ignored_capture','session_startup_project','session_primary_read_only','session_agent_interface','session_steering','session_inclusions','session_memory_patterns','session_optional_defaults','session_epoch_selection','session_review','session_mcp','protocol_connection','compatibility','compatibility_review','trail_adapter','graphify_adapter']
groups += ['source_line_endings','session_root_aliases','session_collections','session_collections_admission','session_dashboard','session_config_cli','symbol_workspace','semantic_workspace','symbol_workspace_routes']
groups += ['agent_repl','agent_repl_lifecycle','agent_repl_api_selection']
assert len(groups)==len(set(groups)) and all((w/'native/tests'/f'{g}.rs').is_file() for g in groups)
try:
 run('cargo-clippy',[cargo,'clippy','--workspace','--all-targets','--locked','--keep-going','-j','2','--','-D','warnings'],timeout=900)
 run('cargo-build',[cargo,'build','--locked','-j','2','--bin','yoke'],timeout=900)
 run('cargo-test-lib',[cargo,'test','--locked','-j','2','--lib','--','--test-threads=1'],timeout=900)
 for group in groups:
  assert shutil.disk_usage(w).free>500_000_000,'Insufficient disk headroom; stop before another owned Cargo'
  run('cargo-test-'+group,[cargo,'test','--locked','-j','2','--test',group,'--','--test-threads=1'],timeout=900)
  assert all(sha(w/n)==h for n,h in inputs.items())
 metadata=json.loads(run('cargo-metadata',[cargo,'metadata','--no-deps','--format-version','1','--locked'],timeout=90));roots=sorted({t['src_path'] for p in metadata['packages'] if p['id'] in metadata['workspace_members'] for t in p['targets']});format_roots=len(roots);assert format_roots==358;(out/'format-roots.json').write_bytes((json.dumps(roots,indent=2)+'\n').encode())
 run('cargo-fmt-all',[cargo,'fmt','--all','--','--check'],expected=None,timeout=120)
 if rows[-1]['exitCode']!=0:assert b'206' in (out/'cargo-fmt-all.stderr').read_bytes()
 for i in range(0,len(roots),20):run(f'rustfmt-roots-{i:03}',[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','--check',*roots[i:i+20]],timeout=120)
 npm=shutil.which('npm.cmd');assert npm
 run('npm-typecheck',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
 run('npm-test',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'formatRoots':format_roots,'cliSha256':sha(w/'target/debug/yoke.exe'),'testGroups':groups};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
