from pathlib import Path
import hashlib,json,sys,urllib.request
p=Path(sys.argv[1])/'vocabulary.txt'
with urllib.request.urlopen('https://huggingface.co/Systran/faster-whisper-tiny.en/resolve/0d3d19a32d3338f10357c0889762bd8d64bbdeba/vocabulary.txt',timeout=60) as response:p.write_bytes(response.read(422310))
b=p.read_bytes();assert len(b)==422309
print(json.dumps({'name':p.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'upstreamLfsSha256':None}))
