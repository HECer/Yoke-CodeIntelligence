﻿from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/asr-host-live-baseline';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prep=json.loads((w/'validation/integration-20261018/asr-runtime-prep1/result.json').read_bytes());assert prep['complete'] and prep['allJobsEmpty'];jobroot=Path(prep['ownedRuntimeRoot']);python=Path(prep['python']);source=jobroot/'audio-source';source.mkdir(exist_ok=False);cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp'),('HF_HOME','private-hf-cache')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','HF_HUB_OFFLINE':'1','DO_NOT_TRACK':'1','OMP_NUM_THREADS':'2'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
inputs=json.loads((w/'validation/integration-20261018/asr-runtime-prep1/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');old=jobroot/'published-yoke.exe';shutil.copyfile(w/'target/debug/yoke.exe',old);assert sha(old)=='d5c7ca4f31ee4b287d6083211c5af09ea3eac9bec75db64ab08b95356d3037a4'
modelroot=jobroot/'model';modelroot.mkdir(exist_ok=False);download=jobroot/'download-selected-public-model.py';download.write_text(r'''
from pathlib import Path
import hashlib,json,sys,urllib.request
repo='Systran/faster-whisper-tiny.en';revision='0d3d19a32d3338f10357c0889762bd8d64bbdeba';root=Path(sys.argv[1]);request=lambda url:urllib.request.Request(url,headers={'User-Agent':'Yoke-owned-ASR-validation/0.5.0'})
with urllib.request.urlopen(request('https://huggingface.co/api/models/'+repo+'?blobs=true'),timeout=30) as response:metadata=json.load(response)
assert metadata['sha']==revision and metadata['cardData']['license']=='mit';files=[]
for name in ['config.json','model.bin','tokenizer.json']:
 entry=next(e for e in metadata['siblings'] if e['rfilename']==name);assert 0<entry['size']<=100000000;h=hashlib.sha256();length=0;target=root/name
 with urllib.request.urlopen(request('https://huggingface.co/'+repo+'/resolve/'+revision+'/'+name),timeout=60) as response,target.open('xb') as stream:
  while chunk:=response.read(65536):
   length+=len(chunk);assert length<=entry['size'];h.update(chunk);stream.write(chunk)
 assert length==entry['size'];digest=h.hexdigest()
 if entry.get('lfs'):assert digest==entry['lfs']['sha256']
 files.append({'name':name,'bytes':length,'sha256':digest,'upstreamLfsSha256':entry.get('lfs',{}).get('sha256')})
print(json.dumps({'repository':repo,'revision':revision,'license':'MIT','files':files,'anonymousPublicDownload':True,'defaultUserCacheSelected':False}))
''',encoding='utf8');(out/'download-model.py').write_bytes(download.read_bytes());complete=False
try:
 model=json.loads(run('explicit-selected-public-model-download',[python,'-I',download,modelroot],timeout=300));(out/'model-files.json').write_text(json.dumps(model,indent=2)+'\n',encoding='utf8')
 path='spoken-'+chr(0x130)+'-'+chr(0x3c0)+'.wav';audio=source/path;phrase='Native audio evidence stays separate from inferred words. This is an owned local test.';quoted=lambda s:"'"+str(s).replace("'","''")+"'"
 script="Add-Type -AssemblyName System.Speech; $s=[System.Speech.Synthesis.SpeechSynthesizer]::new(); try {$s.SelectVoice('Microsoft Zira Desktop'); $f=[System.Speech.AudioFormat.SpeechAudioFormatInfo]::new(16000,[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen,[System.Speech.AudioFormat.AudioChannel]::Mono); $s.SetOutputToWaveFile("+quoted(audio)+",$f); $s.Speak("+quoted(phrase)+"); $s.SetOutputToNull(); [pscustomobject]@{voice='Microsoft Zira Desktop';culture='en-US';text="+quoted(phrase)+";systemSettingsChanged=$false} | ConvertTo-Json -Compress } finally {$s.Dispose()}"
 run('owned-synthetic-english-speech',['powershell.exe','-NoProfile','-NonInteractive','-Command',script],timeout=60);audiohash=sha(audio)
 capture=json.loads(run('published-native-positive-media-inspection',[old,'--root',source,'--timeout','60000','media','inspect',path],timeout=120));assert capture['sourceHash']==audiohash and capture['metadata']['encoding']=='pcm' and capture['metadata']['sampleRate']==16000 and capture['metadata']['bitsPerSample']==16 and capture['metadata']['channels']==1;asset=capture['assetId']
 def database():
  c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
  try:return ('\n'.join(c.iterdump())+'\n').encode()
  finally:c.close()
 before=database();(out/'store-before-native-asr.sql').write_bytes(before);host=jobroot/'future-asr-host.json';host.write_text(json.dumps({'python':str(python),'modelRoot':str(modelroot),'language':'en','fasterWhisperVersion':'1.2.1'}),encoding='utf8');run('published-native-asr-unavailable',[old,'--root',source,'media','transcribe',asset,'--config',host,'--trust-worker'],expected=None);assert rows[-1]['exitCode']!=0 and b'unrecognized subcommand' in (out/'published-native-asr-unavailable.stderr').read_bytes();assert database()==before
 direct=jobroot/'actual-local-cpu-baseline.py';direct.write_text(r'''
import hashlib,importlib.metadata,json,sys
from faster_whisper import WhisperModel
model=WhisperModel(sys.argv[1],device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,local_files_only=True,use_auth_token=False)
segments,info=model.transcribe(sys.argv[2],language='en',beam_size=1,best_of=1,temperature=0.0,condition_on_previous_text=False,vad_filter=False,word_timestamps=False,log_progress=False)
rows=[{'start':s.start,'end':s.end,'text':s.text} for s in segments]
print(json.dumps({'libraryVersion':importlib.metadata.version('faster-whisper'),'device':'cpu','computeType':'int8','language':info.language,'duration':info.duration,'audioSha256':hashlib.sha256(open(sys.argv[2],'rb').read()).hexdigest(),'segments':rows,'localModelCalls':1,'scope':'Direct explicitly prepared SDK feasibility baseline; not native ASR implementation or universal semantic quality.'},allow_nan=False))
''',encoding='utf8');(out/'direct-cpu-baseline.py').write_bytes(direct.read_bytes());observed=json.loads(run('actual-selected-local-cpu-model',[python,'-I',direct,modelroot,audio],timeout=180));assert observed['audioSha256']==audiohash and observed['segments'] and observed['duration']>0 and all(s['text'].strip() for s in observed['segments']);assert database()==before and sha(audio)==audiohash and all(sha(modelroot/r['name'])==r['sha256'] for r in model['files']) and all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'ownedRuntimeRoot':str(jobroot),'python':str(python),'modelRoot':str(modelroot),'sourceRoot':str(source),'originalCli':str(old),'originalCliSha256':sha(old),'assetId':asset if 'asset' in locals() else None,'audioRelativePath':path if 'path' in locals() else None,'audioSha256':audiohash if 'audiohash' in locals() else None,'observedSdkBaseline':observed if complete else None,'nativeAsrAvailableInPublishedBinary':False,'systemChanges':False,'personalAudioSelected':False},indent=2)+'\n',encoding='utf8')
print(json.dumps({'complete':complete,'assetId':asset,'observedSegments':observed['segments'],'nativeAsrStillMissing':True}))
