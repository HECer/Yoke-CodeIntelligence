
from pathlib import Path
import hashlib,json,sys,urllib.request
repo='Systran/faster-whisper-tiny.en';revision='0d3d19a32d3338f10357c0889762bd8d64bbdeba';root=Path(sys.argv[1]);request=lambda url:urllib.request.Request(url,headers={'User-Agent':'Yoke-owned-ASR-validation/0.5.0'})
with urllib.request.urlopen(request('https://huggingface.co/api/models/'+repo+'?blobs=true'),timeout=30) as response:metadata=json.load(response)
assert metadata['sha']==revision and metadata['cardData']['license']=='mit';files=[]
for name in ['config.json','model.bin','tokenizer.json']:
 entry=next(e for e in metadata['siblings'] if e['rfilename']==name);assert 0<entry['size']<=100000000;h=hashlib.sha256();length=0;target=root/name
 with urllib.request.urlopen(request('https://huggingface.co/'+repo+'/resolve/'+revision+'/'+name),timeout=60) as response,target.open('xb') as stream:
  while chunk:=response.read(65536):
   length+=len(chunk);assert length<=entry['size'];h.update(chunk);stream.write(chunk)
 assert length==entry['size'];digest=h.hexdigest()
 if entry.get('lfs'):assert digest==entry['lfs']['sha256']
 files.append({'name':name,'bytes':length,'sha256':digest,'upstreamLfsSha256':entry.get('lfs',{}).get('sha256')})
print(json.dumps({'repository':repo,'revision':revision,'license':'MIT','files':files,'anonymousPublicDownload':True,'defaultUserCacheSelected':False}))
