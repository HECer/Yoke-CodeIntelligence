
import hashlib,importlib.metadata,json,sys
from faster_whisper import WhisperModel
model=WhisperModel(sys.argv[1],device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,local_files_only=True,use_auth_token=False)
segments,info=model.transcribe(sys.argv[2],language='en',beam_size=1,best_of=1,temperature=0.0,condition_on_previous_text=False,vad_filter=False,word_timestamps=False,log_progress=False)
rows=[{'start':s.start,'end':s.end,'text':s.text} for s in segments]
print(json.dumps({'libraryVersion':importlib.metadata.version('faster-whisper'),'device':'cpu','computeType':'int8','language':info.language,'duration':info.duration,'audioSha256':hashlib.sha256(open(sys.argv[2],'rb').read()).hexdigest(),'segments':rows,'localModelCalls':1,'scope':'Direct explicitly prepared SDK feasibility baseline; not native ASR implementation or universal semantic quality.'},allow_nan=False))
