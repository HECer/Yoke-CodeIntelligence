from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/asr-qualified1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-asr-runtime-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','DO_NOT_TRACK':'1','PIP_NO_INPUT':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))


prior=json.loads((w/'validation/integration-20261018/asr-test2/result.json').read_bytes());assert prior['complete'] and prior['allJobsEmpty'];inputs=json.loads((w/'validation/integration-20261018/asr-test2/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';complete=False

def unchanged():assert all(sha(w/n)==h for n,h in inputs.items())

try:
 run('clippy-all-targets',[cargo,'clippy','--workspace','--all-targets','--locked','--keep-going','-j','2','--','-D','warnings'],timeout=900);unchanged()
 run('build-native-cli',[cargo,'build','--locked','-j','2','--bin','yoke'],timeout=900);unchanged()
 for target in ['native-lib','media','process','retention','parity_retention']:
  run(target,[cargo,'test','--locked','-j','2',*(['--lib'] if target=='native-lib' else ['--test',target]),'--','--test-threads=1'],expected=None,timeout=1200);unchanged()
  if rows[-1]['exitCode']!=0:
   import re
   assert target=='media' and rows[-1]['exitCode']==101
   failed=re.findall(rb'^test ([^ ]+) \.\.\. FAILED',(out/(target+'.stdout')).read_bytes(),re.M);assert failed==[b'media_cannot_bypass_source_scope_links_ignore_or_protected_paths'];assert b'1314' in (out/(target+'.stdout')).read_bytes()+(out/(target+'.stderr')).read_bytes();rows[-1]['knownOriginalHostFailure']='Original OS1314 symlink fixture unchanged; no fixture skip, system or privilege change.'
 for name,command in [('typecheck',['cmd.exe','/d','/c','npm.cmd run typecheck']),('npm-tests',['cmd.exe','/d','/c','npm.cmd test'])]:run(name,command,timeout=600);unchanged()
 run('cargo-fmt-all',[cargo,'fmt','--all','--check'],expected=None,timeout=120);unchanged()
 if rows[-1]['exitCode']!=0:assert b'os error 206' in (out/'cargo-fmt-all.stderr').read_bytes()
 metadata=json.loads(run('format-target-metadata',[cargo,'metadata','--no-deps','--format-version','1'],timeout=60));unchanged();roots=sorted(set(t['src_path'] for package in metadata['packages'] for t in package['targets']));assert len(roots)==347;(out/'format-targets.json').write_text(json.dumps(roots,indent=2)+'\n',encoding='utf8')
 for i in range(0,len(roots),20):run('format-targets-'+str(i//20),[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','--check',*roots[i:i+20]],timeout=120);unchanged()
 complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'rows':rows,'wholeWindowsBaseline':False,'originalOs1314FixturesModifiedOrSkipped':False},indent=2)+'\n',encoding='utf8')
assert complete
