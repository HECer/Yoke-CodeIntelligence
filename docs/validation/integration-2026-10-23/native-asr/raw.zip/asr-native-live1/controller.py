from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/asr-native-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prep=json.loads((w/'validation/integration-20261018/asr-runtime-prep1/result.json').read_bytes());assert prep['complete'] and prep['allJobsEmpty'];jobroot=Path(prep['ownedRuntimeRoot']);python=Path(prep['python']);source=jobroot/'audio-source';assert source.is_dir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp'),('HF_HOME','private-hf-cache')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','HF_HUB_OFFLINE':'1','DO_NOT_TRACK':'1','OMP_NUM_THREADS':'2'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



base=json.loads((w/'validation/integration-20261018/asr-host-live-baseline3/result.json').read_bytes());modelroot=Path(base['modelRoot']);audio=source/base['audioRelativePath'];model=json.loads((w/'validation/integration-20261018/asr-host-live-baseline2/model-files.json').read_bytes());native=w/'target/debug/yoke.exe';assert sha(native)!=sha(jobroot/'published-yoke.exe');inputs=json.loads((w/'validation/integration-20261018/asr-test2/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');host=jobroot/'native-asr-host.json';host.write_text(json.dumps({'executable':str(python),'executableSha256':sha(python),'args':['-I'],'modelRoot':str(modelroot),'modelFiles':[{k:r[k] for k in ['name','bytes','sha256']} for r in model['files']],'libraryVersion':'1.2.1','language':'en'}),encoding='utf8');(out/'selected-host.json').write_bytes(host.read_bytes());command=[native,'--root',source,'--timeout','120000'];complete=False

def database():
 c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(c.iterdump())+'\n').encode()
 finally:c.close()

before=database();(out/'store-before.sql').write_bytes(before)
try:
 run('missing-explicit-trust',[*command,'media','transcribe',base['assetId'],'--config',host],expected=None);assert rows[-1]['exitCode']!=0 and b'explicit host worker trust' in (out/'missing-explicit-trust.stderr').read_bytes() and database()==before
 result=json.loads(run('actual-native-local-cpu-asr',[*command,'media','transcribe',base['assetId'],'--config',host,'--trust-worker'],timeout=180));assert result['state']=='completed';job=result['jobId'];after=database();(out/'store-after.sql').write_bytes(after)
 # Reconstruct the original database by removing only the four new typed rows.
 c=sqlite3.connect(':memory:');c.executescript(after.decode());c.execute("DELETE FROM records WHERE kind IN ('native_media_asr_request_v1','native_media_asr_control_v1')");c.execute("DELETE FROM records WHERE kind='artifact' AND id NOT IN (SELECT json_extract(value,'$.artifactId') FROM records WHERE kind='native_media_asset_v1') AND id IN (?,?)",(result['artifactId'],'not-a-real-id'))
 # Explicit new record delta checked against the exact original rows, preserving all tables.
 original=sqlite3.connect(':memory:');original.executescript(before.decode());post=sqlite3.connect(':memory:');post.executescript(after.decode());tables=[r[0] for r in original.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")];delta=[]
 for table in tables:
  old=original.execute('SELECT * FROM "'+table+'" ORDER BY rowid').fetchall();new=post.execute('SELECT * FROM "'+table+'" ORDER BY rowid').fetchall()
  if table=='records':
   extra=[r for r in new if r not in old];assert len(extra)==4 and sorted(r[0] for r in extra)==['artifact','artifact','native_media_asr_control_v1','native_media_asr_request_v1'];assert [r for r in new if r not in extra]==old;delta=extra
  else:assert new==old,table
 (out/'typed-new-records.json').write_text(json.dumps(delta,indent=2)+'\n',encoding='utf8');original.close();post.close();c.close()
 read=json.loads(run('actual-native-asr-read',[*command,'media','asr-read',job]));assert read['audioFrames']==99040 and read['durationSeconds']==6.19 and len(read['segments'])==2;assert [{k.replace('reportedStartSeconds','start').replace('reportedEndSeconds','end'):r[k] for k in ['reportedStartSeconds','reportedEndSeconds','text']} for r in read['segments']]==base['observedSdkBaseline']['segments'];last=read['segments'][-1];assert last['reportedEndSeconds']==7.0 and last['capturedSampleEnvelope']['endFrame']==99040 and last['capturedSampleEnvelope']['endByte']==198126 and last['temporalClassification']=='partial_overlap_with_captured_audio';assert not read['exactSpeechAlignmentEstablished']
 # The selected config is unavailable; status/read/jobs must replay stored data only.
 unavailable=host.with_suffix('.unavailable');host.rename(unavailable)
 try:
  status=json.loads(run('actual-native-asr-status-without-config',[*command,'media','asr-status',job]));assert status['state']=='completed'
  replay=json.loads(run('actual-native-asr-read-without-config',[*command,'media','asr-read',job]));assert replay==read
  page=json.loads(run('actual-native-asr-jobs-zero',[*command,'media','asr-jobs',base['assetId'],'--limit','0']));assert page['total']==1 and page['jobs']==[] and page['hasMore']
 finally:unavailable.rename(host)
 assert database()==after and sha(audio)==base['audioSha256'] and all(sha(modelroot/r['name'])==r['sha256'] for r in model['files']) and all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'cliSha256':sha(native),'selectedLocalInferenceAttempts':1,'newTypedRows':4 if complete else None,'defaultModelCallsAdded':False,'speechQualityUniversal':False,'audioSha256':sha(audio)},indent=2)+'\n',encoding='utf8')
assert complete
