
import hashlib,importlib.metadata,json,sys,wave
import numpy as np
from faster_whisper import WhisperModel
with wave.open(sys.argv[2],'rb') as wav:
 assert wav.getnchannels()==1 and wav.getsampwidth()==2 and wav.getframerate()==16000 and wav.getcomptype()=='NONE'
 count=wav.getnframes();raw=wav.readframes(count);assert len(raw)==count*2
samples=np.frombuffer(raw,dtype='<i2').astype(np.float32)/32768.0
model=WhisperModel(sys.argv[1],device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,local_files_only=True,use_auth_token=False)
assert model.feature_extractor.sampling_rate==16000
segments,info=model.transcribe(samples,language='en',beam_size=1,best_of=1,temperature=0.0,condition_on_previous_text=False,vad_filter=False,word_timestamps=False,log_progress=False)
rows=[{'start':s.start,'end':s.end,'text':s.text} for s in segments]
print(json.dumps({'libraryVersion':importlib.metadata.version('faster-whisper'),'device':'cpu','requestedComputeType':'int8','reportedComputeType':getattr(model.model,'compute_type',None),'language':info.language,'duration':info.duration,'audioSha256':hashlib.sha256(open(sys.argv[2],'rb').read()).hexdigest(),'segments':rows,'localModelCalls':1,'audioDecode':'stdlib-wave-pcm16-to-numpy','frames':len(samples),'scope':'Actual selected local SDK baseline over owned speech; native ASR is still unavailable and universal semantic quality is not established.'},allow_nan=False))
