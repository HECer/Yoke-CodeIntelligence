from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/asr-host-live-baseline3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prep=json.loads((w/'validation/integration-20261018/asr-runtime-prep1/result.json').read_bytes());assert prep['complete'] and prep['allJobsEmpty'];jobroot=Path(prep['ownedRuntimeRoot']);python=Path(prep['python']);source=jobroot/'audio-source';assert source.is_dir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp'),('HF_HOME','private-hf-cache')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','HF_HUB_OFFLINE':'1','DO_NOT_TRACK':'1','OMP_NUM_THREADS':'2'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))


prior=w/'validation/integration-20261018/asr-host-live-baseline';prior2=w/'validation/integration-20261018/asr-host-live-baseline2';baseline=json.loads((prior/'result.json').read_bytes());second=json.loads((prior2/'result.json').read_bytes());assert not second['complete'] and second['allJobsEmpty'];inputs=json.loads((prior/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');modelroot=Path(baseline['modelRoot']);audio=source/baseline['audioRelativePath'];model=json.loads((prior2/'model-files.json').read_bytes());assert len(model['files'])==4 and all(sha(modelroot/r['name'])==r['sha256'] for r in model['files']);(out/'model-files.json').write_text(json.dumps(model,indent=2)+'\n',encoding='utf8');direct=jobroot/'actual-local-pcm-array-baseline.py'
direct.write_text(r"""
import hashlib,importlib.metadata,json,sys,wave
import numpy as np
from faster_whisper import WhisperModel
with wave.open(sys.argv[2],'rb') as wav:
 assert wav.getnchannels()==1 and wav.getsampwidth()==2 and wav.getframerate()==16000 and wav.getcomptype()=='NONE'
 count=wav.getnframes();raw=wav.readframes(count);assert len(raw)==count*2
samples=np.frombuffer(raw,dtype='<i2').astype(np.float32)/32768.0
model=WhisperModel(sys.argv[1],device='cpu',compute_type='int8',cpu_threads=2,num_workers=1,local_files_only=True,use_auth_token=False)
assert model.feature_extractor.sampling_rate==16000
segments,info=model.transcribe(samples,language='en',beam_size=1,best_of=1,temperature=0.0,condition_on_previous_text=False,vad_filter=False,word_timestamps=False,log_progress=False)
rows=[{'start':s.start,'end':s.end,'text':s.text} for s in segments]
print(json.dumps({'libraryVersion':importlib.metadata.version('faster-whisper'),'device':'cpu','requestedComputeType':'int8','reportedComputeType':getattr(model.model,'compute_type',None),'language':info.language,'duration':info.duration,'audioSha256':hashlib.sha256(open(sys.argv[2],'rb').read()).hexdigest(),'segments':rows,'localModelCalls':1,'audioDecode':'stdlib-wave-pcm16-to-numpy','frames':len(samples),'scope':'Actual selected local SDK baseline over owned speech; native ASR is still unavailable and universal semantic quality is not established.'},allow_nan=False))
""",encoding='utf8');(out/'direct-cpu-baseline.py').write_bytes(direct.read_bytes());complete=False
try:
 observed=json.loads(run('actual-selected-local-cpu-model',[python,'-I',direct,modelroot,audio],timeout=180));assert observed['audioSha256']==baseline['audioSha256'] and observed['segments'] and observed['duration']>0 and observed['frames']==99040
 c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:sql=('\n'.join(c.iterdump())+'\n').encode()
 finally:c.close()
 assert sql==(prior/'store-before-native-asr.sql').read_bytes() and sha(audio)==baseline['audioSha256'] and all(sha(modelroot/r['name'])==r['sha256'] for r in model['files']) and all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:(out/'result.json').write_text(json.dumps({**baseline,'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'observedSdkBaseline':observed if complete else None,'requiredModelFiles':4,'initialMissingVocabularyFailureRetained':True,'pyav19FileDecoderIncompatibilityRetained':True,'originalSqlExact':complete,'sourceAudioAndModelFilesExact':complete,'nativeAsrAvailableInPublishedBinary':False},indent=2)+'\n',encoding='utf8')
print(json.dumps({'complete':complete,'segments':observed['segments'],'duration':observed['duration'],'nativeAsrStillMissing':True}))
