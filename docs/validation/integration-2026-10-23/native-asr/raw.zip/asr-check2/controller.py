from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/asr-check2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-asr-runtime-'));source=jobroot/'source';source.mkdir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','DO_NOT_TRACK':'1','PIP_NO_INPUT':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))

prior=json.loads((w/'validation/integration-20261018/asr-worker-live1/source-before.json').read_bytes());prior.update({name:'' for name in ['native/src/media_asr.rs','native/src/media_asr_host.rs','native/src/media_asr_report.rs','native/src/media_asr_cli.rs']});inputs={name:sha(w/name) for name in prior};assert len(inputs)==1070;(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');cwd=w;env['CARGO_HOME']=r'C:\Users\Lomi\.cargo';env['RUSTUP_HOME']=r'C:\Users\Lomi\.rustup';complete=False
try:
 run('cargo-check-asr-lib',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','check','--locked','-j','2','--lib','--bin','yoke'],timeout=600);assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'productBehaviorTestsRun':False,'nativeAsrCliWiredButUnqualified':True},indent=2)+'\n',encoding='utf8')
assert complete
