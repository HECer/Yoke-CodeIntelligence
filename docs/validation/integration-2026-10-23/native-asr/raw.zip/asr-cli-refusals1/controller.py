from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/asr-cli-refusals1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();prep=json.loads((w/'validation/integration-20261018/asr-runtime-prep1/result.json').read_bytes());assert prep['complete'] and prep['allJobsEmpty'];jobroot=Path(prep['ownedRuntimeRoot']);python=Path(prep['python']);source=jobroot/'audio-source';assert source.is_dir();cwd=source;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp'),('HF_HOME','private-hf-cache')]:p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','HF_HUB_OFFLINE':'1','DO_NOT_TRACK':'1','OMP_NUM_THREADS':'2'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))





base=json.loads((w/'validation/integration-20261018/asr-host-live-baseline3/result.json').read_bytes());native=w/'target/debug/yoke.exe';inputs=json.loads((w/'validation/integration-20261018/asr-test2/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());host=jobroot/'native-asr-host.json';spec=json.loads(host.read_bytes());command=[native,'--root',source,'--timeout','120000'];complete=False

def database():
 c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(c.iterdump())+'\n').encode()
 finally:c.close()

before=database();original_audio=sha(source/base['audioRelativePath']);cases=[]
def refusal(name, value=None, raw=None, root=None):
 cfg=jobroot/('refusal-'+name+'.json');cfg.write_bytes(raw if raw is not None else json.dumps(value).encode());argv=[native,'--root',root or source,'--timeout','120000','media','transcribe',base['assetId'],'--config',cfg,'--trust-worker'];run(name,argv,expected=None,timeout=30);assert rows[-1]['exitCode']!=0;assert database()==before;cases.append({'name':name,'exitCode':rows[-1]['exitCode'],'originalSqlExact':True})

try:
 import copy
 for name,key,value in [('relative-model','modelRoot','relative'),('parent-model','modelRoot',str(jobroot/'model'/'..'/'model')),('stale-program','executableSha256','0'*64),('language-authority','language','en --execute'),('unknown-grant','trustWorker',True)]:
  bad=copy.deepcopy(spec);bad[key]=value;refusal(name,bad)
 for name,key,value in [('zero-job-budget','maxJobs',0),('zero-audio-budget','maxAudioMilliseconds',0),('thread-overflow','threads',5)]:
  bad=copy.deepcopy(spec);bad.setdefault('limits',{})[key]=value;refusal(name,bad)
 bad=copy.deepcopy(spec);bad['modelFiles'][0]['name']='../config.json';refusal('model-member-traversal',bad)
 bad=copy.deepcopy(spec);bad['modelFiles'][0]['sha256']='0'*64;refusal('stale-model',bad)
 refusal('duplicate-schema-member',raw=b'{"language":"en",'+json.dumps(spec).encode()[1:])
 canary=source/'never-execute.exe';assert not canary.exists();payload=b'owned ASR source execution canary\r\n';canary.write_bytes(payload)
 try:
  bad=copy.deepcopy(spec);bad['executable']=str(canary);bad['executableSha256']=hashlib.sha256(payload).hexdigest();refusal('source-cannot-select-program',bad)
  assert b'outside analyzed source' in (out/'source-cannot-select-program.stderr').read_bytes();assert canary.read_bytes()==payload
 finally:
  assert canary.resolve().parent==source.resolve() and canary.read_bytes()==payload;canary.unlink()
 prior_temp=env['TEMP'];prior_tmp=env['TMP'];env['TEMP']=str(source);env['TMP']=str(source)
 try:
  refusal('private-data-outside-source',spec);assert b'private data root must be outside analyzed source' in (out/'private-data-outside-source.stderr').read_bytes()
 finally:env['TEMP']=prior_temp;env['TMP']=prior_tmp
 absent=jobroot/'nonexistent-source';assert not absent.exists();refusal('missing-store-does-not-create',spec,root=absent);assert not absent.exists()
 assert all(sha(w/n)==h for n,h in inputs.items()) and sha(source/base['audioRelativePath'])==original_audio and database()==before;complete=True
finally:(out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'cliSha256':sha(native),'selectedLocalInferenceAttempts':0,'originalSqlExact':database()==before,'cases':cases,'systemChanges':False},indent=2)+'\n',encoding='utf8')
assert complete
