from pathlib import Path
import subprocess,sys
p=subprocess.run([sys.executable,'-I',sys.argv[1]],input=Path(sys.argv[2]).read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr);sys.exit(p.returncode)
