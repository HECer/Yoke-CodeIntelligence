from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/jinja-20261023-fc442787-bootstrap1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

env.pop('CARGO_NET_OFFLINE',None)
for name in ['HTTPS_PROXY','HTTP_PROXY','ALL_PROXY','NO_PROXY','SSL_CERT_FILE','SSL_CERT_DIR','CARGO_HTTP_CAINFO','CARGO_HTTP_PROXY']:
 if name in os.environ:env[name]=os.environ[name]
native=w/'target/debug/yoke.exe';assert sha(native)=='57610cc05ed2ba2c3689cbf09e549dc2360bb960bec261fdf72e4fbc642d1db0'
backup=w/'target/jinja-20261023-fc442787-before';backup.mkdir(exist_ok=False);shutil.copyfile(native,backup/'yoke.exe');assert sha(backup/'yoke.exe')==sha(native)
old_lock=(w/'Cargo.lock').read_bytes();(out/'Cargo.before.lock').write_bytes(old_lock)
complete=False
try:
 run('compact-qualified-backup',[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',backup/'yoke.exe'],timeout=90);assert sha(backup/'yoke.exe')==sha(native)
 run('red-old-template-flag',[backup/'yoke.exe','session-config','plan','--selection',jobroot/'unread-selection.json','--allow-configuration-read','--allow-policy-projection','--allow-template-evaluation'],expected=2,timeout=30)
 run('resolve-template-dependency',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','update','-p','yoke-code-intelligence'],timeout=180)
 import tomllib
 old=tomllib.loads(old_lock.decode());new=tomllib.loads((w/'Cargo.lock').read_text());old_packages={(p['name'],p['version'],p.get('source')):p for p in old['package']};new_packages={(p['name'],p['version'],p.get('source')):p for p in new['package']};assert all(new_packages.get(key)==value for key,value in old_packages.items() if key[0]!='yoke-code-intelligence');added=[p for key,p in new_packages.items() if key not in old_packages];assert [p['name'] for p in added]==['minijinja'],added;assert added[0]['version']=='3.0.3';(out/'Cargo.after.lock').write_bytes((w/'Cargo.lock').read_bytes());complete=True
finally:
 result={'complete':complete,'backupSha256':sha(backup/'yoke.exe'),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'commands':rows,'cargoLockSha256':sha(w/'Cargo.lock'),'freeBytes':shutil.disk_usage(w).free};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
