import hashlib,json,subprocess,sys
from pathlib import Path
exe,out=sys.argv[1],Path(sys.argv[2]);rows=[]
cases=[('small-repeat',"{{ 'x' * 100 }}",'x'*100),('large-repeat',"{{ 'x' * 1073741824 }}",None),('small-indent',"{{ 'x'|indent(4,true) }}",'    x'),('large-indent',"{{ 'x'|indent(1073741824,true) }}",None)]
for name,prompt,expected in cases:
 request=json.dumps({'schema':1,'context':{},'prompt':prompt}).encode()
 r=subprocess.run([exe,'session-config','render-worker'],input=request,capture_output=True,timeout=12,creationflags=0x08000000)
 (out/(name+'.worker.stdout')).write_bytes(r.stdout);(out/(name+'.worker.stderr')).write_bytes(r.stderr)
 if expected is not None:
  assert r.returncode==0,(name,r.stderr);reply=json.loads(r.stdout);assert reply['rendered']==expected and reply['memoryCeilingBytes']==268435456
 else:assert r.returncode!=0 and r.stdout==b''
 rows.append({'name':name,'exitCode':r.returncode,'stdoutBytes':len(r.stdout),'stderrBytes':len(r.stderr),'stderrSha256':hashlib.sha256(r.stderr).hexdigest(),'allocatorFailureText':b'memory allocation' in r.stderr and b'failed' in r.stderr})
assert rows[-1]['allocatorFailureText'],rows[-1]
(out/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
