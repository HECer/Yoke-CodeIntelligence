from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/jinja-20261023-fc442787-storage-passed-pdb1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

import contextlib
plan=json.loads((w/'validation/integration-20261018/jinja-passed-pdb-compression-plan.json').read_bytes());inputs=json.loads((w/'validation/integration-20261018/jinja-20261023-fc442787-green1/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'plan.json').write_bytes((json.dumps(plan,indent=2)+'\n').encode());completed=[];done=False;log=(out/'commands.jsonl').open('w',encoding='utf8',buffering=1)
try:
 for record in plan:
  p=Path(record['path']);exe=Path(record['associatedPassedExecutable']);assert p.suffix=='.pdb' and p.parent.resolve()==(w/'target/debug/deps').resolve() and p.stem==exe.stem and not p.name.startswith(('capture_options-','session_fixed_tools-'))
  assert sha(exe)==record['associatedPassedExecutableSha256'] and sha(w/record['cargoAndWholeHarnessLog'])==record['logSha256'] and sha(p)==record['sha256'] and p.stat().st_size==record['bytes']
  assert shutil.disk_usage(w).free>p.stat().st_size+64_000_000
  with contextlib.redirect_stdout(log):run('compact-passed-pdb-'+p.stem,[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',p],timeout=90)
  assert sha(p)==record['sha256'] and p.stat().st_size==record['bytes'];completed.append({**record,'logicalBytesAndSha256Unchanged':True});(out/'compression.json').write_bytes((json.dumps(completed,indent=2)+'\n').encode())
  if len(completed)%5==0:print(json.dumps({'completedFiles':len(completed),'freeBytes':shutil.disk_usage(w).free}),flush=True)
 done=True
finally:
 result={'complete':done,'files':len(completed),'associatedExecutableHashesAndExplicitCompilerPdbFilenamesAndWholeHarnessSuccessVerified':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'freeBytes':shutil.disk_usage(w).free,'artifactDeletion':False,'currentUnqualifiedExecutableOptimizedOrExecuted':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
