import hashlib,json,subprocess,sys
from pathlib import Path
exe,out=sys.argv[1],Path(sys.argv[2]);rows=[]
for name,size in [("small",100),("large",1073741824)]:
 request=json.dumps({"schema":1,"context":{},"prompt":"{{ 'x' * "+str(size)+" }}"}).encode()
 r=subprocess.run([exe,"session-config","render-worker"],input=request,capture_output=True,timeout=12,creationflags=0x08000000)
 (out/(name+".worker.stdout")).write_bytes(r.stdout);(out/(name+".worker.stderr")).write_bytes(r.stderr)
 if name=="small":
  assert r.returncode==0;reply=json.loads(r.stdout);assert reply["rendered"]=="x"*100 and reply["memoryCeilingBytes"]==268435456
 else:assert r.returncode!=0 and r.stdout==b""
 rows.append({"name":name,"requestedRepeat":size,"exitCode":r.returncode,"stdoutBytes":len(r.stdout),"stderrBytes":len(r.stderr),"stderrSha256":hashlib.sha256(r.stderr).hexdigest(),"allocatorFailureText":b"memory allocation" in r.stderr and b"failed" in r.stderr})
(out/"observations.json").write_text(json.dumps(rows,indent=2)+"\n")
