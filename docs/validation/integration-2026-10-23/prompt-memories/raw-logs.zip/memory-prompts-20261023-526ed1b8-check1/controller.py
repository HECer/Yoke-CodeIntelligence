from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/memory-prompts-20261023-526ed1b8-check1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))



inputs=json.loads((w/'validation/integration-20261018/runtime-prompts-20261023-5da7f745-qualified3/source-before.json').read_bytes())
for n in ['native/src/session_prompt_memory.rs','native/src/session_prompt_session.rs','native/src/session_config_memory_cli.rs']:inputs[n]=''
inputs={n:sha(w/n) for n in inputs};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');complete=False;native=w/'target/debug/yoke.exe';backup=w/'target/memory-prompts-20261023-526ed1b8-before/yoke.exe'
try:
 expected='2723f6915c91cbe767a82dfa7c6ea6edb62182d41babf43964635d2ced61408a';assert sha(native)==expected and shutil.disk_usage(w).free>1_200_000_000
 passed=w/'target/debug/deps/session_fixed_tools-runtime-prompts-20261023-5da7f745.exe';proof=w/'validation/integration-20261018/runtime-prompts-20261023-5da7f745-qualified3';assert b'test result: ok. 8 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in (proof/'fixed-tools-fresh.stdout').read_bytes();record={'path':str(passed),'bytes':passed.stat().st_size,'sha256':sha(passed)}
 run('compact-already-passed-fresh-fixed-tools',[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',passed],timeout=90);assert passed.stat().st_size==record['bytes'] and sha(passed)==record['sha256'];record['logicalBytesAndShaExact']=True;(out/'passed-output-compression.json').write_text(json.dumps(record,indent=2)+'\n')
 assert not backup.exists();backup.parent.mkdir(exist_ok=False);shutil.copyfile(native,backup);assert sha(backup)==expected
 run('compact-qualified-cli-backup',[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',backup],timeout=90);assert sha(backup)==expected and sha(native)==expected
 run('check-bin',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','check','--locked','--offline','--bin','yoke','-j','1'],timeout=600)
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'currentCliSha256':sha(native),'freeBytes':shutil.disk_usage(w).free};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
