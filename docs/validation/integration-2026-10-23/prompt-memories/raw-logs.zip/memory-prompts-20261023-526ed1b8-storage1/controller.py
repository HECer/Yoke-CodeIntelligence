from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/memory-prompts-20261023-526ed1b8-storage1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-memory-storage-'));env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for name,relative in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/relative;p.mkdir(parents=True,exist_ok=True);env[name]=str(p)
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))
api=ctypes.WinDLL('kernel32',use_last_error=True);api.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)];api.GetCompressedFileSizeW.restype=ctypes.c_ulong
def allocated(p):
 hi=ctypes.c_ulong();lo=api.GetCompressedFileSizeW(str(p),ctypes.byref(hi));return (hi.value<<32)|lo
plan=json.loads((w/'validation/integration-20261018/memory-prompts-storage-plan.json').read_bytes());shutil.copyfile(w/'validation/integration-20261018/memory-prompts-own-worktree-artifact-admission.json',out/'own-worktree-artifact-admission.json');provenance=out/'qualification-provenance';provenance.mkdir();proofs=[]
for record in plan:
 for field,hashfield in [('cargoAndWholeHarnessLog','logSha256'),('explicitCargoArtifactLog','cargoArtifactLogSha256'),('originalSuccessfulResult','originalSuccessfulResultSha256')]:
  if field not in record:continue
  source=w/record[field];expected_hash=record[hashfield];destination=provenance/(expected_hash+source.suffix)
  assert sha(source)==expected_hash
  if not destination.exists():shutil.copyfile(source,destination)
  assert sha(destination)==expected_hash;proofs.append({'role':field,'origin':record[field],'archived':str(destination.relative_to(out)),'sha256':expected_hash})
(out/'qualification-provenance-index.json').write_text(json.dumps(proofs,indent=2)+'\n')
plan=sorted(plan,key=lambda r:(Path(r['path']).suffix!='.pdb',-r['allocatedBefore']));(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');prior_inputs=json.loads((w/'validation/integration-20261018/memory-prompts-20261023-526ed1b8-green1/source-before.json').read_bytes());inputs={n:sha(w/n) for n in prior_inputs};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');(out/'post-disk-stop-source-changes.json').write_text(json.dumps([n for n,h in prior_inputs.items() if inputs[n]!=h],indent=2)+'\n');current=w/'target/debug/yoke.exe';expected='2723f6915c91cbe767a82dfa7c6ea6edb62182d41babf43964635d2ced61408a';assert sha(current)==expected;done=[];skipped=[];complete=False;before=shutil.disk_usage(w).free;log=(out/'commands.jsonl').open('w',encoding='utf8',buffering=1)
try:
 for record in plan:
  if shutil.disk_usage(w).free>=1_900_000_000:break
  p=Path(record['path']);exe=Path(record['associatedPassedExecutable']);assert p.parent.resolve()==(w/'target/debug/deps').resolve() and p.stem==exe.stem and not p.name.startswith(('capture_options-','session_fixed_tools-','yoke'));assert p.suffix in ['.pdb','.exe'] and p.resolve()!=current.resolve()
  if allocated(p)<p.stat().st_size*0.32:skipped.append(str(p));continue
  if shutil.disk_usage(w).free<500_000_000+p.stat().st_size+64_000_000:skipped.append(str(p));continue
  assert sha(exe)==record['associatedPassedExecutableSha256'] and sha(w/record['cargoAndWholeHarnessLog'])==record['logSha256'] and p.stat().st_size==record['bytes'] and sha(p)==record['sha256']
  if 'explicitCargoArtifactLog' in record:assert sha(w/record['explicitCargoArtifactLog'])==record['cargoArtifactLogSha256'] and sha(w/record['originalSuccessfulResult'])==record['originalSuccessfulResultSha256']
  rec={**record,'allocatedImmediatelyBefore':allocated(p),'decompressedOldNtfsFlagFirst':bool(p.stat().st_file_attributes&0x800)};compact=os.environ['SystemRoot']+'\\System32\\compact.exe'
  if rec['decompressedOldNtfsFlagFirst']:
   with contextlib.redirect_stdout(log):run('decompress-passed-'+p.name,[compact,'/U','/F','/I','/Q',p],timeout=90)
   assert sha(p)==record['sha256'] and p.stat().st_size==record['bytes']
  with contextlib.redirect_stdout(log):run('lzx-passed-'+p.name,[compact,'/C','/F','/EXE:LZX','/I','/Q',p],timeout=90)
  assert sha(p)==record['sha256'] and p.stat().st_size==record['bytes'] and sha(exe)==record['associatedPassedExecutableSha256'];rec.update({'allocatedAfter':allocated(p),'logicalBytesAndSha256Exact':True});done.append(rec);(out/'compression.json').write_text(json.dumps(done,indent=2)+'\n');print(json.dumps({'completed':len(done),'freeBytes':shutil.disk_usage(w).free,'file':p.name,'physicalBytesSaved':rec['allocatedImmediatelyBefore']-rec['allocatedAfter']}),flush=True)
 complete=True
finally:
 result={'complete':complete,'files':len(done),'skipped':len(skipped),'initialFreeBytes':before,'freeBytes':shutil.disk_usage(w).free,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'currentQualifiedCliExact':sha(current)==expected,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'onlyPositivelyPassedExactOwnArtifacts':True,'artifactDeletion':False,'protectedOrUnvalidatedArtifactsAccessed':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)