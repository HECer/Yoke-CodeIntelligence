from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/memory-prompts-20261023-526ed1b8-storage2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-memory-storage-'));env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for name,relative in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/relative;p.mkdir(parents=True,exist_ok=True);env[name]=str(p)
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))
api=ctypes.WinDLL('kernel32',use_last_error=True);api.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)];api.GetCompressedFileSizeW.restype=ctypes.c_ulong
def allocation(p):
 high=ctypes.c_ulong();low=api.GetCompressedFileSizeW(str(p),ctypes.byref(high));return (high.value<<32)|low
base=w/'validation/integration-20261018';prior=base/'memory-prompts-20261023-526ed1b8-storage1';index=json.loads((prior/'qualification-provenance-index.json').read_bytes());copies={r['archived']:r['sha256'] for r in index};inputs=json.loads((prior/'source-before.json').read_bytes());inputs={n:sha(w/n) for n in inputs};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');completed=[];done=False;initial=shutil.disk_usage(w).free;log=(out/'commands.jsonl').open('w',encoding='utf8',buffering=1);compact=os.environ['SystemRoot']+'\\System32\\compact.exe'
try:
 for rel,expected in copies.items():
  p=(prior/rel).resolve();assert p.is_relative_to((prior/'qualification-provenance').resolve()) and p.is_file() and not p.is_symlink() and sha(p)==expected
  st=p.stat();before=allocation(p)
  if before<st.st_size*.5 or st.st_size<10000:continue
  with contextlib.redirect_stdout(log):run('compact-owned-proof-'+p.name,[compact,'/C','/F','/EXE:LZX','/I','/Q',p],timeout=90)
  assert sha(p)==expected and p.stat().st_size==st.st_size;completed.append({'path':str(p),'sha256':expected,'bytes':st.st_size,'allocationBefore':before,'allocationAfter':allocation(p),'logicalBytesAndHashExact':True,'ownVerifiedPositiveQualificationCopy':True})
  if len(completed)%25==0:print(json.dumps({'completedEvidenceFiles':len(completed),'freeBytes':shutil.disk_usage(w).free}),flush=True)
 done=True
finally:
 (out/'compression.json').write_text(json.dumps(completed,indent=2)+'\n');result={'complete':done,'files':len(completed),'initialFreeBytes':initial,'freeBytes':shutil.disk_usage(w).free,'logicalBytesAndHashExact':True,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'onlyOwnAlreadyVerifiedEvidenceCopies':True,'artifactDeletion':False,'executablesOrProtectedArtifactsAccessed':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)