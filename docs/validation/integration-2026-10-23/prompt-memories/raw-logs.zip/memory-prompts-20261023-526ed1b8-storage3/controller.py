from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib,re
w=Path.cwd();out=w/'validation/integration-20261018/memory-prompts-20261023-526ed1b8-storage3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-memory-storage-'));env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for name,relative in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/relative;p.mkdir(parents=True,exist_ok=True);env[name]=str(p)
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))
api=ctypes.WinDLL('kernel32',use_last_error=True);api.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)];api.GetCompressedFileSizeW.restype=ctypes.c_ulong
def allocation(p):
 high=ctypes.c_ulong();low=api.GetCompressedFileSizeW(str(p),ctypes.byref(high));return (high.value<<32)|low
phase=w/'validation/integration-20261018/owned-member-diagnostic-20261023-8fee30c7-qualified2';qualification=json.loads((phase/'result.json').read_bytes());assert qualification['complete'] and qualification['allJobsEmpty'];ledger={r['path']:r for r in json.loads((phase/'compression.json').read_bytes())};inputs=json.loads((w/'validation/integration-20261018/memory-prompts-20261023-526ed1b8-green2/source-before.json').read_bytes());inputs={n:sha(w/n) for n in inputs};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');completed=[];done=False;initial=shutil.disk_usage(w).free;log=(out/'commands.jsonl').open('w',encoding='utf8',buffering=1);compact=os.environ['SystemRoot']+'\\System32\\compact.exe'
try:
 for target in qualification['targets']:
  proof=phase/('test-'+target+'.stdout')
  if not proof.exists():continue
  data=proof.read_bytes();match=re.search(rb'test result: ok\. ([1-9][0-9]*) passed; 0 failed; (\d+) ignored; 0 measured; 0 filtered out;',data)
  if match is None:continue
  for line in data.splitlines():
   try:m=json.loads(line)
   except ValueError:continue
   if m.get('reason')!='compiler-artifact' or Path(m['manifest_path']).resolve()!=(w/'native/Cargo.toml').resolve() or m['target']['name']!=target or not m['profile']['test'] or not m.get('executable'):continue
   exe=Path(m['executable']);record=ledger.get(str(exe))
   if record is None or not exe.is_file() or exe.name.startswith(('capture_options-','session_fixed_tools-','yoke')):continue
   assert sha(exe)==record['sha256']
   for filename in m['filenames']:
    p=Path(filename)
    if p.suffix!='.pdb' or not p.exists() or p.parent.resolve()!=(w/'target/debug/deps').resolve() or p.stem!=exe.stem or p.name.startswith(('capture_options-','session_fixed_tools-','yoke')):continue
    st=p.stat();before=allocation(p)
    if before<st.st_size*.32:continue
    assert st.st_mtime_ns<=proof.stat().st_mtime_ns and shutil.disk_usage(w).free>500_000_000+st.st_size+64_000_000;expected=sha(p);rec={'path':str(p),'bytes':st.st_size,'sha256':expected,'allocationBefore':before,'associatedPassedExecutable':str(exe),'associatedPassedExecutableSha256':record['sha256'],'explicitCargoAndPositiveWholeHarness':str(proof.relative_to(w)),'wholeHarnessLogSha256':sha(proof)}
    if st.st_file_attributes&0x800:
     with contextlib.redirect_stdout(log):run('decompress-passed-'+p.name,[compact,'/U','/F','/I','/Q',p],timeout=90)
     assert sha(p)==expected and p.stat().st_size==st.st_size
    with contextlib.redirect_stdout(log):run('compact-passed-'+p.name,[compact,'/C','/F','/EXE:LZX','/I','/Q',p],timeout=90)
    assert sha(p)==expected and p.stat().st_size==st.st_size and sha(exe)==record['sha256'];rec.update({'allocationAfter':allocation(p),'logicalBytesAndSha256Exact':True});completed.append(rec);(out/'compression.json').write_text(json.dumps(completed,indent=2)+'\n');print(json.dumps({'completedFiles':len(completed),'freeBytes':shutil.disk_usage(w).free,'file':p.name}),flush=True)
 done=True
finally:
 result={'complete':done,'files':len(completed),'initialFreeBytes':initial,'freeBytes':shutil.disk_usage(w).free,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'onlyExactPositiveWholeHarnessPdbArtifacts':True,'artifactDeletion':False,'executablesOptimizedOrProtectedArtifactsAccessed':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)