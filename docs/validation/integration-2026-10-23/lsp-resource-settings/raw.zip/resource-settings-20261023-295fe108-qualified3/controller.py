from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/resource-settings-20261023-295fe108-qualified3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace("if time.monotonic()-start>timeout:raise TimeoutError(name)","if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");disk_samples=[];runner=runner.replace('if shutil.disk_usage(w).free<500_000_000:', "free_now=shutil.disk_usage(w).free\n                if not disk_samples or time.monotonic()-disk_samples[-1]['monotonic']>=5:disk_samples.append({'command':name,'seconds':round(time.monotonic()-start,3),'monotonic':time.monotonic(),'freeBytes':free_now});(out/'disk-headroom.json').write_bytes((json.dumps(disk_samples,indent=2)+chr(10)).encode())\n                if free_now<500_000_000:");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom sampling and stop','exec'))



import contextlib
old=json.loads((w/'validation/integration-20261018/vsix-archive-20261023-df52798b-qualified1/source-before.json').read_bytes());extra=['native/docs/vsix-packaging.md','native/tests/lsp_resource_settings.rs','native/tests/fixtures/resource-settings-lsp.mjs','native/src/lsp_resource_settings.rs'];inputs={n:sha(w/n) for n in [*old,*extra]};assert len(inputs)==1104;assert shutil.disk_usage(w).free>1_200_000_000,'Insufficient debug-target headroom';(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+chr(10)).encode());env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH'];commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
accepted=json.loads((w/'validation/integration-20261018/resource-settings-20261023-295fe108-green5/source-before.json').read_bytes());assert {n for n in inputs if inputs[n]!=accepted[n]}=={'native/tests/lsp_resource_settings.rs'};assert inputs==json.loads((w/'validation/integration-20261018/resource-settings-20261023-295fe108-green6/source-before.json').read_bytes())
old_groups=json.loads((w/'docs/validation/integration-2026-10-23/server-workspace-settings/index.json').read_bytes())['nativeGroupResults'];targets=sorted(row['group'] for row in old_groups if row['group']!='lib');assert len(targets)==30
(out/'selected-targets.json').write_bytes((json.dumps(targets,indent=2)+chr(10)).encode());complete=False;format_roots=[]
def owned(name,args,**kwargs):
 with contextlib.redirect_stdout(commandlog):result=run(name,args,**kwargs)
 print(json.dumps({'command':name,'exitCode':rows[-1].get('exitCode'),'activeAfterCleanup':rows[-1]['activeAfterCleanup']}),flush=True);return result
try:
 cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';rustfmt=r'C:\Users\Lomi\.rustup\toolchains\1.94.1-x86_64-pc-windows-msvc\bin\rustfmt.exe'
 owned('clippy-all-targets',[cargo,'clippy','--workspace','--all-targets','--locked','--offline','--keep-going','-j','2','--','-D','warnings'],timeout=900)
 metadata=json.loads(owned('metadata',[cargo,'metadata','--locked','--offline','--no-deps','--format-version','1'],timeout=90))
 format_roots=sorted({(target['src_path'],package['edition']) for package in metadata['packages'] if package['id'] in metadata['workspace_members'] for target in package['targets']})
 (out/'format-roots.json').write_bytes((json.dumps(format_roots,indent=2)+chr(10)).encode())
 owned('fmt-all',[cargo,'fmt','--all','--','--check'],expected=None,timeout=120)
 fmt_exit=rows[-1]['exitCode'];assert fmt_exit==0 or fmt_exit==1 and b'206' in (out/'fmt-all.stderr').read_bytes()+(out/'fmt-all.stdout').read_bytes()
 for index,(path,edition) in enumerate(format_roots):
  owned('fmt-root-'+str(index),[rustfmt,'--edition',edition,'--check',path],timeout=90)
 compression=[]
 for target in targets:
  test_command=[r'C:\Python314\python.exe','-X','utf8',str(w/'scripts/run_native_tests.py'),'--controlled-test-runner','--locked','--offline','--no-fail-fast','--message-format','json','--test',target,'-j','2','--','--test-threads=1']
  owned('test-'+target,test_command,timeout=300)
  executables=[]
  for line in (out/('test-'+target+'.stdout')).read_bytes().splitlines():
   try:message=json.loads(line)
   except (ValueError,UnicodeDecodeError):continue
   if message.get('reason')=='compiler-artifact' and message['target']['name']==target and message.get('profile',{}).get('test') and message.get('executable'):executables.append(Path(message['executable']))
  assert len(executables)==1;exe=executables[0];assert exe.parent.resolve()==(w/'target/debug/deps').resolve() and exe.name.startswith(target+'-') and exe.suffix=='.exe' and not exe.is_symlink()
  assert exe.name not in ['capture_options-784339a4da3fe379.exe','session_fixed_tools-0671ac4d8f474009.exe','yoke.exe']
  before={'bytes':exe.stat().st_size,'sha256':sha(exe)};assert shutil.disk_usage(w).free>before['bytes']+64_000_000
  owned('compact-passed-'+target,[env['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(exe)],timeout=90)
  assert exe.stat().st_size==before['bytes'] and sha(exe)==before['sha256'];compression.append({'target':target,'path':str(exe),**before,'logicalSizeAndSha256Unchanged':True,'afterSuccessfulWholeHarnessOnly':True});(out/'compression.json').write_bytes((json.dumps(compression,indent=2)+chr(10)).encode())
 owned('debug-build',[cargo,'build','--workspace','--locked','--offline','-j','2','--message-format','json'],timeout=900)
 version=owned('cli-version',[str(w/'target/debug/yoke.exe'),'--version'],timeout=30).decode().strip();assert version=='yoke 0.5.0'
 owned('python-all',[r'C:\Python314\python.exe','-X','utf8','-m','unittest','discover','-s','scripts/tests','-v'],timeout=300)
 npm=shutil.which('npm.cmd');assert npm
 owned('npm-typecheck',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
 owned('npm-test',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'formatRoots':len(format_roots),'oneTargetAtATimeThenLosslessCompactAfterPass':True,'green5LibraryOwnInputsExactExceptUnrelatedIntegrationAssertStyle':True,'green6NewIntegrationSameFreeze':True,'observedExitCode':rows[-1].get('exitCode') if rows else None,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'privateCargoPathOnlyCorrected':True,'productionHelperUnchanged':sha(w/'scripts/run_native_tests.py')==old['scripts/run_native_tests.py'],'sourceCommit':'295fe1086e94b76a16dab4afe4cbe3e4e851cf8d'};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps(result),flush=True)
