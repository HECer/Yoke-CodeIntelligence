from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/resource-settings-20261023-295fe108-namespace-red1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-repository-discovery-check-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))





inputs=json.loads((w/'validation/integration-20261018/resource-settings-20261023-295fe108-green4/source-before.json').read_bytes());assert len(inputs)==1104 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+chr(10)).encode())
native=jobroot/'current-qualified-debug.exe';shutil.copyfile(w/'target/debug/yoke.exe',native);assert sha(native)==sha(w/'target/debug/yoke.exe')=='5a56f6241fc6dc440bd08405bbb46c76b9f3ac2dab4c39788fe4482836f8c4f5'
(source/'unicode').mkdir();(source/'main.rs').write_bytes('// owned \U0001f30d\r\nfn visible() {}\r\n'.encode());(source/'unicode/e\u0301-\U0001f9ed.rs').write_bytes(b'fn alternate() {}\n');original={p.relative_to(source).as_posix():sha(p) for p in source.rglob('*') if p.is_file()}
node=Path(r'C:\Program Files\nodejs\node.exe');worker=jobroot/'protocol-worker.py';shutil.copyfile(w/'validation/integration-20261018/server-workspace-settings-live1/protocol-worker.py',worker);shutil.copyfile(worker,out/'protocol-worker.py');log=jobroot/'lsp.jsonl';fixture=w/'native/tests/fixtures/resource-settings-lsp.mjs'
servers=jobroot/'servers.json';servers.write_bytes(json.dumps([{'backendId':'rust','command':str(node),'args':[str(fixture),str(log)],'configuration':{'passiveProfile':'contract_fixture','settings':{'base':'original'},'resourceSettings':{'main.rs':{'rust-analyzer':None,'cargo':{'extraEnv':{'RUSTC_WRAPPER':'owned-unavailable-wrapper'}}}}}}]).encode());profile=jobroot/'profile.json';profile.write_bytes(json.dumps({'languageServers':{'global':['rust']}}).encode())
args=[str(native),'--root',str(source),'--timeout','60000','--max-bytes','65536','--language-server-config',str(servers),'--trust-servers','serve-session','--id','owned-namespace-counterexample','--profile','native','--host-profile',str(profile)]
spec={'args':args,'call':{'name':'ci_find','arguments':{'languageServer':{'path':'main.rs','offset':0,'operation':'hover'}}},'toolCount':9,'contains':'owned-unavailable-wrapper','stdout':str(out/'probe.native.stdout'),'stderr':str(out/'probe.native.stderr'),'result':str(out/'probe.reply.json')};file=jobroot/'probe.json';file.write_bytes(json.dumps(spec).encode());complete=False
try:
 run('actual-cli-mixed-namespace-counterexample',[r'C:\Python314\python.exe','-I',worker,file],timeout=120)
 reply=json.loads((out/'probe.reply.json').read_bytes());payload=reply['payload'];report=payload.get('data',payload);observed=json.loads(report['response']['contents']['value']);assert observed['pulled'][1]['cargo']['extraEnv']['RUSTC_WRAPPER']=='owned-unavailable-wrapper';assert report['sourceExecutionAuthorized']==False and log.exists();assert all(sha(source/name)==h for name,h in original.items());complete=True
finally:
 result={'counterexampleReproduced':complete,'scopePolicyRefusedBeforeProvider':False if complete else None,'unsafeRootSelectorReachedOwnedFixtureDespiteNoSourceExecutionGrant':complete,'actualWrapperOrAnalyzedSourceExecuted':False,'fixtureRuntimeOnly':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'cliSha256':sha(native),'frozenInputs':len(inputs)};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps(result),flush=True)
assert complete
