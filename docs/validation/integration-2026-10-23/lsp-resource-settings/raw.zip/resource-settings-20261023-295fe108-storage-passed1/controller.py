from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/resource-settings-20261023-295fe108-storage-passed1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=w;configroot=w;client=''
env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
phase=w/'validation/integration-20261018/resource-settings-20261023-295fe108-qualified1';q=json.loads((phase/'result.json').read_bytes());assert not q['complete'] and q['allJobsEmpty'] and q['sourceInputsUnchanged'];inputs=json.loads((phase/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
items=json.loads(Path(tempfile.gettempdir(),'resource-settings-owned-passed-extra-candidates.json').read_bytes());assert len(items)==3;targets=json.loads((phase/'selected-targets.json').read_bytes());start=(phase/'affected-existing-targets.stderr').stat().st_birthtime_ns;end=(phase/'progress.json').stat().st_mtime_ns
storage_api=ctypes.WinDLL('kernel32',use_last_error=True);storage_api.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)];storage_api.GetCompressedFileSizeW.restype=ctypes.c_uint32
def allocated(path):
 high=ctypes.c_uint32();low=storage_api.GetCompressedFileSizeW(str(path),ctypes.byref(high));assert low!=0xffffffff;return (high.value<<32)|low
records=[];complete=False;initial_free=shutil.disk_usage(w).free;commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
try:
 for index,item in enumerate(sorted(items,key=lambda row:row['bytes'])):
  p=Path(item['path']);assert not p.is_symlink();st=p.stat();assert st.st_size==item['bytes'] and st.st_mtime_ns==item['mtimeNs']
  assert p.resolve()!=(w/'target/debug/yoke.exe').resolve() and p.name not in ['capture_options-784339a4da3fe379.exe','session_fixed_tools-0671ac4d8f474009.exe']
  accepted=w/'validation/integration-20261018/resource-settings-20261023-295fe108-green4';accepted_result=json.loads((accepted/'result.json').read_bytes());assert accepted_result['observedExitCode']==0 and accepted_result['allJobsEmpty'] and accepted_result['sourceInputsUnchanged']
  running=[]
  for line in (accepted/'new-resource-contract-green.stderr').read_text(encoding='utf8').splitlines():
   if line.strip().startswith('Running ') and line.endswith('.exe)'):running.append(w/line.rsplit('(',1)[1][:-1])
  if p in running:
   assert p.parent.resolve()==(w/'target/debug/deps').resolve();proof={'passedSourcePhase':accepted.name,'wholeHarnessPassed':True}
  else:
   probe=w/'validation/integration-20261018/resource-settings-20261023-295fe108-namespace-red1';probe_result=json.loads((probe/'result.json').read_bytes());probe_rows=json.loads((probe/'progress.json').read_bytes());spec=Path(probe_rows[0]['command'][-1]);expected=Path(json.loads(spec.read_bytes())['args'][0]);assert p==expected and p.parent==spec.parent and sha(p)==probe_result['cliSha256'] and probe_result['allJobsEmpty'];proof={'passedSourcePhase':probe.name,'ownedCopiedCliExitedSuccessfully':True,'namespaceCounterexampleNotAcceptance':True}
  assert shutil.disk_usage(w).free>p.stat().st_size+64_000_000,'Stop before exact-file compression: insufficient scratch headroom'
  before={'bytes':p.stat().st_size,'sha256':sha(p),'allocatedBytes':allocated(p)}
  with contextlib.redirect_stdout(commandlog):run('compact-compiled-'+str(index),[env['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(p)],timeout=90)
  after={'bytes':p.stat().st_size,'sha256':sha(p),'allocatedBytes':allocated(p)};assert before['bytes']==after['bytes'] and before['sha256']==after['sha256']
  records.append({**item,**proof,'before':before,'after':after,'logicalBytesAndSha256Exact':True,'executedForStorage':False});(out/'compression.json').write_bytes((json.dumps(records,indent=2)+'\n').encode());print(json.dumps({'compressedFiles':len(records),'logicalSha256Exact':True,'freeBytes':shutil.disk_usage(w).free}),flush=True)
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'selectedOwnSuccessfullyCompiledExecutables':len(items),'completed':len(records),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'initialVolumeFree':initial_free,'finalVolumeFree':shutil.disk_usage(w).free,'fileAllocatedBytesBefore':sum(r['before']['allocatedBytes'] for r in records),'fileAllocatedBytesAfter':sum(r['after']['allocatedBytes'] for r in records),'passedHarnessOrOwnedCopiedCli':True,'testsNotCertifiedFromCompression':True,'artifactDeletion':False,'directoryCompressionOrPolicyChange':False,'systemOrProfileChanges':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
