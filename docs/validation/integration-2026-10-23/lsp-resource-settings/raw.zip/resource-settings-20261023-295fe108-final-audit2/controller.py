from pathlib import Path
import hashlib,json,subprocess,shutil
w=Path.cwd();base=w/'validation/integration-20261018';prefix='resource-settings-20261023-295fe108-';out=base/(prefix+'final-audit2');out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
q=base/(prefix+'qualified3');qualified=json.loads((q/'result.json').read_bytes());assert qualified['complete'] and qualified['allJobsEmpty'] and qualified['sourceInputsUnchanged'];inputs=json.loads((q/'source-before.json').read_bytes());assert len(inputs)==1104 and all(sha(w/n)==h for n,h in inputs.items());assert inputs==json.loads((base/(prefix+'green6')/'source-before.json').read_bytes())
green5=base/(prefix+'green5');prior=json.loads((green5/'source-before.json').read_bytes());assert {n for n in inputs if inputs[n]!=prior[n]}=={'native/tests/lsp_resource_settings.rs'}
current=(w/'native/tests/lsp_resource_settings.rs').read_text();needle='let error = run(&mut engine, &server).unwrap_err();';assert current.count(needle)==1;reconstructed=current.replace(needle,'let error = run(&mut engine, &server)\n            .err()\n            .expect("unsafe resource settings must refuse");');assert hashlib.sha256(reconstructed.encode()).hexdigest()==prior['native/tests/lsp_resource_settings.rs']
def results(path):
 rows=[]
 for line in path.read_text(encoding='utf8').splitlines():
  if line.startswith('test result: '):
   assert line.startswith('test result: ok. '),line
   parts=line.split('. ',1)[1].split(';')[:5];counts=[int(part.strip().split()[0]) for part in parts];assert len(counts)==5 and counts[1]==counts[3]==counts[4]==0;rows.append(dict(zip(['passed','failed','ignored','measured','filtered'],counts)))
 return rows
old_results=results(green5/'new-resource-contract-green.stdout');assert len(old_results)==2 and old_results[0]['passed']==579 and old_results[1]['passed']==10
new_results=results(base/(prefix+'green6')/'new-resource-contract-green.stdout');assert len(new_results)==1 and new_results[0]['passed']==10
groups=[{'group':'lib',**old_results[0],'evidence':prefix+'green5/new-resource-contract-green.stdout','reuseScope':'All library compile/runtime source inputs exact; only unrelated integration assertion spelling changes, reverse hash verified.'},{'group':'lsp_resource_settings',**new_results[0],'evidence':prefix+'green6/new-resource-contract-green.stdout'}]
targets=json.loads((q/'selected-targets.json').read_bytes());assert len(targets)==30
for target in targets:
 rows=results(q/('test-'+target+'.stdout'));assert len(rows)==1;groups.append({'group':target,**rows[0],'evidence':q.name+'/test-'+target+'.stdout'})
totals={key:sum(row[key] for row in groups) for key in ['passed','failed','ignored']};assert len(groups)==32 and totals=={'passed':788,'failed':0,'ignored':13}
rows=json.loads((q/'progress.json').read_bytes());assert all(row['activeAfterCleanup']==0 for row in rows)
for row in rows:
 assert row['exitCode']==(1 if row['name']=='fmt-all' else 0),row['name']
assert b'206' in (q/'fmt-all.stderr').read_bytes();format_roots=json.loads((q/'format-roots.json').read_bytes());assert len(format_roots)==361 and len([row for row in rows if row['name'].startswith('fmt-root-')])==361
compressions=json.loads((q/'compression.json').read_bytes());assert len(compressions)==30 and {row['target'] for row in compressions}==set(targets)
for row in compressions:assert sha(Path(row['path']))==row['sha256'] and Path(row['path']).stat().st_size==row['bytes'] and row['logicalSizeAndSha256Unchanged']
python=(q/'python-all.stderr').read_text(encoding='utf8');assert [int(line.split()[1]) for line in python.splitlines() if line.startswith('Ran ')]==[35] and any(line.strip()=='OK' for line in python.splitlines());npm=(q/'npm-test.stdout').read_text(encoding='utf8');assert all(text in npm for text in ['pass 260','fail 0','skipped 3'])
proofs={}
for name in ['namespace-red1','namespace-green1','live1','host-explicit1']:
 phase=base/(prefix+name);r=json.loads((phase/'result.json').read_bytes());assert r['allJobsEmpty'] and r['sourceInputsUnchanged'];assert name=='namespace-red1' or r.get('complete',r.get('counterexampleNowDenied'));proofs[name]=r
 if name!='namespace-red1':assert json.loads((phase/'source-before.json').read_bytes())==inputs
assert proofs['namespace-red1']['counterexampleReproduced'] and not proofs['namespace-red1']['scopePolicyRefusedBeforeProvider'];assert proofs['namespace-green1']['scopePolicyRefusedBeforeProvider'] and proofs['namespace-green1']['noProviderLogCreated']
assert proofs['live1']['ordinaryAbsentAndNullWireAndSqlExact'] and proofs['live1']['originalRowsPreserved'] and proofs['live1']['actualResourceScopesAndStagedAction']
host=json.loads((base/(prefix+'host-explicit1')/'host-result.json').read_bytes());assert host['passed'] and not host['bundledRuntime'] and all(host[key] for key in ['unsavedSourceBound','workspaceExecutableIgnored','protectedOpenBufferExcluded','savedSourceUnchanged'])
pre=json.loads((base/'native-full-current-20261023-89a277f8-preflight1/result.json').read_bytes())
for name,expected in pre['protectedDefaultMetadataOnly'].items():
 p=w/'target/debug/deps'/name
 if expected.get('absent'):assert not p.exists()
 else:
  st=p.stat();assert {'bytes':st.st_size,'mtimeNs':st.st_mtime_ns,'attributes':getattr(st,'st_file_attributes',None)}==expected
native_sha=sha(w/'target/debug/yoke.exe');assert native_sha=='aa391752ae06896894e0610e65f7a006ac8757dccf32eb19428882e5cf72f7c7' and proofs['live1']['cliSha256']==proofs['host-explicit1']['nativeExeSha256']==proofs['namespace-green1']['cliSha256']==native_sha
assert sha(w/'target/resource-settings-20261023-295fe108-before/yoke.exe')==pre['cliSha256']
old_fixture=subprocess.check_output(['git','show','HEAD:native/tests/server_catalog.rs']);new_fixture=(w/'native/tests/server_catalog.rs').read_bytes();reconstructed_fixture=new_fixture.replace(b'        resource_settings: None,\r\n',b'',1);assert reconstructed_fixture.replace(b'\r\n',b'\n')==old_fixture;old_working=json.loads((base/'vsix-archive-20261023-df52798b-qualified1/source-before.json').read_bytes())['native/tests/server_catalog.rs'];assert hashlib.sha256(reconstructed_fixture).hexdigest()==old_working
paths=sorted(set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()));assert set(paths)=={'native/src/lsp.rs','native/src/lsp_resource_settings.rs','native/src/server_catalog.rs','native/src/server_selection.rs','native/src/server_settings.rs','native/tests/server_catalog.rs','native/tests/lsp_resource_settings.rs','native/tests/fixtures/resource-settings-lsp.mjs'}
result={'complete':True,'baseCommit':'295fe1086e94b76a16dab4afe4cbe3e4e851cf8d','qualifiedWorkingChanges':{n:inputs[n] for n in paths},'frozenInputs':1104,'sourceInputsUnchanged':True,'nativeGroups':groups,'nativeTotals':totals,'allJobsEmpty':True,'formatRoots':361,'clippyAllTargetsWarningsDenied':True,'debugBuildPassed':True,'pythonPassed':35,'npmPassed':260,'npmExistingSkipped':3,'typecheckPassed':True,'nativeCliSha256':native_sha,'precedingCliSha256':pre['cliSha256'],'libraryReuseOnlyUnrelatedIntegrationAssertStyleDeltaReconstructedExactly':True,'originalServerCatalogAssertionsExactWithRequiredDefaultFieldOnly':True,'protectedFailedOutputsMetadataExact':True,'ownedLiveCalls':7,'defaultWireAndSqlExact':True,'originalRowsPreserved':True,'actualNamespaceDenialBeforeProvider':True,'actualExplicitCodeHost':host,'canonicalVsixAccepted':False,'releaseAccepted':False,'fullStatusComplete':False,'artifactDeletion':False,'systemOrProfileChanges':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({key:value for key,value in result.items() if key not in ['nativeGroups','qualifiedWorkingChanges','actualExplicitCodeHost']}))
