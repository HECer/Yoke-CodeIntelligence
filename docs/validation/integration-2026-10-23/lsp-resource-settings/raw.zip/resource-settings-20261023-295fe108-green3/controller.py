from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/resource-settings-20261023-295fe108-green3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace("if time.monotonic()-start>timeout:raise TimeoutError(name)","if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom guard','exec'))



import contextlib
old=json.loads((w/'validation/integration-20261018/vsix-archive-20261023-df52798b-qualified1/source-before.json').read_bytes());extra=['native/docs/vsix-packaging.md','native/tests/lsp_resource_settings.rs','native/tests/fixtures/resource-settings-lsp.mjs','native/src/lsp_resource_settings.rs'];inputs={n:sha(w/n) for n in [*old,*extra]};assert len(inputs)==1104;assert shutil.disk_usage(w).free>3_000_000_000,'Insufficient debug-target headroom';(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+chr(10)).encode());env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH'];commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
try:
 with contextlib.redirect_stdout(commandlog):
  run('new-resource-contract-green',[r'C:\Python314\python.exe','-X','utf8',str(w/'scripts/run_native_tests.py'),'--controlled-test-runner','--locked','--offline','--test','lsp_resource_settings','-j','2','--','--test-threads=1'],expected=0,timeout=900)
 assert all(sha(w/n)==h for n,h in inputs.items())
finally:
 result={'allChecksExpectedPass':True,'observedExitCode':rows[-1].get('exitCode') if rows else None,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'privateCargoPathOnlyCorrected':True,'productionHelperUnchanged':sha(w/'scripts/run_native_tests.py')==old['scripts/run_native_tests.py'],'sourceCommit':'295fe1086e94b76a16dab4afe4cbe3e4e851cf8d'};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps(result),flush=True)
