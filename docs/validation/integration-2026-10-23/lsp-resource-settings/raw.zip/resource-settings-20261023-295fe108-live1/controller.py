from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/resource-settings-20261023-295fe108-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-resource-live-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for name,relative in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/relative;p.mkdir(parents=True,exist_ok=True);env[name]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
phase=w/'validation/integration-20261018/resource-settings-20261023-295fe108-qualified3';qualified=json.loads((phase/'result.json').read_bytes());assert qualified['complete'] and qualified['allJobsEmpty'] and qualified['sourceInputsUnchanged'];inputs=json.loads((phase/'source-before.json').read_bytes());assert len(inputs)==1104 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
native=jobroot/'current.exe';old=w/'target/resource-settings-20261023-295fe108-before/yoke.exe';shutil.copyfile(w/'target/debug/yoke.exe',native);assert sha(native)==sha(w/'target/debug/yoke.exe')=='aa391752ae06896894e0610e65f7a006ac8757dccf32eb19428882e5cf72f7c7';assert sha(old)=='8d66415f2af983ff2d8639f6dc50324f3b5d6722631401454897e52c90f7925e'
alt='unicode/e\u0301-\U0001f9ed.rs';(source/'unicode').mkdir();(source/'main.rs').write_bytes('// owned \U0001f30d\r\nfn visible() {}\r\n'.encode());(source/alt).write_bytes(b'fn alternate() {}\n');(source/'.env').write_bytes(b'OWNED_PROTECTED_CANARY=unavailable\n');original={p.relative_to(source).as_posix():sha(p) for p in source.rglob('*') if p.is_file()}
node=Path(r'C:\Program Files\nodejs\node.exe');node_hash=sha(node);fixture=w/'native/tests/fixtures/resource-settings-lsp.mjs';log=jobroot/'lsp.jsonl';servers=jobroot/'servers.json';servers.write_bytes(json.dumps([{'backendId':'rust','command':str(node),'args':[str(fixture),str(log)],'configuration':{'passiveProfile':'contract_fixture','settings':{'base':'original','nested':{'selected':'original'}}}}]).encode())
worker=jobroot/'protocol-worker.py';shutil.copyfile(w/'validation/integration-20261018/server-workspace-settings-live1/protocol-worker.py',worker);shutil.copyfile(worker,out/'protocol-worker.py')
base={'languageServers':{'global':['rust']},'trustedServerSettingsProjects':['default'],'languageServerSettings':{'global':{'rust':{}}}};legacy=jobroot/'legacy.json';legacy.write_bytes(json.dumps(base).encode());commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
def protocol(name,exe,profile,label,operation='hover',contains='original'):
 args=[str(exe),'--root',str(source),'--timeout','60000','--max-bytes','65536','--language-server-config',str(servers),'--trust-servers','serve-session','--id',label,'--profile','native','--host-profile',str(profile)]
 spec={'args':args,'call':{'name':'ci_find','arguments':{'languageServer':{'path':'main.rs','offset':0,'operation':operation}}},'toolCount':9,'contains':contains,'stdout':str(out/(name+'.native.stdout')),'stderr':str(out/(name+'.native.stderr')),'result':str(out/(name+'.reply.json'))};path=jobroot/(name+'.json');path.write_bytes(json.dumps(spec).encode())
 with contextlib.redirect_stdout(commandlog):run(name,[r'C:\Python314\python.exe','-I',worker,path],timeout=120)
 return json.loads((out/(name+'.reply.json')).read_bytes())
def stable(value):
 value=json.loads(json.dumps(value));payload=value['payload'];payload.pop('requestId',None)
 for name in ['durationMs','serializedBytes','estimatedTokens']:payload.get('metrics',{}).pop(name,None)
 return value
def body(value):
 payload=value['payload'];return json.loads(payload.get('data',payload)['response']['contents']['value'])
def sql():
 with sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True) as db:
  return {name:sorted(db.execute('SELECT * FROM '+name).fetchall(),key=repr) for name in ['snapshots','graphs','records']}
complete=False
try:
 protocol('old-cold',old,legacy,'owned-legacy')
 first=protocol('old-warm-first',old,legacy,'owned-legacy');repeat=protocol('old-warm-repeat',old,legacy,'owned-legacy');assert stable(first)==stable(repeat);before=sql();(out/'legacy-sql-before.json').write_bytes((json.dumps(before,indent=2)+'\n').encode())
 current=protocol('new-warm',native,legacy,'owned-legacy');assert stable(current)==stable(first) and sql()==before
 raw=json.loads(legacy.read_bytes());raw['languageServerSettings']['global']['rust']['resourceSettings']=None;null=jobroot/'null.json';null.write_bytes(json.dumps(raw).encode())
 same=protocol('new-null',native,null,'owned-legacy');assert stable(same)==stable(first) and sql()==before
 raw['languageServerSettings']['global']['rust']['resourceSettings']={'main.rs':{'tag':'owned-main-resource'},alt:{'tag':'owned-alt-resource','nested':{'selected':'owned-\u03c0 e\u0301'}}};selected=jobroot/'selected.json';selected.write_bytes(json.dumps(raw).encode());reply=protocol('new-selected',native,selected,'owned-selected',contains='owned-alt-resource');observed=body(reply);assert observed['pulled'][1]['tag']=='owned-main-resource' and observed['pulled'][2]['tag']=='owned-alt-resource' and observed['pulled'][3]=='owned-\u03c0 e\u0301' and all(observed['pulled'][n] is None for n in [5,6,7,9])
 action=protocol('new-staged-action',native,selected,'owned-selected','codeActions','owned-main-resource');assert action['payload']['data']['items'][0]['usable'] is True
 after=sql()
 for table,rows_before in before.items():
  assert all(row in after[table] for row in rows_before),'Original row changed: '+table
 assert all(sha(source/name)==h for name,h in original.items()) and all(sha(w/name)==h for name,h in inputs.items()) and sha(node)==node_hash;complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'sourceInputsUnchanged':all(sha(w/name)==h for name,h in inputs.items()),'frozenInputs':1104,'cliSha256':sha(native),'precedingCliSha256':sha(old),'nodeSha256':node_hash,'ownedParentProcessCalls':len(rows),'independentOldRepeatCalibratesOnlyVolatileFields':complete,'ordinaryAbsentAndNullWireAndSqlExact':complete,'actualResourceScopesAndStagedAction':complete,'originalRowsPreserved':complete,'allSourceBytesExact':all(sha(source/name)==h for name,h in original.items()),'realModelCalls':0,'analyzedSourceExecuted':False,'fixtureRuntimeOnly':True};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
