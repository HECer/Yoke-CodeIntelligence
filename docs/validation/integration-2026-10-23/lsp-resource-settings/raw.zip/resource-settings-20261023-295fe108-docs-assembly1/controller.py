from pathlib import Path
import hashlib,json,subprocess,zipfile
w=Path.cwd();base=w/'validation/integration-20261018';prefix='resource-settings-20261023-295fe108-';d=w/'docs/validation/integration-2026-10-23/lsp-resource-settings';assert not d.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_bytes((json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert commit=='666656bae3c4e5a0abb9918d943505098266e455'
audit=json.loads((base/(prefix+'final-audit2')/'result.json').read_bytes());assert audit['complete'];inputs=json.loads((base/(prefix+'qualified3')/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items()) and subprocess.check_output(['git','status','--porcelain'])==b''
d.mkdir(parents=True);members={};archive=d/'raw.zip';phases=sorted(base.glob(prefix+'*'));files=sorted(p for phase in phases for p in phase.rglob('*') if p.is_file())
assert all(not p.is_symlink() and p.suffix in {'.py','.json','.jsonl','.stdout','.stderr'} for p in files)
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:
  name=p.relative_to(base).as_posix();data=p.read_bytes();assert name not in members
  members[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(members) and set(z.namelist())==set(members)
 for name,proof in members.items():
  data=z.read(name);assert len(data)==proof['bytes'] and hashlib.sha256(data).hexdigest()==proof['sha256']
index={**audit,'qualifiedCodeCommit':commit,'qualifiedCodeBlobsEqualMeasuredWorkingBytes':True,'libraryReuseScope':'Green5 library own compile/runtime inputs exact. Only unrelated integration err().expect() spelling becomes unwrap_err(); reverse source SHA256 reconstruction proves that sole delta. Green6 and qualified3 share the final 1104 input map.','archive':{'members':len(members),'bytes':archive.stat().st_size,'sha256':sha(archive),'everyMemberReopened':True},'rawMembers':members}
write(d/'index.json',index)
intro="""Explicit LSP resourceSettings now selects shallow workspace-setting overlays
for exact captured files, through trusted host registration, project/backend
settings and pinned YAML. Requests retain item order and section projection;
unavailable scopes explicitly return null. Original project/runtime/source/write
grants remain separate, with snapshot membership, effective capacity and passive
policy checked before provider startup. Both direct and rust-analyzer-namespaced
settings are checked, including ASCII-case variants of blocked compiler env keys.
Absent/null options retain original bindings and valid wire behavior.

Qualified code 666656ba passes 788 native functions in 32 scoped groups,
zero failures/13 existing ignores, including all 579 library and ten new resource
integration functions. Final gates track 1,104 source/control inputs; the library
result is reused under unchanged own inputs after one unrelated integration
assertion spelling change, independently reconstructed by SHA256. All-target
Clippy, 361 individual format roots, build, typecheck, Python 35 and npm
260 passed/3 existing skips pass; fmt-all retains Windows OS206.

Actual CLI comparisons preserve default/absent/null wire replies and complete
original SQL rows; selected file scopes and staged actions pass. A controlled
mixed-namespace counterexample first reaches the owned fixture and then refuses
before provider startup after the fix; no wrapper or analyzed source executes.
The current explicit native runtime also passes the unchanged actual host test
on VS Code 1.143.1, including all four source/permission assertions. All Jobs end
empty. Disk-limited compilation and failed audit/lint attempts remain explicit;
exact-file lossless optimization preserves bytes and deletes nothing.
See [resource evidence](validation/integration-2026-10-23/lsp-resource-settings/README.md)
and [contract](../native/docs/lsp-resource-settings.md).
Canonical bundled VSIX/release, current whole-native/Windows/hosted and broader
STATUS/353/R1-R9/77-runtime/client/format/quality/Google/main acceptance remain open.
"""
status=w/'docs/STATUS.md';remaining=w/'docs/REMAINING_WORK.md';marker=b'## Current integration work\n\n';data=status.read_bytes();assert data.count(marker)==1;status.write_bytes(data.replace(marker,marker+intro.encode()+b'\n',1));data=remaining.read_bytes();first,rest=data.split(b'\n\n',1);remaining.write_bytes(first+b'\n\n'+intro.encode()+b'\n'+rest)
reconciliation=w/'docs/parity/native-reconciliation-2026-10-15.json';before=json.loads(reconciliation.read_bytes());key='nativeLspResourceSettingsAcceptance20261023';assert key not in before
checkpoint={'qualifiedCodeCommit':commit,'evidence':'docs/validation/integration-2026-10-23/lsp-resource-settings/README.md','frozenInputs':1104,'nativePassed':788,'nativeFailed':0,'nativeExistingIgnored':13,'nativeGroups':32,'libraryPassed':579,'newIntegrationPassed':10,'allTargetClippyWarningsDenied':True,'formatRoots':361,'fmtAllWindowsOs206Retained':True,'pythonPassed':35,'typescriptPassed':260,'typescriptExistingSkipped':3,'actualDefaultWireAndSqlExact':True,'actualMixedNamespaceDenialBeforeProvider':True,'actualExplicitCodeHostVersion':'1.143.1','actualExplicitCodeHostPassed':True,'allJobsEmpty':True,'canonicalVsixAccepted':False,'releaseAccepted':False,'wholeNativeRerun':False,'all77RuntimeAcceptanceCertified':False,'fullContractCertification':False}
write(reconciliation,{**before,key:checkpoint});after=json.loads(reconciliation.read_bytes());assert after.pop(key)==checkpoint and after==before
workspace_contract=w/'native/docs/server-workspace-settings.md';text=workspace_contract.read_text();old="""does not add per-resource configuration resolution or dynamic configuration
editing in a running session.""";new="""also supports explicit captured-file configuration via
[resourceSettings](lsp-resource-settings.md). It does not add dynamic configuration
editing in a running session.""";assert old in text;text=text.replace(old,new);text=text.replace('Broader vendor aliases, per-resource settings, all 77 runtime/operation reviews,','Broader vendor aliases/resource scopes, all 77 runtime/operation reviews,');workspace_contract.write_bytes(text.encode())
contract=w/'native/docs/lsp-resource-settings.md';assert not contract.exists()
contract.write_bytes("""# Source-bound LSP resource settings

Optional resourceSettings is a map from exact captured file paths to settings
objects. It is accepted by HostConfiguration and catalogue HostRegistration,
and by each trusted project/backend languageServerSettings entry. Pinned YAML
ls_specific_settings uses the same backend entry shape. For CLI
--language-server-config entries it belongs inside configuration.

Example client-side data selection (exampleSection is illustrative vendor data):

    {
      "settings": {"exampleSection": {"base": true, "style": "base"}},
      "resourceSettings": {
        "src/example.rs": {"exampleSection": {"style": "selected-file"}}
      }
    }

The file overlay replaces exampleSection as one top-level key; nested objects
are not recursively merged. A project overlay first merges each named file's
object with that file's ORIGINAL registered overlay. Each resolved file overlay
then merges with the selected workspace settings. Existing whole-backend
project-local/project/global precedence stays unchanged; another project's
effective configuration never becomes the starting point.

## Admission and authority

Paths must be canonical portable relative, non-protected file paths, at most
4,096 bytes. Every selected file must exist in the immutable captured Snapshot
and remain outside passive private-tree omissions. No host/original-source
lookup, glob, directory inheritance or automatic file discovery is added.
Resource data cannot register a provider, change its launch program, grant
source execution or writes, select an outside root, bypass source freshness or
replace an approval/recovery requirement.

At most 100 file entries and 128,000 serialized map bytes are admitted.
Each raw overlay and its effective workspace merge follow the existing
64,000-byte/32-value-level/4,096-node project-setting limits. Passive Rust's
mandatory false execution settings are added to each resolved file object and
its final capacity is rechecked before process startup. Existing overall
host-profile and protocol budgets remain independent. These are bounded
application checks, not a hard OS memory or execution sandbox.

Passive checks inspect initialization, workspace and every effective file object.
Direct and rust-analyzer-namespaced Rust settings are both checked; neither can
mask the other. Existing blocked compiler environment selectors are compared
with ASCII case insensitivity. Explicit source-execution permission remains a
separate host field. Generic/vendor data stays distinct from validated runtime
behavior; no extra vendor aliases or runtime versions are certified.

## Configuration callbacks

An explicit map, including an empty map, activates captured resource resolution.
The copied tree's canonical root URI and absent/null scopeUri select workspace
settings. An exact captured file selects its effective overlay, or workspace
settings when no file override exists. A valid but unavailable/foreign/protected/
omitted/non-file scope returns null for that item; no real host file is opened.
Relative file membership is exact; no Unicode normalization or expanding
case-fold identity is introduced.

Sections retain the existing dotted-key projection and response order.
Non-object items, invalid non-null scope types and overlong scope strings fail.
At most 64 items, 8,192 scope bytes, 1,000 section bytes and the existing
4,000,000-byte callback reply limit apply. These semantics follow the
[LSP configuration request](https://github.com/microsoft/language-server-protocol/blob/gh-pages/_specifications/lsp/3.17/workspace/configuration.md).

Omitted/null host fields retain the preceding no-map format. Omitted/null
project overlays retain original registered defaults. Valid absent/null wire
replies, default profiles and named bindings remain unchanged. Selected maps
bind the existing provider/session fingerprint, and changed named policy refuses.
HTTP authentication/current principal grants/revocation still precede use.
Configuration remains fixed for one provider run; there is no dynamic editor
configuration import or running-session edit mechanism.

Owned Node protocol, actual CLI/default-row and authenticated TCP tests qualify
this mechanism. They are not vendor runtime or semantic-quality certification.
The actual current explicit-runtime VS Code host test passes separately; a
canonical bundled VSIX, all 77 runtimes and release acceptance remain open.
See ../../docs/validation/integration-2026-10-23/lsp-resource-settings/README.md.
""".encode())
changed={name:{'before':value,'after':sha(w/name)} for name,value in inputs.items() if sha(w/name)!=value};assert set(changed)=={'docs/STATUS.md','docs/REMAINING_WORK.md','docs/parity/native-reconciliation-2026-10-15.json','native/docs/server-workspace-settings.md'}
write(d/'post-review-docs.json',{'qualifiedCodeCommit':commit,'productionFilesUnchangedAfterQualification':True,'changedFrozenInputs':changed,'newDocumentationAfterQualification':['native/docs/lsp-resource-settings.md'],'newProductTestsClaimedAfterDocumentation':False,'originalInventoryLedgerAndSummaryUnchanged':True,'reconciliationExactlyOneAdditiveKey':key,'everyArchiveMemberLengthAndSha256Reopened':True})
readme=f"""# Source-bound LSP resource settings

Native Code Intelligence 0.5.0 / retained TypeScript 0.3.0, 2026-10-23.
Qualified code {commit}; cumulative base {audit['baseCommit']}.
Its eight committed code/test blobs equal measured working bytes.

## Accepted scope

Explicit captured-file overlays reach trusted host registration, project/backend
selection and pinned YAML, ordinary queries, unpublished staged edits and current
authenticated HTTP. Item order/sections, original registered bases, independent
projects/backends, source/execution/write grants and stale named bindings remain.
Captured file membership and effective budgets/passive policy precede startup.
Direct/namespaced Rust selectors cannot mask each other; blocked environment
selector names use ASCII case insensitivity. Missing scopes return explicit null.

Final native scope: 32 whole groups, {audit['nativeTotals']['passed']} passed,
zero failures and 13 existing ignores. All 579 library functions and ten new
integration functions are included. [index.json](index.json) binds each group to
completed unfiltered stdout, with measured/filtered counts zero. The 30 existing
groups run individually; newly successful programs are losslessly optimized
after their completed whole-harness pass. Counts overlap historical trials and
must not be added to them.

All-target Clippy with warnings denied, build, 361 individual format roots,
typecheck, Python 35 and npm 260 passed/3 existing skips pass. Aggregate fmt-all
retains its actual Windows OS206 failure; individual roots are separately checked.
The final gates/new integration/CLI/host phases share one 1,104-input map.
Green5's accepted library has identical own compile/runtime inputs. Its sole map
difference is an unrelated integration assertion's err().expect() spelling,
changed to unwrap_err() for Clippy. Reverse reconstruction exactly matches the
old SHA256; the final ten-test integration program is rerun as Green6. The
library is not repeated for this non-library change and is not called a new run.
All completed controlled Jobs end empty. Protected failed output paths remain
metadata-only and exact. No original native ignore or internal deadline changes.

## Actual CLI and editor

Seven actual CLI parent calls independently calibrate old-repeat volatile fields
and compare the preceding 8d66415f image with the current
{audit['nativeCliSha256']} image. Request ID/duration and derived serialization
metrics are the only omitted volatile fields. Absent/null replies and whole
original snapshots/graphs/records are exact on one owned source and Store.
Explicit resource replies and checked staged-action data pass. Later named
selected operations retain every original SQL row and all saved source bytes.

The current unchanged extension-host test passes on official Microsoft-signed
VS Code 1.143.1 with the explicit current native runtime: unsaved source binding,
ignored workspace executable, protected open-buffer exclusion and saved source
preservation all pass. Private profiles/logs remain outside the archive.
This is explicit-runtime contract evidence, not full visual/accessibility,
canonical bundled VSIX, vendor runtime or release acceptance.

## Causal failures and corrections

RED on unchanged 295fe108 produces six actual unknown-field failures before
implementation. Initial compilation exposes one full HostConfiguration literal,
then a failed multi-file patch leaves the newly referenced registration field
absent; both compiler failures are preserved. Complete registration/selection
forwarding then passes the first six actual Node protocol cases.

The expanded library/new-integration pass exposes no ordinary failure, but a
separate actual CLI counterexample demonstrates a masked root RUSTC_WRAPPER
selector reaching the controlled fixture when a rust-analyzer namespace is
present. No real wrapper or analyzed source executes. Inspecting both
representations and ASCII-case variants fixes this; expanded negative cases pass
and the actual CLI returns the specific permission refusal without a provider log.
The preceding 5a56f624 counterexample image and final aa391752 result retain their
distinct exact hashes and source maps.

Qualified2 catches one integration-only err().expect() lint. The idiomatic
equivalent is corrected, final integration reruns and Qualified3 completes.
The first read-only final audit incorrectly assumes LF while comparing the
existing CRLF catalogue fixture to its LF Git blob. The second audit proves its
old frozen working SHA256 after removing only the required new None default
field, and separately reconciles the unchanged Git text. Every original
catalogue assertion is preserved; no old test is weakened or rerun for metadata.

## Disk and evidence integrity

Qualified1's earlier pre-fix 30-target batch stops at the owned 500MB free-space
guard before tests run. Cleanup is measured empty and source remains exact; no
whole qualification or test pass is inferred. Twelve completed compiler outputs
are selected by exact target/time, fresh Cargo completion markers and fingerprint
JSON. They are explicitly not yet executed. Exact-file LZX preserves every size/
SHA256, reducing their measured allocations from 1,443,475,456 to 179,621,888 bytes.
Two previously passed harnesses and one owned CLI copy are separately optimized;
the primary CLI, protected failed outputs and unvalidated old release are excluded.
No artifact is deleted or directory/system/build-profile policy changed.
Volume free-space movement is not attributed entirely to file optimization.
Qualified3 avoids accumulation by executing and optimizing one whole target at
a time; all thirty final selected normal programs then pass under final source.

[raw.zip](raw.zip) contains {len(members)} independently reopened members.
Every member length and SHA256 matches [index.json](index.json).
Archive SHA256 {sha(archive)}; {archive.stat().st_size:,} bytes.
Failed controllers, compiler/lint/audit attempts, source hashes, command/status/
Job cleanup logs, original/recovered results and allocation proofs are retained.
Executables, libraries, PDBs, real profiles and cache binaries are excluded.

Only four existing docs plus the new contract and evidence follow qualification;
[post-review-docs.json](post-review-docs.json) records the exact changed input map.
No later product test is claimed. Removing one additive reconciliation key
leaves the entire prior inventory deep-equal. Original 353 ledger/summary,
73 unreconciled/77 runtime unknowns and historical full Windows baseline remain.
Canonical VSIX/release, current whole Windows/hosted, broader client/vendor/
resource discovery/format/quality, approved Google export and main acceptance
remain open. No Developer Mode, privilege or system-setting change is made.
"""
(d/'README.md').write_bytes(readme.encode())
print(json.dumps({'complete':True,'qualifiedCodeCommit':commit,'archive':index['archive'],'phases':len(phases),'changedFrozenInputs':list(changed),'newContract':str(contract.relative_to(w))}))
