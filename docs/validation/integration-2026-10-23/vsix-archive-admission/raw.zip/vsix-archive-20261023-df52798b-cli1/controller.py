from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/vsix-archive-20261023-df52798b-cli1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-full89-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



import contextlib
old=json.loads((w/'validation/integration-20261018/ci-tls-boundary-20261023-2095792b-qualified4/source-before.json').read_bytes());inputs={n:sha(w/n) for n in old};(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+chr(10)).encode());env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH'];commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
import zipfile,xml.etree.ElementTree as ET
assert not (w/'target/release/yoke').exists()
fixture_binary=b'Owned synthetic fixture only: never execute or deliver.\n'
manifest={'name':'owned-synthetic-fixture-only','version':'0.5.0','target':'x86_64-unknown-linux-gnu','binarySha256':hashlib.sha256(fixture_binary).hexdigest(),'fixtureOnly':True}
archive_input=jobroot/'synthetic-native-only.zip';output=jobroot/'synthetic-only-NOT-DELIVERABLE.vsix'
with zipfile.ZipFile(archive_input,'x') as z:
 z.writestr('yoke',fixture_binary);z.writestr('manifest.json',json.dumps(manifest))
try:
 with contextlib.redirect_stdout(commandlog):
  run('actual-package-cli',[r'C:\Python314\python.exe','-X','utf8',str(w/'scripts/package-vscode.py'),'--native-archive',str(archive_input),'--include-typescript','--output',str(output)],timeout=180)
 members={}
 with zipfile.ZipFile(output) as z:
  assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
  for name in z.namelist():
   data=z.read(name);members[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
   if name in ['extension.vsixmanifest','[Content_Types].xml']:continue
   if name.startswith('extension/runtime/native/'):
    with zipfile.ZipFile(archive_input) as sourcezip:assert data==sourcezip.read(name.removeprefix('extension/runtime/native/'))
   else:
    if name=='extension/LICENSE':source_path=w/'LICENSE'
    elif name.startswith('extension/runtime/'):source_path=w/name.removeprefix('extension/runtime/')
    else:source_path=w/'extensions/vscode'/name.removeprefix('extension/')
    assert data==source_path.read_bytes(),name
  identity=ET.fromstring(z.read('extension.vsixmanifest')).find('{http://schemas.microsoft.com/developer/vsx-schema/2011}Metadata/{http://schemas.microsoft.com/developer/vsx-schema/2011}Identity');assert identity.get('TargetPlatform')=='linux-x64' and identity.get('Version')=='0.5.0'
  assert json.loads(z.read('extension/runtime/package.json'))['version']=='0.3.0'
  assert 'extension/test-host.cjs' not in members
 (out/'archive-members.json').write_bytes((json.dumps(members,indent=2)+chr(10)).encode())
 bad_input=jobroot/'unsafe-native.zip'
 with zipfile.ZipFile(bad_input,'x') as z:
  z.writestr('yoke',fixture_binary);z.writestr('manifest.json',json.dumps(manifest));z.writestr('../outside',b'Owned rejection fixture')
 bad_output=jobroot/'must-not-exist.vsix'
 with contextlib.redirect_stdout(commandlog):run('actual-cli-refuses-unsafe-native',[r'C:\Python314\python.exe','-X','utf8',str(w/'scripts/package-vscode.py'),'--native-archive',str(bad_input),'--output',str(bad_output)],expected=1,timeout=30)
 assert not bad_output.exists()
 existing=jobroot/'existing.vsix';existing.write_bytes(b'Owned existing output')
 with contextlib.redirect_stdout(commandlog):run('actual-cli-preserves-existing-output',[r'C:\Python314\python.exe','-X','utf8',str(w/'scripts/package-vscode.py'),'--native-archive',str(archive_input),'--output',str(existing)],expected=1,timeout=30)
 assert existing.read_bytes()==b'Owned existing output'
 assert all(sha(w/n)==h for n,h in inputs.items())
 (out/'actual-cli-result.json').write_bytes((json.dumps({'complete':True,'syntheticFixtureOnly':True,'syntheticBinariesExecuted':False,'canonicalNativeVsixAccepted':False,'allMembersReopenedAndSourceExact':True,'archiveMembers':len(members),'archiveBytes':output.stat().st_size,'archiveSha256':sha(output),'platform':'linux-x64','nativeVersion':'0.5.0','retainedTypeScriptVersion':'0.3.0','unsafeArchiveRefusedBeforeOutput':True,'existingOutputUnchanged':True,'allJobsEmpty':all(row['activeAfterCleanup']==0 for row in rows),'sourceInputsUnchanged':True},indent=2)+chr(10)).encode())
finally:
 result={'allChecksExpectedPass':True,'observedExitCode':rows[-1].get('exitCode') if rows else None,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'privateCargoPathOnlyCorrected':True,'productionHelperUnchanged':sha(w/'scripts/run_native_tests.py')==old['scripts/run_native_tests.py'],'sourceCommit':'df52798bbf799245397ffacb163dbca0490705d6'};(out/'result.json').write_bytes((json.dumps(result,indent=2)+chr(10)).encode());print(json.dumps(result),flush=True)
