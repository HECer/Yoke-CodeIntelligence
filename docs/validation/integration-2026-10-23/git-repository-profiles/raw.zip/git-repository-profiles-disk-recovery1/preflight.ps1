$ErrorActionPreference = 'Stop'
$workspaceRoot = (Get-Location).ProviderPath
$targetRoot = (Resolve-Path -LiteralPath (Join-Path $workspaceRoot 'target/debug/deps')).ProviderPath
if (-not $targetRoot.StartsWith($workspaceRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Target escaped workspace' }
$cursor = $targetRoot
while ($cursor.Length -ge $workspaceRoot.Length) {
    $item = Get-Item -LiteralPath $cursor -Force
    if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Target ancestor is a reparse point' }
    if ($cursor -eq $workspaceRoot) { break }
    $cursor = Split-Path -Parent $cursor
}
$phaseRoot = Join-Path $workspaceRoot 'validation/integration-20261018/git-repository-profiles-qualified1'
$auditRoot = Join-Path $workspaceRoot 'validation/integration-20261018/git-repository-profiles-disk-recovery1'
New-Item -ItemType Directory -Path $auditRoot -ErrorAction Stop | Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $auditRoot 'preflight.ps1')
$started = (Get-Item -LiteralPath (Join-Path $phaseRoot 'controller.py')).LastWriteTimeUtc.AddSeconds(-2)
$rows = Get-Content -LiteralPath (Join-Path $phaseRoot 'progress.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$manifest = Get-Content -LiteralPath (Join-Path $phaseRoot 'source-before.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$candidates = @()
foreach ($row in $rows) {
    if ($row.name -notlike 'cargo-test-*' -or $row.exitCode -ne 0 -or $row.name -eq 'cargo-test-lib') { continue }
    $group = $row.name.Substring('cargo-test-'.Length)
    if ($group -notmatch '^[a-z0-9_]+$' -or $group -in @('capture_options','session_fixed_tools')) { continue }
    $source = 'native/tests/' + $group + '.rs'
    $expected = $manifest.PSObject.Properties[$source].Value
    if (-not $expected -or (Get-FileHash -LiteralPath (Join-Path $workspaceRoot $source) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expected) { throw 'Test input differs from frozen manifest' }
    $stderr = Get-Content -LiteralPath (Join-Path $phaseRoot ($row.name + '.stderr')) -Raw -Encoding UTF8
    if ($stderr -notmatch 'Compiling yoke-code-intelligence v0\.5\.0') { continue }
    $match = [regex]::Match($stderr, '\((target[\\/]debug[\\/]deps[\\/][^)]+\.exe)\)')
    if (-not $match.Success) { throw 'Successful compiled test executable missing from log' }
    $executable = [IO.Path]::GetFullPath((Join-Path $workspaceRoot $match.Groups[1].Value))
    if ((Split-Path -Parent $executable) -ne $targetRoot -or [IO.Path]::GetFileName($executable) -notmatch ('^' + [regex]::Escape($group) + '-[0-9a-f]{16}\.exe$')) { throw 'Unexpected successful output path' }
    foreach ($path in @($executable, [IO.Path]::ChangeExtension($executable, '.pdb'))) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        $item = Get-Item -LiteralPath $path -Force
        if ($item.LastWriteTimeUtc -lt $started -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
        $candidates += [pscustomobject]@{ path = $item.FullName; group = $group; bytes = $item.Length; sha256 = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant(); modifiedUtc = $item.LastWriteTimeUtc.ToString('o'); successfulOwnedRow = $row.name; exitCode = 0 }
    }
}
$report = [pscustomobject]@{ workspace = $workspaceRoot; target = $targetRoot; phase = $phaseRoot; candidates = @($candidates); bytes = ($candidates | Measure-Object -Property bytes -Sum).Sum; protectedPrefixes = @('capture_options-', 'session_fixed_tools-', 'yoke-'); deletionPerformed = $false }
[IO.File]::WriteAllText((Join-Path $auditRoot 'candidates.json'), ($report | ConvertTo-Json -Depth 12) + "`n", [Text.UTF8Encoding]::new($false))
[pscustomobject]@{ files = $candidates.Count; reclaimableBytes = $report.bytes; sourceInputsChecked = $true; deletionPerformed = $false } | ConvertTo-Json -Compress
