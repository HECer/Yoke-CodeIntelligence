from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/git-repository-profiles-complete2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-hooks-check-'));source=jobroot/'source';source.mkdir();cwd=w;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','DO_NOT_TRACK':'1','PIP_NO_INPUT':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe'
first=w/'validation/integration-20261018/git-repository-profiles-qualified1'
inputs=json.loads((first/'source-before.json').read_bytes());assert len(inputs)==1092 and all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
import re
completed=[]
for file in first.glob('cargo-test-*.stdout'):
 match=re.findall(r'test result: .*? (\d+) passed; (\d+) failed; (\d+) ignored;',file.read_text(encoding='utf8'))
 if match:
  assert len(match)==1 and int(match[0][1])==0;completed.append(file.stem.removeprefix('cargo-test-'))
groups=json.loads((first/'result.json').read_bytes())['testGroups'];pending=[g for g in groups if g not in completed];assert len(completed)==31 and len(pending)==11 and pending[0]=='session_fixed_tools'
(out/'remaining-targets.json').write_bytes((json.dumps({'precedingCompletedGroups':completed,'remainingIntegrationTargets':pending},indent=2)+'\n').encode())
alternate=w/'target/debug/deps/session_fixed_tools-git-profiles-complete-20261023.exe';assert not alternate.exists();complete=False;format_roots=0
try:
 run('cargo-build-session_fixed_tools-alternate',[cargo,'rustc','-p','yoke-code-intelligence','--locked','--profile','test','-j','2','--test','session_fixed_tools','--','-C','extra-filename=-git-profiles-complete-20261023'],timeout=900)
 assert alternate.is_file() and alternate.resolve().parent==(w/'target/debug/deps').resolve()
 run('test-session_fixed_tools-alternate',[alternate,'--test-threads=1'],timeout=900)
 assert all(sha(w/n)==h for n,h in inputs.items())
 for group in pending[1:]:
  assert __import__('shutil').disk_usage(w).free>350_000_000,'Insufficient disk headroom before next owned Cargo'
  run('cargo-test-'+group,[cargo,'test','--locked','-j','2','--test',group,'--','--test-threads=1'],timeout=900)
  assert all(sha(w/n)==h for n,h in inputs.items())
 metadata=json.loads(run('cargo-metadata',[cargo,'metadata','--no-deps','--format-version','1','--locked'],timeout=90));roots=sorted({t['src_path'] for p in metadata['packages'] if p['id'] in metadata['workspace_members'] for t in p['targets']});format_roots=len(roots);assert format_roots==355;(out/'format-roots.json').write_bytes((json.dumps(roots,indent=2)+'\n').encode())
 run('cargo-fmt-all',[cargo,'fmt','--all','--','--check'],expected=None,timeout=120)
 if rows[-1]['exitCode']!=0:assert b'206' in (out/'cargo-fmt-all.stderr').read_bytes()
 for i in range(0,len(roots),20):run(f'rustfmt-roots-{i:03}',[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','--check',*roots[i:i+20]],timeout=120)
 npm=shutil.which('npm.cmd');assert npm
 run('npm-typecheck',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
 run('npm-test',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'formatRoots':format_roots,'cliSha256':sha(w/'target/debug/yoke.exe'),'precedingQualification':'git-repository-profiles-qualified1','remainingIntegrationTargets':pending,'testGroups':groups,'alternateSessionFixedToolsExecutable':str(alternate),'alternateBuildChangesOnlyOutputSuffix':True,'originalFailedSessionFixedToolsOutputReadHashedDeletedOrOverwritten':False,'completedEarlierTestsRepeated':False};(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({key:value for key,value in result.items() if key not in ['testGroups','remainingIntegrationTargets']}),flush=True)
assert complete
