from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/git-repository-scope-pathspec-probe1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-repository-discovery-check-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



root=jobroot/'git-parent';root.mkdir();git=Path(r'C:\Program Files\Git\cmd\git.exe')
complete=False
try:
 run('init',[git,'-C',root,'init','--quiet','--template='])
 for n in ['main.rs','.yoke/cache-one','nested/.YoKe/cache-two','nested/normal.rs']:
  p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'owned')
 first=run('baseline',[git,'-C',root,'ls-files','-t','--stage','--cached','--others','--exclude-standard','-z','--'])
 filtered=run('exclude-owned-state',[git,'-C',root,'ls-files','-t','--stage','--cached','--others','--exclude-standard','-z','--','.',':(exclude,icase,glob)**/.yoke/**'])
 assert filtered==b'? main.rs\0? nested/normal.rs\0',(first,filtered)
 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'fixtureRoot':str(root),'first':first.decode() if 'first' in globals() else None,'filtered':filtered.decode() if 'filtered' in globals() else None},indent=2)+'\n',encoding='utf8')
assert complete
