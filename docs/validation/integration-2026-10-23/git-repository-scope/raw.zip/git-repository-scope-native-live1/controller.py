from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/git-repository-scope-native-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-repository-discovery-check-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))


import sqlite3
native=w/'target/debug/yoke.exe';git=Path(r'C:\Program Files\Git\cmd\git.exe')
old=Path(json.loads((w/'validation/integration-20261018/git-repository-scope-test1/result.json').read_bytes())['preservedPublishedCli'])
prototype=Path(json.loads((w/'validation/integration-20261018/git-repository-scope-recapture-red1/result.json').read_bytes())['preservedQualifiedPrototype'])
assert sha(old)=='286f2aadd70b74eaa8593ec14251f708ca98fcb870cbbaf62f815f33e5cac935'
assert sha(prototype)=='8a2d4a60ad5ea7411152b7444687daf019004615f769c463fbefb84ce6144bc8'
inputs=json.loads((w/'validation/integration-20261018/git-repository-scope-test5/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items())
source=jobroot/("source \u03c0 ' \u0130");source.mkdir();nested=source/'nested \u00df';nested.mkdir();origin=jobroot/'module-origin';origin.mkdir();hooks=jobroot/'empty-hooks';hooks.mkdir()
original=('// '+chr(0x1f30d)+'\r\npub fn entry(){let '+chr(0x3c0)+'=1;}\r\n').encode();after=b'pub fn reviewed_parent(){}\r\n'
(source/'main.rs').write_bytes(original);(nested/'nested.rs').write_bytes(b'pub fn nested(){}\r\n');(origin/'module.rs').write_bytes(b'pub fn module(){}\r\n')
complete=False;applied=False;recovered=False;old_denied=False;verified=False;admin_moved=False;legacy_exact=False;old_rows_exact=False;originals={};current_hash=sha(native)
def args(exe,snapshot=None,writes=False,config=None):
 return [exe,'--root',source,'--timeout','60000','--max-bytes','4000000',*(['--snapshot',snapshot] if snapshot else []),*(['--allow-writes'] if writes else []),*(['--capture-config',config] if config else [])]
def setup(name,root,*values):
 return run(name,[git,'-C',root,'-c','core.hooksPath='+str(hooks),'-c','user.name=Owned Validation','-c','user.email=owned@example.invalid','-c','commit.gpgSign=false',*values])
def sql():
 path=source/'.yoke/index.sqlite'
 with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True) as db:
  names=[row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
  return {name:sorted(db.execute('SELECT * FROM "'+name.replace('"','""')+'"').fetchall(),key=repr) for name in names}
def refuse(name,command,message):
 run(name,command,expected=1,timeout=120)
 assert message in (out/(name+'.stdout')).read_bytes()+(out/(name+'.stderr')).read_bytes(),name
def exact_sources():return all((source/p).read_bytes()==data for p,data in originals.items())
def raw_files(root):
 return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file() and not p.is_symlink()}
try:
 for name,root in [('parent',source),('nested',nested),('origin',origin)]:
  setup('git-init-'+name,root,'init','--quiet','--template=')
  setup('git-add-'+name,root,'add','--','main.rs' if name=='parent' else 'nested.rs' if name=='nested' else 'module.rs')
  setup('git-commit-'+name,root,'commit','--quiet','-m','Owned source')
 setup('git-submodule-local-only',source,'-c','protocol.file.allow=always','submodule','add','--',str(origin),'modules/real')
 assert (source/'modules/real/.git').is_file()
 git_before=raw_files(source/'.git');nested_before=raw_files(nested/'.git')
 run('published-cold-default-index',[*args(old),'index'])
 warm=json.loads(run('published-warm-default-index',[*args(old),'index']))
 repeated=json.loads(run('published-warm-default-repeat',[*args(old),'index']))
 current=json.loads(run('current-warm-default-index',[*args(native),'index']))
 assert warm['data']==repeated['data']==current['data'];legacy_exact=True
 legacy=warm['data']['snapshot']['id'];old_rows={name:rows for name,rows in sql().items() if name in ['snapshots','graphs','records']}
 capture=[*args(native),'git','repository-scope','--capture','--allow-index-read','--trust-git','--git',git,'--follow-submodules','--follow-nested-repositories']
 captured=json.loads(run('capture-explicit-repositories',capture,timeout=120));snapshot=captured['snapshotId']
 assert json.loads(run('repeat-explicit-repositories',capture,timeout=120))['snapshotId']==snapshot
 with sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True) as db:
  manifest=json.loads(db.execute('SELECT value FROM snapshots WHERE id=?',(snapshot,)).fetchone()[0])
  proof=json.loads(db.execute('SELECT value FROM records WHERE kind=? AND id=?',('native_capture_options_v1',snapshot)).fetchone()[0])
 assert proof['options']['repositoryScope']['readOnlyRoots']==['modules/real','nested \u00df']
 assert proof['options']['repositoryScope']['policy']=='exact-host-git-working-files-v1'
 originals={f['path']:(source/f['path']).read_bytes() for f in manifest['files']}
 assert originals['main.rs']==original and 'nested \u00df/nested.rs' in originals and 'modules/real/module.rs' in originals
 config=jobroot/'saved-options.json';config.write_bytes(json.dumps(proof['options'],ensure_ascii=False).encode())
 run('read-new-captured-parent',[*args(native,snapshot),'read','main.rs'])
 before=sql();refuse('published-reader-explicitly-refuses-new-policy',[*args(old,snapshot),'read','main.rs'],b'repositoryScope');assert sql()==before
 run('published-reader-still-reads-old-snapshot',[*args(old,legacy),'read','main.rs'])
 now=sql();assert all(row in now[name] for name,rows_before in old_rows.items() for row in rows_before);old_rows_exact=True
 child='nested \u00df/nested.rs';child_edit=jobroot/'child-edits.json';child_edit.write_bytes(json.dumps([{'kind':'replace','path':child,'expectedHash':hashlib.sha256(originals[child]).hexdigest(),'startByte':0,'endByte':len(originals[child]),'text':'fn refused(){}\r\n'}]).encode())
 before=sql();refuse('captured-child-readonly',[*args(native,snapshot,True),'prepare','--input',child_edit],b'read-only');assert sql()==before and exact_sources()
 before=sql();refuse('current-policy-restricts-old-writable-child',[*args(native,legacy,True,config),'prepare','--input',child_edit],b'repository_capture_current_host_scope_excludes_write');assert sql()==before and exact_sources()
 edits=jobroot/'parent-edits.json';edits.write_bytes(json.dumps([{'kind':'replace','path':'main.rs','expectedHash':hashlib.sha256(original).hexdigest(),'startByte':0,'endByte':len(original),'text':after.decode()}]).encode())
 plan=json.loads(run('prepare-parent-plan',[*args(native,snapshot,True),'prepare','--input',edits]))['data']['plan']['id']
 run('approve-parent-plan',[*args(native),'approve',plan])
 program="from pathlib import Path;assert Path('main.rs').read_bytes()=="+repr(after)
 verification=json.loads(run('explicit-trusted-host-byte-verification',[*args(native),'verify','--plan',plan,'--command',r'C:\Python314\python.exe','--arg','-c','--arg',program,'--trust-project'],timeout=120));assert verification['status']=='passed';verified=True
 # Move only the verified owned administrative directory inside this fixture.
 admin=source/'.git';saved_admin=jobroot/'unavailable-owned-git-admin'
 assert admin.resolve().is_relative_to(jobroot.resolve()) and saved_admin.parent.resolve()==jobroot.resolve() and not saved_admin.exists()
 os.rename(admin,saved_admin);admin_moved=True;assert not admin.exists()
 before=sql();refuse('qualified-prototype-apply-counterexample',[*args(prototype,writes=True),'apply',plan,'--key','prototype-staleness-refusal','--mode','workspace'],b'Repository capture requires explicit host Git inspection');assert sql()==before and exact_sources();old_denied=True
 applied_reply=json.loads(run('apply-parent-without-live-git',[*args(native,writes=True),'apply',plan,'--key','fixed-saved-repository-scope','--mode','workspace'],timeout=120));assert applied_reply['status']=='ok';receipt=applied_reply['data']['receipt'];assert receipt['status']=='applied' and (source/'main.rs').read_bytes()==after;assert all((source/p).read_bytes()==data for p,data in originals.items() if p!='main.rs');applied=True
 run('recover-parent-journal',[*args(native,writes=True),'recover',receipt['id']],timeout=120);assert exact_sources();recovered=True
 assert not admin.exists();assert saved_admin.resolve().is_relative_to(jobroot.resolve()) and admin.parent.resolve()==source.resolve()
 os.rename(saved_admin,admin);admin_moved=False
 assert raw_files(admin)==git_before and raw_files(nested/'.git')==nested_before
 assert sha(native)==current_hash and all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'fixtureRoot':str(jobroot),'nativeSha256':current_hash,'publishedSha256':sha(old),'qualifiedPrototypeSha256':sha(prototype),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'processCalls':len(rows),'oldAndNewWarmDefaultDataExact':legacy_exact,'originalSnapshotGraphControlRowsExact':old_rows_exact,'prototypeCounterexampleObserved':old_denied,'explicitTrustedHostByteVerificationPassed':verified,'reviewedWorkspaceApplyPassed':applied,'journalRestoredOriginalSources':recovered,'gitAdminStillTemporarilyMoved':admin_moved,'projectCodeAutomaticallyExecuted':False,'realModelCalls':0,'systemSettingsChanged':False}
 (out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
assert complete
