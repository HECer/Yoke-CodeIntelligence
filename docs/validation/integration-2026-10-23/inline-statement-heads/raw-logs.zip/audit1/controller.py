from pathlib import Path
import hashlib,json,re,subprocess
w=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root=w/'validation/integration-20261018';q=root/'inline-once-20261023-a66b658-qualified1';live=root/'inline-once-20261023-a66b658-live1';out=root/'inline-once-20261023-a66b658-audit1';out.mkdir(exist_ok=False)
qualified=json.loads((q/'result.json').read_bytes());actual=json.loads((live/'result.json').read_bytes());assert qualified['complete'] and qualified['allJobsEmpty'] and actual['completed'] and actual['allProcessJobsEmpty']
inputs=json.loads((q/'source-before.json').read_bytes());assert len(inputs)==1112 and all(sha(w/n)==h for n,h in inputs.items());assert qualified['nativeCliCurrent']==sha(w/'target/debug/yoke.exe')==actual['cliSha256']
groups={};total=[0,0,0,0]
for name in ['test-compiler_inline_body','test-compiler_inline_predicates','test-compiler_inline','library-all','main-all']:
 s=(q/(name+'.stdout')).read_text();rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out;',s);assert len(rows)==1,(name,rows)
 nums=list(map(int,rows[0]));assert nums[1]==0 and nums[3]==0;groups[name]=nums;total=[a+b for a,b in zip(total,nums)]
assert 'statement_heads_require_the_exact_once_only_original_ast_field ... ok' in (q/'library-all.stdout').read_text()
for name in ['clippy-all-targets','format-complete','debug-build','cli-version','python-all','npm-typecheck','npm-test']:
 assert (q/(name+'.stdout')).is_file() and (q/(name+'.stderr')).is_file()
commands=[json.loads(s) for s in (q/'controller-commands.jsonl').read_text().splitlines()];assert all(r['exitCode']==0 and r['activeAfterCleanup']==0 for r in commands)
changed=set(subprocess.check_output(['git','diff','--name-only']).decode().splitlines());assert changed=={'native/src/compiler_inline_body.rs','native/src/compiler_inline_body_worker.cjs','native/tests/compiler_inline_body.rs'},changed
old_test=subprocess.check_output(['git','show','HEAD:native/tests/compiler_inline_body.rs']).replace(b'\r\n',b'\n');now=(w/'native/tests/compiler_inline_body.rs').read_bytes().replace(b'\r\n',b'\n');assert now.startswith(old_test)
old_core=subprocess.check_output(['git','show','HEAD:native/src/compiler_inline_body.rs']).replace(b'\r\n',b'\n');now_core=(w/'native/src/compiler_inline_body.rs').read_bytes().replace(b'\r\n',b'\n');marker=b'    fn anonymous_return_barriers';assert old_core[old_core.index(marker):]==now_core[now_core.index(marker):]
assert len(actual['cases'])==3 and len(actual['commands'])==27
result={'complete':True,'sourceInputs':len(inputs),'sourceInputsUnchanged':True,'groups':groups,'rustTotals':dict(zip(['passed','failed','ignored','filtered'],total)),'newFunctionsIncluded':5,'nativeCliSha256':qualified['nativeCliCurrent'],'actualCliScenarios':3,'actualCliOwnedParents':27,'allJobsEmpty':True,'allOriginalIntegrationBytesRetainedAsExactPrefix':{'bytes':len(old_test),'sha256':hashlib.sha256(old_test).hexdigest()},'allOriginalBodyUnitBytesRetainedAsExactSuffix':True,'originalFixturesIgnoresDeadlinesProfilesUnchanged':True,'releaseBuiltOrRead':False,'completeWindowsNativeSuite':False,'sourceCommitBeforeFeature':'a66b65881bba3a0948c4da1b3ece8b9a951d0339'}
(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result))
