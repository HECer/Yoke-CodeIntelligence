const events:string[]=[];;function key(){events.push('case');return 2;}export function run(){outer:for(const n of [0,1,2]){
let __ci_inline_1;
{
if (void 0 !== void 0) {
var __ci_inline_4 = function(n:number){events.push('body:'+n);return n*2;};void __ci_inline_4;
var __ci_inline_5 = function(n:number): [typeof n,...unknown[]]{void n;throw void 0;};void __ci_inline_5;
}
const __ci_inline_6 = ((...__ci_inline_7: unknown[])=>__ci_inline_7) as unknown as typeof __ci_inline_5;
const __ci_inline_8 = __ci_inline_6((events.push('arg:'+n),n));
const __ci_inline_3 = __ci_inline_8[0] as (typeof __ci_inline_8)[0];void __ci_inline_3;
{
let n:number = __ci_inline_3;
__ci_inline_2: {
if (void 0 === void 0) {events.push('body:'+n);{ __ci_inline_1 = ( n*2);; break __ci_inline_2; }}
__ci_inline_1 = void 0;
}
}
}
switch(((__ci_inline_1 as unknown as (number)))){case key():events.push('two');continue outer;case 0:events.push('zero');break;default:events.push('other');}
}return events;}export const observed=run();
