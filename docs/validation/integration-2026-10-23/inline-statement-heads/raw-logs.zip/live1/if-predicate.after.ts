// owned é 🦀
const events:string[]=[];;
export function run(input:unknown){{
if (void 0 !== void 0) {
var __ci_inline_4 = function(value:unknown):value is string{events.push('body');try{return typeof value==='string';}finally{events.push('finally');}};void __ci_inline_4;
}
let __ci_inline_5: typeof __ci_inline_4;
let __ci_inline_1: (boolean) | undefined;
{
const __ci_inline_3 = (input);

{
let value:unknown = __ci_inline_3;
__ci_inline_2: {
if (void 0 === void 0) {events.push('body');try{{ __ci_inline_1 = ( typeof value==='string');; break __ci_inline_2; }}finally{events.push('finally');}}
__ci_inline_1 = void 0;
}
}
__ci_inline_5 = ((...__ci_inline_6: unknown[])=>__ci_inline_1) as unknown as typeof __ci_inline_4;
}
if((__ci_inline_5(input)))return input.length;else return 0;
}}export const observed=[run('owned'),run(3),events]; // café 🦀
