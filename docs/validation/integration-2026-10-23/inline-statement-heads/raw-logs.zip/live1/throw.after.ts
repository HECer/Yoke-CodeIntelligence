const events:string[]=[];;export function run(){try{{
let __ci_inline_1;
{
const __ci_inline_3 = ((events.push('arg'),3));

{
let n:number = __ci_inline_3;
__ci_inline_2: {
if (void 0 === void 0) {try{events.push('body');{ __ci_inline_1 = ( 'value:'+n);; break __ci_inline_2; }}finally{events.push('body-finally');}}
__ci_inline_1 = void 0;
}
}
}
throw (((__ci_inline_1 as unknown as (string))));
}}catch(error){events.push(String(error));}finally{events.push('caller-finally');}return events;}export const observed=run();
