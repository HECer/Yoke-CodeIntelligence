from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/rust-analyzer-20261023-41d66b04-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-rust-analyzer-live-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'})
env['PATH']=r'C:\Users\Lomi\.rustup\toolchains\1.94.1-x86_64-pc-windows-msvc\bin'+os.pathsep+r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")]
assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5'
runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)")
exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))
prior=json.loads((w/'validation/integration-20261018/native-format-20261023-f7176df0-qualified1/source-before.json').read_bytes());names=[*prior,'native/docs/native-formatting.md','native/docs/lsp-resource-settings.md','native/docs/server-workspace-settings.md'];inputs={n:sha(w/n) for n in names}
(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());assert len(inputs)==1109
native=w/'target/debug/yoke.exe';native_sha=sha(native);assert native_sha=='aa391752ae06896894e0610e65f7a006ac8757dccf32eb19428882e5cf72f7c7'
provider=Path(r'C:\Users\Lomi\.rustup\toolchains\1.94.1-x86_64-pc-windows-msvc\bin\rust-analyzer.exe');provider_sha=sha(provider);complete=False
try:
 assert shutil.disk_usage(w).free>1_200_000_000
 version=run('actual-rust-analyzer-version',[str(provider),'--version'],timeout=30).decode().strip()
 cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe'
 run('actual-rust-analyzer-gates',[r'C:\Python314\python.exe','-X','utf8',str(w/'scripts/run_native_tests.py'),'--controlled-test-runner','--locked','--offline','--test','live','actual_rust_analyzer','-j','2','--message-format','json','--','--ignored','--test-threads=1'],timeout=600)
 stdout=(out/'actual-rust-analyzer-gates.stdout').read_bytes();assert b'2 passed; 0 failed; 0 ignored' in stdout and b'actual_rust_analyzer_definition_references_and_rename ... ok' in stdout and b'actual_rust_analyzer_mcp_references_bind_immutable_snapshot ... ok' in stdout
 artifacts=[]
 for line in stdout.splitlines():
  try:message=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if message.get('reason')=='compiler-artifact' and message['target']['name']=='live' and message.get('executable') and message.get('profile',{}).get('test'):artifacts.append(Path(message['executable']))
 assert len(artifacts)==1;harness=artifacts[0];assert harness.parent.resolve()==(w/'target/debug/deps').resolve() and harness.name.startswith('live-') and harness.suffix=='.exe'
 harness_evidence={'path':str(harness),'bytes':harness.stat().st_size,'sha256':sha(harness)}
 assert all(sha(w/n)==h for n,h in inputs.items()) and sha(native)==native_sha and sha(provider)==provider_sha
 complete=True
finally:
 result={'complete':complete,'sourceCommit':'41d66b04accd89277ca2ae13a6247f82c0ce286c','nativeCodeCommit':'666656bae3c4e5a0abb9918d943505098266e455','sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'nativeCliSha256':native_sha,'nativeCliUnchanged':sha(native)==native_sha,'provider':{'path':str(provider),'sha256':provider_sha,'version':version if 'version' in globals() else None,'binaryUnchanged':sha(provider)==provider_sha},'harness':harness_evidence if 'harness_evidence' in globals() else None,'passed':2 if complete else None,'selectedOriginalIgnoredGates':True,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'privateHomeAndTempOnly':True,'productionSourceExecutionGranted':False,'settingsOrAll77RuntimeCertification':False,'wholeNativeOrHostedAcceptance':False,'fullStatusComplete':False}
 (out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
