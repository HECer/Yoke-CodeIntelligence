from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/repository-discovery-live3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-repository-discovery-check-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))


native=w/'target/debug/yoke.exe';git=Path(r'C:\Program Files\Git\cmd\git.exe');cmd=Path(env['SystemRoot'])/'System32/cmd.exe'
old=Path(json.loads((w/'validation/integration-20261018/repository-discovery-test1/result.json').read_bytes())['preservedPublishedCli'])
assert sha(old)=='b386daa7cc05cabbddc36cf41ac020d29bf1cecd30db05c64f650e510a3dbf66'
inputs=json.loads((w/'validation/integration-20261018/repository-discovery-qualified1/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items())
prior_live=w/'validation/integration-20261018/repository-discovery-live2'
prior_result=json.loads((prior_live/'result.json').read_bytes());assert prior_result['allJobsEmpty'] and prior_result['processCalls']==11
jobroot=Path(prior_result['fixtureRoot']);root=jobroot/"search \u03c0 \u0130 '";source=jobroot/'source'
replies=[json.loads((prior_live/(n+'.stdout')).read_bytes()) for n in ['published-warm-index','published-warm-index-repeat','current-warm-index']]
for reply in replies:
 size=len(json.dumps(reply,ensure_ascii=False,separators=(',',':')).encode())
 assert reply['metrics']['serializedBytes']==size
 assert reply['metrics']['estimatedTokens']==(size+2)//3
assert replies[0]['data']==replies[1]['data']==replies[2]['data']
def stable(reply):
 reply=json.loads(json.dumps(reply));reply.pop('requestId')
 for name in ['durationMs','serializedBytes','estimatedTokens']:reply['metrics'].pop(name)
 return reply
assert stable(replies[0])==stable(replies[1])==stable(replies[2])
(out/'prior-default-index-audit.json').write_text(json.dumps({'samePreviouslyCompletedCalls':True,'newCalls':0,'exactWarmData':True,'exactEnvelopeExceptRequestIdDurationAndIndependentlyRevalidatedByteMetrics':True,'serializedByteCountsAndTokenFormulaVerified':True,'originalFailedOverstrictComparisonRetained':True},indent=2)+'\n',encoding='utf8')
complete=False;before=None;cli_hash=sha(native)
def snapshot(path):
 result={}
 def visit(directory):
  for child in directory.iterdir():
   relative=str(child.relative_to(path))
   if child.is_symlink() or child.is_junction():result[relative]='reparse';continue
   if child.is_dir():result[relative]='directory';visit(child)
   elif child.is_file():result[relative]=sha(child)
 visit(path);return result
try:
 before=snapshot(jobroot);(out/'fixture-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf8')
 run('published-command-unavailable',[old,'--root',root,'repositories','discover'],expected=2)
 reply=run('discover-owned-real-repositories',[native,'--root',root,'repositories','discover'])
 report=json.loads(reply);(out/'report.json').write_bytes(reply)
 assert [(c['path'],c['marker'],c['parent']) for c in report['candidates']]==[('forged','git-file',None),('linked','git-file',None),('primary','git-directory',None),('primary/nested \u00df','git-directory','primary')]
 assert report['complete'] is False and report['registrationGranted'] is False and report['sourceAccessGranted'] is False
 assert any(o=={'path':'junction','reason':'link-or-reparse-point'} for o in report['omissions'])
 assert any(o=={'path':'marker/.git','reason':'marker-link-or-reparse-point'} for o in report['omissions'])
 assert len([o for o in report['omissions'] if o['reason']=='protected-path'])==3
 assert json.loads(run('repeat-discovery',[native,'--root',root,'repositories','discover']))==report
 selected=json.loads(run('select-nested',[native,'--root',root,'repositories','discover','--select','primary/nested \u00df']))
 assert selected['candidate']==report['candidates'][3] and selected['registrationGranted'] is False
 limited=json.loads(run('depth-zero',[native,'--root',root,'repositories','discover','--max-depth','0']))
 assert limited['candidates']==[] and any(o=={'path':'primary','reason':'depth-limit'} for o in limited['omissions'])
 refusals=[('unknown-select',['--select','missing']),('escape-select',['--select','../outside']),('source-grant',['--allow-writes']),('provider-grant',['--trust-servers']),('config',['--capture-config',jobroot/'missing.json']),('entries',['--max-entries','1']),('directories',['--max-directories','1']),('candidates',['--max-repositories','0']),('output',['--max-bytes','1']),('deadline',['--timeout','0'])]
 for name,flags in refusals:
  run('refuse-'+name,[native,'--root',root,'repositories','discover',*flags],expected=1)
  assert (out/('refuse-'+name+'.stdout')).read_bytes()==b''
 run('refuse-junction-root',[native,'--root',root/'junction','repositories','discover'],expected=1)
 assert (out/'refuse-junction-root.stdout').read_bytes()==b''
 assert snapshot(jobroot)==before
 assert sha(native)==cli_hash and all(sha(w/n)==h for n,h in inputs.items())
 complete=True
finally:
 result={'complete':complete,'fixtureRoot':str(jobroot),'cliSha256':cli_hash,'publishedCliSha256':sha(old),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'fixtureBytesAndDirectoriesUnchanged':snapshot(jobroot)==before if before is not None else False,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'processCalls':len(rows),'systemSettingsChanged':False,'sourceOrGitContentReadByDiscovery':False,'gitInvokedByDiscovery':False,'automaticRegistration':False,'priorOwnedProcessCalls':11,'oldAndNewDefaultWarmDataExact':True,'originalByteMetricsIndependentlyChecked':True}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result),flush=True)
assert complete
