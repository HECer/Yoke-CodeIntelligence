from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/repository-discovery-qualified1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-source-hooks-check-'));source=jobroot/'source';source.mkdir();cwd=w;configroot=jobroot;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','HF_HUB_DISABLE_IMPLICIT_TOKEN':'1','HF_HUB_DISABLE_TELEMETRY':'1','DO_NOT_TRACK':'1','PIP_NO_INPUT':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
run('rustfmt-changed',[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','native/src/repository_discovery.rs','native/tests/repository_discovery.rs'],timeout=120)
prior=json.loads((w/'validation/integration-20261018/repository-discovery-test1/source-before.json').read_bytes());inputs={n:sha(w/n) for n in prior};assert len(inputs)==1082;(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');complete=False;format_roots=0
cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe'
groups=['repository_discovery','repository_discovery_cli','project_session','session_startup_project','ignored_directory_identity','store_read_only']
assert all((w/'native/tests'/f'{g}.rs').is_file() for g in groups)
try:
 run('cargo-clippy',[cargo,'clippy','--workspace','--all-targets','--locked','--keep-going','-j','2','--','-D','warnings'],timeout=900)
 assert all(sha(w/n)==h for n,h in inputs.items())
 run('cargo-build',[cargo,'build','--locked','-j','2','--bin','yoke'],timeout=900)
 run('cargo-test-lib',[cargo,'test','--locked','-j','2','--lib','--','--test-threads=1'],timeout=900)
 for group in groups:
  run('cargo-test-'+group,[cargo,'test','--locked','-j','2','--test',group,'--','--test-threads=1'],timeout=900)
  assert all(sha(w/n)==h for n,h in inputs.items())
 metadata=json.loads(run('cargo-metadata',[cargo,'metadata','--no-deps','--format-version','1','--locked'],timeout=90));roots=sorted({t['src_path'] for p in metadata['packages'] if p['id'] in metadata['workspace_members'] for t in p['targets']});format_roots=len(roots);(out/'format-roots.json').write_text(json.dumps(roots,indent=2)+'\n',encoding='utf8')
 run('cargo-fmt-all',[cargo,'fmt','--all','--','--check'],expected=None,timeout=120)
 if rows[-1]['exitCode']!=0:assert b'206' in (out/'cargo-fmt-all.stderr').read_bytes(), 'Unexpected cargo fmt failure'
 for i in range(0,len(roots),20):run(f'rustfmt-roots-{i:03}',[r'C:\Users\Lomi\.cargo\bin\rustfmt.exe','--edition','2024','--check',*roots[i:i+20]],timeout=120)
 npm=shutil.which('npm.cmd');assert npm
 run('npm-typecheck',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
 run('npm-test',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'frozenInputs':len(inputs),'formatRoots':format_roots,'cliSha256':sha(w/'target/debug/yoke.exe'),'testGroups':groups},indent=2)+'\n',encoding='utf8')
assert complete