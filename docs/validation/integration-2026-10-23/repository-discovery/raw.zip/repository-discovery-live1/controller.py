from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/repository-discovery-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-repository-discovery-check-'));source=jobroot/'source';source.mkdir();configroot=jobroot;cwd=w;client=''
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))


native=w/'target/debug/yoke.exe';git=Path(r'C:\Program Files\Git\cmd\git.exe');cmd=Path(env['SystemRoot'])/'System32/cmd.exe'
old=Path(json.loads((w/'validation/integration-20261018/repository-discovery-test1/result.json').read_bytes())['preservedPublishedCli'])
assert sha(old)=='b386daa7cc05cabbddc36cf41ac020d29bf1cecd30db05c64f650e510a3dbf66'
inputs=json.loads((w/'validation/integration-20261018/repository-discovery-qualified1/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items())
root=jobroot/"search ? ? '";root.mkdir();empty_hooks=jobroot/'empty-hooks';empty_hooks.mkdir()
main=root/'primary';main.mkdir();nested=main/'nested ?';nested.mkdir();linked=root/'linked';outside=jobroot/'outside';outside.mkdir();(outside/'.git').mkdir();(outside/'canary.rs').write_bytes(b'outside canary must stay untouched\r\n')
complete=False;before=None;cli_hash=sha(native)
def snapshot(path):
 result={}
 def visit(directory):
  for child in directory.iterdir():
   relative=str(child.relative_to(path))
   if child.is_symlink() or child.is_junction():result[relative]='reparse';continue
   if child.is_dir():result[relative]='directory';visit(child)
   elif child.is_file():result[relative]=sha(child)
 visit(path);return result
try:
 run('git-init-primary',[git,'-C',main,'init','--quiet','--template='])
 run('git-init-nested',[git,'-C',nested,'init','--quiet','--template='])
 (main/'owned.rs').write_bytes('fn owned(){let ?=1;}\r\n'.encode())
 run('git-stage-owned',[git,'-C',main,'add','--','owned.rs'])
 run('git-commit-owned',[git,'-C',main,'-c','user.name=Owned Validation','-c','user.email=owned@example.invalid','-c','commit.gpgSign=false','-c','core.hooksPath='+str(empty_hooks),'commit','--quiet','-m','Owned inert source'])
 run('git-linked-worktree',[git,'-C',main,'-c','core.hooksPath='+str(empty_hooks),'worktree','add','--detach',linked,'HEAD'])
 forged=root/'forged';forged.mkdir();(forged/'.git').write_bytes(('gitdir: '+str(outside)+'\r\n').encode())
 for name in ['.env.private','node_modules','.yoke']:
  (root/name/'.git').mkdir(parents=True)
 marker=root/'marker';marker.mkdir()
 for name,target in [('junction',outside),('marker/.git',outside/'.git')]:
  link=root/name
  assert all(not any(c in str(p) for c in '&|<>^%!"\r\n') for p in [link,target])
  run('mklink-'+name.replace('/','-'),[cmd,'/d','/c','mklink','/J',link,target])
 (source/'compat.rs').write_bytes('fn compat(){let ?=1;}\r\n'.encode())
 cold=json.loads(run('published-default-index',[old,'--root',source,'index']))
 warm=json.loads(run('published-warm-index',[old,'--root',source,'index']))
 repeat=json.loads(run('published-warm-index-repeat',[old,'--root',source,'index']))
 current=json.loads(run('current-warm-index',[native,'--root',source,'index']))
 assert cold['data']['snapshot']==warm['data']['snapshot']==current['data']['snapshot']
 assert warm['data']==repeat['data']==current['data']
 def stable(reply):
  reply=json.loads(json.dumps(reply));reply.pop('requestId');reply['metrics'].pop('durationMs');return reply
 assert stable(warm)==stable(repeat)==stable(current)
 before=snapshot(jobroot);(out/'fixture-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf8')
 run('published-command-unavailable',[old,'--root',root,'repositories','discover'],expected=2)
 reply=run('discover-owned-real-repositories',[native,'--root',root,'repositories','discover'])
 report=json.loads(reply);(out/'report.json').write_bytes(reply)
 assert [(c['path'],c['marker'],c['parent']) for c in report['candidates']]==[('forged','git-file',None),('linked','git-file',None),('primary','git-directory',None),('primary/nested ?','git-directory','primary')]
 assert report['complete'] is False and report['registrationGranted'] is False and report['sourceAccessGranted'] is False
 assert any(o=={'path':'junction','reason':'link-or-reparse-point'} for o in report['omissions'])
 assert any(o=={'path':'marker/.git','reason':'marker-link-or-reparse-point'} for o in report['omissions'])
 assert len([o for o in report['omissions'] if o['reason']=='protected-path'])==3
 assert json.loads(run('repeat-discovery',[native,'--root',root,'repositories','discover']))==report
 selected=json.loads(run('select-nested',[native,'--root',root,'repositories','discover','--select','primary/nested ?']))
 assert selected['candidate']==report['candidates'][3] and selected['registrationGranted'] is False
 limited=json.loads(run('depth-zero',[native,'--root',root,'repositories','discover','--max-depth','0']))
 assert limited['candidates']==[] and any(o=={'path':'primary','reason':'depth-limit'} for o in limited['omissions'])
 refusals=[('unknown-select',['--select','missing']),('escape-select',['--select','../outside']),('source-grant',['--allow-writes']),('provider-grant',['--trust-servers']),('config',['--capture-config',jobroot/'missing.json']),('entries',['--max-entries','1']),('directories',['--max-directories','1']),('candidates',['--max-repositories','0']),('output',['--max-bytes','1']),('deadline',['--timeout','0'])]
 for name,flags in refusals:
  run('refuse-'+name,[native,'--root',root,'repositories','discover',*flags],expected=1)
  assert (out/('refuse-'+name+'.stdout')).read_bytes()==b''
 run('refuse-junction-root',[native,'--root',root/'junction','repositories','discover'],expected=1)
 assert (out/'refuse-junction-root.stdout').read_bytes()==b''
 assert snapshot(jobroot)==before
 assert sha(native)==cli_hash and all(sha(w/n)==h for n,h in inputs.items())
 complete=True
finally:
 result={'complete':complete,'fixtureRoot':str(jobroot),'cliSha256':cli_hash,'publishedCliSha256':sha(old),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'fixtureBytesAndDirectoriesUnchanged':snapshot(jobroot)==before if before is not None else False,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'processCalls':len(rows),'systemSettingsChanged':False,'sourceOrGitContentReadByDiscovery':False,'gitInvokedByDiscovery':False,'automaticRegistration':False,'oldAndNewWarmDefaultIndexExactExceptRequestIdAndDuration':True}
 (out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result),flush=True)
assert complete
