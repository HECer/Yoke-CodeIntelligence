from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();out=w/'validation/integration-20261018/native-format-20261023-f7176df0-audit1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=os.environ.copy();env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH'];cwd=configroot=w;client=''
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")]
assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
qualified=w/'validation/integration-20261018/native-format-20261023-f7176df0-qualified1';red=w/'validation/integration-20261018/native-format-20261023-f7176df0-red1'
inputs=json.loads((qualified/'source-before.json').read_bytes());complete=False
try:
 assert json.loads((qualified/'result.json').read_bytes())['complete']
 assert all(sha(w/name)==digest for name,digest in inputs.items())
 roots=json.loads((qualified/'format-roots.json').read_bytes());actual={(r['path'],r['edition']) for r in roots};assert len(actual)==361
 verbose_roots=[]
 for line in (red/'cargo-fmt-all-overflow.stdout').read_text(encoding='utf8').splitlines():
  if line.startswith('[') and '] "' in line:
   header,path=line.split('] ',1);edition=header.rsplit('(',1)[1][:-1];raw=json.loads(path)
   if raw.startswith('\\\\?\\'):raw=raw[4:]
   verbose_roots.append((str(Path(raw).resolve()),edition))
 assert set(verbose_roots)==actual and len(verbose_roots)==361
 gate=(qualified/'complete-format-check.stdout').read_text(encoding='utf8');assert gate.count('Native format root ')==361 and 'Native format check: 361 roots, 0 failed' in gate
 assert b'Ran 47 tests' in (qualified/'python-all.stderr').read_bytes() and (qualified/'python-all.stderr').read_bytes().rstrip().endswith(b'OK')
 npm=(qualified/'npm-test.stdout').read_bytes();assert b'pass 260' in npm and b'fail 0' in npm and b'skipped 3' in npm
 python=r'C:\Python314\python.exe';cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe'
 rustfmt=Path(run('rustfmt-selected',[r'C:\Users\Lomi\.cargo\bin\rustup.exe','which','rustfmt'],timeout=30).decode().strip());assert rustfmt.is_file()
 version=run('rustfmt-version',[str(rustfmt),'--version'],timeout=30).decode().strip();assert version.startswith('rustfmt 1.8.0-stable')
 run('cargo-version',[cargo,'--version'],timeout=30)
 run('python-version',[python,'--version'],timeout=30)
 run('node-version',['node','--version'],timeout=30)
 old=json.loads((w/'validation/integration-20261018/resource-settings-20261023-295fe108-qualified3/source-before.json').read_bytes())
 original_test_paths=[name for name in old if name.startswith('scripts/tests/')];assert len(original_test_paths)==3
 assert all(sha(w/name)==old[name] for name in original_test_paths)
 native=w/'target/debug/yoke.exe';native_sha=sha(native);assert native_sha=='aa391752ae06896894e0610e65f7a006ac8757dccf32eb19428882e5cf72f7c7'
 observed_changes=[name for name in old if sha(w/name)!=old[name]]
 # Docs were committed since that historical map; only the workflow changes in this action.
 product_changed=[name for name in observed_changes if not name.startswith('docs/') and name!='native/docs/server-workspace-settings.md']
 assert product_changed==['.github/workflows/rust.yml'],product_changed
 command=[str(rustfmt),*[str(Path(path)) for path,edition in sorted(actual)],'--edition','2024','--check']
 command_units=len(subprocess.list2cmdline(command).encode('utf-16-le'))//2;assert command_units>32767
 result={'complete':True,'formatRoots':361,'canonicalVerboseRootsExactlyEqual':True,'allTargetKindsAndModuleRecursionRetained':True,'canonicalAggregateStillOs206':True,'aggregateCommandUtf16Units':command_units,'newCompleteGatePassed':True,'pythonPassed':47,'originalPythonTestFilesExact':original_test_paths,'typecheckPassed':True,'npmPassed':260,'npmFailed':0,'npmExistingSkipped':3,'sourceInputCount':len(inputs),'sourceInputsUnchanged':True,'nativeCliSha256':native_sha,'nativeProductionAndOriginalTestsUnchanged':True,'formatter':{'version':version,'path':str(rustfmt),'sha256':sha(rustfmt),'RUSTFMTOverridePresent':'RUSTFMT' in os.environ},'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'noRustCompilationOrNativeTestRerun':True,'wholeWindowsOrHostedAcceptance':False,'fullStatusComplete':False}
 (out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode());(out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());complete=True;print(json.dumps(result),flush=True)
finally:
 if not complete:(out/'result.json').write_bytes((json.dumps({'complete':False,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/name)==digest for name,digest in inputs.items())},indent=2)+'\n').encode())
