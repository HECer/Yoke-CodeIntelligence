from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil
w=Path.cwd();phase=sys.argv[1];out=w/('validation/integration-20261018/native-format-20261023-f7176df0-'+phase);out.mkdir(exist_ok=False)
shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cwd=w;configroot=w;client='';env=os.environ.copy();env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text()
runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")]
assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5'
exec(compile(runner,'reviewed Windows Job runner','exec'))
baseline=json.loads((w/'validation/integration-20261018/resource-settings-20261023-295fe108-qualified3/source-before.json').read_bytes())
names=[*baseline,'scripts/tests/test_native_fmt.py']
if phase!='red1':names+=['scripts/native_fmt.py']
inputs={name:sha(w/name) for name in names};(out/'source-before.json').write_bytes((json.dumps(inputs,indent=2)+'\n').encode())
complete=False
try:
 cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';python=r'C:\Python314\python.exe'
 if phase=='red1':
  run('new-format-tests-red',[python,'-X','utf8','-m','unittest','discover','-s','scripts/tests','-p','test_native_fmt.py','-v'],expected=1,timeout=60)
  assert b'FileNotFoundError' in (out/'new-format-tests-red.stderr').read_bytes() and b'native_fmt.py' in (out/'new-format-tests-red.stderr').read_bytes()
  run('cargo-fmt-all-overflow',[cargo,'fmt','--all','--check','--verbose'],expected=1,timeout=120)
  assert b'206' in (out/'cargo-fmt-all-overflow.stderr').read_bytes()
  metadata=json.loads(run('cargo-metadata',[cargo,'metadata','--offline','--locked','--no-deps','--format-version','1'],timeout=90))
  roots=sorted({(t['src_path'],t['edition']) for p in metadata['packages'] for t in p['targets']});assert len(roots)==361
  (out/'format-roots.json').write_bytes((json.dumps(roots,indent=2)+'\n').encode())
 else:
  run('python-all',[python,'-X','utf8','-m','unittest','discover','-s','scripts/tests','-v'],timeout=300)
  roots=json.loads(run('complete-format-list',[python,'-X','utf8','scripts/native_fmt.py','--list'],timeout=120))
  metadata=json.loads(run('cargo-metadata',[cargo,'metadata','--offline','--locked','--no-deps','--format-version','1'],timeout=90))
  expected=sorted({(str(Path(t['src_path']).resolve()),t['edition']) for p in metadata['packages'] for t in p['targets']})
  assert [(r['path'],r['edition']) for r in roots]==expected and len(roots)==361
  (out/'format-roots.json').write_bytes((json.dumps(roots,indent=2)+'\n').encode())
  run('complete-format-check',[python,'-X','utf8','scripts/native_fmt.py','--check'],timeout=600)
  npm=shutil.which('npm.cmd');assert npm
  run('npm-typecheck',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
  run('npm-test',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 assert all(sha(w/name)==digest for name,digest in inputs.items());complete=True
finally:
 result={'complete':complete,'phase':phase,'sourceCommit':'f7176df00c025bd119e9431108948e76e3b30504','sourceInputCount':len(inputs),'sourceInputsUnchanged':all(sha(w/name)==digest for name,digest in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows)}
 (out/'result.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result),flush=True)
