from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/capture-unicode-native-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-capture-unicode-live-'));source=jobroot/('source '+chr(0x130)+' '+chr(0x3c0)+" '");source.mkdir();configroot=jobroot;cwd=jobroot;client=''
qualified=json.loads((w/'validation/integration-20261018/capture-unicode-qualified2/result.json').read_bytes());assert qualified['complete'] and qualified['allJobsEmpty'];native=w/'target/debug/yoke.exe';assert sha(native)==qualified['cliSha256'];old=Path(json.loads((w/'validation/integration-20261018/capture-unicode-preflight1/result.json').read_bytes())['preservedPublishedExecutable']);assert sha(old)=='558409a2aa9151022d0a8fb7e1bee61a686a1460d42c7b39046952e757a5969c';inputs=json.loads((w/'validation/integration-20261018/capture-unicode-qualified2/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8')
sharp=chr(0xdf);long_dir='Ignored long '+sharp+' directory'
for directory in [sharp,'SS',long_dir,chr(0xe9)]:(source/directory).mkdir()
assert (source/sharp).stat().st_ino!=(source/'SS').stat().st_ino
originals={'.gitignore':(sharp+'/\n'+long_dir+'/\n').encode(),sharp+'/hidden.rs':b'fn captured_read_only(){}\r\n','SS/plain.rs':('fn ordinary(){ let '+chr(0x3c0)+' = 1; }\r\n').encode(),long_dir+'/existing.rs':b'fn long_read_only(){}\r\n',chr(0xe9)+'/plain.rs':b'fn unicode_physical(){}\r\n'}
for path,data in originals.items():(source/path).write_bytes(data)
configs={}
for name,value in [('legacy',{'includeIgnoredDirs':[sharp]}),('physical',{'includeIgnoredDirs':[sharp],'ignoredDirectoryIdentity':'windows-physical-v1'}),('restrict-sibling',{'includeIgnoredDirs':['SS'],'ignoredDirectoryIdentity':'windows-physical-v1'}),('restrict-long',{'includeIgnoredDirs':[long_dir],'ignoredDirectoryIdentity':'windows-physical-v1'}),('unicode-exact',{'includeIgnoredDirs':[chr(0xe9)],'ignoredDirectoryIdentity':'windows-physical-v1'}),('unicode-alias',{'includeIgnoredDirs':[chr(0xc9)],'ignoredDirectoryIdentity':'windows-physical-v1'})]:p=jobroot/(name+'.json');p.write_text(json.dumps(value),encoding='utf8');configs[name]=p
edits=jobroot/'edits.json';after=b'fn reviewed_change(){}\r\n';edits.write_text(json.dumps([{'kind':'replace','path':'SS/plain.rs','expectedHash':hashlib.sha256(originals['SS/plain.rs']).hexdigest(),'startByte':0,'endByte':len(originals['SS/plain.rs']),'text':after.decode()}]),encoding='utf8')
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','PYTHONNOUSERSITE':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
def args(executable,config=None,snapshot=None,writes=False):return [executable,'--root',source,'--timeout','60000','--max-bytes','4000000',*(['--capture-config',configs[config]] if config else []),*(['--snapshot',snapshot] if snapshot else []),*(['--allow-writes'] if writes else [])]
def sql():
 c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return ('\n'.join(c.iterdump())+'\n').encode()
 finally:c.close()
def immutable_rows():
 c=sqlite3.connect((source/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return {t:dict(c.execute('SELECT id,value FROM '+t)) for t in ['snapshots','graphs']}|{'records':{kind+'\0'+id:value for kind,id,value in c.execute('SELECT kind,id,value FROM records')}}
 finally:c.close()
def refuse(name,argv,needle=None):
 before=sql();run(name,argv,expected=None,timeout=90);assert rows[-1]['exitCode']!=0 and sql()==before
 if needle:assert needle in (out/(name+'.stdout')).read_bytes()+(out/(name+'.stderr')).read_bytes()
def exact_sources():return all((source/p).read_bytes()==data for p,data in originals.items())
complete=False;applied=False;recovered=False;alias='';old_rows_exact=False;verification_explicit=False
try:
 default=json.loads(run('published-default-index',[*args(old),'index'],timeout=90))['data']['snapshot']['id']
 control=json.loads(run('published-default-prepare',[*args(old,snapshot=default,writes=True),'prepare','--input',edits],timeout=90));assert control['status']=='ok'
 legacy=json.loads(run('published-legacy-index',[*args(old,'legacy'),'index'],timeout=90))['data']['snapshot']['id'];old_rows=immutable_rows();current_default=json.loads(run('current-default-identity',[*args(native),'index'],timeout=90))['data']['snapshot']['id'];assert current_default==default
 current_legacy=json.loads(run('current-legacy-identity',[*args(native,'legacy'),'index'],timeout=90))['data']['snapshot']['id'];assert current_legacy==legacy
 refuse('published-legacy-ascii-sibling-refused',[*args(old,'legacy',legacy,True),'prepare','--input',edits],b'Captured host scope is read-only')
 refuse('current-physical-cannot-reinterpret-old-legacy',[*args(native,'physical',legacy,True),'prepare','--input',edits],b'Captured host scope is read-only');assert exact_sources()
 strict=json.loads(run('current-physical-index',[*args(native,'physical'),'index'],timeout=90))['data']['snapshot']['id'];assert strict!=legacy
 now=immutable_rows();assert all(all(now[t].get(id)==value for id,value in table.items()) for t,table in old_rows.items());old_rows_exact=True
 run('published-reader-still-reads-old-snapshot',[*args(old,snapshot=legacy),'read','SS/plain.rs'],timeout=90)
 refuse('published-reader-refuses-new-policy',[*args(old,snapshot=strict),'read','SS/plain.rs'],b'ignoredDirectoryIdentity')
 alias_api=k.GetShortPathNameW;alias_api.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_uint32];alias_api.restype=ctypes.c_uint32;buffer=ctypes.create_unicode_buffer(32768);length=alias_api(str(source/long_dir),buffer,len(buffer));assert 0<length<len(buffer);alias=Path(buffer.value).name;assert alias!=long_dir
 alias_edits=jobroot/'alias-edits.json';alias_edits.write_text(json.dumps([{'kind':'create','path':alias+'/new.rs','text':'fn denied_alias(){}\n'}]),encoding='utf8');refuse('current-host-physical-real-dos-alias-refused',[*args(native,'restrict-long',default,True),'prepare','--input',alias_edits],b'ignored_directory_is_read_only_in_current_host_selection');assert not (source/long_dir/'new.rs').exists()
 unicode_exact=json.loads(run('current-unicode-physical-index',[*args(native,'unicode-exact'),'index'],timeout=90))['data']['snapshot']['id'];unicode_alias=json.loads(run('current-unicode-alias-index',[*args(native,'unicode-alias'),'index'],timeout=90))['data']['snapshot']['id'];assert unicode_exact==unicode_alias
 unicode_edits=jobroot/'unicode-edits.json';raw=originals[chr(0xe9)+'/plain.rs'];unicode_edits.write_text(json.dumps([{'kind':'replace','path':chr(0xe9)+'/plain.rs','expectedHash':hashlib.sha256(raw).hexdigest(),'startByte':0,'endByte':len(raw),'text':'fn denied_alias(){}\r\n'}]),encoding='utf8');refuse('current-unicode-alias-restricts-old-writable-snapshot',[*args(native,'unicode-alias',default,True),'prepare','--input',unicode_edits],b'ignored_directory_is_read_only_in_current_host_selection')
 plan=json.loads(run('current-physical-prepare-ascii-sibling',[*args(native,'physical',strict,True),'prepare','--input',edits],timeout=90))['data']['plan']['id'];run('approve-owned-plan',[*args(native,'physical'),'approve',plan],timeout=90)
 program="from pathlib import Path;assert Path('SS/plain.rs').read_bytes()=="+repr(after)
 verification=json.loads(run('verify-explicit-owned-byte-check',[*args(native,'physical'),'verify','--plan',plan,'--command',r'C:\Python314\python.exe','--arg','-c','--arg',program,'--trust-project'],timeout=120));assert verification['status']=='passed';verification_explicit=True
 refuse('current-host-selection-blocks-approved-verified-plan',[*args(native,'restrict-sibling',writes=True),'apply',plan,'--key','owned-case-blocked','--mode','workspace'],b'ignored_directory_is_read_only_in_current_host_selection');assert exact_sources()
 applied_output=json.loads(run('apply-reviewed-owned-plan',[*args(native,'physical',writes=True),'apply',plan,'--key','owned-case-applied','--mode','workspace'],timeout=120));assert applied_output['status']=='ok';receipt=applied_output['data']['receipt'];assert receipt['status']=='applied' and (source/'SS/plain.rs').read_bytes()==after;assert all((source/p).read_bytes()==b for p,b in originals.items() if p!='SS/plain.rs');applied=True
 run('recover-owned-plan',[*args(native,'physical',writes=True),'recover',receipt['id']],timeout=120);assert exact_sources();recovered=True
 outside=jobroot/'outside-junction-target';outside.mkdir();canary=b'fn outside_junction_canary(){}\r\n';(outside/'outside.rs').write_bytes(canary);link=source/'junction-fixture';assert outside.resolve().is_relative_to(jobroot.resolve()) and link.parent.resolve()==source.resolve()
 for path in [link,outside]:assert not any(c in str(path) for c in '&|<>^%!\r\n"')
 run('create-owned-junction',[env['SystemRoot']+'\\System32\\cmd.exe','/d','/c','mklink','/J',link,outside],timeout=30);assert link.is_dir()
 junction_config=jobroot/'junction.json';junction_config.write_text(json.dumps({'includeIgnoredDirs':['junction-fixture'],'ignoredDirectoryIdentity':'windows-physical-v1'}),encoding='utf8');configs['junction']=junction_config
 refuse('junction-capture-selection-refused',[*args(native,'junction'),'index'],b'reparse');refuse('junction-current-write-selection-refused',[*args(native,'junction',default,True),'prepare','--input',edits],b'reparse');assert (outside/'outside.rs').read_bytes()==canary and not (source/'.yoke/blobs'/hashlib.sha256(canary).hexdigest()).exists()
 current=immutable_rows();assert all(all(current[t].get(id)==value for id,value in table.items()) for t,table in old_rows.items());assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'fixtureRoot':str(jobroot),'nativeSha256':sha(native),'publishedCliSha256':sha(old),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'oldCaptureGraphAndControlRowsExact':old_rows_exact,'physicallyDistinctSharpSAndAsciiSibling':True,'realDosAlias':alias,'explicitTrustedHostByteVerificationPassed':verification_explicit,'reviewedWorkspaceApplyPassed':applied,'journalRecoveryRestoredOriginalSourceBytes':recovered,'realModelCalls':0,'projectCodeImportedOrExecutedByDefault':False},indent=2)+'\n',encoding='utf8')
assert complete