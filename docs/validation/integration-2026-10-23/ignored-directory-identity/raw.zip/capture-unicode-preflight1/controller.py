from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/capture-unicode-preflight1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-owned-capture-unicode-'));source=jobroot/'initial';source.mkdir();configroot=jobroot;cwd=jobroot;client='';native=w/'target/debug/yoke.exe';assert sha(native)=='558409a2aa9151022d0a8fb7e1bee61a686a1460d42c7b39046952e757a5969c';old=jobroot/'published-yoke.exe';shutil.copyfile(native,old);assert sha(old)==sha(native)
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))
prior=json.loads((w/'validation/integration-20261018/source-hooks-qualified1/source-before.json').read_bytes());prior['native/docs/claude-source-hooks.md']='';inputs={n:sha(w/n) for n in prior};assert len(inputs)==1076;(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf8');complete=False;observed=[]
def sql(root):
 c=sqlite3.connect((root/'.yoke/index.sqlite').as_uri()+'?mode=ro',uri=True)
 try:return '\n'.join(c.iterdump())+'\n'
 finally:c.close()
try:
 for selected in [False,True]:
  case=jobroot/('legacy-selected' if selected else 'default-control');case.mkdir();source=case/'source';source.mkdir();sharp=source/chr(0xdf);ordinary=source/'SS';sharp.mkdir();ordinary.mkdir();assert sharp.stat().st_ino!=ordinary.stat().st_ino
  (source/'.gitignore').write_bytes((chr(0xdf)+'/\n').encode());(sharp/'hidden.rs').write_bytes(b'fn captured_read_only(){}\r\n');original=('pub fn public(){ let '+chr(0x3c0)+' = 1; }\r\n').encode();file=ordinary/'plain.rs';file.write_bytes(original);before={str(p.relative_to(source)):sha(p) for p in source.rglob('*') if p.is_file()};config=case/'capture.json';config.write_text(json.dumps({'includeIgnoredDirs':[chr(0xdf)]}),encoding='utf8');edits=case/'edit.json';edits.write_text(json.dumps([{'kind':'replace','path':'SS/plain.rs','expectedHash':hashlib.sha256(original).hexdigest(),'startByte':0,'endByte':len(original),'text':'pub fn reviewed_change(){}\r\n'}]),encoding='utf8');prefix=[old,'--root',source,'--timeout','60000','--max-bytes','4000000',*(['--capture-config',config] if selected else [])]
  run(('legacy' if selected else 'default')+'-index',[*prefix,'index'],timeout=90);baseline=sql(source);run(('legacy' if selected else 'default')+'-prepare-unselected-ascii-sibling',[*prefix,'--allow-writes','prepare','--input',edits],expected=None,timeout=90)
  if selected:
   assert rows[-1]['exitCode']!=0;error=(out/'legacy-prepare-unselected-ascii-sibling.stdout').read_bytes()+(out/'legacy-prepare-unselected-ascii-sibling.stderr').read_bytes();assert b'Captured host scope is read-only' in error;assert sql(source)==baseline
  else:assert rows[-1]['exitCode']==0
  assert all(sha(source/p)==h for p,h in before.items());observed.append({'selectedIgnoredDirectory':chr(0xdf) if selected else None,'ordinarySibling':'SS','physicallyDistinctDirectories':True,'prepareExitCode':rows[-1]['exitCode'],'sourceBytesUnchanged':True,'refusalSqlExact':sql(source)==baseline if selected else None})
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'fixtureRoot':str(jobroot),'preservedPublishedExecutable':str(old),'publishedCliSha256':sha(old),'counterexampleReproduced':complete,'observations':observed,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'productionSourceEdited':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
assert complete
print(json.dumps(result,indent=2))