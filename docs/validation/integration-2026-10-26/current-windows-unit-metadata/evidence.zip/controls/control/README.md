# Prepared guarded validation controllers

Prepared only. No controller, Cargo command, build, native image, test, worker,
Node command, or PowerShell fixture was executed by the preparation agent.
The parent must review all new source, including the private extracted function,
finish its source integration and commit it before invoking these controllers.
Preparation deliberately does not require a clean working tree. Invocation does.

`validation_controller.py` is the single fixed-choice entrypoint. It accepts only
`build`, `test`, and `clippy`; there is no arbitrary command, image, argument,
source revision default, profile, feature, ignored-test, or name-filter option.
Use Python 3.11+ on 64-bit Windows, from the repository root. Replace the
placeholder below with the exact future integration commit reviewed by the host.
These examples are instructions, not executed evidence.

```powershell
$sourceCommit = '<40-lowercase-hex-integration-commit>'
$controller = 'validation/integration-20261025/platform-repairs/control/validation_controller.py'
python $controller build --target lib --source-commit $sourceCommit --run-id build-lib-reviewed
python $controller test --target lib --source-commit $sourceCommit --run-id test-lib-reviewed --producer-run-id build-lib-reviewed
python $controller build --target repository_discovery --source-commit $sourceCommit --run-id build-repository-discovery-reviewed
python $controller test --target repository_discovery --source-commit $sourceCommit --run-id test-repository-discovery-reviewed --producer-run-id build-repository-discovery-reviewed
python $controller build --target github_app_ingress --source-commit $sourceCommit --run-id build-github-app-ingress-reviewed
python $controller test --target github_app_ingress --source-commit $sourceCommit --run-id test-github-app-ingress-reviewed --producer-run-id build-github-app-ingress-reviewed
python $controller build --target process --source-commit $sourceCommit --run-id build-process-reviewed
python $controller test --target process --source-commit $sourceCommit --run-id test-process-reviewed --producer-run-id build-process-reviewed
python $controller build --target agent_repl --source-commit $sourceCommit --run-id build-agent-repl-reviewed
python $controller test --target agent_repl --source-commit $sourceCommit --run-id test-agent-repl-reviewed --producer-run-id build-agent-repl-reviewed
# Optional separate metadata-only scope; no fixture/test/image execution.
python $controller clippy --source-commit $sourceCommit --run-id clippy-reviewed
```

Run commands one at a time and inspect each result before invoking a dependent
test. A failed build/controller is never a valid producer. Run IDs create new
directories only, under `platform-repairs/runs/`; a retry requires a new run ID.
No files or build caches are deleted, compressed, invalidated, or adopted. Cached
`fresh:true` artifacts refuse admission; the controller never touches a source
mtime to manufacture freshness. A fresh build may need an actual source change
committed by the parent. Do not weaken freshness to reuse an old artifact.

The exact build commands are `cargo test --lib --no-run --locked -j1
--message-format=json` and `cargo test --test <selected enum> --no-run --locked
-j1 --message-format=json`. Cargo is the existing fixed
`C:\Users\Lomi\.cargo\bin\cargo.exe`. The optional Clippy command is `cargo
clippy --workspace --all-targets --locked --keep-going -j2 --message-format=json
-- -D warnings`. Original default Cargo profiles/features apply. Ambient compiler,
target, runner and profile overrides refuse; any discovered Cargo config refuses
without reading global config contents. No Cargo metadata/version probe, build,
fixture or other uncontrolled subprocess is used for preflight. All read-only Git
children also use the suspended/private-Job lifecycle guard.

All builds and library runs retain the archived 1,200-second ceiling. `process`
retains 120 seconds and `agent_repl` retains 300 seconds. No archived target-specific
budget was found for the newly selected discovery/ingress groups; each receives
the shortest existing integration ceiling, 120 seconds, explicitly as a new
conservative scope. Clippy retains the earlier 1,200-second metadata ceiling.
The 16,000,000-byte combined stream cap is enforced by bounded pipe readers;
Git observations use 30 seconds and a stricter 2,000,000-byte cap. Disk admission
is at least 1,200,000,000 free bytes on C:, with a 500,000,000-byte running reserve.
Stdin is closed and only fixed argument arrays are passed directly to CreateProcess.
The root starts suspended, joins an unnamed kill-on-close private Job, then resumes.
Original one-second drain observations retain active counts and member metadata
before forced cleanup. There is a two-second total cleanup budget, and both root
exit and zero accounting must be proved. Unknown/query-denied members remain
unknown. Cargo/root exit zero with a nonempty original-drain tree is incomplete.
Only the just-created suspended root (if assignment failed) or its private Job
can be terminated. No PID-wide cleanup or recursive deletion exists.

The selected-input map includes every tracked `Cargo.toml`/`Cargo.lock`, every
tracked file in `native/` and `scripts/`, `.github/workflows/rust.yml`, and tracked
Cargo/toolchain configuration. It records exact working-file SHA-256 bytes before
and after with HEAD and clean tracked status checked independently. Private
controls/helper bytes have a separate before/after map. The helper is the
`windows_api()` function extracted from committed
`562357d331d95dfb022e53f9e06f0cee73d7792a:scripts/host_powershell_probe.py`, not the
concurrently edited working probe. It retains the original four-item ABI.
`review-manifest.json` records the exact blob/function/helper hashes.
The directory-local `.gitattributes` retains LF bytes for these private controls;
the helper pin is byte-exact and never silently normalizes a changed checkout.
Successful runs also retain final source/control maps after image checks, with
identical bytes required. Each selected source pass is bounded to 10,000 files,
512,000,000 total bytes, 64,000,000 bytes per file and 120 seconds of hashing.
Failed command paths attempt separate byte-only after maps without launching
additional children after uncertain cleanup; those maps do not prove clean HEAD.

Only a completed matching build, unchanged inputs, successful Cargo
`build-finished`, and exactly one selected `fresh:false` test compiler artifact
can reach image selection. Selection checks its actual target source and requires
the exact `target/debug/deps` parent plus `<target>-<16 lowercase hex>.exe`.
For the complete library group that name is `yoke-<16 lowercase hex>.exe` and is
admitted only from a lib test artifact. Every ancestor must be ordinary and
non-reparse; the selected file must be regular and single-link. A read pin denies
writers/deletion through hashing, execution, cleanup and recheck, with filesystem
identity and SHA-256 retained. The build pins/hashes its selected fresh image;
the test requires the same image record, replays the producer's raw Cargo log,
and holds read pins on its exact producer evidence. Execution is the selected
image with only `--test-threads=1 --nocapture`, preserving original ignored tests.
The parent libtest summary, actual owner exit and complete containment are all
required. Results and counts are per run; earlier evidence is never merged.

Ordinary Yoke/main byproducts, root release images, plain `deps/yoke.exe`,
`capture_options-784339a4da3fe379.exe/.pdb`, and
`session_fixed_tools-0671ac4d8f474009.exe/.pdb` are never opened, hashed or selected.
The general source/receipt byte reader explicitly refuses every EXE/PDB suffix.
Clippy parses JSON metadata only and never admits any image or executes fixtures.

Remaining qualifications: the input map is a selected tracked source map, not
every dependency, external tool, cache or environment input. Actual tool versions
are not probed by this controller. External Cargo invocations must be excluded
by the host; the local named mutex coordinates only these controllers. Reparse
and identity rechecks are not protection against a hostile equal-privilege host.
No live Windows lifecycle, failure injection, cap/disk exhaustion, fresh producer,
native compilation, fixture behavior, or group execution is certified by AST
parsing. All such checks remain unrun until the parent reviews and invokes them.
Receipts are UTF-8 JSON and console JSON uses `ensure_ascii=True`.
