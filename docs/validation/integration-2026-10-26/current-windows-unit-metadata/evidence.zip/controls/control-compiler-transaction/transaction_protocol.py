"""Closed compiler transaction protocol; importing this file starts no process."""
from contextlib import ExitStack
import ctypes as c
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time


ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
CONTROL = ROOT / "validation/integration-20261025/platform-repairs/control-compiler-transaction"
ORIGINAL = CONTROL.parent / "control-cli"
RUNS = CONTROL.parent / "runs-compiler-transaction"
OWNER = "integration-20261026-compiler-transaction-v2"
SCHEMA = 2
BUILD_SECONDS = 3600
VERSION_SECONDS = 30
QUIESCENCE_SECONDS = 60
OUTER_DRAIN_SECONDS = 1
CLEANUP_SECONDS = 2
START_FREE = 4_000_000_000
IMAGE_FREE = 1_200_000_000
RUN_FREE = 500_000_000
MAX_LOG = 16_000_000
MAX_IMAGE = 512_000_000
NANO = 1_000_000_000
IMAGE_NAME = "owned-release-cli.exe"
CARGO = Path(r"C:\Users\Lomi\.cargo\bin\cargo.exe")
RUNTIME_SHA = "00e02c00c22eb540eca9eb971b533bcc52566015e3a3963ccef76c7320401513"
ORIGINAL_PINS = {
    "cli_controller.py": "d6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582",
    "base_controller.py": "a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7",
    "private_windows_api.py": "d9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500",
    "test_metadata_pin.py": "6f555a7b29a85f17c404cba57474c682ae84adf28915ac8b1f10db73b9041aca",
    "README.md": "1bbe94b3ac00dff9d1116ab8ccc8aadce545b14dd536888644d1cb92eac3cea6",
    "review-manifest.json": "8dd48b1595220464fc638d458a6f8dd7b19f55454c35c0bda7eb7cea255b94f8",
    ".gitattributes": "a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9",
}
SPEC_KEYS = {"owner", "schema", "role", "sourceCommit", "runId", "outerJobName",
             "startedNs", "deadlineNs", "quiescenceSeconds", "logCapBytes", "reserveBytes",
             "cargoCommand", "sourceDigest", "originalControlsDigest", "transactionControlsDigest"}
REQUEST_KEYS = {"owner", "schema", "mode", "runId", "sourceCommit", "producerRunId", "command",
                "imagePath", "selectedImageAbsentBeforeCommand", "freshPrivateOutputRole",
                "startAdmissionBytes", "runtimeReserveBytes", "deadlineSeconds", "outerDrainSeconds",
                "cleanupSeconds", "sourceDigest", "originalControlsDigest", "transactionControlsDigest",
                "preparationInventoryIsSeparate"}
INNER_KEYS = {"owner", "schema", "role", "runId", "sourceCommit", "outerJobName",
              "outerMembershipBeforeCargo", "command", "startedNs", "deadlineNs",
              "quiescenceSeconds", "captureOwner", "logCapBytes", "reserveBytes",
              "innerKillOnClose", "breakawayAllowed", "innerInitiallyEmpty", "pid",
              "startedSuspended", "cargoInOuterBeforeInner", "assignedBeforeResume",
              "membershipConfirmedBeforeResume", "resumePreviousSuspendCount", "exitCode",
              "rootExited", "cargoExitObservedNs", "activeAtCargoExit", "quiescenceDeadlineNs",
              "naturalEmptyNs", "activeBeforeClose", "allMembersExitedNaturally", "minimumFreeObserved",
              "abortAuthority", "innerForcedTermination", "cleanupWaitSeconds", "handleCloseErrors",
              "imageAbsentBeforeCargo", "completed", "failureCode"}
RESULT_KEYS = {"owner", "schema", "mode", "runId", "sourceCommit", "completed", "inputsUnchanged",
               "protectedMetadataUnchanged", "nativeImageReadAttempted", "nativeImageRead",
               "selectedImage", "selectedArtifact", "observedVersion", "errorCode",
               "releaseQualification", "vsixQualification", "qualification", "freeAfter"}
OUTER_KEYS = {"command", "deadlineSeconds", "logCapBytes", "stdinClosed", "startedSuspended",
              "assignedBeforeResume", "completed", "treeExitedBeforeCleanup", "minimumFreeObserved",
              "cleanupErrors", "streamEOF", "readerErrors", "startedMonotonicNs", "absoluteDeadlineNs",
              "jobName", "namedJobCreatedNew", "pid", "resumePreviousSuspendCount", "exitCode",
              "rootObservedMonotonicNs", "membersAtRootObservation", "rootExitedAtObservation",
              "activeAtRootObservation", "originalDrainSeconds", "activeBeforeCleanup",
              "membersAfterOriginalDrain", "treeObservedMonotonicNs", "cleanupSeconds", "activeAfterCleanup",
              "rootExitedAfterCleanup", "elapsedSeconds", "capturedLogBytes", "outputExceeded", "cleanupUnproven"}


class Refusal(RuntimeError):
    """Public errors are closed codes; captured compiler logs remain private."""
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def need(value, code="protocol-refusal"):
    if not value:
        raise Refusal(code)


def closed(value, keys):
    need(type(value) is dict and set(value) == keys)


def integer(value, minimum=0, maximum=(1 << 63) - 1):
    return type(value) is int and minimum <= value <= maximum


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def run_name(value):
    need(type(value) is str and re.fullmatch(r"[a-z][a-z0-9-]{0,95}", value))
    return value


def commit_name(value):
    need(type(value) is str and re.fullmatch(r"[0-9a-f]{40}", value))
    return value


def job_name(value):
    need(type(value) is str and re.fullmatch(r"Local\\YokeCompilerTransaction-[0-9a-f]{64}", value))
    return value


def image_path(run_id):
    return RUNS / run_name(run_id) / IMAGE_NAME


def cargo_command(out):
    need(out.parent == RUNS and out.name == run_name(out.name))
    return [str(CARGO), "rustc", "--package", "yoke-code-intelligence", "--bin", "yoke",
            "--release", "--locked", "--offline", "-j2", "--message-format=json", "--",
            "-o", str(out / IMAGE_NAME)]


def worker_command(run_id):
    return [str(Path(sys.executable).absolute()), "-I", str(CONTROL / "compiler_transaction_worker.py"),
            str(RUNS / run_name(run_id) / "worker-spec.json")]


def source_bytes(path, expected):
    need(path.suffix == ".py", "source-role")
    for ancestor in reversed(path.parents):
        info = ancestor.lstat()
        need(stat.S_ISDIR(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400,
             "source-route")
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
         and not getattr(before, "st_file_attributes", 0) & 0x400
         and 0 < before.st_size <= 1_000_000, "source-role")
    data = path.read_bytes()
    after = path.lstat()
    need((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_nlink) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_nlink)
         and hashlib.sha256(data).hexdigest() == expected, "source-pin")
    return data


def load_runtime():
    path = CONTROL / "transaction_runtime.py"
    data = source_bytes(path, RUNTIME_SHA)
    namespace = {"__name__": "reviewed_compiler_transaction_runtime", "__file__": str(path)}
    exec(compile(data, str(path), "exec"), namespace)
    need(namespace["ROOT"] == ROOT and namespace["RUNS"] == RUNS
         and namespace["OWNER"] == OWNER and namespace["SCHEMA"] == SCHEMA, "runtime-binding")
    return namespace


def load_original():
    path = ORIGINAL / "cli_controller.py"
    data = source_bytes(path, ORIGINAL_PINS["cli_controller.py"])
    namespace = {"__name__": "immutable_original_release_cli", "__file__": str(path)}
    exec(compile(data, str(path), "exec"), namespace)
    need(namespace["ROOT"] == ROOT, "original-binding")
    return namespace


def original_map(g):
    values = {name: g["source_digest"](ORIGINAL / name, 1_000_000) for name in ORIGINAL_PINS}
    need(all(values[name]["sha256"] == sha for name, sha in ORIGINAL_PINS.items()), "original-drift")
    return values


def pin_control_files(g, api, stack):
    pins = {}
    for folder, names, prefix in ((ORIGINAL, ORIGINAL_PINS, "original/"),
                                   (CONTROL, g["CONTROL_NAMES"], "transaction/")):
        for name in names:
            pins[prefix + name] = stack.enter_context(g["ReadPin"](api, folder / name, 1_000_000))
    return pins


def pin_rechecks(pins):
    return {name: pin.recheck() for name, pin in pins.items()}


def make_spec(run_id, commit, outer_name, started_ns, sources, originals, controls):
    return {"owner": OWNER, "schema": SCHEMA, "role": "compiler-worker", "sourceCommit": commit,
            "runId": run_id, "outerJobName": outer_name, "startedNs": started_ns,
            "deadlineNs": started_ns + BUILD_SECONDS * NANO, "quiescenceSeconds": QUIESCENCE_SECONDS,
            "logCapBytes": MAX_LOG, "reserveBytes": RUN_FREE, "cargoCommand": cargo_command(RUNS / run_id),
            "sourceDigest": digest(sources), "originalControlsDigest": digest(originals),
            "transactionControlsDigest": digest(controls)}


def validate_spec(spec, *, now_ns=None):
    closed(spec, SPEC_KEYS)
    need(spec["owner"] == OWNER and type(spec["schema"]) is int and spec["schema"] == SCHEMA
         and spec["role"] == "compiler-worker")
    run_name(spec["runId"]); commit_name(spec["sourceCommit"]); job_name(spec["outerJobName"])
    need(integer(spec["startedNs"], 1) and integer(spec["deadlineNs"], 1)
         and spec["deadlineNs"] - spec["startedNs"] == BUILD_SECONDS * NANO)
    need(type(spec["quiescenceSeconds"]) is int and spec["quiescenceSeconds"] == QUIESCENCE_SECONDS
         and type(spec["logCapBytes"]) is int and spec["logCapBytes"] == MAX_LOG
         and type(spec["reserveBytes"]) is int and spec["reserveBytes"] == RUN_FREE)
    need(spec["cargoCommand"] == cargo_command(RUNS / spec["runId"]))
    need(all(type(spec[key]) is str and re.fullmatch(r"[0-9a-f]{64}", spec[key])
             for key in ("sourceDigest", "originalControlsDigest", "transactionControlsDigest")))
    if now_ns is not None:
        need(integer(now_ns) and spec["startedNs"] <= now_ns < spec["deadlineNs"], "build-deadline")
    return spec


def request_record(mode, run_id, commit, producer_run_id, sources, originals, controls):
    need(mode in ("build", "version")); run_name(run_id); commit_name(commit)
    need((mode == "version") == (producer_run_id is not None))
    selected_run = run_name(producer_run_id) if mode == "version" else run_id
    need(mode == "build" or selected_run != run_id)
    return {"owner": OWNER, "schema": SCHEMA, "mode": mode, "runId": run_id,
            "sourceCommit": commit, "producerRunId": producer_run_id,
            "command": worker_command(run_id) if mode == "build" else [str(image_path(selected_run)), "--version"],
            "imagePath": str(image_path(selected_run)), "selectedImageAbsentBeforeCommand": mode == "build",
            "freshPrivateOutputRole": mode == "build", "startAdmissionBytes": START_FREE if mode == "build" else IMAGE_FREE,
            "runtimeReserveBytes": RUN_FREE, "deadlineSeconds": BUILD_SECONDS if mode == "build" else VERSION_SECONDS,
            "outerDrainSeconds": OUTER_DRAIN_SECONDS, "cleanupSeconds": CLEANUP_SECONDS,
            "sourceDigest": digest(sources), "originalControlsDigest": digest(originals),
            "transactionControlsDigest": digest(controls), "preparationInventoryIsSeparate": True}


def validate_request(request, expected):
    closed(request, REQUEST_KEYS)
    need(request == expected and type(request["schema"]) is int
         and all(type(request[key]) is int for key in ("startAdmissionBytes", "runtimeReserveBytes",
                  "deadlineSeconds", "outerDrainSeconds", "cleanupSeconds")))
    need(all(type(request[key]) is bool for key in ("selectedImageAbsentBeforeCommand",
                                                  "freshPrivateOutputRole", "preparationInventoryIsSeparate")))


def validate_inner(row, spec):
    closed(row, INNER_KEYS); validate_spec(spec)
    need(row["owner"] == OWNER and type(row["schema"]) is int and row["schema"] == SCHEMA
         and row["role"] == "compiler-inner" and row["runId"] == spec["runId"]
         and row["sourceCommit"] == spec["sourceCommit"] and row["outerJobName"] == spec["outerJobName"]
         and row["command"] == spec["cargoCommand"])
    need(all(row[key] is True for key in ("outerMembershipBeforeCargo", "innerInitiallyEmpty", "startedSuspended",
         "cargoInOuterBeforeInner", "assignedBeforeResume", "membershipConfirmedBeforeResume", "rootExited",
         "allMembersExitedNaturally", "imageAbsentBeforeCargo", "completed")))
    need(row["innerKillOnClose"] is False and row["breakawayAllowed"] is False
         and row["innerForcedTermination"] is False and row["failureCode"] is None)
    need(all(integer(row[key]) for key in ("startedNs", "deadlineNs", "cargoExitObservedNs", "naturalEmptyNs",
         "quiescenceDeadlineNs", "activeAtCargoExit", "activeBeforeClose", "minimumFreeObserved",
         "resumePreviousSuspendCount", "exitCode", "cleanupWaitSeconds", "pid", "logCapBytes", "reserveBytes",
         "quiescenceSeconds")))
    need(row["pid"] > 0 and row["resumePreviousSuspendCount"] == 1 and row["exitCode"] == 0
         and row["activeBeforeClose"] == 0 and row["cleanupWaitSeconds"] == 0 and row["handleCloseErrors"] == [])
    need(row["startedNs"] == spec["startedNs"] and row["deadlineNs"] == spec["deadlineNs"]
         and row["startedNs"] <= row["cargoExitObservedNs"] <= row["naturalEmptyNs"]
         < row["quiescenceDeadlineNs"] <= row["deadlineNs"])
    need(row["quiescenceDeadlineNs"] == min(spec["deadlineNs"], row["cargoExitObservedNs"] + QUIESCENCE_SECONDS * NANO)
         and row["quiescenceSeconds"] == QUIESCENCE_SECONDS and row["logCapBytes"] == MAX_LOG
         and row["reserveBytes"] == RUN_FREE and row["minimumFreeObserved"] >= RUN_FREE
         and row["captureOwner"] == "outer" and row["abortAuthority"] == "outer")


def validate_outer(row, spec, command, seconds=BUILD_SECONDS):
    closed(row, OUTER_KEYS)
    need(row["command"] == command and all(row[key] is True for key in ("stdinClosed", "startedSuspended",
         "assignedBeforeResume", "completed", "treeExitedBeforeCleanup", "rootExitedAtObservation", "rootExitedAfterCleanup")))
    need(row["outputExceeded"] is False and row["cleanupUnproven"] is False
         and row["cleanupErrors"] == [] and row["streamEOF"] == [True, True]
         and row["readerErrors"] == [False, False] and row["membersAfterOriginalDrain"] == [])
    need(type(row["streamEOF"]) is list and type(row["readerErrors"]) is list
         and all(type(value) is bool for value in row["streamEOF"] + row["readerErrors"])
         and type(row["namedJobCreatedNew"]) is bool
         and type(row["membersAtRootObservation"]) is list)
    need(len(row["membersAtRootObservation"]) <= 2048)
    observed_pids = set()
    for observed in row["membersAtRootObservation"]:
        need(type(observed) is dict and {"pid", "imageBytesRead", "imageIdentityKnown"}.issubset(observed)
             and set(observed).issubset({"pid", "imageBytesRead", "imageIdentityKnown", "membershipConfirmed",
                                        "imagePathMetadata", "imageQueryError", "membershipQueryError", "openError"}))
        need(integer(observed["pid"], 1) and observed["pid"] not in observed_pids
             and observed["imageBytesRead"] is False and observed["imageIdentityKnown"] is False)
        observed_pids.add(observed["pid"])
        if "membershipConfirmed" in observed: need(type(observed["membershipConfirmed"]) is bool)
        if "imagePathMetadata" in observed:
            need(observed.get("membershipConfirmed") is True and type(observed["imagePathMetadata"]) is str
                 and 0 < len(observed["imagePathMetadata"]) <= 32768)
        need(all(integer(observed[key]) for key in ("imageQueryError", "membershipQueryError", "openError") if key in observed))
    for key in ("deadlineSeconds", "logCapBytes", "minimumFreeObserved", "startedMonotonicNs", "absoluteDeadlineNs",
                "pid", "resumePreviousSuspendCount", "exitCode", "rootObservedMonotonicNs", "activeAtRootObservation",
                "originalDrainSeconds", "activeBeforeCleanup", "treeObservedMonotonicNs", "cleanupSeconds",
                "activeAfterCleanup", "capturedLogBytes"):
        need(integer(row[key]))
    need(row["pid"] > 0 and row["resumePreviousSuspendCount"] == 1 and row["exitCode"] == 0
         and row["activeBeforeCleanup"] == row["activeAfterCleanup"] == 0
         and row["originalDrainSeconds"] == OUTER_DRAIN_SECONDS and row["cleanupSeconds"] == CLEANUP_SECONDS
         and row["deadlineSeconds"] == seconds and row["logCapBytes"] == MAX_LOG
         and row["capturedLogBytes"] <= MAX_LOG and row["minimumFreeObserved"] >= RUN_FREE)
    need(type(row["elapsedSeconds"]) in (int, float) and math.isfinite(row["elapsedSeconds"])
         and 0 <= row["elapsedSeconds"] <= seconds + CLEANUP_SECONDS)
    need(row["startedMonotonicNs"] <= row["rootObservedMonotonicNs"] <= row["treeObservedMonotonicNs"] < row["absoluteDeadlineNs"])
    if spec is not None:
        need(row["jobName"] == spec["outerJobName"] and row["namedJobCreatedNew"] is True
             and row["absoluteDeadlineNs"] == spec["deadlineNs"]
             and spec["startedNs"] <= row["startedMonotonicNs"])
    else:
        need(seconds == VERSION_SECONDS and row["jobName"] is None and row["namedJobCreatedNew"] is False
             and row["absoluteDeadlineNs"] - row["startedMonotonicNs"] == seconds * NANO)


def image_record(record, run_id):
    need(type(record) is dict and set(record) == {"path", "sha256", "fileIdentity", "bytes", "mtimeNs", "links",
                                                 "noReparseAncestors", "writersAndDeletionDeniedThroughRecheck"})
    need(record["path"] == str(image_path(run_id)) and type(record["sha256"]) is str
         and re.fullmatch(r"[0-9a-f]{64}", record["sha256"]) and integer(record["bytes"], 1, MAX_IMAGE)
         and integer(record["mtimeNs"]) and type(record["links"]) is int and record["links"] == 1
         and record["noReparseAncestors"] is True and record["writersAndDeletionDeniedThroughRecheck"] is True)
    ids = record["fileIdentity"]
    need(type(ids) is list and len(ids) == 2 and integer(ids[0]) and integer(ids[1], 1))


def validate_result(result, run_id, commit):
    closed(result, RESULT_KEYS)
    need(result["owner"] == OWNER and type(result["schema"]) is int and result["schema"] == SCHEMA
         and result["mode"] == "build" and result["runId"] == run_id and result["sourceCommit"] == commit
         and result["completed"] is True and result["inputsUnchanged"] is True
         and result["protectedMetadataUnchanged"] is True and result["nativeImageReadAttempted"] is True
         and result["nativeImageRead"] is True and result["errorCode"] is None
         and result["releaseQualification"] is False and result["vsixQualification"] is False
         and result["observedVersion"] is None and integer(result["freeAfter"], RUN_FREE)
         and result["qualification"] == "compiler-transaction/version-only")
    image_record(result["selectedImage"], run_id)


def protected_pins(g, api, original, stack):
    pins = {name: stack.enter_context(original["MetadataPin"](api, name)) for name in original["PROTECTED_RELATIVE"]}
    before = {name: pin.recheck() for name, pin in pins.items()}
    original["checked_protected"](before, before)
    return pins, before


def protected_recheck(original, pins, before):
    after = {name: pin.recheck() for name, pin in pins.items()}
    original["checked_protected"](before, after)
    return after


def cargo_summary(g, original, data):
    """Retain the reviewed selector and additionally close its JSON types."""
    summary = original["cargo_summary"](g, data)
    finished = []
    for line in data.splitlines():
        if not line.strip(): continue
        row = g["unique_json"](line)
        if row.get("reason") == "build-finished":
            closed(row, {"reason", "success"})
            need(row["success"] is True, "cargo-finished")
            finished.append(row)
    need(len(finished) == 1, "cargo-finished")
    artifact = summary["selectedArtifact"]
    closed(artifact, {"reason", "package_id", "manifest_path", "target", "profile", "features",
                      "filenames", "executable", "fresh"})
    need(artifact["fresh"] is False and type(artifact["features"]) is list
         and all(type(value) is str for value in artifact["features"])
         and Path(artifact["manifest_path"]) == ROOT / "native/Cargo.toml", "cargo-artifact")
    profile = artifact["profile"]
    closed(profile, {"opt_level", "debuginfo", "debug_assertions", "overflow_checks", "test"})
    need(profile["test"] is False and profile["opt_level"] == "3"
         and profile["debug_assertions"] is False and profile["overflow_checks"] is False
         and type(profile["debuginfo"]) is int and profile["debuginfo"] == 0, "cargo-profile")
    target = artifact["target"]
    closed(target, {"kind", "crate_types", "name", "src_path", "edition", "doc", "doctest", "test"})
    need(target["kind"] == ["bin"] and target["crate_types"] == ["bin"] and target["name"] == "yoke"
         and type(target["edition"]) is str
         and all(type(target[key]) is bool for key in ("doc", "doctest", "test")), "cargo-target")
    return summary


PRODUCER_FILES = ("request.json", "result.json", "worker-spec.json", "inner.job.json", "outer.job.json",
                  "outer.stdout", "outer.stderr", "source-before.json", "source-after.json", "source-final.json",
                  "original-control-before.json", "original-control-after.json", "original-control-final.json",
                  "transaction-control-before.json", "transaction-control-after.json", "transaction-control-final.json",
                  "protected-before.json", "protected-after.json", "protected-final.json", "cargo-summary.json",
                  "selected-image.json", "selected-image-after.json")


def producer_admission(g, api, original, stack, run_id, commit, sources, originals, controls, *, on_image_attempt=None):
    """New protocol only. Pin and validate receipts before reading the fresh image."""
    run_name(run_id); commit_name(commit)
    out = RUNS / run_id; g["ordinary"](out, directory=True)
    need(sum((out / name).lstat().st_size for name in PRODUCER_FILES) <= 64_000_000, "receipt-capacity")
    pins = {name: stack.enter_context(g["ReadPin"](api, out / name, MAX_LOG)) for name in PRODUCER_FILES}
    values = {name: g["unique_json"](pin.bytes()) for name, pin in pins.items() if name.endswith(".json")}
    expected = request_record("build", run_id, commit, None, sources, originals, controls)
    validate_request(values["request.json"], expected)
    validate_result(values["result.json"], run_id, commit)
    spec = validate_spec(values["worker-spec.json"])
    need(spec["runId"] == run_id and spec["sourceCommit"] == commit
         and spec["sourceDigest"] == digest(sources) and spec["originalControlsDigest"] == digest(originals)
         and spec["transactionControlsDigest"] == digest(controls))
    validate_inner(values["inner.job.json"], spec)
    validate_outer(values["outer.job.json"], spec, worker_command(run_id))
    need(values["inner.job.json"]["naturalEmptyNs"] <= values["outer.job.json"]["rootObservedMonotonicNs"])
    need(len(pins["outer.stdout"].bytes()) + len(pins["outer.stderr"].bytes()) == values["outer.job.json"]["capturedLogBytes"])
    for stem, expected_map in (("source", sources), ("original-control", originals), ("transaction-control", controls)):
        need(all(values[stem + "-" + phase + ".json"] == expected_map for phase in ("before", "after", "final")), "input-drift")
    summary = cargo_summary(g, original, pins["outer.stdout"].bytes())
    need(summary == values["cargo-summary.json"] and summary["selectedArtifact"] == values["result.json"]["selectedArtifact"])
    protected, current = protected_pins(g, api, original, stack)
    need(all(values["protected-" + phase + ".json"] == current for phase in ("before", "after", "final")), "protected-drift")
    protected_recheck(original, protected, current)
    image = image_path(run_id); record = values["selected-image.json"]
    image_record(record, run_id)
    need(record == values["selected-image-after.json"] == values["result.json"]["selectedImage"])
    need(shutil.disk_usage("C:\\").free >= IMAGE_FREE, "image-admission")
    if on_image_attempt is not None: on_image_attempt()
    image_pin = stack.enter_context(g["ReadPin"](api, image, MAX_IMAGE, image=True))
    need(image_pin.record() == record, "image-drift")
    # Consumer must repeat these rechecks before publishing its own success.
    return {"image": image, "imagePin": image_pin, "receiptPins": pins, "record": record,
            "protectedPins": protected, "protectedBefore": current, "artifact": summary["selectedArtifact"]}


def recheck_admission(original, admitted):
    protected_recheck(original, admitted["protectedPins"], admitted["protectedBefore"])
    need(admitted["imagePin"].recheck() == admitted["record"], "image-drift")
    pin_rechecks(admitted["receiptPins"])


def configure_worker_api(api):
    api.OpenJobObjectW.argtypes, api.OpenJobObjectW.restype = [c.c_ulong, c.c_int, c.c_wchar_p], c.c_void_p
    api.GetCurrentProcess.argtypes, api.GetCurrentProcess.restype = [], c.c_void_p


def member(api, process, job):
    inside = c.c_int()
    need(api.IsProcessInJob(process, job, c.byref(inside)), "membership-query")
    return bool(inside.value)


def active(api, job):
    data = c.create_string_buffer(48)
    need(api.QueryInformationJobObject(job, 1, data, len(data), None), "job-accounting")
    return int.from_bytes(data.raw[40:44], "little")


def inner_run(g, api, extended, spec, outer, environment, *, _trusted_test_argv=None, _test_fault=None):
    """No inner termination or cleanup wait; the containing outer Job owns abort."""
    import _winapi
    import msvcrt
    row = {key: None for key in INNER_KEYS}
    row.update(owner=OWNER, schema=SCHEMA, role="compiler-inner", runId=spec["runId"],
               sourceCommit=spec["sourceCommit"], outerJobName=spec["outerJobName"],
               command=spec["cargoCommand"] if _trusted_test_argv is None else _trusted_test_argv,
               startedNs=spec["startedNs"], deadlineNs=spec["deadlineNs"], quiescenceSeconds=QUIESCENCE_SECONDS,
               captureOwner="outer", logCapBytes=MAX_LOG, reserveBytes=RUN_FREE, innerKillOnClose=False,
               breakawayAllowed=False, innerInitiallyEmpty=False, startedSuspended=False,
               cargoInOuterBeforeInner=False, assignedBeforeResume=False, membershipConfirmedBeforeResume=False,
               rootExited=False, allMembersExitedNaturally=False, minimumFreeObserved=shutil.disk_usage("C:\\").free,
               abortAuthority="outer", innerForcedTermination=False, cleanupWaitSeconds=0,
               handleCloseErrors=[], imageAbsentBeforeCargo=False, completed=False, failureCode=None,
               outerMembershipBeforeCargo=False)
    job = process = thread = None
    def limits(deadline):
        free = shutil.disk_usage("C:\\").free
        row["minimumFreeObserved"] = min(row["minimumFreeObserved"], free)
        need(free >= RUN_FREE, "disk-reserve")
        need(time.monotonic_ns() < deadline, "build-deadline" if deadline == spec["deadlineNs"] else "quiescence-deadline")
    try:
        need(_test_fault in (None, "after-create", "assignment", "resume", "query", "wrapper-crash"), "test-fault-role")
        need(member(api, api.GetCurrentProcess(), outer), "outer-membership")
        row["outerMembershipBeforeCargo"] = True
        limits(spec["deadlineNs"])
        need(not os.path.lexists(image_path(spec["runId"])), "occupied-image")
        row["imageAbsentBeforeCargo"] = True
        job = api.CreateJobObjectW(None, None); need(job, "inner-job-create")
        settings = extended(); settings.basic.flags = 0
        need(api.SetInformationJobObject(job, 9, c.byref(settings), c.sizeof(settings)), "inner-job-limits")
        need(active(api, job) == 0, "inner-job-not-empty"); row["innerInitiallyEmpty"] = True
        handles = [msvcrt.get_osfhandle(stream.fileno()) for stream in (sys.stdin, sys.stdout, sys.stderr)]
        for handle in handles: os.set_handle_inheritable(handle, True)
        startup = subprocess.STARTUPINFO(); startup.dwFlags = subprocess.STARTF_USESTDHANDLES
        startup.hStdInput, startup.hStdOutput, startup.hStdError = handles
        startup.lpAttributeList = {"handle_list": handles}
        argv = row["command"]
        limits(spec["deadlineNs"])
        process, thread, pid, _ = _winapi.CreateProcess(str(argv[0]), subprocess.list2cmdline(argv),
            None, None, True, subprocess.CREATE_NO_WINDOW | 4, environment, str(ROOT), startup)
        row.update(pid=pid, startedSuspended=True)
        if _test_fault == "after-create": raise Refusal("test-after-create")
        need(member(api, process, outer), "cargo-outer-membership"); row["cargoInOuterBeforeInner"] = True
        if _test_fault == "assignment": raise Refusal("test-assignment")
        need(api.AssignProcessToJobObject(job, process), "inner-assignment"); row["assignedBeforeResume"] = True
        need(member(api, process, job), "inner-membership"); row["membershipConfirmedBeforeResume"] = True
        if _test_fault == "resume": raise Refusal("test-resume")
        row["resumePreviousSuspendCount"] = api.ResumeThread(thread)
        need(row["resumePreviousSuspendCount"] == 1, "inner-resume")
        if _test_fault == "wrapper-crash": os._exit(17)
        while True:
            status = _winapi.WaitForSingleObject(process, 50)
            limits(spec["deadlineNs"])
            if status == 0:
                row["exitCode"] = _winapi.GetExitCodeProcess(process)
                row["rootExited"] = True
                row["cargoExitObservedNs"] = time.monotonic_ns()
                break
            need(status == 258, "cargo-wait")
        need(row["exitCode"] == 0, "cargo-exit")
        row["activeAtCargoExit"] = active(api, job)
        row["quiescenceDeadlineNs"] = min(spec["deadlineNs"], row["cargoExitObservedNs"] + QUIESCENCE_SECONDS * NANO)
        while True:
            limits(row["quiescenceDeadlineNs"])
            if _test_fault == "query": raise Refusal("test-query")
            remaining = active(api, job)
            limits(row["quiescenceDeadlineNs"])
            if remaining == 0:
                row["naturalEmptyNs"] = time.monotonic_ns()
                row["activeBeforeClose"] = 0
                row["allMembersExitedNaturally"] = True
                break
            time.sleep(.01)
        row["completed"] = True
    except Refusal as error:
        row["failureCode"] = error.code
    except BaseException:
        row["failureCode"] = "inner-internal"
    finally:
        # No TerminateJobObject, TerminateProcess, kill-on-close or cleanup wait.
        # Cargo inherited the containing outer Job before inner assignment.
        # Failure exits the worker promptly; the outer owner's two-second abort
        # is the sole whole-tree cleanup. Never convert its removal to success.
        for handle in (thread, process, job):
            if handle is not None:
                try:
                    if not api.CloseHandle(handle): row["handleCloseErrors"].append("close")
                except BaseException: row["handleCloseErrors"].append("close")
        if row["handleCloseErrors"] or row["failureCode"] is not None:
            row["completed"] = False
    return row


def worker_entry(spec_path):
    """Called only by the hash-pinned thin worker; no generic command input."""
    need(os.name == "nt", "platform")
    g = load_runtime(); api, extended = g["load_windows_api"](); configure_worker_api(api)
    spec_path = Path(spec_path)
    need(spec_path.is_absolute() and spec_path.name == "worker-spec.json"
         and spec_path.parent.parent == RUNS, "spec-role")
    run_id = run_name(spec_path.parent.name); outer = None; row = None
    with ExitStack() as stack:
        spec_pin = stack.enter_context(g["ReadPin"](api, spec_path, 64_000))
        spec = validate_spec(g["unique_json"](spec_pin.bytes()), now_ns=time.monotonic_ns())
        need(spec["runId"] == run_id, "spec-role")
        original_controls = original_map(g); own_controls = g["controls_map"]()
        need(digest(original_controls) == spec["originalControlsDigest"]
             and digest(own_controls) == spec["transactionControlsDigest"], "control-drift")
        out = RUNS / run_id; g["ordinary"](out, directory=True)
        need(not os.path.lexists(out / "inner.job.json"), "occupied-inner-receipt")
        outer = api.OpenJobObjectW(4, False, spec["outerJobName"])
        need(outer not in (None, -1, (1 << 64) - 1), "outer-job-open")
        try:
            need(member(api, api.GetCurrentProcess(), outer), "outer-membership")
            env = g["environment_for"]("build")
            row = inner_run(g, api, extended, spec, outer, env)
            spec_pin.recheck()
            need(original_map(g) == original_controls and g["controls_map"]() == own_controls, "control-drift")
        except BaseException as error:
            if row is not None:
                row.update(completed=False, failureCode=error.code if isinstance(error, Refusal) else "worker-recheck")
            else: raise
        finally:
            if not api.CloseHandle(outer) and row is not None:
                row.update(completed=False, failureCode="outer-handle-close")
        g["write_json"](out, "inner.job.json", row)
    return 0 if row is not None and row["completed"] else 1


if __name__ == "__main__":
    raise SystemExit("Library-only compiler transaction protocol")
