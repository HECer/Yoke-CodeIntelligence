"""Authored adversarial checks. No test has been run during preparation.

Real Windows cases execute only inert Python children under private Jobs. They
never build, read or execute a Yoke/native image. Captures stay in private runs.
"""
from contextlib import ExitStack
import copy
import ctypes as c
import hashlib
import json
import os
from pathlib import Path
import secrets
import sys
import tempfile
import time
from types import ModuleType, SimpleNamespace
import unittest
from unittest import mock


HERE = Path(__file__).absolute().parent


def module(name, filename):
    value = ModuleType(name)
    value.__file__ = str(HERE / filename)
    exec(compile((HERE / filename).read_bytes(), value.__file__, "exec"), value.__dict__)
    return value


def protocol():
    return module("inert_test_protocol", "transaction_protocol.py")


def successful_inner(p, spec):
    row = {key: None for key in p.INNER_KEYS}
    row.update(owner=p.OWNER, schema=p.SCHEMA, role="compiler-inner", runId=spec["runId"],
               sourceCommit=spec["sourceCommit"], outerJobName=spec["outerJobName"],
               command=spec["cargoCommand"], startedNs=spec["startedNs"], deadlineNs=spec["deadlineNs"],
               quiescenceSeconds=60, captureOwner="outer", logCapBytes=p.MAX_LOG, reserveBytes=p.RUN_FREE,
               innerKillOnClose=False, breakawayAllowed=False, innerInitiallyEmpty=True, pid=100,
               outerMembershipBeforeCargo=True, startedSuspended=True, cargoInOuterBeforeInner=True,
               assignedBeforeResume=True, membershipConfirmedBeforeResume=True, resumePreviousSuspendCount=1,
               exitCode=0, rootExited=True, cargoExitObservedNs=spec["startedNs"] + 10 * p.NANO,
               activeAtCargoExit=1, naturalEmptyNs=spec["startedNs"] + 12 * p.NANO,
               activeBeforeClose=0, allMembersExitedNaturally=True, minimumFreeObserved=p.START_FREE,
               abortAuthority="outer", innerForcedTermination=False, cleanupWaitSeconds=0,
               handleCloseErrors=[], imageAbsentBeforeCargo=True, completed=True, failureCode=None)
    row["quiescenceDeadlineNs"] = min(spec["deadlineNs"], row["cargoExitObservedNs"] + 60 * p.NANO)
    return row


def successful_outer(p, spec):
    row = {key: None for key in p.OUTER_KEYS}
    row.update(command=p.worker_command(spec["runId"]), deadlineSeconds=3600, logCapBytes=p.MAX_LOG,
               stdinClosed=True, startedSuspended=True, assignedBeforeResume=True, completed=True,
               treeExitedBeforeCleanup=True, minimumFreeObserved=p.START_FREE, cleanupErrors=[],
               streamEOF=[True, True], readerErrors=[False, False], startedMonotonicNs=spec["startedNs"] + 1,
               absoluteDeadlineNs=spec["deadlineNs"], jobName=spec["outerJobName"], namedJobCreatedNew=True,
               pid=101, resumePreviousSuspendCount=1, exitCode=0,
               rootObservedMonotonicNs=spec["startedNs"] + 13 * p.NANO, membersAtRootObservation=[],
               rootExitedAtObservation=True, activeAtRootObservation=0, originalDrainSeconds=1,
               activeBeforeCleanup=0, membersAfterOriginalDrain=[],
               treeObservedMonotonicNs=spec["startedNs"] + 13 * p.NANO + 1,
               cleanupSeconds=2, activeAfterCleanup=0, rootExitedAfterCleanup=True,
               elapsedSeconds=13.1, capturedLogBytes=0, outputExceeded=False, cleanupUnproven=False)
    return row


def artifact(p):
    return {"reason": "compiler-artifact", "package_id": "path+" + (p.ROOT / "native").as_uri()
            + "#yoke-code-intelligence@0.5.0", "manifest_path": str(p.ROOT / "native/Cargo.toml"),
            "target": {"kind": ["bin"], "crate_types": ["bin"], "name": "yoke",
                       "src_path": str(p.ROOT / "native/src/main.rs"), "edition": "2024",
                       "doc": True, "doctest": False, "test": True},
            "profile": {"opt_level": "3", "debuginfo": 0, "debug_assertions": False,
                        "overflow_checks": False, "test": False}, "features": [], "filenames": [],
            "executable": str(p.ROOT / "target/release/yoke.exe"), "fresh": False}


def golden(p):
    run = "inert-receipt-producer"
    commit = "f" * 40
    sources = {"native/src/main.rs": {"sha256": "1" * 64, "bytes": 123}}
    originals = {"immutable": {"sha256": "2" * 64, "bytes": 123}}
    controls = {"transaction": {"sha256": "3" * 64, "bytes": 123}}
    spec = p.make_spec(run, commit, "Local\\YokeCompilerTransaction-" + "a" * 64,
                       100 * p.NANO, sources, originals, controls)
    selected = {"path": str(p.image_path(run)), "sha256": "b" * 64, "fileIdentity": [1, 2],
                "bytes": 123, "mtimeNs": 10, "links": 1, "noReparseAncestors": True,
                "writersAndDeletionDeniedThroughRecheck": True}
    selected_artifact = artifact(p)
    summary = {"selectedArtifact": selected_artifact}
    stdout = (json.dumps(selected_artifact) + "\n" + json.dumps({"reason": "build-finished", "success": True}) + "\n").encode()
    outer = successful_outer(p, spec); outer["capturedLogBytes"] = len(stdout)
    result = {"owner": p.OWNER, "schema": p.SCHEMA, "mode": "build", "runId": run,
              "sourceCommit": commit, "completed": True, "inputsUnchanged": True,
              "protectedMetadataUnchanged": True, "nativeImageReadAttempted": True,
              "nativeImageRead": True, "selectedImage": selected, "selectedArtifact": selected_artifact,
              "observedVersion": None, "errorCode": None, "releaseQualification": False,
              "vsixQualification": False, "qualification": "compiler-transaction/version-only", "freeAfter": p.START_FREE}
    values = {"request.json": p.request_record("build", run, commit, None, sources, originals, controls),
              "result.json": result, "worker-spec.json": spec, "inner.job.json": successful_inner(p, spec),
              "outer.job.json": outer, "outer.stdout": stdout, "outer.stderr": b"", "cargo-summary.json": summary,
              "selected-image.json": selected, "selected-image-after.json": copy.deepcopy(selected)}
    for stem, value in (("source", sources), ("original-control", originals), ("transaction-control", controls), ("protected", {})):
        for phase in ("before", "after", "final"): values[stem + "-" + phase + ".json"] = copy.deepcopy(value)
    return run, commit, sources, originals, controls, spec, values


class ClosedReceiptTests(unittest.TestCase):
    def setUp(self):
        self.p = protocol()
        self.run, self.commit, self.sources, self.originals, self.controls, self.spec, self.values = golden(self.p)

    def refused_inner(self, changes):
        row = copy.deepcopy(self.values["inner.job.json"]); row.update(changes)
        with self.assertRaises(self.p.Refusal): self.p.validate_inner(row, self.spec)

    def test_valid_closed_records(self):
        self.p.validate_spec(self.spec, now_ns=self.spec["startedNs"])
        self.p.validate_inner(self.values["inner.job.json"], self.spec)
        self.p.validate_outer(self.values["outer.job.json"], self.spec, self.p.worker_command(self.run))
        self.p.validate_result(self.values["result.json"], self.run, self.commit)

    def test_cargo_failure_cannot_be_hidden_by_wrapper_zero(self):
        self.refused_inner({"exitCode": 1})
        self.refused_inner({"rootExited": False})

    def test_every_owned_launch_and_natural_completion_proof_is_required(self):
        for key in ("outerMembershipBeforeCargo", "innerInitiallyEmpty", "startedSuspended", "cargoInOuterBeforeInner",
                    "assignedBeforeResume", "membershipConfirmedBeforeResume", "rootExited", "allMembersExitedNaturally"):
            with self.subTest(key=key): self.refused_inner({key: False})
        for changes in ({"innerForcedTermination": True}, {"innerKillOnClose": True}, {"breakawayAllowed": True},
                        {"activeBeforeClose": 1}, {"cleanupWaitSeconds": 2}, {"abortAuthority": "inner"}):
            with self.subTest(changes=changes): self.refused_inner(changes)

    def test_bool_counters_and_resumed_twice_refuse(self):
        for key in ("pid", "exitCode", "activeBeforeClose", "activeAtCargoExit", "cleanupWaitSeconds", "startedNs"):
            with self.subTest(key=key): self.refused_inner({key: False})
        self.refused_inner({"resumePreviousSuspendCount": 0})
        self.refused_inner({"resumePreviousSuspendCount": 2})

    def test_absolute_deadline_cannot_reset_or_expand(self):
        self.refused_inner({"deadlineNs": self.spec["deadlineNs"] + 1})
        self.refused_inner({"quiescenceDeadlineNs": self.spec["deadlineNs"]})
        self.refused_inner({"naturalEmptyNs": self.spec["deadlineNs"]})
        for key in ("startedNs", "deadlineNs"):
            changed = copy.deepcopy(self.spec); changed[key] += 1
            with self.subTest(key=key), self.assertRaises(self.p.Refusal): self.p.validate_spec(changed)
        with self.assertRaises(self.p.Refusal): self.p.validate_spec(self.spec, now_ns=self.spec["deadlineNs"])

    def test_quiescence_is_clamped_to_original_deadline(self):
        inner = successful_inner(self.p, self.spec)
        inner["cargoExitObservedNs"] = self.spec["deadlineNs"] - 2 * self.p.NANO
        inner["naturalEmptyNs"] = self.spec["deadlineNs"] - self.p.NANO
        inner["quiescenceDeadlineNs"] = self.spec["deadlineNs"]
        self.p.validate_inner(inner, self.spec)

    def test_outer_force_stream_disk_query_and_deadline_failures_refuse(self):
        changes = ({"completed": False}, {"activeBeforeCleanup": 1}, {"treeExitedBeforeCleanup": False},
                   {"cleanupErrors": ["job-accounting"]}, {"cleanupUnproven": True},
                   {"streamEOF": [True, False]}, {"readerErrors": [True, False]}, {"outputExceeded": True},
                   {"minimumFreeObserved": self.p.RUN_FREE - 1}, {"capturedLogBytes": self.p.MAX_LOG + 1},
                   {"treeObservedMonotonicNs": self.spec["deadlineNs"]}, {"namedJobCreatedNew": False},
                   {"originalDrainSeconds": 2}, {"cleanupSeconds": 3}, {"activeAfterCleanup": False},
                   {"streamEOF": [1, True]}, {"readerErrors": [False, 0]}, {"exitCode": False})
        for change in changes:
            row = copy.deepcopy(self.values["outer.job.json"]); row.update(change)
            with self.subTest(change=change), self.assertRaises(self.p.Refusal):
                self.p.validate_outer(row, self.spec, self.p.worker_command(self.run))

    def test_request_and_spec_reject_test_hooks_arbitrary_argv_and_unknown_fields(self):
        request = self.values["request.json"]
        for changes in ({"command": [sys.executable, "-c", "pass"]}, {"deadlineSeconds": True},
                        {"preparationInventoryIsSeparate": 1}, {"testArgv": ["anything"]}):
            changed = copy.deepcopy(request); changed.update(changes)
            with self.subTest(changes=changes), self.assertRaises(self.p.Refusal): self.p.validate_request(changed, request)
        changed = copy.deepcopy(self.spec); changed["cargoCommand"][-1] = str(self.p.ROOT / "target/release/yoke.exe")
        with self.assertRaises(self.p.Refusal): self.p.validate_spec(changed)

    def test_native_image_metadata_has_no_default_alias_or_link_escape(self):
        record = self.values["selected-image.json"]
        changes = ({"path": str(self.p.ROOT / "target/release/yoke.exe")}, {"links": 2}, {"links": True},
                   {"noReparseAncestors": False}, {"writersAndDeletionDeniedThroughRecheck": False},
                   {"fileIdentity": [1, True]}, {"bytes": True})
        for change in changes:
            changed = copy.deepcopy(record); changed.update(change)
            with self.subTest(change=change), self.assertRaises(self.p.Refusal): self.p.image_record(changed, self.run)

    def test_source_hardlink_and_symlink_refusal_uses_inert_text_only(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "inert.py"; source.write_text("pass\n", encoding="ascii")
            expected = hashlib.sha256(source.read_bytes()).hexdigest()
            link = Path(directory) / "alias.py"
            os.link(source, link)
            with self.assertRaises(self.p.Refusal): self.p.source_bytes(source, expected)
            link.unlink()
            try: link.symlink_to(source)
            except (OSError, NotImplementedError): return
            with self.assertRaises(self.p.Refusal): self.p.source_bytes(link, expected)

    def test_original_controls_are_immutable_and_old_result_refuses(self):
        self.assertEqual(self.p.ORIGINAL_PINS["base_controller.py"], "a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7")
        for change in ({"owner": "integration-20261025-private-release-cli-v1"}, {"schema": 1},
                       {"runId": "release-cli-isolated-f8-r2"}, {"nativeImageRead": False}):
            row = copy.deepcopy(self.values["result.json"]); row.update(change)
            with self.subTest(change=change), self.assertRaises(self.p.Refusal): self.p.validate_result(row, self.run, self.commit)


class ProducerAdmissionTests(ClosedReceiptTests):
    def admit(self, values=None, image_error=False, protected_error=False):
        p = self.p; values = self.values if values is None else values
        self.image_reads = []
        class Pin:
            def __init__(pin, api, path, maximum, image=False):
                pin.path = path; pin.image = image
                if image:
                    self.image_reads.append(str(path))
                    if image_error: raise p.Refusal("image-drift")
                else:
                    if path.name not in values: raise p.Refusal("missing-receipt")
            def __enter__(pin): return pin
            def __exit__(pin, *args): pin.recheck()
            def bytes(pin):
                value = values[pin.path.name]
                return value if type(value) is bytes else json.dumps(value).encode()
            def record(pin): return copy.deepcopy(values["selected-image.json"])
            def recheck(pin): return pin.record() if pin.image else {"pinned": str(pin.path)}
        g = {"ReadPin": Pin, "ordinary": lambda *a, **k: None, "unique_json": json.loads}
        original = {"cargo_summary": lambda g, data: values["cargo-summary.json"]}
        def check(*a):
            if protected_error: raise p.Refusal("protected-drift")
            return {}
        # Stat is metadata only, and every fake image observation is in memory.
        with mock.patch.object(Path, "lstat", return_value=SimpleNamespace(st_size=1)), \
             mock.patch.object(p, "protected_pins", return_value=({}, {})), \
             mock.patch.object(p, "protected_recheck", side_effect=check), \
             mock.patch.object(p.shutil, "disk_usage", return_value=SimpleNamespace(free=p.START_FREE)), ExitStack() as stack:
            return p.producer_admission(g, None, original, stack, self.run, self.commit,
                                        self.sources, self.originals, self.controls)

    def test_full_matching_new_producer_reaches_only_selected_image(self):
        admitted = self.admit()
        self.assertEqual(admitted["image"], self.p.image_path(self.run))
        self.assertEqual(self.image_reads, [str(self.p.image_path(self.run))])

    def test_all_forged_or_drifted_receipts_refuse_before_image(self):
        mutations = (("inner.job.json", "exitCode", 1), ("outer.job.json", "activeBeforeCleanup", 1),
                     ("result.json", "owner", "old-r2"), ("request.json", "producerRunId", "foreign"),
                     ("source-final.json", "foreign", {}), ("transaction-control-after.json", "foreign", {}),
                     ("selected-image.json", "path", str(self.p.ROOT / "target/release/yoke.exe")),
                     ("selected-image.json", "links", 2), ("selected-image.json", "noReparseAncestors", False),
                     ("worker-spec.json", "deadlineNs", self.spec["deadlineNs"] + self.p.NANO))
        for filename, key, value in mutations:
            values = copy.deepcopy(self.values); values[filename][key] = value
            with self.subTest(filename=filename, key=key), self.assertRaises(self.p.Refusal): self.admit(values)
            self.assertEqual(self.image_reads, [])

    def test_late_protected_failure_prevents_first_image_read(self):
        with self.assertRaises(self.p.Refusal): self.admit(protected_error=True)
        self.assertEqual(self.image_reads, [])

    def test_pin_alias_reparse_failure_is_not_success(self):
        with self.assertRaises(self.p.Refusal): self.admit(image_error=True)

    def test_cargo_json_bool_and_unknown_profile_fields_refuse(self):
        for where, key, value in (("artifact", "fresh", 0), ("profile", "test", 0),
                                  ("profile", "debuginfo", False), ("profile", "debuginfo", None),
                                  ("profile", "debuginfo", 1), ("profile", "debuginfo", 2),
                                  ("profile", "debug_assertions", True), ("profile", "overflow_checks", True),
                                  ("target", "test", 1),
                                  ("target", "arbitrary", True)):
            values = copy.deepcopy(self.values); selected = values["cargo-summary.json"]["selectedArtifact"]
            (selected if where == "artifact" else selected[where])[key] = value
            with self.subTest(where=where, key=key), self.assertRaises(self.p.Refusal): self.admit(values)
            self.assertEqual(self.image_reads, [])


@unittest.skipUnless(os.name == "nt", "Controller's fixed Windows platform admission")
class ControllerPublicationTests(unittest.TestCase):
    def simulate(self, *, late_pin=False, protected_phase=None):
        p = protocol(); controller = module("inert_controller", "compiler_transaction_controller.py")
        run, commit, sources, originals, controls, _, values = golden(p)
        args = SimpleNamespace(mode="build", run_id=run, source_commit=commit, producer_run_id=None)
        receipts = {}; attempted = []; protected_calls = [0]
        class Pin:
            def __init__(pin, api, path, maximum, image=False):
                pin.path = path; pin.image = image
                if image: attempted.append(str(path))
            def __enter__(pin): return pin
            def __exit__(pin, *args): pin.recheck()
            def bytes(pin):
                value = receipts[pin.path.name]
                return value if type(value) is bytes else json.dumps(value).encode()
            def recheck(pin): return values["selected-image.json"] if pin.image else {"pin": str(pin.path)}
        class LateControlPin:
            def __enter__(pin): return pin
            def __exit__(pin, *args):
                if late_pin: raise p.Refusal("late-control-pin")
        def pin_controls(g, api, stack):
            stack.enter_context(LateControlPin())
            return {}
        def protected(*args):
            protected_calls[0] += 1
            if protected_calls[0] == protected_phase: raise p.Refusal("protected-drift")
            return {}
        def owned(*args, **kwargs):
            spec = receipts["worker-spec.json"]
            row = successful_outer(p, spec)
            receipts["inner.job.json"] = successful_inner(p, spec)
            receipts["outer.stdout"] = values["outer.stdout"]; receipts["outer.stderr"] = b""
            row["capturedLogBytes"] = len(receipts["outer.stdout"])
            receipts["outer.job.json"] = row
            return row
        g = {"new_output": lambda run: p.RUNS / run, "source_map": lambda *args: sources,
             "controls_map": lambda: controls, "ReadPin": Pin, "unique_json": json.loads,
             "environment_for": lambda mode: {}, "load_windows_api": lambda: (None, None),
             "run_owned": owned, "write_json": lambda out, name, value: receipts.__setitem__(name, copy.deepcopy(value))}
        with mock.patch.object(p, "load_runtime", return_value=g), mock.patch.object(p, "load_original", return_value={}), \
             mock.patch.object(p, "original_map", return_value=originals), mock.patch.object(p, "pin_control_files", side_effect=pin_controls), \
             mock.patch.object(p, "protected_pins", return_value=({}, {})), \
             mock.patch.object(p, "protected_recheck", side_effect=protected), \
             mock.patch.object(p, "cargo_summary", return_value=values["cargo-summary.json"]), \
             mock.patch.object(p.shutil, "disk_usage", return_value=SimpleNamespace(free=p.START_FREE)), \
             mock.patch.object(controller, "acquire_mutex", return_value=1), \
             mock.patch.object(controller, "release_mutex", return_value=None):
            result = controller.execute(p, args)
        return result, attempted, receipts

    def test_success_is_published_only_after_all_context_rechecks(self):
        result, attempted, receipts = self.simulate()
        self.assertTrue(result["completed"], result)
        self.assertTrue(attempted)
        self.assertEqual(receipts["result.json"], result)

    def test_late_pin_failure_never_publishes_completed(self):
        result, attempted, receipts = self.simulate(late_pin=True)
        self.assertTrue(attempted)
        self.assertFalse(result["completed"], result)
        self.assertFalse(receipts["result.json"]["completed"])
        self.assertFalse(result["inputsUnchanged"])

    def test_protected_failure_before_image_prevents_read_and_late_failure_refuses(self):
        result, attempted, _ = self.simulate(protected_phase=1)
        self.assertFalse(result["completed"])
        self.assertEqual(attempted, [])
        self.assertFalse(result["nativeImageReadAttempted"])
        result, attempted, _ = self.simulate(protected_phase=2)
        self.assertTrue(attempted)
        self.assertFalse(result["completed"])
        self.assertFalse(result["protectedMetadataUnchanged"])


def inert_compiler_argv(mode):
    helper_seconds = 1.6 if mode == "linger" else 30
    # Open only the test compiler's retained, owned root before acknowledging
    # readiness. Sleep begins after the actual root exit receipt, removing a
    # scheduling assumption from the >1s direct-gate comparison.
    helper = ("import ctypes as c,sys,time; k=c.WinDLL('kernel32',use_last_error=True); "
              "k.OpenProcess.argtypes=[c.c_ulong,c.c_int,c.c_ulong]; k.OpenProcess.restype=c.c_void_p; "
              "k.WaitForSingleObject.argtypes=[c.c_void_p,c.c_ulong]; k.WaitForSingleObject.restype=c.c_ulong; "
              "k.CloseHandle.argtypes=[c.c_void_p]; k.CloseHandle.restype=c.c_int; "
              "h=k.OpenProcess(0x100000,False,int(sys.argv[1])); assert h; print('ready',flush=True); "
              "s=k.WaitForSingleObject(h,10000); assert k.CloseHandle(h); assert s==0; "
              "time.sleep(" + str(helper_seconds) + ")")
    code = ("import os,subprocess,sys; p=subprocess.Popen([sys.executable,'-I','-c'," + repr(helper)
            + ",str(os.getpid())],stdout=subprocess.PIPE,text=True); "
              "assert p.stdout.readline()=='ready\\n'; print('inert compiler',flush=True)")
    if mode == "output": code += "; sys.stdout.write('x'*200000); sys.stdout.flush()"
    return [str(Path(sys.executable).absolute()), "-I", "-c", code]


def inert_worker(spec_path, fault, mode):
    """Internal test entry; never reachable from the production CLI or spec."""
    p = protocol(); g = p.load_runtime(); api, extended = g["load_windows_api"](); p.configure_worker_api(api)
    spec = json.loads(Path(spec_path).read_text())
    outer = api.OpenJobObjectW(4, False, spec["outerJobName"])
    try:
        p.need(outer and p.member(api, api.GetCurrentProcess(), outer), "test-outer-membership")
        row = p.inner_run(g, api, extended, spec, outer, os.environ.copy(),
                          _trusted_test_argv=inert_compiler_argv(mode), _test_fault=None if fault == "none" else fault)
        g["write_json"](Path(spec_path).parent, "inner.job.json", row)
        return 0 if row["completed"] else 1
    finally:
        api.CloseHandle(outer)


@unittest.skipUnless(os.name == "nt", "Windows nested Jobs required")
class InertWindowsLifecycleTests(unittest.TestCase):
    def prepare(self):
        p = protocol(); g = p.load_runtime(); api, extended = g["load_windows_api"]()
        out = g["new_output"]("inert-transaction-" + secrets.token_hex(12))
        # Keep the real protocol's 3600-second origin/difference, but start this
        # inert challenge with only six seconds REMAINING. Never reset in worker.
        start = time.monotonic_ns() - (p.BUILD_SECONDS - 6) * p.NANO
        spec = p.make_spec(out.name, "f" * 40, "Local\\YokeCompilerTransaction-" + secrets.token_hex(32),
                           start, {}, {}, {})
        g["write_json"](out, "worker-spec.json", spec)
        return p, g, api, extended, out, spec

    def run_wrapper(self, fault="none", mode="linger", cap=16_000_000, inject=None):
        p, g, api, extended, out, spec = self.prepare()
        argv = [str(Path(sys.executable).absolute()), "-I", str(Path(__file__).absolute()),
                "--owned-inert-worker", str(out / "worker-spec.json"), fault, mode]
        with ExitStack() as stack:
            if inject == "disk":
                calls = [0]
                def disk(_):
                    calls[0] += 1
                    return SimpleNamespace(free=p.START_FREE if calls[0] < 4 else 0)
                stack.enter_context(mock.patch.object(g["shutil"], "disk_usage", side_effect=disk))
            if inject == "stream":
                read = os.read
                def broken_read(fd, size): raise OSError("inert reader fault")
                stack.enter_context(mock.patch.object(g["os"], "read", side_effect=broken_read))
            row = g["run_owned"](api, extended, out, "outer", argv, os.environ.copy(), 6, cap=cap,
                                  absolute_deadline_ns=spec["deadlineNs"], job_name=spec["outerJobName"])
        return p, g, api, extended, out, spec, row

    def test_delayed_helper_is_natural_under_new_transaction_but_fails_old_direct_gate(self):
        p, g, api, extended, out, spec, row = self.run_wrapper()
        self.assertTrue(row["completed"], row)
        inner = json.loads((out / "inner.job.json").read_text())
        self.assertTrue(inner["completed"], inner)
        self.assertGreater(inner["naturalEmptyNs"] - inner["cargoExitObservedNs"], p.NANO)
        self.assertEqual(inner["activeBeforeClose"], 0)
        old = p.load_original()["load_base"]()
        direct_out = g["new_output"]("inert-direct-" + secrets.token_hex(12))
        direct = old["run_owned"](api, extended, direct_out, "command", inert_compiler_argv("linger"), os.environ.copy(), 6)
        self.assertFalse(direct["completed"], direct)
        self.assertGreater(direct["activeBeforeCleanup"], 0)
        self.assertEqual(direct["activeAfterCleanup"], 0)

    def test_neverending_member_keeps_failure_after_forced_cleanup(self):
        *_, row = self.run_wrapper(mode="forever")
        self.assertFalse(row["completed"], row)
        self.assertEqual(row["activeAfterCleanup"], 0, row)
        self.assertLessEqual(row["elapsedSeconds"], 8.5, row)

    def test_assignment_resume_query_and_wrapper_crash_do_not_orphan(self):
        for fault in ("after-create", "assignment", "resume", "query", "wrapper-crash"):
            with self.subTest(fault=fault):
                *_, row = self.run_wrapper(fault=fault)
                self.assertFalse(row["completed"], row)
                self.assertEqual(row["activeAfterCleanup"], 0, row)
                self.assertTrue(row["rootExitedAfterCleanup"], row)
                self.assertFalse(row["cleanupUnproven"], row)

    def test_output_disk_and_reader_faults_remain_failure_after_cleanup(self):
        for kwargs in ({"mode": "output", "cap": 64}, {"inject": "disk"}, {"inject": "stream"}):
            with self.subTest(kwargs=kwargs):
                *_, row = self.run_wrapper(**kwargs)
                self.assertFalse(row["completed"], row)
                self.assertEqual(row["activeAfterCleanup"], 0, row)

    def test_named_job_collision_never_terminates_or_queries_the_existing_job(self):
        p, g, api, extended, out, spec = self.prepare()
        owned_existing = api.CreateJobObjectW(None, spec["outerJobName"])
        self.assertTrue(owned_existing)
        try:
            with mock.patch.object(api, "TerminateJobObject", wraps=api.TerminateJobObject) as terminate, \
                 mock.patch.object(api, "QueryInformationJobObject", wraps=api.QueryInformationJobObject) as query:
                row = g["run_owned"](api, extended, out, "collision", inert_compiler_argv("linger"),
                                      os.environ.copy(), 6, absolute_deadline_ns=spec["deadlineNs"],
                                      job_name=spec["outerJobName"])
            self.assertFalse(row["completed"], row)
            self.assertFalse(row["startedSuspended"], row)
            terminate.assert_not_called()
            query.assert_not_called()
        finally:
            self.assertTrue(api.CloseHandle(owned_existing))


if __name__ == "__main__":
    if len(sys.argv) == 5 and sys.argv[1] == "--owned-inert-worker":
        try: code = inert_worker(sys.argv[2], sys.argv[3], sys.argv[4])
        except BaseException: code = 1
        os._exit(code)
    unittest.main()
