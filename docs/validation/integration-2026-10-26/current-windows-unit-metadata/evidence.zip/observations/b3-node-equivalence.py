from pathlib import Path
import hashlib,json,stat
root=Path.cwd()
proof=root/"docs/validation/integration-2026-10-26/editor-http-response-completion/node-checks"
before=json.loads((proof/"source-before.json").read_text(encoding="utf-8"))
after=json.loads((proof/"source-after.json").read_text(encoding="utf-8"))
assert before==after and len(before)==1135
for name,expected in before.items():
    relative=Path(name)
    assert not relative.is_absolute() and ".." not in relative.parts
    path=root/relative
    assert path.suffix.lower() not in (".exe",".pdb",".dll",".rlib",".lib",".obj",".o")
    first=path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink==1 and not first.st_file_attributes&0x400 and first.st_size<=64_000_000
    raw=path.read_bytes()
    last=path.lstat()
    assert (first.st_dev,first.st_ino,first.st_size,first.st_mtime_ns,first.st_nlink)==(last.st_dev,last.st_ino,last.st_size,last.st_mtime_ns,last.st_nlink)
    assert len(raw)==expected["bytes"] and hashlib.sha256(raw).hexdigest()==expected["sha256"],name
controls=json.loads((proof/"control-before.json").read_text(encoding="utf-8"))
assert controls==json.loads((proof/"control-after.json").read_text(encoding="utf-8")) and len(controls)==7
for name,expected in controls.items():
    raw=(root/"validation/integration-20261025/platform-repairs/control-cli"/name).read_bytes()
    assert len(raw)==expected["bytes"] and hashlib.sha256(raw).hexdigest()==expected["sha256"]
result={"scope":"exact-raw-byte-equivalence-not-a-new-test-run","actualNodeSourceCommit":"771833bb5180f3d51e092e64de5fd22c783c920a","currentNativeSourceCommit":"b3a87d5d5de32668ddf7f36f230424e5f3a3a7ca","selectedInputsEqual":1135,"originalControlsEqual":7,"actualTypecheckExitCode":0,"actualNpmPass":260,"actualNpmFail":0,"actualNpmOriginalSkips":3,"commandsRerun":False,"broaderEnvironmentOrCacheFrozen":False}
out=root/"validation/integration-20261025/platform-repairs/b3-current-source-node-equivalence.json"
assert not out.exists()
out.write_bytes((json.dumps(result,indent=2)+"\n").encode())
print(json.dumps(result))
