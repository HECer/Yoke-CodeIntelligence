"""Run reviewed compiler receipt and inert Windows lifecycle tests; no Yoke image."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import types

WORKTREE = Path("C:/Users/Lomi/Documents/NN-Developed/Yoke-CodeIntelligence")
REL = Path("validation/integration-20261025/platform-repairs")
SOURCE = "b3a87d5d5de32668ddf7f36f230424e5f3a3a7ca"
CLI = WORKTREE / REL / "control-cli/cli_controller.py"
CLI_SHA = "d6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582"
CONSUMER = WORKTREE / REL / "control-unit-lld-metadata"
PINS = {'compiler_transaction_controller.py': 'c05fc14aa4b2292ea2884b09c12a99649b66fea0e793c4e37d381d1f45241a0b', 'compiler_transaction_worker.py': '7c93d4026bcf497d1d9a10e835a3ff303fe71883acd38fc4aa392c29604a34e3', 'transaction_protocol.py': '1845cf2061981b7dd804cee5237dcc7f86fcc91f9798e8c3a01eabaeb06ef657', 'transaction_runtime.py': 'b31f3b4c1290521ea6e115d7c84c924d3368c1c65e14176810caf0dde86dd014', 'private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'test_compiler_transaction.py': 'c537f2ffbd5d90c5f6af658fb58dc56b778aa00f21dce80bc550d92c729eee19', 'review-manifest.json': '62bad632c17678edfab1ea176e49041c0decaa882c0cf97b7ef958521a2a6374', 'README.md': 'b088bd5537c7af7d039913a88496d2a8cb7665187030c0202a157a42d3bf2776', '.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'runtime-fork.patch': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6', 'v2-fork.patch': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5', 'unit-fork.patch': '06d78157ced6ae53023f0eab6656ad36f45e93c78930af61fc1adaad5ee4e2de', 'DERIVATION.md': 'd30d5ba242f6d57c27f5a31866d141a27ac8b9a89f51c03f3219869a05051e59', 'accepted-compiler-lld/compiler_transaction_controller.py': 'd6ab4fe93432a74a769e9abcdddcef40e87ef274e98fea498a219d95c2c9f29d', 'accepted-compiler-lld/compiler_transaction_worker.py': 'cf24492dafb4c30ce057a0885c5021339fc76fa3dba1e1efdddaf111fa1285fb', 'accepted-compiler-lld/transaction_protocol.py': 'eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a', 'accepted-compiler-lld/transaction_runtime.py': '1608c69131ab3374812496ee9ff855e2c906ac172d31f9899331aa33f2e98de8', 'accepted-compiler-lld/private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'accepted-compiler-lld/test_compiler_transaction.py': 'da422d730d3db84b4967fe422d8b8106ed5bb2faac05fa95b012ec5c5ee4bed9', 'accepted-compiler-lld/review-manifest.json': '141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9', 'accepted-compiler-lld/README.md': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0', 'accepted-compiler-lld/.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'accepted-compiler-lld/runtime-fork.patch': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6', 'accepted-compiler-lld/v2-fork.patch': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5', 'protected_role_metadata.py': 'a88766af3fc94bad16239e5b4bafc2e3920dc3507c3845c282d963079cb704fc', 'test_protected_role_metadata.py': 'e908ea5adff53a09153d2dd3cec197ab8cf97d9a89281118bcaab8965dd1ff29', 'accepted-unit-lld/compiler_transaction_controller.py': '27607b5542b341e5a413e3cb1ff3f5058d84b1bc006a9fa0166f8f2efd87fa06', 'accepted-unit-lld/compiler_transaction_worker.py': '9873dd7172de5628b2eb38305a0e67c9658dd05d2b614d3651746bab34e48911', 'accepted-unit-lld/transaction_protocol.py': 'ed744abf77c7e4a2852999df8c7460cfe38c88c3f8773921abdd6db16554a14f', 'accepted-unit-lld/transaction_runtime.py': '5e7e57c4a3171755d20ad184eca41871082ed220a9c77e455369b8fd8a2cb360', 'accepted-unit-lld/private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'accepted-unit-lld/test_compiler_transaction.py': 'caf8c068c68ff2e3e60c60957db8fd9fa6684ff1d9bdb058c9cc9fb60230bc24', 'accepted-unit-lld/review-manifest.json': 'e4569e2a0ff012e78c0c013ff23358f4cf652de5371f8c56260c80affdd4ded4', 'accepted-unit-lld/README.md': 'e1a6b02652d0b9d2c95cf8a8a50f16d2542d85700d3f1653fca9471df8554a87', 'accepted-unit-lld/.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'accepted-unit-lld/runtime-fork.patch': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6', 'accepted-unit-lld/v2-fork.patch': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5', 'accepted-unit-lld/unit-fork.patch': '3a85f420dc5290bdc520b0ff9cb2c265747e33a322de9356da8119b21fe0e2b9', 'accepted-unit-lld/DERIVATION.md': '0979a73ca65c26582481c7463bf85310a8dc9e211c8d917cb7cfffe35d063ef9', 'accepted-unit-lld/accepted-compiler-lld/compiler_transaction_controller.py': 'd6ab4fe93432a74a769e9abcdddcef40e87ef274e98fea498a219d95c2c9f29d', 'accepted-unit-lld/accepted-compiler-lld/compiler_transaction_worker.py': 'cf24492dafb4c30ce057a0885c5021339fc76fa3dba1e1efdddaf111fa1285fb', 'accepted-unit-lld/accepted-compiler-lld/transaction_protocol.py': 'eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a', 'accepted-unit-lld/accepted-compiler-lld/transaction_runtime.py': '1608c69131ab3374812496ee9ff855e2c906ac172d31f9899331aa33f2e98de8', 'accepted-unit-lld/accepted-compiler-lld/private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'accepted-unit-lld/accepted-compiler-lld/test_compiler_transaction.py': 'da422d730d3db84b4967fe422d8b8106ed5bb2faac05fa95b012ec5c5ee4bed9', 'accepted-unit-lld/accepted-compiler-lld/review-manifest.json': '141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9', 'accepted-unit-lld/accepted-compiler-lld/README.md': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0', 'accepted-unit-lld/accepted-compiler-lld/.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'accepted-unit-lld/accepted-compiler-lld/runtime-fork.patch': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6', 'accepted-unit-lld/accepted-compiler-lld/v2-fork.patch': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5'}
V2_PINS = {'compiler_transaction_controller.py': {'bytes': 12692, 'sha256': '8a4e6a14b3354fa9e822ffaf3b43147b4bd3a1daba5b1a78f6d5df02fe8570db'}, 'compiler_transaction_worker.py': {'bytes': 1608, 'sha256': 'aa4d531fc5a4d4f8176ef6d61c7003375f573b8c6d0974a209f51aa1457a397f'}, 'transaction_protocol.py': {'bytes': 33932, 'sha256': '1f36c8c159bbcee87dc5adcd8e2ef78372e046d082237faa8b24e4e26324010c'}, 'transaction_runtime.py': {'bytes': 44163, 'sha256': '00e02c00c22eb540eca9eb971b533bcc52566015e3a3963ccef76c7320401513'}, 'private_windows_api.py': {'bytes': 2146, 'sha256': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500'}, 'test_compiler_transaction.py': {'bytes': 29502, 'sha256': 'acfb8914cac9e4dc49cadb14044b5d45eedc7de3373f8c5def5029f6d2f53c0c'}, 'review-manifest.json': {'bytes': 6103, 'sha256': 'b1b681c3bb78b6f7117d37ea70e0b4129e08c16d730a5007e89b90293d783f37'}, 'README.md': {'bytes': 8304, 'sha256': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0'}, '.gitattributes': {'bytes': 14, 'sha256': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9'}, 'runtime-fork.patch': {'bytes': 5286, 'sha256': '2a72d74ef199ca1cf8454df1ee8005e72b1debf926ee69d81e956d5f347df93f'}}


def source_bytes(path):
    assert path.suffix.lower() not in (".exe", ".pdb", ".dll", ".lib", ".obj", ".o")
    info = path.lstat()
    assert info.st_size <= 1_000_000 and info.st_nlink == 1
    assert not getattr(info, "st_file_attributes", 0) & 0x400
    return path.read_bytes()


def consumer_map():
    result = {}
    for name, expected in PINS.items():
        data = source_bytes(CONSUMER / name)
        digest = hashlib.sha256(data).hexdigest()
        assert digest == expected, name
        result[name] = {"bytes": len(data), "sha256": digest}
    return result


def v2_map():
    result = {}
    for name, expected in V2_PINS.items():
        data = source_bytes(CONSUMER.parent / "control-compiler-transaction" / name)
        observed = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        assert observed == expected, name
        result[name] = observed
    return result


def main():
    assert os.name == "nt" and len(sys.argv) == 1
    data = source_bytes(CLI)
    assert hashlib.sha256(data).hexdigest() == CLI_SHA
    module = types.ModuleType("reviewed_private_release_cli_for_compiler_inert_tests")
    module.__file__ = str(CLI)
    exec(compile(data, str(CLI), "exec"), module.__dict__)
    g = module.load_base()
    assert g["ROOT"] == WORKTREE
    g.update(RUNS=WORKTREE / REL / "runs-unit-lld-guard-tests", OWNER="unit-lld-source-guard-tests-v1")
    api, extended = g["load_windows_api"]()
    out = g["new_output"]("unit-lld-metadata-guard-tests-b3-r1")
    result = {
        "sourceCommit": SOURCE, "completed": False, "testMethodsExpected": 116,
        "nativeImageRead": False, "nativeImageExecuted": False,
        "actualArchiveAcceptance": False, "releaseQualification": False,
    }
    before_driver = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    mutex = None
    owned = False
    try:
        import _winapi
        name = "Local\\YokeValidation-" + hashlib.sha256(str(WORKTREE).encode()).hexdigest()[:24]
        mutex = api.CreateMutexW(None, False, name)
        assert mutex
        wait = _winapi.WaitForSingleObject(mutex, 0)
        assert wait in (0, 128), "Another validation controller is active"
        owned = True
        result["serialMutexAbandoned"] = wait == 128
        environment = g["environment_for"]("build")
        sources = g["source_map"](api, extended, out, environment, SOURCE, "before")
        controls = g["controls_map"]()
        consumer = consumer_map()
        v2_before = v2_map()
        g["write_json"](out, "v2-before.json", v2_before)
        g["write_json"](out, "control-before.json", controls)
        g["write_json"](out, "consumer-before.json", consumer)
        command = [sys.executable, "-B", "-m", "unittest", "discover", "-s", str(CONSUMER),
                   "-p", "test_*.py", "-v"]
        job = g["run_owned"](api, extended, out, "tests", command, environment, 180)
        assert job["completed"] and job["exitCode"] == 0
        assert job["treeExitedBeforeCleanup"] and job["activeBeforeCleanup"] == 0
        assert job["activeAfterCleanup"] == 0 and job["rootExitedAfterCleanup"]
        assert job["cleanupUnproven"] is False
        stderr = (out / "tests.stderr").read_bytes()
        assert re.search(rb"Ran 116 tests in [0-9.]+s", stderr)
        assert re.search(rb"\nOK\r?\n", stderr) and b"skipped=" not in stderr
        after = g["source_map"](api, extended, out, environment, SOURCE, "after")
        after_controls = g["controls_map"]()
        after_consumer = consumer_map()
        v2_after = v2_map()
        g["write_json"](out, "v2-after.json", v2_after)
        assert v2_after == v2_before
        g["write_json"](out, "control-after.json", after_controls)
        g["write_json"](out, "consumer-after.json", after_consumer)
        assert sources == after and controls == after_controls and consumer == after_consumer
        assert before_driver == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        result.update(completed=True, testsPassed=116, testsSkipped=0,
                      sourceInputs=len(sources), sourcesUnchanged=True,
                      originalControlsUnchanged=True, transactionControlsUnchanged=True, actualCargoBuild=False, actualVersion=False, actualHistory=False,
                      driverSha256=before_driver, jobTreeExitedBeforeCleanup=True)
    except BaseException as error:
        result.update(completed=False, errorType=type(error).__name__)
    finally:
        if owned:
            if not api.ReleaseMutex(mutex):
                result.update(completed=False, mutexReleaseFailed=True)
        if mutex:
            if not api.CloseHandle(mutex):
                result.update(completed=False, mutexCloseFailed=True)
        g["write_json"](out, "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
