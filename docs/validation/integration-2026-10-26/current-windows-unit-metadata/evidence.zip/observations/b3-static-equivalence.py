from pathlib import Path
import ast,hashlib,json
base=Path.cwd()/"validation/integration-20261025/platform-repairs"
old=base/"control-unit-lld";new=base/"control-unit-lld-metadata"
allowed_functions={"transaction_runtime.py":{"controls_map"},"transaction_protocol.py":{"protected_pins","protected_recheck","producer_admission","load_protected"},"compiler_transaction_controller.py":set(),"compiler_transaction_worker.py":set()}
allowed_assignments={"transaction_runtime.py":{"OWNER","SCHEMA","CONTROL","RUNS","CONTROL_NAMES","ACCEPTED_UNIT_LLD_PINS"},"transaction_protocol.py":{"OWNER","SCHEMA","CONTROL","RUNS","RUNTIME_SHA","METADATA_SHA"},"compiler_transaction_controller.py":{"PROTOCOL_SHA"},"compiler_transaction_worker.py":{"PROTOCOL_SHA"}}
checked={}
for name in allowed_functions:
    before=ast.parse((old/name).read_text(encoding="utf-8"));after=ast.parse((new/name).read_text(encoding="utf-8"))
    defs=lambda tree:{node.name:ast.dump(node,include_attributes=False) for node in tree.body if isinstance(node,(ast.FunctionDef,ast.ClassDef))}
    a=defs(before);b=defs(after)
    for function in set(a)|set(b):
        if function not in allowed_functions[name]:
            assert a.get(function)==b.get(function),(name,function)
    assigns=lambda tree:{node.targets[0].id:ast.dump(node.value,include_attributes=False) for node in tree.body if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name)}
    x=assigns(before);y=assigns(after)
    for key in set(x)|set(y):
        if key not in allowed_assignments[name]:
            assert x.get(key)==y.get(key),(name,key)
    checked[name]={"unchangedTopLevelFunctionsAndClasses":len(set(a)-allowed_functions[name]),"onlyAllowedFunctionDeltas":sorted(allowed_functions[name]),"onlyAllowedPolicyAndPinDeltas":sorted(allowed_assignments[name])}
before=ast.parse((old/"test_compiler_transaction.py").read_text(encoding="utf-8"));after=ast.parse((new/"test_compiler_transaction.py").read_text(encoding="utf-8"))
def tests(tree):
    return {(cls.name,method.name):ast.dump(method,include_attributes=False) for cls in tree.body if isinstance(cls,ast.ClassDef) for method in cls.body if isinstance(method,ast.FunctionDef) and method.name.startswith("test_")}
a=tests(before);b=tests(after)
assert all(b.get(key)==value for key,value in a.items())
manifest=json.loads((new/"review-manifest.json").read_text(encoding="utf-8"))
for name,expected in manifest["acceptedUnitLldSnapshot"].items():
    actual=(new/"accepted-unit-lld"/name).read_bytes()
    assert hashlib.sha256(actual).hexdigest()==expected["sha256"] and len(actual)==expected["bytes"]
print(json.dumps({"unchangedPolicyFunctions":checked,"allOriginalTestMethodBodiesRetained":len(a),"newProtocolTestMethods":len(set(b)-set(a)),"snapshotFilesByteExact":len(manifest["acceptedUnitLldSnapshot"]),"limitsCommandsProfilesAndLifecycleOutsideMetadataUnchanged":True}))
