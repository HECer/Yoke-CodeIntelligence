from pathlib import Path
import ctypes as c,hashlib,json,os,msvcrt
path=Path.cwd()/"validation/integration-20261025/platform-repairs/control-unit-lld/compiler_transaction_controller.py"
raw=path.read_bytes()
assert hashlib.sha256(raw).hexdigest()=="27607b5542b341e5a413e3cb1ff3f5058d84b1bc006a9fa0166f8f2efd87fa06"
n={"__name__":"reviewed_b3_handle_observation_diagnostic","__file__":str(path)}
exec(compile(raw,str(path),"exec"),n)
p=n["protocol"]();g=p.load_runtime();original=p.load_original();api,_=g["load_windows_api"]()
mutex=n["acquire_mutex"](p,api)
target=Path.cwd()/original["PROTECTED_RELATIVE"][0]
handle=None;fd=None
try:
    before=original["MetadataPin"].observation(target.lstat())
    handle=api.CreateFileW(str(target),0xA0,1,None,3,0x00200000,None)
    assert handle not in (None,-1,(1<<64)-1)
    fd=msvcrt.open_osfhandle(handle,os.O_RDONLY|os.O_BINARY)
    handle=None
    held=original["MetadataPin"].observation(os.fstat(fd))
    after=original["MetadataPin"].observation(target.lstat())
    assert before==after
    difference={key:{"path":before[key],"held":held[key]} for key in before if before[key]!=held[key]}
    print(json.dumps({"role":str(target.relative_to(Path.cwd())),"desiredAccess":"FILE_EXECUTE|FILE_READ_ATTRIBUTES","dataReadAccessRequested":False,"imageBytesRead":False,"imageExecuted":False,"metadataUnchanged":True,"differences":difference,"sameFileIdentity":(before["device"],before["inode"])==(held["device"],held["inode"]),"sameBytesAndMtime":(before["bytes"],before["mtimeNs"])==(held["bytes"],held["mtimeNs"])}))
finally:
    if fd is not None:os.close(fd)
    if handle is not None:api.CloseHandle(handle)
    n["release_mutex"](p,api,mutex)
