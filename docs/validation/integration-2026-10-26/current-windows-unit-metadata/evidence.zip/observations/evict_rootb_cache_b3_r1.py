"""Closed, task-owned Cargo cache eviction; metadata only, never native payloads."""
from pathlib import Path
import ctypes as c
import hashlib,json,os,shutil,stat,subprocess,sys
PRIMARY=Path("C:/Users/Lomi/Documents/NN-Developed/Yoke-CodeIntelligence")
ROOT=Path("C:/Users/Lomi/.t3/worktrees/Yoke-CodeIntelligence/t3-b1973677")
TARGET=ROOT/"target"
OUT=PRIMARY/"validation/integration-20261025/platform-repairs/cache-eviction-rootb-b3-r1"
SUFFIXES={".rlib",".rmeta",".o",".obj",".bc"}
ROOT_HEAD="704b647d625dcc5f359386b20834d329ffb6cdf4"
K=c.WinDLL("kernel32",use_last_error=True)
K.CreateMutexW.argtypes=[c.c_void_p,c.c_int,c.c_wchar_p];K.CreateMutexW.restype=c.c_void_p
K.ReleaseMutex.argtypes=[c.c_void_p];K.ReleaseMutex.restype=c.c_int
K.CloseHandle.argtypes=[c.c_void_p];K.CloseHandle.restype=c.c_int
K.GetCompressedFileSizeW.argtypes=[c.c_wchar_p,c.POINTER(c.c_ulong)];K.GetCompressedFileSizeW.restype=c.c_ulong
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def info(path,directory=False):
    value=path.lstat()
    need(not getattr(value,"st_file_attributes",0)&0x400,"reparse")
    need(stat.S_ISDIR(value.st_mode) if directory else stat.S_ISREG(value.st_mode),"type")
    need(value.st_dev>0 and value.st_ino>0,"identity")
    return value
def route(path):
    result=[]
    for parent in reversed(path.parents):
        value=info(parent,True)
        result.append([str(parent),value.st_dev,value.st_ino,value.st_mode,value.st_file_attributes])
    return result
def record(path):
    value=info(path)
    return {"path":str(path),"device":value.st_dev,"inode":value.st_ino,"bytes":value.st_size,"mtimeNs":value.st_mtime_ns,"links":value.st_nlink,"mode":value.st_mode,"attributes":value.st_file_attributes}
def git(*args):
    return subprocess.check_output(["git","-C",str(ROOT),*args],timeout=10)
def project():
    need(git("rev-parse","HEAD").decode().strip()==ROOT_HEAD,"root-head")
    need(not git("status","--porcelain=v1","--untracked-files=no"),"root-dirty")
    common=Path(git("rev-parse","--path-format=absolute","--git-common-dir").decode().strip())
    need(common==PRIMARY/".git","foreign-project")
    need(not git("ls-files","-z","--","target"),"tracked-target")
def take_mutexes():
    handles=[]
    try:
        for root in sorted((ROOT,PRIMARY),key=str):
            c.set_last_error(0)
            handle=K.CreateMutexW(None,True,"Local\\YokeValidation-"+hashlib.sha256(str(root).encode()).hexdigest()[:24])
            error=c.get_last_error()
            need(handle not in (None,-1,(1<<64)-1),"mutex")
            if error==183:
                need(K.CloseHandle(handle),"occupied-mutex-close")
                raise RuntimeError("occupied-owner")
            handles.append(handle)
        return handles
    except BaseException:
        close_mutexes(handles)
        raise
def close_mutexes(handles):
    errors=[]
    for handle in reversed(handles):
        if not K.ReleaseMutex(handle):errors.append("release")
        if not K.CloseHandle(handle):errors.append("close")
    need(not errors,"mutex-close")
def storage(path):
    high=c.c_ulong()
    c.set_last_error(0)
    low=K.GetCompressedFileSizeW(str(path),c.byref(high))
    need(not (low==0xffffffff and c.get_last_error()!=0),"storage-unavailable")
    return (high.value<<32)|low
def scan():
    dirs={};candidates=[];retained=[]
    def walk(path):
        value=info(path,True)
        dirs[str(path)]=[value.st_dev,value.st_ino,value.st_mode,value.st_file_attributes]
        with os.scandir(path) as entries:
            paths=sorted((Path(entry.path) for entry in entries),key=str)
        for child in paths:
            value=child.lstat()
            need(not value.st_file_attributes&0x400,"reparse")
            if stat.S_ISDIR(value.st_mode):
                walk(child)
            else:
                first=record(child)
                if child.suffix.lower() in SUFFIXES and first["links"]==1:
                    first["storageBytes"]=storage(child)
                    need({k:v for k,v in first.items() if k!="storageBytes"}==record(child),"unstable-cache")
                    candidates.append(first)
                else:retained.append(first)
    walk(TARGET)
    return dirs,candidates,retained
def json_bytes(value):
    return (json.dumps(value,indent=2,sort_keys=True)+"\n").encode()
def write_new(name,value):
    path=OUT/name
    need(not path.exists(),"occupied-receipt")
    with path.open("xb") as stream:stream.write(json_bytes(value))
def main():
    need(os.name=="nt" and sys.argv[1:] and sys.argv[1] in ("plan","apply"),"arguments")
    mode=sys.argv[1]
    need((mode=="plan" and len(sys.argv)==2) or (mode=="apply" and len(sys.argv)==3 and len(sys.argv[2])==64),"arguments")
    need(TARGET.is_absolute() and os.path.normpath(str(TARGET))==str(TARGET),"root-path")
    root_route=route(TARGET)
    locks=take_mutexes()
    result=None
    try:
        project()
        if mode=="plan":
            need(not OUT.exists(),"occupied-output")
            OUT.mkdir(parents=True)
            dirs,candidates,retained=scan()
            need(candidates and len(candidates)<=20000,"cache-count")
            manifest={"scope":"same-project-single-link-reproducible-cache-only","root":str(TARGET),"rootHead":ROOT_HEAD,"rootRoute":root_route,"directories":dirs,"files":candidates,"retainedTargetFiles":retained,"freeBefore":shutil.disk_usage("C:/").free,"payloadBytesRead":False}
            write_new("manifest.json",manifest)
            raw=(OUT/"manifest.json").read_bytes()
            result={"planned":True,"files":len(candidates),"logicalBytes":sum(row["bytes"] for row in candidates),"reportedStorageBytes":sum(row["storageBytes"] for row in candidates),"manifestSha256":hashlib.sha256(raw).hexdigest(),"freeBefore":manifest["freeBefore"],"payloadBytesRead":False,"filesDeleted":False}
        else:
            raw=(OUT/"manifest.json").read_bytes()
            need(hashlib.sha256(raw).hexdigest()==sys.argv[2],"manifest-drift")
            manifest=json.loads(raw)
            need(manifest["root"]==str(TARGET) and manifest["rootHead"]==ROOT_HEAD and root_route==manifest["rootRoute"],"root-drift")
            dirs,candidates,retained=scan()
            need(dirs==manifest["directories"] and candidates==manifest["files"] and retained==manifest["retainedTargetFiles"],"inventory-drift")
            write_new("deletion-intent.json",{"manifestSha256":sys.argv[2],"files":len(candidates),"logicalBytes":sum(row["bytes"] for row in candidates),"onlyIndividualUnlinks":True})
            removed=0;removed_bytes=0
            try:
                for row in candidates:
                    path=Path(row["path"])
                    relative=path.relative_to(TARGET)
                    need(relative.parts and ".." not in relative.parts and path.suffix.lower() in SUFFIXES,"path-escape")
                    need(route(path)==route(TARGET)+[[str(parent),*manifest["directories"][str(parent)]] for parent in list(reversed(path.parents)) if parent==TARGET or TARGET in parent.parents],"route-drift")
                    current=record(path)
                    need(current=={key:value for key,value in row.items() if key!="storageBytes"} and current["links"]==1,"cache-drift")
                    path.unlink()
                    removed+=1;removed_bytes+=row["bytes"]
                for row in retained:need(record(Path(row["path"]))==row,"retained-target-drift")
                for name,expected in dirs.items():
                    value=info(Path(name),True)
                    need([value.st_dev,value.st_ino,value.st_mode,value.st_file_attributes]==expected,"directory-drift")
                project()
                result={"completed":True,"filesRemoved":removed,"logicalBytesRemoved":removed_bytes,"freeAfter":shutil.disk_usage("C:/").free,"sourceGitClean":True,"retainedTargetFilesUnchanged":len(retained),"allDirectoriesPreserved":True,"payloadBytesRead":False,"nativeImagesTouched":False}
            except BaseException as error:
                result={"completed":False,"filesRemoved":removed,"logicalBytesRemoved":removed_bytes,"errorType":type(error).__name__,"error":str(error),"freeAfter":shutil.disk_usage("C:/").free}
                write_new("result.json",result)
                raise
            write_new("result.json",result)
    finally:
        close_mutexes(locks)
    print(json.dumps(result),flush=True)
if __name__=="__main__":main()
