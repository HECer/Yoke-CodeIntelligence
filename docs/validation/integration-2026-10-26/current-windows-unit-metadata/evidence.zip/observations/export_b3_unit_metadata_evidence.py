"""Export an explicit text/source/metadata allowlist, never native payloads."""
from pathlib import Path
import hashlib
import json
import re
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'validation/integration-20261025/platform-repairs'
OUT = ROOT / 'docs/validation/integration-2026-10-26/current-windows-unit-metadata'
SOURCE = 'b3a87d5d5de32668ddf7f36f230424e5f3a3a7ca'
ALLOWED = {'.py', '.json', '.md', '.patch', '.stdout', '.stderr'}
RUNS = [
    'runs-unit-lld-guard-tests/unit-lld-guard-tests-b3-r1',
    'runs-unit-lld-guard-tests/unit-lld-metadata-guard-tests-b3-r1',
    'runs-unit-lld-fixed-output/unit-lib-build-b3-r1',
    'runs-unit-lld-metadata-only/protected-roles-b3-r1',
    'runs-unit-lld-metadata/unit-lib-build-b3-metadata-r1',
    'runs-unit-lld-metadata/post-refusal-b3-r1',
    'runs-unit-lld-metadata/unit-lib-build-b3-metadata-r2',
    'runs-unit-lld-metadata/unit-lib-test-b3-metadata-r1',
    'runs-unit-lld-metadata/unit-cli-build-b3-metadata-r1',
    'runs-unit-lld-metadata/unit-cli-test-b3-metadata-r1',
    'runs/clippy-b3-r1',
]


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read_text_file(path):
    require(path.is_relative_to(ROOT), 'Outside primary root')
    for ancestor in [path, *path.parents]:
        info = ancestor.lstat()
        require(not stat.S_ISLNK(info.st_mode) and not info.st_file_attributes & 0x400,
                'Linked or reparse export route')
        if ancestor == ROOT:
            break
    first = path.lstat()
    require(stat.S_ISREG(first.st_mode) and first.st_size <= 16_000_000,
            'Export is not bounded regular text')
    require(path.suffix.lower() in ALLOWED or path.name == '.gitattributes',
            'Non-text export denied')
    raw = path.read_bytes()
    raw.decode('utf-8')
    last = path.lstat()
    observation = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size,
                              s.st_mtime_ns, s.st_nlink, s.st_file_attributes)
    require(observation(first) == observation(last), 'Export source changed')
    return raw


def load(path):
    return json.loads(read_text_file(path))


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def main():
    require(ROOT == Path.cwd() and not OUT.exists(), 'Fresh correct-root output required')
    results = {run: load(BASE / run / 'result.json') for run in RUNS}
    for name in ('unit-lib-build-b3-metadata-r2', 'unit-lib-test-b3-metadata-r1',
                 'unit-cli-build-b3-metadata-r1', 'unit-cli-test-b3-metadata-r1'):
        result = results['runs-unit-lld-metadata/' + name]
        require(result['completed'] is True and result['sourceCommit'] == SOURCE
                and result['schema'] == 6 and result['inputsUnchanged'] is True
                and result['protectedMetadataUnchanged'] is True, 'Unaccepted native run')
        job = load(BASE / 'runs-unit-lld-metadata' / name / 'outer.job.json')
        require(job['completed'] is True and job['treeExitedBeforeCleanup'] is True
                and job['activeBeforeCleanup'] == 0 and job['activeAfterCleanup'] == 0
                and job['cleanupUnproven'] is False and job['streamEOF'] == [True, True]
                and job['readerErrors'] == [False, False], 'Incomplete native lifecycle')
    lib = results['runs-unit-lld-metadata/unit-lib-test-b3-metadata-r1']['testSummary']
    cli = results['runs-unit-lld-metadata/unit-cli-test-b3-metadata-r1']['testSummary']
    require((lib['passed'], lib['failed'], lib['ignored'], lib['filteredOut']) == (773, 0, 7, 0)
            and (cli['passed'], cli['failed'], cli['ignored'], cli['filteredOut']) == (16, 0, 0, 0),
            'Unexpected actual suite counts')
    candidates = []
    def add(path, name):
        candidates.append((path, name))
    for directory in ('control-unit-lld-metadata', 'control-cli', 'control', 'control-compiler-transaction'):
        root = BASE / directory
        # This list covers only known source bundles. No run/target tree recursion.
        for path in sorted(root.rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                require(path.suffix.lower() in ALLOWED or path.name == '.gitattributes',
                        'Unexpected control file')
                add(path, 'controls/' + directory + '/' + path.relative_to(root).as_posix())
    omissions = []
    nonces = set()
    for run in RUNS:
        directory = BASE / run
        for path in sorted(directory.iterdir()):
            if not path.is_file():
                continue
            if path.name == 'worker-spec.json':
                omissions.append({'path': str(path.relative_to(ROOT)),
                                  'reason': 'private worker protocol not exported'})
                continue
            if path.suffix.lower() not in ALLOWED:
                # File names/metadata are not payload reads. Never open native images.
                continue
            raw = read_text_file(path)
            if path.name.startswith('git-files-') and path.suffix == '.stdout':
                omissions.append({'path': str(path.relative_to(ROOT)), 'bytes': len(raw),
                                  'sha256': digest(raw), 'reason': 'redundant full Git listing'})
                continue
            for value in re.findall(r'Local\\+Yoke[A-Za-z0-9]+-[0-9a-f]{48,128}', raw.decode('utf-8')):
                nonces.add(value)
            add(path, 'runs/' + run + '/' + path.name)
    for name in ('b3-current-source-node-equivalence.json', 'b3-node-equivalence.py',
                 'b3-static-equivalence.json', 'b3-static-equivalence.py',
                 'b3-metadata-mode-difference.json', 'b3-metadata-mode-difference.py',
                 'b3-metadata-pin-diagnosis.json', 'run_unit_lld_guard_tests_b3_r1.py',
                 'run_unit_lld_metadata_guard_tests_b3_r1.py', 'evict_rootb_cache_b3_r1.py',
                 'export_b3_unit_metadata_evidence.py'):
        add(BASE / name, 'observations/' + name)
    for name in ('result.json', 'deletion-intent.json'):
        add(BASE / 'cache-eviction-rootb-b3-r1' / name, 'cache-eviction/' + name)
    cache_manifest = BASE / 'cache-eviction-rootb-b3-r1/manifest.json'
    cache_raw = read_text_file(cache_manifest)
    omissions.append({'path': str(cache_manifest.relative_to(ROOT)), 'bytes': len(cache_raw),
                      'sha256': digest(cache_raw), 'reason': 'full private deletion inventory retained locally'})
    records = []
    payloads = []
    for path, name in sorted(candidates, key=lambda pair: pair[1]):
        require('..' not in Path(name).parts and not Path(name).is_absolute(), 'Unsafe member')
        raw = read_text_file(path)
        text = raw.decode('utf-8')
        original_sha = digest(raw)
        changed = False
        for nonce in sorted(nonces, key=len, reverse=True):
            if nonce in text:
                require(not name.startswith('controls/'), 'Unexpected nonce in source')
                text = text.replace(nonce, '<private-owned-job-name-redacted>')
                changed = True
        require(not re.search(r'Local\\+Yoke[A-Za-z0-9]+-[0-9a-f]{48,128}', text), 'Nonce remains')
        public = text.encode('utf-8') if changed else raw
        records.append({'name': name, 'bytes': len(public), 'sha256': digest(public),
                        'origin': path.relative_to(ROOT).as_posix(),
                        'representation': 'job-name-redacted-public-view' if changed else 'byte-exact',
                        'originalBytes': len(raw), 'originalSha256': original_sha})
        payloads.append((name, public))
    require(len({name for name, _ in payloads}) == len(payloads), 'Duplicate ZIP member')
    require(len(payloads) <= 1200 and sum(len(raw) for _, raw in payloads) <= 40_000_000,
            'Export budget exceeded')
    OUT.mkdir(parents=True)
    archive = OUT / 'evidence.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, raw in payloads:
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 26, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, raw)
    with zipfile.ZipFile(archive) as z:
        require(z.namelist() == [r['name'] for r in records], 'ZIP index differs')
        for item in records:
            raw = z.read(item['name'])
            require(len(raw) == item['bytes'] and digest(raw) == item['sha256'], 'ZIP bytes differ')
    checks = {'sourceCommit': SOURCE, 'platform': 'Windows x86_64',
              'library': lib, 'cliUnit': cli,
              'protocolGuards': {'passed': 116, 'skipped': 0, 'nativeRuntimeCoverage': False},
              'actualProtectedRoleCount': 10,
              'clippy': {'completed': True, 'warningsDenied': True, 'workspaceAllTargets': True,
                         'artifactObservationsMetadataOnly': 757},
              'node': load(BASE / 'b3-current-source-node-equivalence.json'),
              'priorFailedAttemptsRetained': ['schema5-protected-metadata-mode', 'schema6-disk-reserve'],
              'releaseQualification': False, 'vsixQualification': False,
              'hostedOrUnixAcceptance': False, 'fullProjectComplete': False}
    (OUT / 'checks.json').write_bytes(encoded(checks))
    index = {'sourceCommit': SOURCE, 'scope': 'text/source/metadata evidence only',
             'archive': {'name': 'evidence.zip', 'bytes': archive.stat().st_size,
                         'sha256': digest(archive.read_bytes()), 'members': len(records),
                         'expandedBytes': sum(item['bytes'] for item in records)},
             'members': records, 'omissions': omissions,
             'privateOriginalProducerProofs': 'Held and admitted locally; public views omit worker specs and redact named Job nonces; this packet alone is not a runnable relocated producer.'}
    (OUT / 'index.json').write_bytes(encoded(index))
    (OUT / '.gitattributes').write_bytes(b'evidence.zip binary\n*.json -text\n*.md text eol=lf\n')
    print(json.dumps({'output': str(OUT), **index['archive']}))


if __name__ == '__main__':
    main()
