"""Authored source/mock/inert-text ZIP tests; no native image or host execution."""
from contextlib import ExitStack
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import time
import types
import unittest
from unittest import mock
import warnings
import zipfile


HERE = Path(__file__).absolute().parent


def module(name, path):
    value = types.ModuleType(name)
    value.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), "exec"), value.__dict__)
    return value


def controller():
    return module("inert_package_test_controller", HERE / "package_vscode_controller.py")


def row(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def zipped(files):
    stream = io.BytesIO()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, data in files:
                info = zipfile.ZipInfo(name)
                info.create_system = 3
                info.external_attr = 0o100644 << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, data)
    return stream.getvalue()


def fixture(p):
    binary = b"Labeled inert executable text; never executed."
    notice = b"Synthetic pinned notice\r\n"
    own = b"Synthetic own license\n"
    readme = b"Synthetic generated portable README\n"
    package = json.dumps({"name": "code-intelligence-local", "publisher": "hecer", "version": "0.5.0"}).encode()
    inputs = {"nativeMembers": {"LICENSE": "LICENSE"},
              "extensionMembers": {"extension/LICENSE": "LICENSE", "extension/package.json": "extensions/vscode/package.json"},
              "files": {"LICENSE": row(own), "extensions/vscode/package.json": row(package)}}
    manifest = {"name": "yoke-code-intelligence", "version": "0.5.0", "target": p.TARGET,
                "binarySha256": row(binary)["sha256"],
                "dependencyScope": "Cargo resolved native build graph, including build-time crates; not a runtime module-load claim",
                "dependencies": [{"name": "fixture", "version": "1.0.0", "spdx": "MIT", "repository": "https://github.com/owner/fixture",
                    "licenseTexts": [{"path": "licenses/fixture-1.0.0/LICENSE", "source": "locked-crate-package", "sha256": row(notice)["sha256"]}]}]}
    files = {"yoke.exe": binary, "README.md": readme, "LICENSE": own,
             "licenses/fixture-1.0.0/LICENSE": notice, "manifest.json": json.dumps(manifest).encode()}
    identity = ("<Identity Language=\"en-US\" Id=\"code-intelligence-local\" Version=\"0.5.0\" "
                "Publisher=\"hecer\" TargetPlatform=\"win32-x64\" />")
    xml = ("<PackageManifest xmlns=\"" + p.VSX + "\"><Metadata>" + identity + "</Metadata></PackageManifest>").encode()
    vsix = {"extension.vsixmanifest": xml, "[Content_Types].xml": b"<Types/>",
            "extension/LICENSE": own, "extension/package.json": package}
    vsix.update({"extension/runtime/native/" + name: data for name, data in files.items()})
    return inputs, files, vsix, manifest, row(binary), row(readme)["sha256"]


def valid_job(p, command=None, seconds=190):
    command = ["fixed-inert-host"] if command is None else command
    start = 100_000_000_000
    deadline = start + seconds * 1_000_000_000
    return {"command": command, "deadlineSeconds": seconds, "logCapBytes": 16_000_000,
            "stdinClosed": True, "startedSuspended": True, "assignedBeforeResume": True,
            "completed": True, "treeExitedBeforeCleanup": True, "minimumFreeObserved": 2_000_000_000,
            "cleanupErrors": [], "streamEOF": [True, True], "readerErrors": [False, False],
            "startedMonotonicNs": start, "absoluteDeadlineNs": deadline, "jobName": None,
            "namedJobCreatedNew": False, "pid": 123, "resumePreviousSuspendCount": 1, "exitCode": 0,
            "rootObservedMonotonicNs": start + 1_000_000_000, "membersAtRootObservation": [],
            "rootExitedAtObservation": True, "activeAtRootObservation": 0, "originalDrainSeconds": 1,
            "activeBeforeCleanup": 0, "membersAfterOriginalDrain": [], "treeObservedMonotonicNs": start + 1_000_000_001,
            "cleanupSeconds": 2, "activeAfterCleanup": 0, "rootExitedAfterCleanup": True,
            "elapsedSeconds": 1.1, "capturedLogBytes": 0, "outputExceeded": False, "cleanupUnproven": False}


def host_result():
    return {"kind": "actual-vscode-extension-host", "passed": True, "runtime": "rust", "bundledRuntime": True,
            "vscodeVersion": "1.143.1", "unsavedSourceBound": True, "workspaceExecutableIgnored": True,
            "protectedOpenBufferExcluded": True, "savedSourceUnchanged": True}


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.p = controller()
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.code = Path(self.directory.name) / "Code.exe"
        self.code.write_bytes(b"Owned inert host-tool selector text; never executed")

    def test_closed_arguments_require_exact_source_and_separate_build_version_roles(self):
        args = ["--source-commit", self.p.SOURCE_COMMIT, "--run-id", "package-one",
                "--producer-run-id", "producer-one", "--version-run-id", "version-one",
                "--code-executable", str(self.code)]
        self.assertFalse(self.p.options(args).fetch_missing_licenses)
        self.assertTrue(self.p.options(args + ["--fetch-missing-licenses"]).fetch_missing_licenses)
        changes = [args + ["--image", "anything"], args + ["--fetch-missing-licenses"] * 2,
                   args + ["--run-id", "other"], args[:-2], ["--source-commit", "f" * 40, *args[2:]],
                   [*args[:7], "producer-one", *args[8:]], [*args[:3], "../escape", *args[4:]]]
        for changed in changes:
            with self.subTest(arguments=changed), self.assertRaises(self.p.Refusal): self.p.options(changed)

    def test_code_selector_is_explicit_local_metadata_only_and_has_no_unavailable_default(self):
        with mock.patch.object(Path, "read_bytes", side_effect=AssertionError("Tool image bytes must not be read")):
            path, observed = self.p.code_selector(self.code)
        self.assertEqual(path, self.code)
        self.assertFalse(observed["imageBytesRead"])
        self.assertTrue(observed["noReparseAncestors"])
        for value in ("relative/Code.exe", str(self.code.parent / "yoke.exe"), "Z:/foreign/Code.exe"):
            with self.subTest(selector=value), self.assertRaises(self.p.Refusal): self.p.code_selector(value)
        args = ["--source-commit", self.p.SOURCE_COMMIT, "--run-id", "package-one",
                "--producer-run-id", "producer-one", "--version-run-id", "version-one"]
        with self.assertRaises(self.p.Refusal): self.p.options(args)

    def test_reparse_code_selector_refuses_before_any_tool_execution(self):
        original = Path.lstat
        def changed(path):
            info = original(path)
            if path != self.code: return info
            return types.SimpleNamespace(st_mode=info.st_mode, st_ino=info.st_ino, st_dev=info.st_dev,
                st_nlink=info.st_nlink, st_size=info.st_size, st_mtime_ns=info.st_mtime_ns,
                st_file_attributes=getattr(info, "st_file_attributes", 0) | 0x400)
        with mock.patch.object(Path, "lstat", changed), self.assertRaises(self.p.Refusal):
            self.p.code_selector(self.code)

    def test_142702080_byte_windows_release_fits_separate_selected_binary_limit(self):
        self.p.check_capacity({"bytes": 142_702_080})
        self.p.check_capacity({"bytes": 160_000_000})
        self.assertEqual(self.p.BUDGETS["nativeEntryBytes"], 128_000_000)
        for value in (True, 0, -1, 160_000_001):
            with self.subTest(bytes=value), self.assertRaises(self.p.Refusal): self.p.check_capacity({"bytes": value})

    def test_oversize_refusal_precedes_staged_byte_read_and_mutation(self):
        pin = mock.Mock()
        with tempfile.TemporaryDirectory() as directory, ExitStack() as stack:
            target = Path(directory) / "release/yoke.exe"
            with self.assertRaises(self.p.Refusal):
                self.p.stage_copy({}, None, stack, {"record": {"bytes": 160_000_001}, "imagePin": pin}, target)
            pin.bytes.assert_not_called()
            self.assertFalse(target.exists())

    def test_native_stage_uses_only_the_held_new_image_and_preserves_occupied_output(self):
        p = self.p; data = b"Owned inert stage-copy text; never executed"
        admitted = {"record": {**row(data), "fileIdentity": [0, 1]}, "imagePin": types.SimpleNamespace(bytes=lambda: data)}
        class Pin:
            def __init__(self, api, path, maximum, image=False): self.path = path
            def __enter__(self): return self
            def __exit__(self, *args): self.recheck()
            def recheck(self):
                info = self.path.stat()
                return {**row(self.path.read_bytes()), "fileIdentity": [info.st_dev, info.st_ino], "links": info.st_nlink}
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "release/yoke.exe"; target.parent.mkdir()
            with ExitStack() as stack:
                _, observed = p.stage_copy({"ReadPin": Pin}, None, stack, admitted, target)
                self.assertEqual(observed["sha256"], row(data)["sha256"])
                with self.assertRaises(p.Refusal): p.stage_copy({"ReadPin": Pin}, None, stack, admitted, target)
                self.assertEqual(target.read_bytes(), data)

    def test_manifest_unknown_fields_changed_budgets_and_adapter_pins_refuse(self):
        own = {name: {"bytes": 1, "sha256": "a" * 64} for name in self.p.CONTROL_NAMES}
        manifest = {"owner": self.p.OWNER, "schema": self.p.SCHEMA, "sourceCommit": self.p.SOURCE_COMMIT,
                    "scope": "native-only-derived-bundled-host", "controlNames": list(self.p.CONTROL_NAMES),
                    "sourceHashes": {name: value for name, value in own.items() if name != "review-manifest.json"},
                    "adapterPins": self.p.ADAPTER_PINS, "scriptPins": self.p.SCRIPT_PINS,
                    "originalLauncherSha256": self.p.ORIGINAL_LAUNCHER_SHA,
                    "derivedLauncherSha256": self.p.DERIVED_LAUNCHER_SHA,
                    "portableReadmeSha256": self.p.PORTABLE_README_SHA, "budgets": self.p.BUDGETS,
                    "checks": {}, "unrun": []}
        self.p.validate_manifest(manifest, own)
        for change in ({"schema": True}, {"sourceCommit": "f" * 40}, {"adapterPins": {}},
                       {"extra": True}, {"budgets": dict(self.p.BUDGETS, nativeEntryBytes=160_000_000)}):
            altered = copy.deepcopy(manifest); altered.update(change)
            with self.subTest(change=change), self.assertRaises(self.p.Refusal): self.p.validate_manifest(altered, own)

    def test_duplicate_json_keys_nonfinite_constants_and_exhausted_bytes_refuse(self):
        for data in (b'{"key":1,"key":2}', b'{"value":NaN}', b'{"value":Infinity}', b'\xff',
                     b'\xef\xbb\xbf{}', '{"key":1}'.encode("utf-16")):
            with self.subTest(data=data), self.assertRaises(self.p.Refusal): self.p.unique_json(data)
        with self.assertRaises(self.p.Refusal): self.p.unique_json(b'{}', 1)

    def test_large_metadata_has_a_separate_bounded_parser_without_raising_management_json(self):
        raw = json.dumps({"padding": "x" * 1_000_000}).encode()
        self.assertEqual(len(self.p.metadata_json(raw)["padding"]), 1_000_000)
        with self.assertRaises(self.p.Refusal): self.p.unique_json(raw)
        self.assertEqual(self.p.BUDGETS["jsonBytes"], 1_000_000)
        self.assertEqual(self.p.BUDGETS["metadataJsonBytes"], self.p.BUDGETS["logBytes"])
        with mock.patch.dict(self.p.BUDGETS, metadataJsonBytes=1), self.assertRaises(self.p.Refusal):
            self.p.metadata_json(b'{}')

    def test_derived_launcher_changes_only_internal_force_cleanup_and_keeps_bundled_switch(self):
        original = (self.p.ROOT / "scripts/test-vscode.ps1").read_bytes()
        derived = self.p.derive_launcher(original)
        self.assertEqual(row(derived)["sha256"], self.p.DERIVED_LAUNCHER_SHA)
        self.assertNotIn(b"taskkill", derived)
        self.assertIn(b"if ($UseBundledRuntime)", derived)
        self.assertIn(b"$taskProcess.WaitForExit(5000)", derived)
        self.assertIn(b"$taskProcess.Dispose()", derived)
        self.assertEqual(derived[:original.index(b"                $taskCleanupOut")], original[:original.index(b"                $taskCleanupOut")])
        with self.assertRaises(self.p.Refusal): self.p.derive_launcher(original + b"\n# drift")

    def test_protected_default_image_presence_refuses_before_packager(self):
        pin = types.SimpleNamespace(recheck=lambda: {"metadata": {"exists": True}})
        with self.assertRaises(self.p.Refusal):
            self.p.default_release_absent({}, {"protectedPins": {"target/release/yoke.exe": pin}})

    def test_all_host_result_authority_and_source_assertions_are_required(self):
        self.p.validate_host(host_result())
        for key in ("passed", "bundledRuntime", "unsavedSourceBound", "workspaceExecutableIgnored",
                    "protectedOpenBufferExcluded", "savedSourceUnchanged"):
            for value in (False, 1):
                changed = host_result(); changed[key] = value
                with self.subTest(key=key, value=value), self.assertRaises(self.p.Refusal): self.p.validate_host(changed)
        for changed in (dict(host_result(), runtime="typescript"), dict(host_result(), extra=True)):
            with self.assertRaises(self.p.Refusal): self.p.validate_host(changed)


class JobTests(unittest.TestCase):
    def setUp(self): self.p = controller()

    def test_natural_complete_job_is_admitted(self):
        value = valid_job(self.p)
        self.p.validate_job(value, value["command"], 190, value["absoluteDeadlineNs"])

    def test_internal_or_outer_forced_cleanup_cannot_become_host_success(self):
        for changes in ({"exitCode": 1}, {"completed": False}, {"treeExitedBeforeCleanup": False},
                        {"activeBeforeCleanup": 1}, {"activeAfterCleanup": 1}, {"cleanupUnproven": True},
                        {"cleanupErrors": ["forced"]}, {"membersAfterOriginalDrain": [{"pid": 123}]}):
            value = valid_job(self.p); value.update(changes)
            with self.subTest(changes=changes), self.assertRaises(self.p.Refusal):
                self.p.validate_job(value, value["command"], 190, value["absoluteDeadlineNs"])

    def test_bool_counters_stream_faults_disk_and_budget_drift_refuse(self):
        mutations = ({"activeAfterCleanup": False}, {"resumePreviousSuspendCount": True}, {"exitCode": False},
                     {"streamEOF": [True, 1]}, {"readerErrors": [False, True]}, {"capturedLogBytes": 16_000_001},
                     {"minimumFreeObserved": 499_999_999}, {"originalDrainSeconds": 2}, {"cleanupSeconds": 3},
                     {"outputExceeded": True}, {"startedSuspended": False}, {"assignedBeforeResume": False})
        for mutation in mutations:
            value = valid_job(self.p); value.update(mutation)
            with self.subTest(mutation=mutation), self.assertRaises(self.p.Refusal):
                self.p.validate_job(value, value["command"], 190, value["absoluteDeadlineNs"])

    def test_refreshed_or_expired_absolute_stage_deadline_refuses(self):
        value = valid_job(self.p)
        for change in ({"absoluteDeadlineNs": value["absoluteDeadlineNs"] + 1},
                       {"treeObservedMonotonicNs": value["absoluteDeadlineNs"]}, {"jobName": "foreign"}):
            changed = dict(value, **change)
            with self.subTest(change=change), self.assertRaises(self.p.Refusal):
                self.p.validate_job(changed, value["command"], 190, value["absoluteDeadlineNs"])


class ZipTests(unittest.TestCase):
    def setUp(self):
        self.p = controller()
        self.pv = module("inert_test_trusted_zip_metadata", self.p.ROOT / "scripts/package-vscode.py")
        self.inputs, self.files, self.vsix, self.manifest, self.image, self.readme = fixture(self.p)

    def inspect(self, files=None, allow=False, expected=None):
        files = self.files if files is None else files
        with mock.patch.object(self.p, "PORTABLE_README_SHA", self.readme):
            return self.p.inspect_native(self.pv, zipped(files.items()), self.inputs, self.image, allow,
                                         {("fixture", "1.0.0"): {"spdx": "MIT", "repository": "https://github.com/owner/fixture"}}
                                         if expected is None else expected)

    def metadata_probe(self, kind, *, name=None, size=142_702_080, target=None, platform=b"win32-x64"):
        p = self.p
        role = "yoke.exe" if kind == "native" else "extension/runtime/native/yoke.exe"
        manifest_role = "manifest.json" if kind == "native" else "extension/runtime/native/manifest.json"
        metadata = {manifest_role: json.dumps({"name": "yoke-code-intelligence", "version": "0.5.0",
            "target": p.TARGET if target is None else target, "binarySha256": "b" * 64}).encode()}
        if kind == "vsix":
            metadata["extension.vsixmanifest"] = self.vsix["extension.vsixmanifest"].replace(b"win32-x64", platform)
            metadata["extension/package.json"] = self.vsix["extension/package.json"]
        entries = []
        for filename, raw in metadata.items():
            info = zipfile.ZipInfo(filename); info.file_size = len(raw); info.external_attr = 0o100644 << 16
            entries.append(info)
        info = zipfile.ZipInfo(role if name is None else name)
        info.file_size = size; info.external_attr = 0o100644 << 16
        entries.append(info)
        reads = []
        class PayloadReached(RuntimeError): pass
        class Archive:
            def __enter__(self): return self
            def __exit__(self, *args): return None
            def infolist(self): return entries
            def read(self, entry):
                reads.append(entry.filename)
                if entry.filename not in metadata: raise PayloadReached()
                return metadata[entry.filename]
        return entries, reads, Archive, PayloadReached, {"bytes": size, "sha256": "b" * 64}, role

    def test_only_exact_manifest_selected_windows_roles_receive_160mb_before_body_read(self):
        for kind in ("native", "vsix"):
            for size in (142_702_080, 160_000_000):
                entries, reads, archive, payload, image, role = self.metadata_probe(kind, size=size)
                with mock.patch.object(self.pv, "native_zip_directory", return_value=len(entries)), \
                     mock.patch.object(self.p.zipfile, "ZipFile", return_value=archive()), \
                     self.subTest(kind=kind, size=size), self.assertRaises(payload):
                    self.p.archive_members(self.pv, b"owned inert metadata stub", kind, image)
                self.assertEqual(reads[-1], role)
                self.assertIn("manifest.json" if kind == "native" else "extension/runtime/native/manifest.json", reads[:-1])
                if kind == "vsix": self.assertIn("extension.vsixmanifest", reads[:-1])

    def test_oversized_lookalikes_unix_and_wrong_platform_refuse_before_executable_body(self):
        cases = (("native", {"name": "YOKE.EXE"}), ("native", {"name": "nested/yoke.exe"}),
                 ("native", {"name": "yoke", "target": "x86_64-unknown-linux-gnu"}),
                 ("native", {"target": "x86_64-unknown-linux-gnu"}),
                 ("vsix", {"name": "yoke.exe"}), ("vsix", {"name": "extension/runtime/native/YOKE.EXE"}),
                 ("vsix", {"platform": b"linux-x64"}), ("native", {"size": 160_000_001}))
        for kind, arguments in cases:
            entries, reads, archive, payload, image, role = self.metadata_probe(kind, **arguments)
            with mock.patch.object(self.pv, "native_zip_directory", return_value=len(entries)), \
                 mock.patch.object(self.p.zipfile, "ZipFile", return_value=archive()), \
                 self.subTest(kind=kind, arguments=arguments), self.assertRaises(self.p.Refusal):
                self.p.archive_members(self.pv, b"owned inert metadata stub", kind, image)
            self.assertNotIn(role, reads)

    def test_nonwindows_and_unrelated_entries_keep_the_exact_128mb_ceiling(self):
        self.assertEqual(self.p.BUDGETS["nativeEntryBytes"], 128_000_000)
        for kind, name in (("native", "yoke"), ("native", "LICENSE"), ("vsix", "extension/notes.bin")):
            entries, reads, archive, payload, image, role = self.metadata_probe(kind, name=name, size=128_000_001)
            with mock.patch.object(self.pv, "native_zip_directory", return_value=len(entries)), \
                 mock.patch.object(self.p.zipfile, "ZipFile", return_value=archive()), \
                 self.subTest(name=name), self.assertRaises(self.p.Refusal):
                self.p.archive_members(self.pv, b"owned inert metadata stub", kind, image)
            self.assertEqual(reads, [])

    def test_exact_inert_native_archive_and_vsix_preserve_all_source_and_binary_bytes(self):
        native, summary = self.inspect()
        vsix, vsix_summary = self.p.inspect_vsix(self.pv, zipped(self.vsix.items()), native, self.inputs)
        self.assertEqual(summary["binarySha256"], self.image["sha256"])
        self.assertEqual(vsix_summary["binarySha256"], self.image["sha256"])
        self.assertTrue(vsix_summary["nativeOnly"])
        self.assertEqual(vsix["extension/runtime/native/yoke.exe"], self.files["yoke.exe"])

    def test_foreign_native_payload_and_rewritten_source_or_binary_refuse(self):
        for member, value in (("foreign", b"foreign"), ("LICENSE", b"changed"), ("yoke.exe", b"changed"),
                              ("README.md", b"changed")):
            files = dict(self.files); files[member] = value
            with self.subTest(member=member), self.assertRaises(self.p.Refusal): self.inspect(files)

    def test_missing_or_forged_dependency_license_inventory_refuses(self):
        for mutation in ("missing", "hash", "identity", "extra-field"):
            manifest = copy.deepcopy(self.manifest)
            if mutation == "missing": manifest["dependencies"] = []
            if mutation == "hash": manifest["dependencies"][0]["licenseTexts"][0]["sha256"] = "0" * 64
            if mutation == "identity": manifest["dependencies"][0]["version"] = "2.0.0"
            if mutation == "extra-field": manifest["dependencies"][0]["licenseTexts"][0]["approved"] = True
            files = dict(self.files, **{"manifest.json": json.dumps(manifest).encode()})
            with self.subTest(mutation=mutation), self.assertRaises(self.p.Refusal): self.inspect(files)

    def test_archive_spdx_and_repository_claims_must_match_observed_metadata_exactly(self):
        for field, value in (("spdx", "Apache-2.0"), ("spdx", None), ("spdx", True),
                             ("repository", "https://github.com/foreign/repository"),
                             ("repository", None), ("repository", {"forged": "url"})):
            manifest = copy.deepcopy(self.manifest)
            manifest["dependencies"][0][field] = value
            files = dict(self.files, **{"manifest.json": json.dumps(manifest).encode()})
            with self.subTest(field=field, value=value), self.assertRaises(self.p.Refusal): self.inspect(files)

    def test_remote_notice_provenance_requires_the_explicit_fetch_selection(self):
        manifest = copy.deepcopy(self.manifest)
        manifest["dependencies"][0]["licenseTexts"][0]["source"] = "https://github.com/owner/fixture/blob/" + "a" * 40 + "/LICENSE"
        files = dict(self.files, **{"manifest.json": json.dumps(manifest).encode()})
        with self.assertRaises(self.p.Refusal): self.inspect(files)
        self.inspect(files, allow=True)

    def test_zip_case_alias_traversal_parent_conflict_and_duplicate_refuse(self):
        for extras in ([("YOKE.EXE", b"alias")], [("../escape", b"foreign")], [("file", b"a"), ("file/child", b"b")],
                       [("yoke.exe", b"duplicate")], [("C:ads", b"foreign")]):
            with self.subTest(extras=extras), self.assertRaises((self.p.Refusal, ValueError)):
                self.p.archive_members(self.pv, zipped([*self.files.items(), *extras]), "native", self.image)

    def test_all_zip_limits_remain_finite_without_payload_clipping(self):
        for key, limit in (("archiveBytes", 1), ("nativeEntryBytes", 1), ("windowsBinaryBytes", 1),
                           ("archivePayloadBytes", 1), ("archiveEntries", 1)):
            with mock.patch.dict(self.p.BUDGETS, {key: limit}), self.subTest(key=key), self.assertRaises(self.p.Refusal):
                self.p.archive_members(self.pv, zipped(self.files.items()), "native", self.image)

    def test_vsix_rejects_version_platform_ts_mix_and_replaced_native_bytes(self):
        for mutation in ("version", "platform", "typescript", "native"):
            files = dict(self.vsix)
            if mutation == "version": files["extension/package.json"] = b'{"name":"code-intelligence-local","version":"0.4.0"}'
            if mutation == "platform": files["extension.vsixmanifest"] = files["extension.vsixmanifest"].replace(b"win32-x64", b"linux-x64")
            if mutation == "typescript": files["extension/runtime/dist/cli.js"] = b"inert"
            if mutation == "native": files["extension/runtime/native/yoke.exe"] = b"foreign"
            with self.subTest(mutation=mutation), self.assertRaises(self.p.Refusal):
                self.p.inspect_vsix(self.pv, zipped(files.items()), self.files, self.inputs)

    def test_extraction_is_create_only_and_preserves_exact_unicode_bytes(self):
        files = {"extension/notes-\u00e9.txt": b"BOM\xef\xbb\xbf\r\n", "extension/package.json": b"{}"}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.p.extract_owned(files, root)
            self.assertEqual((root / "extension/notes-\u00e9.txt").read_bytes(), files["extension/notes-\u00e9.txt"])
            with self.assertRaises(self.p.Refusal): self.p.extract_owned(files, root)

    def test_staging_metadata_requires_exact_target_root_identity_and_dependency_closure(self):
        admitted = {"artifact": {"package_id": "root"}}
        target = self.p.ROOT / "validation/integration-20261025/platform-repairs/private-package-vscode/inert/cargo-target"
        value = {"version": 1, "target_directory": str(target), "packages": [
            {"id": "root", "name": "yoke-code-intelligence", "version": "0.5.0", "manifest_path": str(self.p.ROOT / "native/Cargo.toml")},
            {"id": "dependency", "name": "fixture", "version": "1.0.0", "license": "MIT", "repository": None}],
            "resolve": {"nodes": [{"id": "root", "deps": [{"pkg": "dependency"}]}, {"id": "dependency", "deps": []}]}}
        self.assertEqual(self.p.validate_metadata(value, target, admitted), {("fixture", "1.0.0"): {"spdx": "MIT", "repository": None}})
        for change in ({"target_directory": str(self.p.ROOT / "target")}, {"version": True}):
            with self.subTest(change=change), self.assertRaises(self.p.Refusal): self.p.validate_metadata(dict(value, **change), target, admitted)
        altered = copy.deepcopy(value); altered["resolve"]["nodes"][0]["deps"] = [{"pkg": "unavailable"}]
        with self.assertRaises(self.p.Refusal): self.p.validate_metadata(altered, target, admitted)
        for field, wrong in (("license", True), ("repository", ["forged"])):
            altered = copy.deepcopy(value); altered["packages"][1][field] = wrong
            with self.subTest(field=field), self.assertRaises(self.p.Refusal): self.p.validate_metadata(altered, target, admitted)

    def test_extraction_path_budget_refuses_before_any_output_without_longpath_policy_change(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with mock.patch.dict(self.p.BUDGETS, stagedPathUtf16Units=1), self.assertRaises(self.p.Refusal):
                self.p.extract_owned({"extension/owned.txt": b"inert"}, root)
            self.assertEqual(list(root.iterdir()), [])


class InputTests(unittest.TestCase):
    def setUp(self): self.p = controller()

    def inputs(self, root, extra=False):
        names = ("LICENSE", "SECURITY.md", "CHANGELOG.md", "THIRD_PARTY_NOTICES.md", "Cargo.lock",
                 "UPSTREAMS.json", "native/README.md", "native/docs/guide.md", "docs/guide.md", "extensions/vscode/package.json")
        for name in names:
            path = root / name; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(b"Owned inert text\n")
        (root / "docs/validation").mkdir()
        if extra: (root / "docs/untracked.md").write_bytes(b"Foreign source must refuse\n")
        return names

    def test_untracked_public_payload_refuses_before_any_content_read(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); names = self.inputs(root, extra=True)
            read = mock.Mock()
            g = {"git_capture": lambda *a: ("\0".join(names) + "\0").encode(), "source_digest": read}
            with mock.patch.object(self.p, "ROOT", root), mock.patch.object(self.p, "SCRIPT_PINS", {}), \
                 mock.patch.object(self.p.shutil, "disk_usage", return_value=types.SimpleNamespace(free=2_000_000_000)):
                with self.assertRaises(self.p.Refusal): self.p.public_inputs(g, None, None, root, {}, "before", time.monotonic_ns() + 10_000_000_000)
            read.assert_not_called()

    def test_tracked_source_maps_remain_exact_and_source_byte_budget_refuses(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); names = self.inputs(root)
            def source(path, maximum):
                raw = path.read_bytes()
                if len(raw) > maximum: raise self.p.Refusal("budget")
                return row(raw)
            g = {"git_capture": lambda *a: ("\0".join(names) + "\0").encode(), "source_digest": source}
            with mock.patch.object(self.p, "ROOT", root), mock.patch.object(self.p, "SCRIPT_PINS", {}), \
                 mock.patch.object(self.p.shutil, "disk_usage", return_value=types.SimpleNamespace(free=2_000_000_000)):
                observed = self.p.public_inputs(g, None, None, root, {}, "before", time.monotonic_ns() + 10_000_000_000)
                self.assertEqual(set(observed["files"]), set(names))
                with mock.patch.dict(self.p.BUDGETS, sourceFileBytes=1), self.assertRaises(self.p.Refusal):
                    self.p.public_inputs(g, None, None, root, {}, "after", time.monotonic_ns() + 10_000_000_000)

    def test_reparse_directory_refuses_before_descent_and_scan_count_is_bounded(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); (root / "plain.txt").write_bytes(b"Owned")
            with mock.patch.dict(self.p.BUDGETS, walkEntries=0), self.assertRaises(self.p.Refusal): list(self.p.walk_files(root))
            entry = types.SimpleNamespace(name="linked", path=str(root / "linked"),
                stat=lambda **kw: types.SimpleNamespace(st_mode=stat.S_IFDIR, st_file_attributes=0x400))
            context = mock.MagicMock(); context.__enter__.return_value = iter([entry])
            with mock.patch.object(self.p.os, "scandir", return_value=context), self.assertRaises(self.p.Refusal): list(self.p.walk_files(root))

    def test_cached_zero_link_count_requires_fresh_metadata_and_hardlinks_still_refuse(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); source = root / "inert.md"; source.write_bytes(b"Owned inert metadata fixture\n")
            entry = types.SimpleNamespace(name=source.name, path=str(source),
                stat=lambda **kw: types.SimpleNamespace(st_mode=stat.S_IFREG, st_file_attributes=0, st_nlink=0))

            def enumeration():
                context = mock.MagicMock(); context.__enter__.return_value = iter([entry]); return context

            with mock.patch.object(self.p.os, "scandir", return_value=enumeration()), \
                    mock.patch.object(self.p, "ordinary", wraps=self.p.ordinary) as observe:
                self.assertEqual(list(self.p.walk_files(root)), [source])
                observe.assert_any_call(source)
            os.link(source, root / "alias.md")
            self.assertEqual(source.lstat().st_nlink, 2)
            with mock.patch.object(self.p.os, "scandir", return_value=enumeration()), \
                    mock.patch.object(self.p, "ordinary", wraps=self.p.ordinary) as observe:
                with self.assertRaises(self.p.Refusal): list(self.p.walk_files(root))
                observe.assert_any_call(source)

    def test_short_stage_uses_explicit_existing_local_temp_and_preserves_occupied_roles(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with mock.patch.object(self.p, "ROOT", root), mock.patch.dict(self.p.os.environ, TEMP=str(root)):
                stage = self.p.fresh_stage("owned-stage")
                self.assertEqual(stage.parent, root)
                self.assertRegex(stage.name, r"^yp-[0-9a-f]{12}$")
                (stage / "foreign.txt").write_bytes(b"Preserve occupied inert fixture")
                with self.assertRaises(self.p.Refusal): self.p.fresh_stage("owned-stage")
                self.assertEqual((stage / "foreign.txt").read_bytes(), b"Preserve occupied inert fixture")

    def test_missing_foreign_or_overlong_temp_refuses_without_fallback_or_creation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for value in ("", "relative-path", "Z:/foreign-host-temp"):
                with mock.patch.object(self.p, "ROOT", root), mock.patch.dict(self.p.os.environ, TEMP=value), \
                     mock.patch.object(self.p, "fresh_directory") as create, self.subTest(value=value):
                    with self.assertRaises(self.p.Refusal): self.p.fresh_stage("owned-stage")
                    create.assert_not_called()
            with mock.patch.object(self.p, "ROOT", root), mock.patch.dict(self.p.os.environ, TEMP=str(root)), \
                 mock.patch.dict(self.p.BUDGETS, stageRootUtf16Units=1), self.assertRaises(self.p.Refusal):
                self.p.fresh_stage("owned-stage")
            self.assertEqual(list(root.iterdir()), [])

    def test_stage_creation_does_not_enumerate_shared_temp(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with mock.patch.object(self.p, "ROOT", root), mock.patch.dict(self.p.os.environ, TEMP=str(root)), \
                 mock.patch.object(self.p.os, "scandir", side_effect=AssertionError("No shared TEMP enumeration")):
                stage = self.p.fresh_stage("owned-stage")
                self.assertTrue(stage.is_dir())


class PublicationTests(unittest.TestCase):
    """Mock every execution/image boundary; exercise actual terminal control flow."""
    def simulate(self, *, late_close=False, admission_error=None, oversize=False, windows_large=False):
        p = controller()
        with tempfile.TemporaryDirectory() as directory, ExitStack() as patches:
            root = Path(directory)
            maps = {"legacy-history": {}, "harness": {}, "original": {}, "transaction": {}}
            controls = {name: {"bytes": 1, "sha256": "a" * 64} for name in p.CONTROL_NAMES}
            record = {"bytes": 160_000_001 if oversize else 142_702_080 if windows_large else 10,
                      "sha256": "b" * 64, "fileIdentity": [1, 2]}
            staged = {**record, "fileIdentity": [1, 3]}
            publications, stages = {}, []
            class Pin:
                def __init__(self, data=b"", observed=None): self.data, self.observed = data, observed
                def __enter__(self): return self
                def __exit__(self, *args): self.recheck()
                def bytes(self): return self.data
                def record(self): return self.observed if self.observed is not None else row(self.data)
                def recheck(self): return self.record()
            class Mutex:
                def __enter__(self): return self
                def __exit__(self, *args):
                    if late_close: raise p.Refusal("mutex")
            admitted = {"record": record, "artifact": {"package_id": "owned-root"}}
            def admit(*args):
                if admission_error: raise p.Refusal(admission_error)
                args[-1].update(nativeImageReadAttempted=True, nativeImageRead=True)
                return admitted, {}, {}
            def stage(*args):
                stages.append(args[-1])
                return {"treeExitedBeforeCleanup": True}, {".stdout": Pin(json.dumps(host_result()).encode()),
                    ".stderr": Pin(), ".job.json": Pin(b"{}")}
            h = types.SimpleNamespace(Mutex=lambda *args: Mutex(), current_maps=lambda *args: maps,
                pin_sources=lambda *args: {}, pin_snapshot=lambda *args: {}, recheck_snapshot=lambda *args: None,
                recheck_pair=lambda *args: None, LEGACY=root, admit_pair=admit)
            protocol = {"CARGO": root / "cargo.exe", "pin_control_files": lambda *args: {},
                        "recheck_admission": lambda *args: None}
            g = {"environment_for": lambda *args: {"PATH": "inert"}, "source_map": lambda *args: {},
                 "ReadPin": lambda api, path, maximum, **kwargs: Pin(b"derived" if path.suffix == ".ps1" else b"host"),
                 "load_windows_api": lambda: (None, None)}
            h.load_dependencies = lambda: (None, types.SimpleNamespace(**protocol), g, {}, None, None, None)
            pv = types.SimpleNamespace(NATIVE_ENTRY_BYTES=128_000_000, NATIVE_WINDOWS_BINARY_BYTES=160_000_000,
                NATIVE_TOTAL_BYTES=256_000_000,
                NATIVE_ARCHIVE_BYTES=256_000_000, NATIVE_ENTRIES=8192, NATIVE_MANIFEST_BYTES=1_000_000)
            tool_info = types.SimpleNamespace(st_dev=1, st_ino=2, st_size=3, st_mtime_ns=4)
            inputs = {"files": {}, "nativeMembers": {}, "extensionMembers": {}}
            input_pins = {"scripts/test-vscode.ps1": Pin(b"original"), "extensions/vscode/test-host.cjs": Pin(b"host")}
            for name, value in (("ROOT", root), ("RUNS", root / "runs"),
                                ("ADAPTER_PINS", {"history_transaction_controller.py": "c" * 64}),
                                ("SCRIPT_PINS", {"scripts/package-vscode.py": "c" * 64,
                                                 "extensions/vscode/test-host.cjs": row(b"host")["sha256"]}),
                                ("DERIVED_LAUNCHER_SHA", row(b"derived")["sha256"])):
                patches.enter_context(mock.patch.object(p, name, value))
            replacements = {"ordinary": lambda *args, **kwargs: tool_info, "source_map": lambda *args: controls,
                "validate_manifest": lambda *args: None, "text_bytes": lambda *args, **kwargs: b"{}",
                "checked_map": lambda *args: controls, "load_source": mock.Mock(side_effect=(h, pv)),
                "admit_pair": admit, "public_inputs": lambda *args: inputs, "pin_inputs": lambda *args: input_pins,
                "stage_copy": lambda *args: (Pin(observed=staged), staged), "run_stage": stage,
                "private_size": lambda *args: {"bytes": 0, "entries": 0},
                "validate_metadata": lambda *args: set(), "inspect_native": lambda *args: ({}, {"fixture": True}),
                "inspect_vsix": lambda *args: ({}, {"fixture": True}), "extract_owned": lambda *args: None,
                "derive_launcher": lambda *args: b"derived", "default_release_absent": lambda *args: None,
                "code_selector": lambda value: (Path(value), {"trustedMock": True}),
                "write_json": lambda path, value: publications.__setitem__(path.name, copy.deepcopy(value))}
            for name, value in replacements.items(): patches.enter_context(mock.patch.object(p, name, value))
            patches.enter_context(mock.patch.object(p.shutil, "disk_usage", return_value=types.SimpleNamespace(free=2_000_000_000)))
            patches.enter_context(mock.patch.object(p.shutil, "which", return_value=str(root / "pwsh.exe")))
            patches.enter_context(mock.patch.dict(p.os.environ, TEMP=str(root)))
            opt = types.SimpleNamespace(source_commit=p.SOURCE_COMMIT, run_id="package-inert",
                producer_run_id="producer-inert", version_run_id="version-inert", fetch_missing_licenses=False,
                code_executable=root / "Code.exe", code_metadata={"trustedMock": True})
            result = p.execute(opt)
            return result, publications, stages

    def test_full_mock_completion_waits_for_context_exit_and_never_claims_visual_or_release(self):
        result, publications, stages = self.simulate()
        self.assertTrue(result["completed"], result)
        self.assertTrue(stages)
        self.assertEqual(publications["result.json"], result)
        self.assertFalse(result["visualAcceptance"])
        self.assertFalse(result["releaseQualification"])

    def test_late_mutex_failure_clears_all_qualification_flags(self):
        result, publications, stages = self.simulate(late_close=True)
        self.assertTrue(stages)
        self.assertFalse(result["completed"], result)
        for key in ("nativeArchiveQualified", "nativeVsixQualified", "derivedBundledHostQualified",
                    "sourceInputsUnchanged", "protectedMetadataUnchanged"):
            self.assertIs(result[key], False, key)
        self.assertFalse(publications["result.json"]["completed"])

    def test_missing_profile_or_version_authority_refuses_before_copy_or_execution(self):
        for code in ("producer", "version", "image"):
            result, _, stages = self.simulate(admission_error=code)
            with self.subTest(code=code):
                self.assertFalse(result["completed"])
                self.assertFalse(result["stagedImageCreated"])
                self.assertFalse(stages)

    def test_160000001_byte_release_refuses_without_packaging_or_host_calls(self):
        result, publications, stages = self.simulate(oversize=True)
        self.assertFalse(result["completed"])
        self.assertEqual(result["failureCode"], "package-size")
        self.assertEqual(result["phase"], "native-entry-capacity")
        self.assertFalse(result["stagedImageCreated"])
        self.assertFalse(stages)
        self.assertFalse(publications["result.json"]["completed"])

    def test_reported_142702080_byte_size_advances_under_mocked_windows_capacity_only(self):
        result, _, stages = self.simulate(windows_large=True)
        self.assertTrue(result["completed"], result)
        self.assertTrue(stages)
        self.assertTrue(result["stagedImageCreated"])
        self.assertEqual(result["nativeImageBytes"], 142_702_080)
        self.assertEqual(result["selectedWindowsBinaryByteLimit"], 160_000_000)
        self.assertEqual(result["generalNativeEntryByteLimit"], 128_000_000)


class E89InteropTests(unittest.TestCase):
    """Real unchanged h2/pure protocol validators; only file/image IO is mocked."""
    def setUp(self):
        self.p = controller()
        self.h = module("frozen_history_pure_version_interop", self.p.ADAPTER / "history_transaction_controller.py")
        self.compiler = module("frozen_compiler_pure_version_interop",
            self.p.BASE / "control-compiler-transaction/transaction_protocol.py")

    def golden(self):
        p, h, c = self.p, self.h, self.compiler
        opt = types.SimpleNamespace(source_commit=p.SOURCE_COMMIT, run_id="package-e89-inert",
            producer_run_id="producer-e89-inert", version_run_id="version-e89-inert")
        sources, originals, transactions = ({"native/source.rs": row(b"source")}, {"control.py": row(b"original")},
                                           {"transaction.py": row(b"transaction")})
        image = {"path": str(c.image_path(opt.producer_run_id)), "sha256": "b" * 64,
                 "fileIdentity": [1, 2], "bytes": 142_702_080, "mtimeNs": 1, "links": 1,
                 "noReparseAncestors": True, "writersAndDeletionDeniedThroughRecheck": True}
        artifact = {"reason": "compiler-artifact", "package_id": "path+" + (c.ROOT / "native").as_uri() + "#yoke-code-intelligence@0.5.0",
            "manifest_path": str(c.ROOT / "native/Cargo.toml"), "target": {"kind": ["bin"], "crate_types": ["bin"],
            "name": "yoke", "src_path": str(c.ROOT / "native/src/main.rs"), "edition": "2024", "doc": True,
            "doctest": False, "test": True}, "profile": {"opt_level": "3", "debuginfo": 0,
            "debug_assertions": False, "overflow_checks": False, "test": False}, "features": [], "filenames": [],
            "executable": str(c.ROOT / "target/release/yoke.exe"), "fresh": False}
        admitted = {"image": c.image_path(opt.producer_run_id), "imagePin": types.SimpleNamespace(recheck=lambda: image),
                    "record": image, "artifact": artifact, "receiptPins": {}, "protectedPins": {}, "protectedBefore": {}}
        request = c.request_record("version", opt.version_run_id, opt.source_commit, opt.producer_run_id,
                                   sources, originals, transactions)
        stdout = b"yoke 0.5.0\r\n"
        job = valid_job(p, request["command"], 30); job["capturedLogBytes"] = len(stdout)
        result = {"owner": c.OWNER, "schema": c.SCHEMA, "mode": "version", "runId": opt.version_run_id,
            "sourceCommit": opt.source_commit, "completed": True, "inputsUnchanged": True,
            "protectedMetadataUnchanged": True, "nativeImageReadAttempted": True, "nativeImageRead": True,
            "selectedImage": image, "selectedArtifact": artifact, "observedVersion": "yoke 0.5.0",
            "errorCode": None, "releaseQualification": False, "vsixQualification": False,
            "qualification": "compiler-transaction/version-only", "freeAfter": 2_000_000_000}
        values = {"request.json": request, "result.json": result, "outer.job.json": job,
                  "selected-image.json": image, "selected-image-after.json": copy.deepcopy(image)}
        for stem, mapping in (("source", sources), ("original-control", originals),
                              ("transaction-control", transactions), ("protected", {})):
            for phase in ("before", "after", "final"): values[stem + "-" + phase + ".json"] = copy.deepcopy(mapping)
        return opt, sources, originals, transactions, admitted, values, stdout

    def test_real_frozen_version_validator_accepts_provided_e89_and_refuses_f8_receipt_mix(self):
        opt, sources, originals, transactions, admitted, values, stdout = self.golden()
        self.assertNotEqual(self.h.SOURCE_COMMIT, self.p.SOURCE_COMMIT)
        self.h.validate_version(self.compiler, opt, sources, originals, transactions, admitted, values, stdout, b"")
        for name in ("request.json", "result.json"):
            altered = copy.deepcopy(values); altered[name]["sourceCommit"] = self.h.SOURCE_COMMIT
            with self.subTest(receipt=name), self.assertRaises((self.h.Refusal, self.compiler.Refusal)):
                self.h.validate_version(self.compiler, opt, sources, originals, transactions, admitted, altered, stdout, b"")

    def test_e89_wrapper_uses_real_pure_version_validator_without_f8_wrappers_or_global_changes(self):
        p, h, c = self.p, self.h, self.compiler
        opt, sources, originals, transactions, admitted, values, stdout = self.golden()
        data = {name: json.dumps(value).encode() for name, value in values.items()}
        data.update({"outer.stdout": stdout, "outer.stderr": b""})
        class Pin:
            def __init__(self, api, path, maximum): self.path = path
            def __enter__(self): return self
            def __exit__(self, *args): self.recheck()
            def bytes(self): return data[self.path.name]
            def recheck(self): return row(self.bytes())
        def producer(*args, **kwargs):
            self.assertEqual(args[5], p.SOURCE_COMMIT)
            kwargs["on_image_attempt"]()
            return admitted
        original = {"checked_protected": lambda *args: None}
        before = h.SOURCE_COMMIT
        with mock.patch.object(p, "ordinary", return_value=types.SimpleNamespace(st_size=1)), \
             mock.patch.object(c, "producer_admission", side_effect=producer) as build, \
             mock.patch.object(h, "admit_pair", side_effect=AssertionError("No f8 wrapper")), \
             mock.patch.object(h, "version_admission", side_effect=AssertionError("No f8 wrapper")), \
             mock.patch.object(h, "execute", side_effect=AssertionError("No history executor")), ExitStack() as stack:
            result = {"nativeImageReadAttempted": False, "nativeImageRead": False}
            observed, pins, snapshot = p.admit_pair(h, c, {"ReadPin": Pin}, None, original, stack, opt,
                sources, originals, transactions, result)
            self.assertIs(observed, admitted)
            self.assertEqual(set(pins), set(p.VERSION_FILES))
            self.assertTrue(snapshot)
            self.assertTrue(result["nativeImageReadAttempted"])
            self.assertTrue(result["nativeImageRead"])
            build.assert_called_once()
        self.assertEqual(h.SOURCE_COMMIT, before)

    def test_wrong_package_source_root_or_roles_refuse_before_producer_io(self):
        p, h, c = self.p, self.h, self.compiler
        opt, sources, originals, transactions, admitted, values, stdout = self.golden()
        for changed in (dict(source_commit=h.SOURCE_COMMIT), dict(version_run_id=opt.producer_run_id)):
            altered = copy.copy(opt)
            for key, value in changed.items(): setattr(altered, key, value)
            with mock.patch.object(c, "producer_admission") as build, ExitStack() as stack:
                with self.assertRaises(p.Refusal): p.admit_pair(h, c, {}, None, {}, stack, altered,
                    sources, originals, transactions, {})
                build.assert_not_called()
        with mock.patch.object(c, "ROOT", c.ROOT / "foreign"), \
             mock.patch.object(c, "producer_admission") as build, ExitStack() as stack:
            with self.assertRaises(p.Refusal): p.admit_pair(h, c, {}, None, {}, stack, opt,
                sources, originals, transactions, {})
            build.assert_not_called()


if __name__ == "__main__":
    unittest.main()
