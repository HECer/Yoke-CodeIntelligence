# Source-prepared native package and bundled extension-host consumer

This is a new ignored validation policy, not a product change or a release
certificate. Preparation executes no controller, helper, tests, compiler, worker
or native image. The parent must independently review and execute the tests and
all real stages. Existing producer, history and tracked harness bytes stay intact.

The only accepted source commit is
`e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e`. Its completed new compiler-transaction
producer and a complete version receipt for the exact same image are mandatory.
There is no old-schema, default executable, old-r2, arbitrary path or command
fallback. The pinned history-transaction module supplies unchanged pure validation gates;
its f8-only execution and admission wrappers are never called or monkeypatched.

## Selected Windows capacity at e89

The reviewed public e89 packager retains its **128,000,000-byte general entry
cap** and introduces a separate **160,000,000-byte ceiling only for the exact
manifest-selected Windows executable**. The earlier parent's 142,702,080-byte
observation fits that numeric role; it is not admission of an old f8 image.
A fresh matching e89 producer, matching version receipt, current-root identity,
source maps and the complete package/host checks are still required.

The native ZIP role is exactly `yoke.exe`; the VSIX role is exactly
`extension/runtime/native/yoke.exe`. Metadata, namespace and aggregate limits
are checked before payload inflation. The bounded native manifest must bind the
Windows target, version, selected-image size and checksum. The VSIX additionally
needs its bounded Windows identity and package metadata before native executable
payload reading. Other names, lookalikes and every Unix executable retain the
128 MB ceiling. Full body checksums and source/license/member closure are required
before qualification. A selected Windows image larger than 160,000,000 bytes
refuses before a staged copy or execution.

The previous six-file f8 source-only unrun baseline is preserved byte-exact in
`source-snapshot-f8-r1-unrun`, with its snapshot receipt. No old receipt or cap is
silently rewritten or reclassified as passing.

## Closed invocation, after parent review

```text
python -B validation/integration-20261025/platform-repairs/control-package-vscode/package_vscode_controller.py --source-commit e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e --run-id <fresh-run> --producer-run-id <completed-new-producer> --version-run-id <matching-version> --code-executable <trusted-local-Code.exe>
```

The only optional argument is `--fetch-missing-licenses`. Without it, missing
locked-crate notices refuse and no network fetching is selected. With it, the
unchanged native packager may fetch missing notices through its pinned upstream
revision/blob admission. Repository metadata is not a substitute for license text.
The Code selector is required, absolute, ordinary, on the checkout drive and
named exactly `Code.exe`; missing, linked/reparse, relative or foreign-drive roles
refuse. There is no unavailable installed-path fallback. No caller Yoke image,
generic command, profile or output override is accepted. Analyzed repository
content cannot select this trusted host tool.

## Producer, source and input closure

The adapter and all five of its files are pinned separately from the unchanged
seven original CLI controls and ten compiler controls. A small explicit e89 package adapter pins all nineteen version files and invokes
the unchanged parameterized `validate_version` plus `validate_admitted` and
`recheck_pair`. Both f8-only `admit_pair` and `version_admission` wrappers are
left unchanged and unused, as are `execute` and `options`. The supplied e89 source
and current new root bind the actual receipts; historical h2 module provenance
remains f8. Pure interoperability tests call the real unchanged validator, require
e89 success and refuse f8 receipt mixing without mocking that validator.
The consumer preserves the build profile, both compiler Job receipts, version request/result/streams,
source/control/protected maps and exact selected-image identity/hash. All remain
held in the consumer's ExitStack and are rechecked before success. The per-root
owner mutex is the same as the existing controllers. Parent maintains host-wide
serialization; this is not an equal-privilege sandbox.

The compiler's source map is distinct from the package input map. The latter
enumerates actual native documentation/notices and extension payloads, requires
all such project inputs to be tracked, and rejects links, reparse directories,
unexpected compiled extension payloads, aliases and untracked source additions.
Bounded raw hashes are taken before and after execution, with all selected source
files held against writes/deletion. Source text, extension JSON and retained
documents remain data. They grant no authority or executable selection.

Staging is fresh and create-only under the explicit existing ordinary host-selected TEMP root on the checkout
drive. Missing, foreign-drive, relative or unavailable TEMP routes refuse without
fallback; its fresh stage root is capped at 70 UTF-16 units.
Its short `yp-<12hex>` component derives from the run label; any occupied role
refuses without inspecting or modifying the prior occupant. The TEMP root is
never enumerated. Compact `t/a/x/j/z` subdirectories limit fixture path length.
Extraction checks its complete 248-UTF-16-unit path ceiling before writing any
member. No extended-prefix alias or system long-path setting is introduced. A copy is made
only from the held admitted image; its independent file identity, exact bytes
and checksum are recorded. It is not passed off as the producer's original image
record. `CARGO_TARGET_DIR` is added only to the native packaging child's derived
environment, pointing to that fresh `t/release/yoke.exe`. There is no
machine environment, Cargo configuration, toolchain or registry change.

A separate owned Cargo metadata command must observe that exact target directory,
root manifest/package/version and full resolved dependency closure. Cargo
metadata uses a separate explicit 16 MB JSON ceiling within the existing 16 MB
aggregate pipe capture; generic management/manifest JSON remains limited to 1 MB.
Native archive license identities, exact bounded nullable SPDX/repository claims
and text hashes must match that observed closure. Public package scripts
are executed unchanged with `--skip-build` and explicit fresh output paths.

The VSIX packager also probes `ROOT/target/release/yoke.exe` independently of the
staged target. This consumer requires metadata-only proof that the protected
default role is absent before either packager, and again afterward. It never
invokes that comparison against an existing legacy default executable.

Native ZIP and VSIX members are independently reopened after bounded ZIP-directory
admission. Portable paths, exact/ASCII-case aliases, links, special/encrypted
entries, parent conflicts, unique strict manifest JSON and all source/native/
license checksums are checked. The output is native-only: no optional retained
TypeScript runtime is silently mixed in. VSIX platform/version/identity and every
extracted member bind back to the native archive and producer. Extraction is
create-only into a fresh ordinary private directory.

## Derived actual bundled-host launcher

`derived-launcher.patch` records the one replacement in a byte-pinned copy of
`scripts/test-vscode.ps1`: the original internal `taskkill.exe` cleanup branch
becomes a closed refusal after the original five-second natural exit wait. The
original launch, 180-second request timer, settings, `-UseBundledRuntime`, fixture,
test assertions, environment restoration and process Dispose remain. The public
tracked script is not edited.

The derived launcher is written to private `scripts/test-vscode-owned.ps1` and
the unchanged original `test-host.cjs` to private `extensions/vscode/`. Thus its
existing `$taskRepo` resolution works without another source rewrite. The explicit
extension directory selects only the freshly extracted VSIX. The explicit required trusted-host `--code-executable` selects the ordinary
local `Code.exe`; an installed absolute `pwsh.exe` is resolved through trusted
host PATH. The selected Code path/file identity/size/mtime/link metadata are
recorded and rechecked before and after host execution without reading or hashing
its executable bytes. Tool resources remain declared trusted inputs; this is not
a vendor signature or image-byte attestation.
Missing tools refuse; no ExecutionPolicy, privileges or installed extensions are
changed. Both tool roles are observed through metadata, not image-byte reads.

The actual host assertions must report Rust, `bundledRuntime:true`, unsaved source
binding, ignored workspace executable override, excluded protected open buffer
and unchanged saved source. This functional result alone is insufficient.
The outer owned Job must also report root and tree exit before forced cleanup.
The derived launcher launches no internal cleanup helper, so its natural-exit
proof cannot be supplied by a hidden successful taskkill. Parent-owned forced
abort remains a failed run. Evidence is explicitly **derived-launcher actual
bundled-host acceptance**, not unchanged-original-launcher acceptance.

The launcher stays hidden as originally authored. `visualAcceptance:false`
remains fixed: actual visible extension and desktop/mobile dashboard inspection
must be performed separately. Packaging or this functional host test establishes
neither overall platform acceptance nor complete project/release publication.

## Fixed budgets and privacy

The public ZIP caps remain: 128,000,000 bytes for general entries, with the
separate exact selected-Windows role at 160,000,000 bytes;
256,000,000 physical/aggregate payload bytes; 8,192 entries; 1,000,000 manifest
bytes. Staging/read admission starts at 1.2 GB free, and the runtime reserve stays
500 MB. Private-tree acceptance accounting is measured between and after stages,
refusing observations above 1,024,000,000 bytes or 16,384 files. This is not a
continuous disk quota. Code stdout/stderr are redirected to private files outside
the outer 16 MB pipe capture. Fixed deadlines and the 500 MB free-space reserve
remain the continuous owned-runner guards; a later oversized tree refuses.
Installed tools and locked Cargo caches remain trusted inputs, not independently
attested by these local license hashes.

Fixed command ceilings are 30 seconds for metadata, 900 seconds for native
packaging, 300 seconds for VSIX packaging, and 190 seconds for the derived host
launcher. The latter retains its original 180-second request timer and
five-second natural Code exit wait. All stages share a fixed 1800-second pipeline
deadline; a command's deadline is clipped to the remaining time. Every outer
runner retains the one-second natural drain and sole two-second forced abort.
Only natural successful stages advance. Captures are bounded at 16 MB per command.

Raw logs, temporary host profiles, workspaces, state and any capability-bearing
data remain under the private run. Public reporting contains closed failure codes,
source/artifact hashes, counts, versions and scoped qualification flags. Arbitrary
exception messages, command output and private host fixture data are not printed.
Read-pin, mutex or final publication failures cannot return success. Parent must
also require the consumer command's actual exit 0/natural owner receipt; a result
file alone is not a completion authority.

## Authored validation, unrun

Tests use mocks, owned text files and explicitly labeled in-memory text ZIPs.
No test builds, reads or executes a real native image or launches VS Code. They
cover strict source/build/version roles, explicit license fetching, the selected Windows 142,702,080-byte capacity and
160,000,001-byte pre-copy refusal, general/Unix 128 MB and wrong-role pre-payload
refusal, real unchanged e89/f8 version-validator interoperability, explicit
metadata-only Code selection, create-only copies/extraction, exact manifest
budgets, launcher derivation, original required host assertions, natural-versus-
forced cleanup, stream/disk/deadline/type faults, metadata target/dependency
closure, license/source/image forgery, ZIP namespace/budget attacks, untracked
payloads/reparse descent, and success publication after final context closure.

Parent gates: independent source review; controlled execution of every authored
test with unchanged source/control maps; actual matching package/host execution
only when its image fits the exact selected-Windows cap; visible inspection; broader native,
platform, history, VSIX, main and release gates. No authored test is counted as run.

Windows source enumeration uses fresh ordinary-path metadata for link counts.
DirEntry.stat reports an unavailable zero link count on this host. Zero is never
admitted as one; fresh two-link fixtures still refuse before content selection.
The first guard run executed44 tests with one positive metadata failure;
that failed guard receipt and all six source files remain retained separately.
