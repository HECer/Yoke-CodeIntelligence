"""Closed native-only packaging and derived bundled-host acceptance consumer.

Importing this source starts nothing. Only a pinned, completed compiler
transaction plus its matching version receipt can supply executable bytes.
"""
import argparse
from contextlib import ExitStack
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import time
import types
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
BASE = ROOT / "validation/integration-20261025/platform-repairs"
CONTROL = BASE / "control-package-vscode"
ADAPTER = BASE / "control-history-transaction"
RUNS = BASE / "runs-package-vscode"
OWNER = "local-native-package-derived-bundled-host-e89-v2"
SCHEMA = 2
SOURCE_COMMIT = "e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e"
CONTROL_NAMES = ("package_vscode_controller.py", "test_package_vscode_controller.py",
                 "README.md", "review-manifest.json", ".gitattributes", "derived-launcher.patch")
ADAPTER_PINS = {'history_transaction_controller.py': '1608983241f4c83def5939cb994703e0955fabe8d8c7ae864555c0438d529684', 'test_history_transaction_controller.py': '71cfde520152dccc4f7121119b91337a92e6478bbbff40c9c942ffc33bbcafad', 'README.md': '655539d0363decae59ef9829c9d97a49485c4ebf7282ffd7a600ce7f33fb7fe9', 'review-manifest.json': '5df3f94193fc318fccda5277f4b2d34b2d118a6128d6cafc95d0666afe67b27b', '.gitattributes': '85e48d232edc7b02f6cecf8fbbf905f3b126c467b594d8dd16c4f8fa283a8320'}
SCRIPT_PINS = {'scripts/package-native.py': '74c6917af87916128b79f7306aa61a3b0b7ee186b11544a5b2e21bd8395d3897', 'scripts/package-vscode.py': '3a4724c8e7b2fe431bdebad63f2b586da9e36a89511a9a0d31e982a4502591dd', 'scripts/test-vscode.ps1': 'ff7fa431ca8139b3de5958aa12b7e5a1226a29079d1122410bb585b00ccd7b2d', 'extensions/vscode/test-host.cjs': '063bdd94d30440c757be0344a460ebba1167b32da3365e34bf4e73207ae352de'}
ORIGINAL_LAUNCHER_SHA = "ff7fa431ca8139b3de5958aa12b7e5a1226a29079d1122410bb585b00ccd7b2d"
DERIVED_LAUNCHER_SHA = "6e71f3e6faa38fd15c9d3f033435e71e9ed20eb6cfc167b270520f5b92f6e1e8"
PORTABLE_README_SHA = "550adac7a885379fa330c9b3b5a17b2bd4695994c082eea314eb55e009d91a22"
VERSION = "0.5.0"
TARGET = "x86_64-pc-windows-msvc"
PLATFORM = "win32-x64"
RUN_PATTERN = re.compile(r"[a-z][a-z0-9-]{0,95}")
COMPILED_SUFFIXES = {".exe", ".pdb", ".dll", ".lib", ".obj", ".o", ".rlib", ".rmeta"}
VERSION_FILES = (
    "request.json", "result.json", "outer.job.json", "outer.stdout", "outer.stderr",
    "source-before.json", "source-after.json", "source-final.json",
    "original-control-before.json", "original-control-after.json", "original-control-final.json",
    "transaction-control-before.json", "transaction-control-after.json", "transaction-control-final.json",
    "protected-before.json", "protected-after.json", "protected-final.json",
    "selected-image.json", "selected-image-after.json",
)
VSX = "http://schemas.microsoft.com/developer/vsx-schema/2011"
BUDGETS = {
    "imageAdmissionBytes": 1_200_000_000, "reserveBytes": 500_000_000,
    "nativeEntryBytes": 128_000_000, "windowsBinaryBytes": 160_000_000, "archiveBytes": 256_000_000,
    "archivePayloadBytes": 256_000_000, "archiveEntries": 8192,
    "manifestBytes": 1_000_000, "jsonBytes": 1_000_000, "metadataJsonBytes": 16_000_000, "logBytes": 16_000_000,
    "sourceFiles": 8192, "sourceBytes": 96_000_000, "sourceFileBytes": 1_000_000,
    "walkEntries": 100_000, "walkDepth": 64, "sourceSeconds": 120,
    "privateEntries": 16_384, "privateBytes": 1_024_000_000,
    "stageRootUtf16Units": 70, "stagedPathUtf16Units": 248,
    "metadataSeconds": 30, "nativePackageSeconds": 900, "vsixPackageSeconds": 300,
    "hostOuterSeconds": 190, "hostRequestSeconds": 180,
    "hostNaturalExitMilliseconds": 5000, "outerDrainSeconds": 1,
    "outerCleanupSeconds": 2, "pipelineSeconds": 1800,
}
CODES = {"arguments", "platform", "control", "manifest", "source", "path", "occupied",
         "budget", "disk", "mutex", "producer", "version", "image", "package-size",
         "copy", "archive", "license", "derived-launcher", "host", "job", "drift",
         "deadline", "external-failure"}


class Refusal(RuntimeError):
    def __init__(self, code):
        self.code = code if code in CODES else "external-failure"
        super().__init__(self.code)


def need(condition, code):
    if not condition:
        raise Refusal(code)


def closed(value, keys, code):
    need(type(value) is dict and set(value) == set(keys), code)


def integer(value, minimum=0, maximum=(1 << 63) - 1):
    return type(value) is int and minimum <= value <= maximum


def digest(data):
    return hashlib.sha256(data).hexdigest()


def unique_json(data, maximum=None):
    maximum = BUDGETS["jsonBytes"] if maximum is None else maximum
    need(type(data) is bytes and len(data) <= maximum, "budget")
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "manifest")
            result[key] = value
        return result
    def constant(_):
        raise Refusal("manifest")
    try:
        return json.loads(data.decode("utf-8", "strict"), object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, UnicodeError, RecursionError):
        raise Refusal("manifest") from None


def metadata_json(data):
    return unique_json(data, BUDGETS["metadataJsonBytes"])


class Arguments(argparse.ArgumentParser):
    def error(self, message):
        raise Refusal("arguments")


def options(arguments=None):
    values = sys.argv[1:] if arguments is None else list(arguments)
    names = ("--source-commit", "--run-id", "--producer-run-id", "--version-run-id", "--code-executable")
    need(all(values.count(name) == 1 for name in names)
         and values.count("--fetch-missing-licenses") <= 1, "arguments")
    parser = Arguments(add_help=False, allow_abbrev=False)
    for name in names: parser.add_argument(name, required=True)
    parser.add_argument("--fetch-missing-licenses", action="store_true")
    opt = parser.parse_args(values)
    need(opt.source_commit == SOURCE_COMMIT and all(RUN_PATTERN.fullmatch(name)
         for name in (opt.run_id, opt.producer_run_id, opt.version_run_id))
         and len({opt.run_id, opt.producer_run_id, opt.version_run_id}) == 3, "arguments")
    opt.code_executable, opt.code_metadata = code_selector(opt.code_executable)
    return opt


def ordinary(path, directory=False):
    path = Path(path)
    need(path.is_absolute() and os.path.normpath(str(path)) == str(path), "path")
    for ancestor in reversed(path.parents):
        info = ancestor.lstat()
        need(stat.S_ISDIR(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400, "path")
    info = path.lstat()
    need(not getattr(info, "st_file_attributes", 0) & 0x400
         and (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)), "path")
    need(info.st_ino > 0 and (directory or info.st_nlink == 1), "path")
    return info


def code_selector(value):
    need(type(value) is str or isinstance(value, Path), "host")
    path = Path(value)
    need(path.is_absolute() and path.drive.lower() == ROOT.drive.lower() and path.name == "Code.exe", "host")
    info = ordinary(path)
    need(info.st_size > 0, "host")
    # This is explicit trusted-host tool authority and metadata continuity,
    # not an image-byte hash or a vendor-signature attestation.
    return path, {"path": str(path), "fileIdentity": [info.st_dev, info.st_ino], "bytes": info.st_size,
                  "mtimeNs": info.st_mtime_ns, "links": info.st_nlink, "noReparseAncestors": True,
                  "imageBytesRead": False}


def text_bytes(path, maximum=1_000_000):
    need(path.suffix.lower() not in COMPILED_SUFFIXES, "path")
    before = ordinary(path)
    need(before.st_size <= maximum, "budget")
    data = path.read_bytes()
    after = ordinary(path)
    need(len(data) == before.st_size <= maximum and
         (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
         (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), "drift")
    return data


def source_map(folder, names):
    return {name: {"bytes": len(data), "sha256": digest(data)} for name in names
            for data in (text_bytes(folder / name),)}


def checked_map(folder, pins):
    need(bool(pins), "control")
    values = source_map(folder, pins)
    need(all(values[name]["sha256"] == expected for name, expected in pins.items()), "control")
    return values


def load_source(path, expected, name):
    data = text_bytes(path)
    need(digest(data) == expected and path.suffix == ".py", "control")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(data, str(path), "exec"), module.__dict__)
    return module


def validate_manifest(manifest, controls):
    closed(manifest, ("owner", "schema", "sourceCommit", "scope", "controlNames", "sourceHashes",
                      "adapterPins", "scriptPins", "originalLauncherSha256", "derivedLauncherSha256",
                      "portableReadmeSha256", "budgets", "checks", "unrun"), "manifest")
    need(manifest["owner"] == OWNER and type(manifest["schema"]) is int and manifest["schema"] == SCHEMA
         and manifest["sourceCommit"] == SOURCE_COMMIT and manifest["scope"] == "native-only-derived-bundled-host"
         and manifest["controlNames"] == list(CONTROL_NAMES) and manifest["adapterPins"] == ADAPTER_PINS
         and manifest["scriptPins"] == SCRIPT_PINS and manifest["budgets"] == BUDGETS
         and all(type(number) is int for number in manifest["budgets"].values())
         and manifest["originalLauncherSha256"] == ORIGINAL_LAUNCHER_SHA
         and manifest["derivedLauncherSha256"] == DERIVED_LAUNCHER_SHA
         and manifest["portableReadmeSha256"] == PORTABLE_README_SHA, "manifest")
    expected = set(CONTROL_NAMES) - {"review-manifest.json"}
    closed(manifest["sourceHashes"], expected, "manifest")
    need(set(controls) == set(CONTROL_NAMES) and all(controls[name] == row
         for name, row in manifest["sourceHashes"].items()), "manifest")


def fresh_parent(path):
    ordinary(path.parent, directory=True)
    if not os.path.lexists(path): path.mkdir(mode=0o700)
    ordinary(path, directory=True)
    return path


def fresh_directory(parent, name):
    need(type(name) is str and RUN_PATTERN.fullmatch(name), "path")
    ordinary(parent, directory=True)
    path = parent / name
    need(not os.path.lexists(path), "occupied")
    path.mkdir(mode=0o700)
    ordinary(path, directory=True)
    return path


def fresh_stage(run_id):
    need(type(run_id) is str and RUN_PATTERN.fullmatch(run_id), "path")
    value = os.environ.get("TEMP")
    need(type(value) is str and bool(value), "path")
    parent = Path(value)
    need(parent.is_absolute() and parent.drive.lower() == ROOT.drive.lower(), "path")
    name = "yp-" + digest(run_id.encode("utf8"))[:12]
    need(len(str(parent / name).encode("utf-16-le")) // 2 <= BUDGETS["stageRootUtf16Units"], "path")
    ordinary(parent, directory=True)
    return fresh_directory(parent, name)


def write_bytes(path, data):
    ordinary(path.parent, directory=True)
    need(type(data) is bytes and not os.path.lexists(path), "occupied")
    with path.open("xb") as stream:
        need(stream.write(data) == len(data), "copy")
        stream.flush()
        os.fsync(stream.fileno())
    ordinary(path)


def write_json(path, value):
    data = json.dumps(value, ensure_ascii=True, allow_nan=False, indent=2).encode() + b"\n"
    need(len(data) <= BUDGETS["jsonBytes"], "budget")
    write_bytes(path, data)


def check_deadline(deadline):
    need(time.monotonic_ns() < deadline, "deadline")
    need(shutil.disk_usage(ROOT).free >= BUDGETS["reserveBytes"], "disk")


def relative_name(name):
    need(type(name) is str and name and "\\" not in name and ":" not in name
         and not name.startswith("/") and all(ord(char) >= 32 and ord(char) != 127 for char in name)
         and all(part and part not in (".", "..") and part.rstrip(" .") == part
                 for part in name.split("/")), "path")
    return name


def walk_files(root, *, entries=None, depth=0):
    ordinary(root, directory=True)
    need(depth <= BUDGETS["walkDepth"], "budget")
    entries = [0] if entries is None else entries
    observed = []
    with os.scandir(root) as stream:
        for item in stream:
            entries[0] += 1
            need(entries[0] <= BUDGETS["walkEntries"], "budget")
            observed.append(item)
    observed.sort(key=lambda item: item.name)
    for item in observed:
        info = item.stat(follow_symlinks=False)
        need(not getattr(info, "st_file_attributes", 0) & 0x400 and not stat.S_ISLNK(info.st_mode), "path")
        path = Path(item.path)
        if stat.S_ISDIR(info.st_mode):
            yield from walk_files(path, entries=entries, depth=depth + 1)
        else:
            # Windows DirEntry.stat caches no link count (zero is unavailable).
            # Reobserve the ordinary path; only an actual single link is admitted.
            need(stat.S_ISREG(info.st_mode), "path")
            fresh = ordinary(path)
            need(stat.S_ISREG(fresh.st_mode) and fresh.st_nlink == 1, "path")
            yield path


def public_inputs(g, api, extended, out, environment, phase, deadline):
    need(phase in ("before", "after", "final"), "source")
    data = g["git_capture"](api, extended, out, environment, "package-tracked-" + phase, ["ls-files", "-z"])
    need(len(data) <= 2_000_000 and data.endswith(b"\0"), "budget")
    try: listing = data.decode("utf8", "strict").split("\0")[:-1]
    except UnicodeError: raise Refusal("source") from None
    need(len(listing) == len(set(listing)), "source")
    tracked = {relative_name(name) for name in listing}
    native = {name: name for name in ("LICENSE", "SECURITY.md", "CHANGELOG.md", "THIRD_PARTY_NOTICES.md",
                                      "Cargo.lock", "UPSTREAMS.json", "native/README.md")}
    for directory in (ROOT / "native/docs", ROOT / "docs"):
        for path in walk_files(directory):
            check_deadline(deadline)
            if path.suffix == ".md":
                name = path.relative_to(ROOT).as_posix(); native[name] = name
    validation = ROOT / "docs/validation"
    ordinary(validation, directory=True)
    with os.scandir(validation) as stream:
        for entry in stream:
            if entry.name.startswith("native-") and not entry.name.startswith("native-distribution"):
                path = Path(entry.path)
                if path.suffix in (".json", ".txt"):
                    ordinary(path); native[path.relative_to(ROOT).as_posix()] = path.relative_to(ROOT).as_posix()
    extension = {}
    directory = ROOT / "extensions/vscode"
    for path in walk_files(directory):
        check_deadline(deadline)
        relative = path.relative_to(directory)
        if "__pycache__" in relative.parts or path.name == "test-host.cjs" or path.suffix == ".pyc": continue
        name = path.relative_to(ROOT).as_posix()
        need(path.suffix.lower() not in COMPILED_SUFFIXES, "source")
        extension["extension/" + relative.as_posix()] = name
    extension["extension/LICENSE"] = "LICENSE"
    names = set(native.values()) | set(extension.values()) | set(SCRIPT_PINS) | {"extensions/vscode/package.json"}
    need(names <= tracked and len(names) <= BUDGETS["sourceFiles"], "source")
    result, total = {}, 0
    end = min(deadline, time.monotonic_ns() + BUDGETS["sourceSeconds"] * 1_000_000_000)
    for name in sorted(names):
        check_deadline(end)
        need(Path(name).suffix.lower() not in COMPILED_SUFFIXES, "source")
        row = g["source_digest"](ROOT / relative_name(name), BUDGETS["sourceFileBytes"])
        need(integer(row.get("bytes"), 0, BUDGETS["sourceFileBytes"])
             and re.fullmatch(r"[0-9a-f]{64}", row.get("sha256", "")), "source")
        total += row["bytes"]; need(total <= BUDGETS["sourceBytes"], "budget")
        result[name] = row
    need(result.keys() >= SCRIPT_PINS.keys() and all(result[name]["sha256"] == sha
         for name, sha in SCRIPT_PINS.items()), "source")
    return {"files": result, "nativeMembers": native, "extensionMembers": extension}


def pin_inputs(g, api, stack, inputs):
    pins = {name: stack.enter_context(g["ReadPin"](api, ROOT / name, BUDGETS["sourceFileBytes"]))
            for name in inputs["files"]}
    need(all(pin.record()["sha256"] == inputs["files"][name]["sha256"] for name, pin in pins.items()), "source")
    return pins


def version_admission(h, p, g, api, stack, opt, sources, originals, transactions, admitted):
    """New e89 wrapper; frozen h2 execute and admission wrappers remain f8-only."""
    need(opt.source_commit == SOURCE_COMMIT and type(opt.version_run_id) is str
         and RUN_PATTERN.fullmatch(opt.version_run_id) and opt.version_run_id != opt.producer_run_id, "version")
    need(p.ROOT == ROOT and h.ROOT == ROOT and p.RUNS == BASE / "runs-compiler-transaction"
         and tuple(h.VERSION_FILES) == VERSION_FILES, "version")
    out = p.RUNS / opt.version_run_id
    ordinary(out, directory=True)
    sizes = {name: ordinary(out / name).st_size for name in VERSION_FILES}
    need(sum(sizes.values()) <= 64_000_000, "budget")
    pins = {name: stack.enter_context(g["ReadPin"](
        api, out / name, BUDGETS["logBytes"] if name in ("outer.stdout", "outer.stderr") else BUDGETS["jsonBytes"]))
        for name in VERSION_FILES}
    values = {name: unique_json(pin.bytes()) for name, pin in pins.items() if name.endswith(".json")}
    # This unchanged validator binds provided source/producer/current-root
    # receipts. Neither h2.version_admission nor h2.admit_pair is called.
    h.validate_version(p, opt, sources, originals, transactions, admitted, values,
                       pins["outer.stdout"].bytes(), pins["outer.stderr"].bytes())
    return pins, h.pin_snapshot(pins)


def admit_pair(h, p, g, api, original, stack, opt, sources, originals, transactions, result):
    need(opt.source_commit == SOURCE_COMMIT and p.ROOT == ROOT and h.ROOT == ROOT
         and p.RUNS == BASE / "runs-compiler-transaction", "producer")
    need(all(type(name) is str and RUN_PATTERN.fullmatch(name)
         for name in (opt.run_id, opt.producer_run_id, opt.version_run_id))
         and len({opt.run_id, opt.producer_run_id, opt.version_run_id}) == 3, "arguments")
    admitted = p.producer_admission(g, api, original, stack, opt.producer_run_id, opt.source_commit,
        sources, originals, transactions, on_image_attempt=lambda: result.update(nativeImageReadAttempted=True))
    result["nativeImageRead"] = True
    h.validate_admitted(p, admitted, opt.producer_run_id)
    version_pins, version_before = version_admission(h, p, g, api, stack, opt, sources, originals, transactions, admitted)
    h.recheck_pair(p, original, admitted, version_pins, version_before)
    return admitted, version_pins, version_before


def check_capacity(record):
    need(type(record) is dict and integer(record.get("bytes"), 1), "image")
    need(record["bytes"] <= BUDGETS["windowsBinaryBytes"], "package-size")


def stage_copy(g, api, stack, admitted, target):
    check_capacity(admitted["record"])
    need(target.name == "yoke.exe" and target.parent.name == "release", "path")
    raw = admitted["imagePin"].bytes()
    need(len(raw) == admitted["record"]["bytes"] and digest(raw) == admitted["record"]["sha256"], "image")
    write_bytes(target, raw)
    pin = stack.enter_context(g["ReadPin"](api, target, BUDGETS["windowsBinaryBytes"], image=True))
    record = pin.recheck()
    need(record["sha256"] == admitted["record"]["sha256"] and record["bytes"] == admitted["record"]["bytes"]
         and record["fileIdentity"] != admitted["record"]["fileIdentity"] and record["links"] == 1, "copy")
    return pin, record


def derive_launcher(original):
    need(type(original) is bytes and digest(original) == ORIGINAL_LAUNCHER_SHA, "derived-launcher")
    begin = b"                $taskCleanupOut = Join-Path $taskFixture 'cleanup.stdout.log'"
    finish = b"                } finally {\r\n                    $taskCleanup.Dispose()\r\n                }"
    need(original.count(begin) == original.count(finish) == 1, "derived-launcher")
    start = original.index(begin); end = original.index(finish, start) + len(finish)
    derived = original[:start] + b"                throw 'Owned VS Code did not exit naturally; outer owner must refuse'" + original[end:]
    need(digest(derived) == DERIVED_LAUNCHER_SHA and b"taskkill.exe" not in derived
         and derived.count(b"WaitForExit(5000)") == 1
         and b"if ($UseBundledRuntime)" in derived, "derived-launcher")
    return derived


def default_release_absent(original, admitted):
    row = admitted["protectedPins"]["target/release/yoke.exe"].recheck()
    need(row["metadata"] == {"exists": False}, "producer")
    original["checked_protected"](admitted["protectedBefore"],
        {name: pin.recheck() for name, pin in admitted["protectedPins"].items()})


def validate_job(row, command, seconds, absolute_deadline):
    required = {"command", "deadlineSeconds", "logCapBytes", "stdinClosed", "startedSuspended",
        "assignedBeforeResume", "completed", "treeExitedBeforeCleanup", "minimumFreeObserved", "cleanupErrors",
        "streamEOF", "readerErrors", "startedMonotonicNs", "absoluteDeadlineNs", "jobName", "namedJobCreatedNew",
        "pid", "resumePreviousSuspendCount", "exitCode", "rootObservedMonotonicNs", "membersAtRootObservation",
        "rootExitedAtObservation", "activeAtRootObservation", "originalDrainSeconds", "activeBeforeCleanup",
        "membersAfterOriginalDrain", "treeObservedMonotonicNs", "cleanupSeconds", "activeAfterCleanup",
        "rootExitedAfterCleanup", "elapsedSeconds", "capturedLogBytes", "outputExceeded", "cleanupUnproven"}
    closed(row, required, "job")
    need(row["command"] == command and type(row["deadlineSeconds"]) is int and row["deadlineSeconds"] == seconds
         and type(row["logCapBytes"]) is int and row["logCapBytes"] == BUDGETS["logBytes"]
         and row["absoluteDeadlineNs"] == absolute_deadline and integer(row["startedMonotonicNs"], 1)
         and row["startedMonotonicNs"] < absolute_deadline <= row["startedMonotonicNs"] + seconds * 1_000_000_000
         and row["jobName"] is None and row["namedJobCreatedNew"] is False, "job")
    need(all(row[key] is True for key in ("stdinClosed", "startedSuspended", "assignedBeforeResume", "completed",
         "treeExitedBeforeCleanup", "rootExitedAtObservation", "rootExitedAfterCleanup"))
         and all(row[key] is False for key in ("outputExceeded", "cleanupUnproven"))
         and row["streamEOF"] == [True, True] and all(type(value) is bool for value in row["streamEOF"])
         and row["readerErrors"] == [False, False] and all(type(value) is bool for value in row["readerErrors"])
         and row["cleanupErrors"] == [] and row["membersAfterOriginalDrain"] == []
         and type(row["membersAtRootObservation"]) is list and len(row["membersAtRootObservation"]) <= 256, "job")
    need(all(type(row[key]) is int and row[key] == expected for key, expected in
         (("exitCode", 0), ("resumePreviousSuspendCount", 1), ("activeBeforeCleanup", 0), ("activeAfterCleanup", 0),
          ("originalDrainSeconds", 1), ("cleanupSeconds", 2))) and integer(row["activeAtRootObservation"])
         and integer(row["pid"], 1) and integer(row["minimumFreeObserved"], BUDGETS["reserveBytes"])
         and integer(row["capturedLogBytes"], 0, BUDGETS["logBytes"])
         and integer(row["rootObservedMonotonicNs"], row["startedMonotonicNs"], absolute_deadline - 1)
         and integer(row["treeObservedMonotonicNs"], row["rootObservedMonotonicNs"], absolute_deadline - 1)
         and type(row["elapsedSeconds"]) in (int, float) and math.isfinite(row["elapsedSeconds"])
         and 0 <= row["elapsedSeconds"] <= seconds + 2.5, "job")


def run_stage(g, api, extended, stack, jobs, label, argv, environment, seconds, deadline):
    check_deadline(deadline)
    stage_deadline = min(deadline, time.monotonic_ns() + seconds * 1_000_000_000)
    row = g["run_owned"](api, extended, jobs, label, argv, environment, seconds,
                          absolute_deadline_ns=stage_deadline)
    validate_job(row, argv, seconds, stage_deadline)
    pins = {suffix: stack.enter_context(g["ReadPin"](api, jobs / (label + suffix), BUDGETS["logBytes"]))
            for suffix in (".job.json", ".stdout", ".stderr")}
    need(unique_json(pins[".job.json"].bytes()) == row and
         len(pins[".stdout"].bytes()) + len(pins[".stderr"].bytes()) == row["capturedLogBytes"], "job")
    check_deadline(deadline)
    return row, pins


def validate_vsix_identity(xml, package_data):
    need(type(xml) is bytes and len(xml) <= BUDGETS["manifestBytes"]
         and b"<!DOCTYPE" not in xml and b"<!ENTITY" not in xml, "manifest")
    try: tree = ET.fromstring(xml)
    except ET.ParseError: raise Refusal("manifest") from None
    identity = tree.find("{" + VSX + "}Metadata/{" + VSX + "}Identity")
    need(identity is not None and identity.attrib == {"Language": "en-US", "Id": "code-intelligence-local",
         "Version": VERSION, "Publisher": "hecer", "TargetPlatform": PLATFORM}, "manifest")
    package = unique_json(package_data)
    need(type(package) is dict and package.get("name") == "code-intelligence-local"
         and package.get("publisher") == "hecer" and package.get("version") == VERSION, "manifest")


def archive_members(pv, data, kind, image):
    need(type(data) is bytes and len(data) <= BUDGETS["archiveBytes"], "budget")
    need(kind in ("native", "vsix"), "archive")
    check_capacity(image)
    need(type(image.get("sha256")) is str and re.fullmatch(r"[0-9a-f]{64}", image["sha256"]), "image")
    binary_role = "yoke.exe" if kind == "native" else "extension/runtime/native/yoke.exe"
    manifest_role = "manifest.json" if kind == "native" else "extension/runtime/native/manifest.json"
    source = io.BytesIO(data)
    count = pv.native_zip_directory(source)
    with zipfile.ZipFile(source) as archive:
        entries = archive.infolist()
        need(len(entries) == count <= BUDGETS["archiveEntries"], "archive")
        keys, total = {}, 0
        for entry in entries:
            key = pv.native_member_key(entry)
            need(key not in keys, "archive"); keys[key] = entry
            total += entry.file_size
            preliminary_limit = BUDGETS["windowsBinaryBytes"] if entry.filename == binary_role else BUDGETS["nativeEntryBytes"]
            need(entry.file_size <= preliminary_limit and total <= BUDGETS["archivePayloadBytes"]
                 and (not entry.is_dir() or entry.file_size == 0), "budget")
        for key in keys:
            parts = key.split("/")
            need(all(prefix not in keys or keys[prefix].is_dir()
                 for prefix in ("/".join(parts[:i]) for i in range(1, len(parts)))), "archive")
        exact = {entry.filename: entry for entry in entries}
        metadata = exact.get(manifest_role)
        selected = exact.get(binary_role)
        need(metadata is not None and not metadata.is_dir() and metadata.file_size <= BUDGETS["manifestBytes"]
             and selected is not None and not selected.is_dir() and selected.file_size == image["bytes"], "manifest")
        raw_manifest = archive.read(metadata)
        need(len(raw_manifest) == metadata.file_size, "archive")
        manifest = unique_json(raw_manifest)
        need(type(manifest) is dict and manifest.get("name") == "yoke-code-intelligence"
             and manifest.get("version") == VERSION and manifest.get("target") == TARGET
             and manifest.get("binarySha256") == image["sha256"], "manifest")
        files = {manifest_role: raw_manifest}
        if kind == "vsix":
            for name in ("extension.vsixmanifest", "extension/package.json"):
                entry = exact.get(name)
                need(entry is not None and not entry.is_dir() and entry.file_size <= BUDGETS["manifestBytes"], "manifest")
                files[name] = archive.read(entry)
                need(len(files[name]) == entry.file_size, "archive")
            validate_vsix_identity(files["extension.vsixmanifest"], files["extension/package.json"])
        # Only this exact Windows manifest-selected object may exceed128MB.
        # All namespace/aggregate metadata and bounded identity material above
        # precede inflation of any native executable payload.
        for entry in entries:
            limit = BUDGETS["windowsBinaryBytes"] if entry is selected else BUDGETS["nativeEntryBytes"]
            need(entry.file_size <= limit, "budget")
        for entry in entries:
            if entry.is_dir() or entry.filename in files: continue
            raw = archive.read(entry)
            need(len(raw) == entry.file_size, "archive")
            files[entry.filename] = raw
        return files


def validate_metadata(value, staged_target, admitted):
    need(type(value) is dict and value.get("version") == 1 and type(value.get("version")) is int
         and value.get("target_directory") == str(staged_target)
         and type(value.get("packages")) is list and len(value["packages"]) <= 4096
         and type(value.get("resolve")) is dict and type(value["resolve"].get("nodes")) is list
         and len(value["resolve"]["nodes"]) <= 4096, "manifest")
    need(all(type(row) is dict and type(row.get("id")) is str and 0 < len(row["id"]) <= 8192
         for row in value["packages"] + value["resolve"]["nodes"]), "manifest")
    packages = {row["id"]: row for row in value["packages"]}
    nodes = {row["id"]: row for row in value["resolve"]["nodes"]}
    need(len(packages) == len(value["packages"]) and len(nodes) == len(value["resolve"]["nodes"]), "manifest")
    root_id = admitted["artifact"]["package_id"]
    root = packages.get(root_id)
    need(root and root.get("name") == "yoke-code-intelligence" and root.get("version") == VERSION
         and root.get("manifest_path") == str(ROOT / "native/Cargo.toml"), "manifest")
    selected, pending = set(), [root_id]
    while pending:
        current = pending.pop()
        if current in selected: continue
        need(current in packages and current in nodes and len(selected) < 4096, "manifest")
        selected.add(current)
        dependencies = nodes[current].get("deps")
        need(type(dependencies) is list and len(dependencies) <= 4096, "manifest")
        for row in dependencies:
            need(type(row) is dict and type(row.get("pkg")) is str, "manifest")
            pending.append(row["pkg"])
        need(len(pending) <= 100_000, "budget")
    claims = {}
    for key in selected - {root_id}:
        package = packages[key]
        identity = (package.get("name"), package.get("version"))
        need(all(type(value) is str and 0 < len(value) <= 8192 for value in identity)
             and "license" in package and "repository" in package
             and all(package[field] is None or type(package[field]) is str and len(package[field]) <= 8192
                     for field in ("license", "repository")), "manifest")
        need(identity not in claims, "manifest")
        claims[identity] = {"spdx": package["license"], "repository": package["repository"]}
    return claims


def inspect_native(pv, data, inputs, image, allow_fetch, expected_dependencies):
    files = archive_members(pv, data, "native", image)
    need("manifest.json" in files and len(files["manifest.json"]) <= BUDGETS["manifestBytes"], "manifest")
    manifest = unique_json(files["manifest.json"])
    closed(manifest, ("name", "version", "target", "binarySha256", "dependencyScope", "dependencies"), "manifest")
    need(manifest["name"] == "yoke-code-intelligence" and manifest["version"] == VERSION
         and manifest["target"] == TARGET and manifest["binarySha256"] == image["sha256"]
         and manifest["dependencyScope"] == "Cargo resolved native build graph, including build-time crates; not a runtime module-load claim"
         and type(manifest["dependencies"]) is list and len(manifest["dependencies"]) <= 4096, "manifest")
    expected = set(inputs["nativeMembers"]) | {"manifest.json", "README.md", "yoke.exe"}
    identities, licenses = set(), 0
    for dependency in manifest["dependencies"]:
        closed(dependency, ("name", "version", "spdx", "repository", "licenseTexts"), "license")
        identity = (dependency["name"], dependency["version"])
        need(all(type(value) is str and re.fullmatch(r"[A-Za-z0-9_.+-]+", value) for value in identity)
             and identity not in identities and type(dependency["licenseTexts"]) is list
             and 0 < len(dependency["licenseTexts"]) <= 64, "license")
        need(identity in expected_dependencies
             and dependency["spdx"] == expected_dependencies[identity]["spdx"]
             and dependency["repository"] == expected_dependencies[identity]["repository"]
             and all(dependency[field] is None or type(dependency[field]) is str
                     for field in ("spdx", "repository")), "license")
        identities.add(identity)
        for notice in dependency["licenseTexts"]:
            closed(notice, ("path", "source", "sha256"), "license")
            name = relative_name(notice["path"])
            need(name.startswith("licenses/" + identity[0] + "-" + identity[1] + "/") and name not in expected
                 and name in files and 0 < len(files[name]) <= 1_000_000 and digest(files[name]) == notice["sha256"], "license")
            source = notice["source"]
            need(source == "locked-crate-package" or allow_fetch and type(source) is str and
                 re.fullmatch(r"https://github\.com/[^/]+/[^/]+/blob/[0-9a-f]{40}/[^\s]+", source), "license")
            expected.add(name); licenses += 1
    need(identities == set(expected_dependencies), "license")
    need(set(files) == expected and digest(files["yoke.exe"]) == image["sha256"]
         and len(files["yoke.exe"]) == image["bytes"] and digest(files["README.md"]) == PORTABLE_README_SHA, "archive")
    for member, name in inputs["nativeMembers"].items():
        need(digest(files[member]) == inputs["files"][name]["sha256"] and
             len(files[member]) == inputs["files"][name]["bytes"], "source")
    return files, {"sha256": digest(data), "bytes": len(data), "members": len(files),
                   "dependencyCount": len(identities), "licenseTextCount": licenses,
                   "binarySha256": image["sha256"], "target": TARGET, "version": VERSION}


def inspect_vsix(pv, data, native_files, inputs):
    files = archive_members(pv, data, "vsix", {"bytes": len(native_files["yoke.exe"]),
                                               "sha256": digest(native_files["yoke.exe"])})
    expected = set(inputs["extensionMembers"]) | {"extension.vsixmanifest", "[Content_Types].xml"}
    expected |= {"extension/runtime/native/" + name for name in native_files}
    need(set(files) == expected, "archive")
    for member, name in inputs["extensionMembers"].items():
        need(digest(files[member]) == inputs["files"][name]["sha256"] and
             len(files[member]) == inputs["files"][name]["bytes"], "source")
    for name, raw in native_files.items(): need(files["extension/runtime/native/" + name] == raw, "archive")
    for name in ("extension.vsixmanifest", "[Content_Types].xml"):
        need(len(files[name]) <= 1_000_000 and b"<!DOCTYPE" not in files[name] and b"<!ENTITY" not in files[name], "manifest")
    validate_vsix_identity(files["extension.vsixmanifest"], files["extension/package.json"])
    return files, {"sha256": digest(data), "bytes": len(data), "members": len(files), "version": VERSION,
                   "platform": PLATFORM, "nativeOnly": True, "binarySha256": digest(files["extension/runtime/native/yoke.exe"])}


def extract_owned(files, destination):
    ordinary(destination, directory=True)
    need(not any(destination.iterdir()), "occupied")
    for name in files:
        relative_name(name)
        try: units = len(str(destination.joinpath(*name.split("/"))).encode("utf-16-le")) // 2
        except UnicodeError: raise Refusal("path") from None
        need(units <= BUDGETS["stagedPathUtf16Units"], "budget")
    for name, raw in sorted(files.items()):
        relative_name(name)
        path = destination.joinpath(*name.split("/"))
        need(path.is_relative_to(destination), "path")
        for parent in reversed(path.parent.parents):
            if parent == destination or parent.is_relative_to(destination):
                if not os.path.lexists(parent): parent.mkdir(mode=0o700)
                ordinary(parent, directory=True)
        if not os.path.lexists(path.parent): path.parent.mkdir(mode=0o700)
        ordinary(path.parent, directory=True)
        write_bytes(path, raw)


def validate_host(value):
    closed(value, ("kind", "passed", "runtime", "bundledRuntime", "vscodeVersion", "unsavedSourceBound",
                   "workspaceExecutableIgnored", "protectedOpenBufferExcluded", "savedSourceUnchanged"), "host")
    need(value["kind"] == "actual-vscode-extension-host" and value["runtime"] == "rust"
         and type(value["vscodeVersion"]) is str and re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?", value["vscodeVersion"])
         and all(value[key] is True for key in ("passed", "bundledRuntime", "unsavedSourceBound",
             "workspaceExecutableIgnored", "protectedOpenBufferExcluded", "savedSourceUnchanged")), "host")


def private_size(root):
    count = total = 0
    for path in walk_files(root):
        count += 1; total += ordinary(path).st_size
        need(count <= BUDGETS["privateEntries"] and total <= BUDGETS["privateBytes"], "budget")
    return {"entries": count, "bytes": total}


def initial_result(opt):
    return {"owner": OWNER, "schema": SCHEMA, "sourceCommit": opt.source_commit, "runId": opt.run_id,
            "producerRunId": opt.producer_run_id, "versionRunId": opt.version_run_id,
            "fetchMissingLicenses": opt.fetch_missing_licenses, "codeExecutableMetadata": opt.code_metadata,
            "completed": False,
            "nativeImageReadAttempted": False, "nativeImageRead": False, "stagedImageCreated": False,
            "matchingVersionReceiptAdmitted": False, "nativeArchiveQualified": False,
            "nativeVsixQualified": False, "derivedBundledHostQualified": False,
            "visualAcceptance": False, "releaseQualification": False, "wholeProjectComplete": False,
            "sourceInputsUnchanged": False, "protectedMetadataUnchanged": False,
            "phase": "preflight", "failureCode": None}


def execute(opt):
    result, out = initial_result(opt), None
    deadline = time.monotonic_ns() + BUDGETS["pipelineSeconds"] * 1_000_000_000
    try:
        need(os.name == "nt", "platform")
        need(shutil.disk_usage(ROOT).free >= BUDGETS["imageAdmissionBytes"], "disk")
        code, code_record = code_selector(opt.code_executable)
        need(code_record == opt.code_metadata, "drift")
        own = source_map(CONTROL, CONTROL_NAMES)
        validate_manifest(unique_json(text_bytes(CONTROL / "review-manifest.json")), own)
        adapter_map = checked_map(ADAPTER, ADAPTER_PINS)
        scripts = checked_map(ROOT, SCRIPT_PINS)
        h = load_source(ADAPTER / "history_transaction_controller.py", ADAPTER_PINS["history_transaction_controller.py"],
                        "reviewed_package_version_admission")
        compiler, p, g, original, legacy, api, extended = h.load_dependencies()
        with h.Mutex(compiler, p, api), ExitStack() as stack:
            fresh_parent(RUNS)
            out = fresh_directory(RUNS, opt.run_id)
            private = fresh_stage(opt.run_id)
            for name in ("t", "a", "x", "scripts", "extensions", "z", "j"):
                (private / name).mkdir(mode=0o700)
            (private / "t/release").mkdir(mode=0o700)
            (private / "extensions/vscode").mkdir(mode=0o700)
            write_json(out / "request.json", {**result, "budgets": BUDGETS, "derivedLauncherOnly": True})
            dependency_maps = h.current_maps(p, g)
            pins = p.pin_control_files(g, api, stack)
            pins.update(h.pin_sources(g, api, stack, (
                ("package", CONTROL, own), ("history-adapter", ADAPTER, adapter_map),
                ("legacy-history", h.LEGACY, dependency_maps["legacy-history"]),
                ("history-harness", ROOT, dependency_maps["harness"]), ("package-script", ROOT, scripts))))
            pin_before = h.pin_snapshot(pins)
            environment = g["environment_for"]("build")
            sources = g["source_map"](api, extended, out, environment, opt.source_commit, "before")
            result["phase"] = "producer-and-version-admission"
            admitted, version_pins, version_before = admit_pair(h, p, g, api, original, stack, opt, sources,
                dependency_maps["original"], dependency_maps["transaction"], result)
            result["matchingVersionReceiptAdmitted"] = True
            result["phase"] = "native-entry-capacity"
            result.update(nativeImageBytes=admitted["record"]["bytes"],
                          selectedWindowsBinaryByteLimit=BUDGETS["windowsBinaryBytes"],
                          generalNativeEntryByteLimit=BUDGETS["nativeEntryBytes"])
            check_capacity(admitted["record"])
            result["phase"] = "packaging-source-admission"
            inputs = public_inputs(g, api, extended, out, environment, "before", deadline)
            input_pins = pin_inputs(g, api, stack, inputs)
            input_before = h.pin_snapshot(input_pins)
            write_json(out / "packaging-inputs-before.json", inputs)
            write_json(out / "dependency-controls-before.json", dependency_maps)
            write_json(out / "package-controls-before.json", own)
            pv = load_source(ROOT / "scripts/package-vscode.py", SCRIPT_PINS["scripts/package-vscode.py"], "reviewed_zip_metadata")
            need((pv.NATIVE_ENTRY_BYTES, pv.NATIVE_WINDOWS_BINARY_BYTES, pv.NATIVE_TOTAL_BYTES, pv.NATIVE_ARCHIVE_BYTES,
                  pv.NATIVE_ENTRIES, pv.NATIVE_MANIFEST_BYTES) == (128_000_000, 160_000_000,
                  256_000_000, 256_000_000, 8192, 1_000_000), "control")
            result["phase"] = "staged-image"
            image_pin, staged = stage_copy(g, api, stack, admitted, private / "t/release/yoke.exe")
            result["stagedImageCreated"] = True
            write_json(out / "staged-image.json", {"producerImage": admitted["record"], "stagedCopy": staged})
            native_zip = private / "a/yoke-0.5.0-x86_64-pc-windows-msvc.zip"
            vsix_path = private / "a/code-intelligence-0.5.0-win32-x64.vsix"
            package_environment = dict(environment, CARGO_TARGET_DIR=str(private / "t"))
            argv = [str(Path(sys.executable).absolute()), "-I", str(ROOT / "scripts/package-native.py"),
                    "--skip-build", "--output", str(native_zip)]
            if opt.fetch_missing_licenses: argv.append("--fetch-missing-licenses")
            result["phase"] = "native-package"
            jobs = private / "j"
            job_rows, job_pins = [], []
            default_release_absent(original, admitted)
            metadata_command = [str(p.CARGO), "metadata", "--manifest-path", str(ROOT / "Cargo.toml"),
                                "--locked", "--offline", "--format-version", "1", "--filter-platform", TARGET]
            row, held = run_stage(g, api, extended, stack, jobs, "package-metadata", metadata_command,
                                  package_environment, BUDGETS["metadataSeconds"], deadline)
            job_rows.append(row); job_pins.extend(held.values())
            expected_dependencies = validate_metadata(metadata_json(held[".stdout"].bytes()), private / "t", admitted)
            row, held = run_stage(g, api, extended, stack, jobs, "native-package", argv, package_environment,
                                  BUDGETS["nativePackageSeconds"], deadline)
            job_rows.append(row); job_pins.extend(held.values()); private_size(private)
            native_pin = stack.enter_context(g["ReadPin"](api, native_zip, BUDGETS["archiveBytes"]))
            native_files, native_summary = inspect_native(pv, native_pin.bytes(), inputs, staged,
                                                          opt.fetch_missing_licenses, expected_dependencies)
            result["nativeArchiveQualified"] = True
            default_release_absent(original, admitted)
            argv = [str(Path(sys.executable).absolute()), "-I", str(ROOT / "scripts/package-vscode.py"),
                    "--native-archive", str(native_zip), "--output", str(vsix_path)]
            result["phase"] = "vsix-package"
            row, held = run_stage(g, api, extended, stack, jobs, "vsix-package", argv, environment,
                                  BUDGETS["vsixPackageSeconds"], deadline)
            job_rows.append(row); job_pins.extend(held.values()); private_size(private)
            default_release_absent(original, admitted)
            vsix_pin = stack.enter_context(g["ReadPin"](api, vsix_path, BUDGETS["archiveBytes"]))
            vsix_files, vsix_summary = inspect_vsix(pv, vsix_pin.bytes(), native_files, inputs)
            result["nativeVsixQualified"] = True
            extract_owned(vsix_files, private / "x")
            extracted_pins = {}
            for name, raw in vsix_files.items():
                path = (private / "x").joinpath(*name.split("/"))
                selected_binary = name == "extension/runtime/native/yoke.exe"
                maximum = BUDGETS["windowsBinaryBytes"] if selected_binary else BUDGETS["nativeEntryBytes"]
                pin = stack.enter_context(g["ReadPin"](api, path, maximum, image=selected_binary))
                need(pin.record()["sha256"] == digest(raw) and pin.record()["bytes"] == len(raw), "archive")
                extracted_pins[name] = pin
            derived = derive_launcher(input_pins["scripts/test-vscode.ps1"].bytes())
            launcher = private / "scripts/test-vscode-owned.ps1"
            write_bytes(launcher, derived)
            test_host = private / "extensions/vscode/test-host.cjs"
            write_bytes(test_host, input_pins["extensions/vscode/test-host.cjs"].bytes())
            launcher_pin = stack.enter_context(g["ReadPin"](api, launcher, 1_000_000))
            test_host_pin = stack.enter_context(g["ReadPin"](api, test_host, 1_000_000))
            need(launcher_pin.record()["sha256"] == DERIVED_LAUNCHER_SHA
                 and test_host_pin.record()["sha256"] == SCRIPT_PINS["extensions/vscode/test-host.cjs"], "derived-launcher")
            pwsh = shutil.which("pwsh.exe", path=environment["PATH"])
            need(pwsh and Path(pwsh).is_absolute(), "host")
            need(code_selector(code)[1] == code_record, "drift")
            code_info = ordinary(code); pwsh_info = ordinary(Path(pwsh))
            tools_before = [(info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) for info in (code_info, pwsh_info)]
            host_environment = dict(environment, TEMP=str(private / "z"), TMP=str(private / "z"))
            argv = [pwsh, "-NoProfile", "-NonInteractive", "-File", str(launcher), "-CodeExecutable", str(code),
                    "-ExtensionDirectory", str(private / "x/extension"), "-UseBundledRuntime",
                    "-TimeoutSeconds", str(BUDGETS["hostRequestSeconds"])]
            result["phase"] = "derived-bundled-extension-host"
            row, held = run_stage(g, api, extended, stack, jobs, "vscode-host", argv, host_environment,
                                  BUDGETS["hostOuterSeconds"], deadline)
            job_rows.append(row); job_pins.extend(held.values())
            host = unique_json(held[".stdout"].bytes().strip(), 64_000)
            validate_host(host)
            result["derivedBundledHostQualified"] = True
            result["phase"] = "final-recheck"
            check_deadline(deadline); private_summary = private_size(private)
            need(public_inputs(g, api, extended, out, environment, "after", deadline) == inputs, "drift")
            need(public_inputs(g, api, extended, out, environment, "final", deadline) == inputs, "drift")
            need(g["source_map"](api, extended, out, environment, opt.source_commit, "after") == sources
                 and g["source_map"](api, extended, out, environment, opt.source_commit, "final") == sources, "drift")
            need(h.current_maps(p, g) == dependency_maps and source_map(CONTROL, CONTROL_NAMES) == own, "drift")
            h.recheck_snapshot(pins, pin_before); h.recheck_snapshot(input_pins, input_before)
            h.recheck_pair(p, original, admitted, version_pins, version_before)
            need(image_pin.recheck() == staged, "drift")
            for pin in (*extracted_pins.values(), *job_pins, native_pin, vsix_pin, launcher_pin, test_host_pin): pin.recheck()
            tools_after = [ordinary(path) for path in (code, Path(pwsh))]
            need(tools_before == [(info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) for info in tools_after], "drift")
            need(code_selector(code)[1] == code_record, "drift")
            write_json(out / "packaging-inputs-after.json", inputs)
            write_json(out / "package-controls-after.json", own)
            write_json(out / "artifacts.json", {"native": native_summary, "vsix": vsix_summary,
                "derivedLauncherSha256": DERIVED_LAUNCHER_SHA, "originalLauncherSha256": ORIGINAL_LAUNCHER_SHA,
                "host": host, "privateOutputAccounting": private_summary,
                "privateOutputAccountingMode": "stage-boundary observations; not a continuous quota",
                "outerPipeCaptureBytes": BUDGETS["logBytes"], "codeRedirectedLogsWithinOuterPipeCap": False,
                "naturalTreeExitBeforeForce": all(row["treeExitedBeforeCleanup"] for row in job_rows)})
            result.update(sourceInputsUnchanged=True, protectedMetadataUnchanged=True,
                          nativeSha256=staged["sha256"], nativeArchive=native_summary, nativeVsix=vsix_summary,
                          originalHostLauncherUnchangedEvidence=False, derivedLauncherSha256=DERIVED_LAUNCHER_SHA,
                          bundledRuntime=True, treeExitedBeforeCleanup=True, packagingSourceCount=len(inputs["files"]))
        check_deadline(deadline)
        result.update(completed=True, phase="complete")
    except BaseException as error:
        result.update(completed=False, sourceInputsUnchanged=False, protectedMetadataUnchanged=False,
                      nativeArchiveQualified=False, nativeVsixQualified=False, derivedBundledHostQualified=False,
                      failureCode=error.code if isinstance(error, Refusal) else "external-failure")
    finally:
        if out is not None:
            try: write_json(out / "result.json", result)
            except BaseException:
                result.update(completed=False, nativeArchiveQualified=False, nativeVsixQualified=False,
                              derivedBundledHostQualified=False, failureCode="external-failure", phase="result-publication")
    return result


def main(arguments=None):
    try: result = execute(options(arguments))
    except BaseException: result = {"completed": False, "phase": "arguments", "failureCode": "arguments"}
    print(json.dumps({"owner": OWNER, "completed": result["completed"], "phase": result["phase"],
                      "failureCode": result["failureCode"]}), flush=True)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
