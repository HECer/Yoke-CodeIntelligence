'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const ready='<owned-ready-path>',ack='<owned-ack-path>',nonce='<one-time-local-test-nonce>';
exports.run=async function(){
 const original=path.join(__dirname,'original-host.cjs');
 if(crypto.createHash('sha256').update(fs.readFileSync(original)).digest('hex')!=='063bdd94d30440c757be0344a460ebba1167b32da3365e34bf4e73207ae352de')throw Error('Original host drift');
 const result=process.env.YOKE_VSCODE_RESULT,intermediate=result+'.visual-original.json';
 process.env.YOKE_VSCODE_RESULT=intermediate;
 try{await require(original).run();}finally{process.env.YOKE_VSCODE_RESULT=result;}
 const data=fs.readFileSync(intermediate),value=JSON.parse(data);
 if(value.passed!==true||value.bundledRuntime!==true)throw Error('Original host did not pass');
 fs.writeFileSync(ready,JSON.stringify({kind:'owned-code-visual-ready',nonce,originalHostPassed:true,vscodeVersion:value.vscodeVersion})+'\n',{flag:'wx'});
 const deadline=process.hrtime.bigint()+90000000000n;
 while(!fs.existsSync(ack)&&process.hrtime.bigint()<deadline)await new Promise(resolve=>setTimeout(resolve,100));
 if(!fs.existsSync(ack))throw Error('Visual inspection deadline');
 const info=fs.lstatSync(ack);if(!info.isFile()||info.isSymbolicLink()||info.size>16384)throw Error('Visual acknowledgement unavailable');
 const review=JSON.parse(fs.readFileSync(ack));
 if(Object.keys(review).sort().join(',')!=='inspected,nonce,screenshots'||review.nonce!==nonce||review.inspected!==true||!Array.isArray(review.screenshots)||review.screenshots.length<2)throw Error('Visual acknowledgement refused');
 fs.writeFileSync(result,data,{flag:'wx'});
};
