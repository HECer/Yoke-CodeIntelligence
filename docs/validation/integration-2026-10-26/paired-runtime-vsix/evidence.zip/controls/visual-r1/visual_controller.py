"""Bounded visible inspection of the already qualified paired VSIX; no release claim."""
from pathlib import Path
from contextlib import ExitStack
import hashlib,json,os,sys,time,types
CONTROL=Path(__file__).absolute().parent
ROOT=CONTROL.parents[3]
BASE=ROOT/'validation/integration-20261025/platform-repairs'
SPEC_SHA='0f560de53c41e0a194d827312706b61adb60e6ed10781eefcbecc80517d30a3e'

def main():
    data=(CONTROL/'visual-spec.json').read_bytes()
    assert hashlib.sha256(data).hexdigest()==SPEC_SHA
    spec=json.loads(data)
    pair=BASE/'control-package-paired'
    data=(pair/'package_vscode_controller.py').read_bytes()
    assert hashlib.sha256(data).hexdigest()==spec['pairControllerSha256']
    c=types.ModuleType('reviewed_pair_for_visual');c.__file__=str(pair/'package_vscode_controller.py')
    exec(compile(data,c.__file__,'exec'),c.__dict__)
    assert hashlib.sha256((pair/'review-manifest.json').read_bytes()).hexdigest()==spec['pairManifestSha256']
    c.validate_context()
    runtime,packaging=c.load_pair_dependencies();h,p,g,api,extended=runtime.h,runtime.p,runtime.g,runtime.api,runtime.extended
    result={'completed':False,'runtimeSourceCommit':c.RUNTIME_COMMIT,'packagingSourceCommit':c.SOURCE_COMMIT,
        'exactHeadBuild':False,'currentPlatformAcceptance':False,'releaseQualification':False,'wholeProjectComplete':False,
        'visualInspection':False,'functionalPackageRun':'native-vsix-f8-e89-r2','phase':'admission'}
    out=None;deadline=time.monotonic_ns()+c.BUDGETS['pipelineSeconds']*1_000_000_000
    try:
        with ExitStack() as roots,ExitStack() as stack:
            c.acquire_pair_mutexes(runtime,packaging,roots)
            c.fresh_parent(Path(spec['out']).parent);out=c.fresh_directory(Path(spec['out']).parent,spec['runId'])
            for name in ('runtime-source','packaging-source','jobs'):c.fresh_directory(out,name)
            control_pins={name:stack.enter_context(g['ReadPin'](api,CONTROL/name,1_000_000)) for name in ('visual-spec.json','visual-host.cjs','test-vscode-visual.ps1','visual_controller.py')}
            assert control_pins['visual-spec.json'].record()['sha256']==SPEC_SHA
            assert control_pins['visual-host.cjs'].record()['sha256']==spec['wrapperSha256']
            assert control_pins['test-vscode-visual.ps1'].record()['sha256']==spec['launcherSha256']
            c.validate_manifest(c.unique_json((pair/'review-manifest.json').read_bytes()),c.source_map(pair,c.CONTROL_NAMES))
            pins=p.pin_control_files(g,api,stack);pins.update(c.pin_provenance_sources(g,api,stack))
            pins.update({'packaging/'+name:pin for name,pin in packaging.p.pin_control_files(packaging.g,packaging.api,stack).items()})
            protected,protected_before=c.packaging_protected(packaging,stack)
            receipts={path:stack.enter_context(g['ReadPin'](api,Path(path),16_000_000)) for path in spec['receiptPins']}
            for path,pin in receipts.items():assert pin.record()['sha256']==spec['receiptPins'][path]['sha256'] and pin.record()['bytes']==spec['receiptPins'][path]['bytes']
            package=Path(spec['packageRun']);stage=Path(spec['packageStage'])
            accepted=c.unique_json(receipts[str(package/'result.json')].bytes())
            assert accepted['completed'] is True and accepted['derivedBundledHostQualified'] is True and accepted['treeExitedBeforeCleanup'] is True
            environment=g['environment_for']('build');c.check_pair_environment(runtime,packaging,environment)
            before=c.observe_equivalence(runtime,packaging,out,environment,'before',deadline)
            maps=h.current_maps(p,g)
            opt=types.SimpleNamespace(source_commit=c.SOURCE_COMMIT,run_id=spec['runId'],producer_run_id=c.RUNTIME_PRODUCER_RUN,version_run_id=c.RUNTIME_VERSION_RUN)
            admitted,version_pins,version_before=c.admit_pair(h,p,g,api,runtime.original,stack,opt,before['runtimeSources'],maps['original'],maps['transaction'],result)
            current_inputs=c.public_inputs(g,api,extended,out,environment,'before',deadline)
            assert current_inputs==c.unique_json(receipts[str(package/'packaging-inputs-before.json')].bytes())
            input_pins=c.pin_inputs(g,api,stack,current_inputs);input_before=h.pin_snapshot(input_pins)
            pv=c.load_source(c.ROOT/'scripts/package-vscode.py',c.SCRIPT_PINS['scripts/package-vscode.py'],'visual_archive_validation')
            metadata={label:c.metadata_json(receipts[str(stage/'j'/(label+'-metadata.stdout'))].bytes()) for label in ('runtime','packaging')}
            dependencies,graph=c.validate_paired_metadata(metadata['runtime'],metadata['packaging'],stage/'t',admitted)
            archive=stage/'a/yoke-0.5.0-x86_64-pc-windows-msvc.zip';vsix=stage/'a/code-intelligence-0.5.0-win32-x64.vsix'
            archive_pin=stack.enter_context(g['ReadPin'](api,archive,c.BUDGETS['archiveBytes']))
            vsix_pin=stack.enter_context(g['ReadPin'](api,vsix,c.BUDGETS['archiveBytes']))
            assert archive_pin.record()['sha256']==accepted['nativeArchive']['sha256'] and vsix_pin.record()['sha256']==accepted['nativeVsix']['sha256']
            native_files,native_summary=c.inspect_native(pv,archive_pin.bytes(),current_inputs,admitted['record'],True,dependencies)
            files,vsix_summary=c.inspect_vsix(pv,vsix_pin.bytes(),native_files,current_inputs)
            assert native_summary==accepted['nativeArchive'] and vsix_summary==accepted['nativeVsix']
            extracted={}
            for name,raw in files.items():
                path=(stage/'x').joinpath(*name.split('/'))
                pin=stack.enter_context(g['ReadPin'](api,path,c.BUDGETS['windowsBinaryBytes'] if name=='extension/runtime/native/yoke.exe' else c.BUDGETS['nativeEntryBytes'],image=name=='extension/runtime/native/yoke.exe'))
                assert pin.record()['sha256']==c.digest(raw) and pin.record()['bytes']==len(raw)
                extracted[name]=pin
            private=c.fresh_stage(spec['runId'])
            for name in ('scripts','extensions','extensions/vscode','z'): (private/name).mkdir()
            c.write_bytes(private/'scripts/test-vscode-visual.ps1',control_pins['test-vscode-visual.ps1'].bytes())
            c.write_bytes(private/'extensions/vscode/test-host.cjs',control_pins['visual-host.cjs'].bytes())
            c.write_bytes(private/'extensions/vscode/original-host.cjs',input_pins['extensions/vscode/test-host.cjs'].bytes())
            tool,observed=c.code_selector(spec['code']);assert observed==accepted['codeExecutableMetadata']
            c.ordinary(Path(spec['pwsh']));c.default_release_absent(runtime.original,admitted)
            host_environment=dict(environment,TEMP=str(private/'z'),TMP=str(private/'z'))
            command=[spec['pwsh'],'-NoProfile','-NonInteractive','-File',str(private/'scripts/test-vscode-visual.ps1'),'-CodeExecutable',str(tool),'-ExtensionDirectory',str(stage/'x/extension'),'-UseBundledRuntime','-TimeoutSeconds','180']
            result['phase']='visible-original-host';c.write_json(out/'request.json',{'scope':'Separate visible fixture; original functional package result unchanged','visualAckSeconds':90,'hostRequestSeconds':180,'hostOuterSeconds':190,'sourceCommits':[c.RUNTIME_COMMIT,c.SOURCE_COMMIT]})
            job,host_pins=c.run_stage(g,api,extended,stack,out/'jobs','visual-host',command,host_environment,190,deadline)
            host=c.unique_json(host_pins['.stdout'].bytes().strip());c.validate_host(host)
            acknowledgement=c.unique_json((out/'visual-ack.json').read_bytes(),16384)
            assert set(acknowledgement)=={'nonce','inspected','screenshots'} and acknowledgement['nonce']==spec['nonce'] and acknowledgement['inspected'] is True and len(acknowledgement['screenshots'])>=2
            images=[]
            for entry in acknowledgement['screenshots']:
                assert set(entry)=={'path','sha256'}
                path=Path(entry['path']);assert path.parent==out and path.suffix=='.png'
                pin=stack.enter_context(g['ReadPin'](api,path,16_000_000));assert pin.bytes().startswith(b'\x89PNG\r\n\x1a\n') and pin.record()['sha256']==entry['sha256']
                images.append({'path':path.name,'sha256':entry['sha256']})
            assert c.observe_equivalence(runtime,packaging,out,environment,'after',deadline)==before and c.observe_equivalence(runtime,packaging,out,environment,'final',deadline)==before
            c.recheck_packaging_protected(packaging,protected,protected_before);h.recheck_pair(p,runtime.original,admitted,version_pins,version_before);h.recheck_snapshot(input_pins,input_before)
            for pin in (*receipts.values(),*control_pins.values(),*pins.values(),*extracted.values(),archive_pin,vsix_pin):pin.recheck()
            result.update(phase='complete',visualInspection=True,operator='codex actual-image inspection',screenshots=images,host=host,treeExitedBeforeCleanup=job['treeExitedBeforeCleanup'],nativeVsixSha256=vsix_summary['sha256'],nativeBinarySha256=admitted['record']['sha256'])
        result['completed']=True
    except BaseException as error:result.update(completed=False,visualInspection=False,failureType=type(error).__name__)
    finally:
        if out is not None:c.write_json(out/'result.json',result)
    print(json.dumps(result),flush=True)
    return 0 if result['completed'] else 1
if __name__=='__main__':raise SystemExit(main())
