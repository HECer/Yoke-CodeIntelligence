# Explicit f8 runtime and e89 packaging qualification

This is a separate ignored validation policy, owner
`local-native-package-f8-runtime-e89-packager-v3`, schema 3. It prepares scoped
native archive, VSIX and derived bundled extension-host evidence. It never
qualifies a new e89 compiler build, current platform matrix or full release.
No authored function, import, test, controller, compiler, native image or Code
process was executed during this source preparation.

## Two fixed provenances

- Runtime source: `f8b02d4eb0145de95f108e12df51786d368b6ef3`, in the unchanged
  `t3-d1694160` worktree. Only `release-cli-compiler-transaction-f8-r1` and its
  `release-cli-compiler-version-f8-r1` receipt are accepted, through the unchanged
  frozen f8 history/compiler admission functions. Both receipt identities and
  their held image/source/control/protected proofs remain f8.
- Packaging source: `e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e`, in the unchanged
  `t3-b1973677` worktree. Packagers, documentation, notices, extension sources
  and the unchanged test host come from this separately pinned source.

Both e89 compiler attempts remain rejected. This consumer never reads their
EXE/PDB outputs or uses them as a fallback. The original six e89-only package
controls remain byte-exact, hash-pinned inputs and continue refusing f8 runtime
receipts. This new policy does not mutate imported module globals or old
receipts. `sourceCommit` remains the packaging selector; the result additionally
records both roots and `runtimeSourceCommit`/`packagingSourceCommit`, with
`exactHeadBuild:false`, `currentPlatformAcceptance:false`,
`releaseQualification:false` and `wholeProjectComplete:false`.

## Preconditions before the first native image read

Two unchanged dependency loaders retain their own physical roots. The same
reviewed per-root owner mutexes are acquired for both roots in deterministic
order and released only after all held source/image/receipt contexts close.
Parent host-wide serialization remains necessary; this is not an equal-privilege
sandbox. Both exact Git heads must be clean. Source observations have separate
`runtime-source/` and `packaging-source/` receipt namespaces.

Each producer map must contain the same exact 1,050-member inventory, pinned by
its ordered-name SHA-256. Exactly 1,048 records must be equal. The only two
permitted differences are the exact hash/length pairs for
`scripts/package-vscode.py` and `scripts/tests/test_package_vscode.py`.
The full Git delta must be modifications of those two paths plus
`docs/ARCHITECTURE.md`, whose two working-byte versions are separately pinned.
Unexpected members, additional changes, renamed paths and excluded-byte drift
refuse. Both unchanged environment guards also recheck untracked Cargo-config
absence and retained environment equality before every source phase and metadata
admission; an initial or late config cannot escape the tracked inventories. Both authored Cargo manifests must retain the workspace shape and no
build hook; a default root/native `build.rs`, including an untracked one,
refuses. Source maps and all of these checks repeat after execution and before
success. The changed source/document roles are held against writes/deletion.

This demonstrates authored runtime-source equivalence within the existing
trusted compiler/tool/dependency-cache boundary. It does not exhaustively
observe arbitrary external build-script inputs or attest vendor tool binaries.
The producer's original source bounds (64 MB per file, 512 MB aggregate) apply
to these maps; package member source admission remains separately capped at
1 MB per selected file and 96 MB aggregate. The large existing inert analyzer
fixture therefore does not incorrectly inherit a packaging member limit.

## Locked dependency and physical-root identity

Two owned, offline/locked Cargo metadata observations use the same fresh staged
target. Together they share one original 30-second metadata deadline, clipped
to the unchanged overall 1,800-second pipeline deadline. Full metadata objects,
package identities, dependencies, resolver features, edges and dependency kinds
must agree. Only the two exact authored root-package IDs, manifest path,
workspace selectors and native target/readme/license source paths are normalized
through an explicit two-root mapping. Foreign IDs, same-name/version replacement
crates, changed features or changed edges refuse. The unchanged f8 compiler
artifact's package ID and features must match its actual runtime metadata.
Nothing relabels that artifact as e89. The normalized graph and both original
metadata hashes are retained.

The packaging root receives an independent metadata-only pin set for every
original protected role. Its default `target/release/yoke.exe` must be absent,
because the unchanged VSIX packager probes that role independently of
`CARGO_TARGET_DIR`. F8 producer protected pins remain separate. Both sets
recheck before packaging stages, at final acceptance and during context exit.
No protected native image bytes are read by those metadata checks.

## Unchanged package, execution and lifecycle limits

Only the held admitted f8 image can supply a fresh, ordinary, single-link staged
copy, with a different physical identity and identical bytes/hash. Fresh TEMP
placement stays on the selected local drive, at most 70 UTF-16 units; extraction
preflights 248 units. Occupants, aliases, links, reparses, untracked payloads and
unexpected compiled extension members refuse. No global settings, registry,
Cargo configuration or toolchain changes occur. `CARGO_TARGET_DIR` changes only
for the owned native packaging/metadata child environment.

The manifest-selected Windows executable has its reviewed 160,000,000-byte
ceiling; other native/Unix entries remain 128,000,000 bytes, aggregate and archive
payload remain 256,000,000 bytes, member count remains 8,192, and manifests remain
1 MB. Native ZIP and VSIX identities, exact source members, target/version,
image checksums and complete license/dependency closure are independently
reopened and checked. Metadata JSON alone has the existing 16 MB ceiling within
the aggregate 16 MB pipe capture; ordinary management JSON remains 1 MB.

All stage limits remain unchanged: metadata 30 seconds shared across both roots,
native packaging 900, VSIX 300, host request 180 and host outer 190, each clipped
to the single 1,800-second pipeline. Free-space admission/reserve, complete
bounded streams, root exit, natural whole-Job exit before cleanup, one-second
drain and sole two-second abort remain. No helper exemption, additional wait,
breakaway or forced-cleanup success exists. Private output accounting is at
stage boundaries, not a continuous quota. Code's redirected logs are not claimed
to be within the outer 16 MB pipe cap.

The original tracked launcher and test host stay unchanged. The separately
pinned derived launcher removes only its internal `taskkill` path and refuses
after the original five-second natural exit wait, leaving abort to the checked
outer owner. Actual `-UseBundledRuntime` and all six original host assertions
remain mandatory. Functional host JSON alone cannot qualify a retained process
tree. Actual visual inspection is separate and `visualAcceptance` remains false.

## Closed invocation after parent review and guarded tests

```text
python -B validation/integration-20261025/platform-repairs/control-package-paired/package_vscode_controller.py --source-commit e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e --run-id native-vsix-f8-e89-r1 --producer-run-id release-cli-compiler-transaction-f8-r1 --version-run-id release-cli-compiler-version-f8-r1 --code-executable <explicit-local-Code.exe>
```

`--fetch-missing-licenses` is the sole optional switch. Omitted, missing notices
refuse without selecting network fetching. If explicitly present, the unchanged
native packager may fetch only its pinned upstream revision/blob notices.
The required Code selector stays absolute, ordinary, local-drive, metadata-bound
and named `Code.exe`; no default path, arbitrary native image or command exists.
The installed portable host/runtime dependencies remain trusted tools, not
vendor image attestations.

The authored tests retain the prior ZIP/source/host/Job challenges and add
membership, hash exclusion, Git delta, hooks, root guards, cross-root metadata,
wrong runtime commit/run, original-gate refusal and late drift challenges. They
include real unchanged f8 pure admission validators with mocked receipt/image IO
and owned inert text/ZIP fixtures. No test invokes an actual native/Code image.
All tests and every real pipeline stage are unrun by the author. Parent review,
guarded test execution, actual archive/VSIX/host execution, visible inspection,
exact-head build, platform, main and full release gates remain open.

`paired-provenance.patch` records this controller/test/document delta against the
unchanged six-file e89 gate. The seven-file source manifest pins the delta and
all other control files; its own hash is reported externally to avoid a cycle.
