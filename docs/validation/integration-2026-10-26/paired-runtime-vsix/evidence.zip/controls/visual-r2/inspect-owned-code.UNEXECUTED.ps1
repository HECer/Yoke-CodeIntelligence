$ErrorActionPreference='Stop'
$outputPath='C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-b1973677\validation\integration-20261025\platform-repairs\runs-visual-paired\native-vsix-visual-f8-e89-r2'
$readyPath=Join-Path $outputPath 'visual-ready.json'
$watch=[Diagnostics.Stopwatch]::StartNew()
while (-not (Test-Path -LiteralPath $readyPath) -and $watch.Elapsed.TotalSeconds -lt 45) {
    if (Test-Path -LiteralPath (Join-Path $outputPath 'result.json')) {throw 'Visual owner already ended'}
    Start-Sleep -Milliseconds 250
}
if (-not (Test-Path -LiteralPath $readyPath)) {throw 'Owned visual ready event not observed'}
$inventory=orca computer list-apps --json|ConvertFrom-Json
if (-not $inventory.ok) {throw 'Own app inventory unavailable'}
$codeApps=@($inventory.result.apps|Where-Object{$_.name -in @('Code','Visual Studio Code','Code.exe')})
if ($codeApps.Count -ne 1) {throw 'Own Code app is ambiguous'}
$appSelector='pid:'+$codeApps[0].pid
$listed=orca computer list-windows --app $appSelector --json|ConvertFrom-Json
$windows=@($listed.result.windows)
if (-not $listed.ok -or $windows.Count -ne 1 -or -not $windows[0].title.Contains('[Extension Development Host]')) {throw 'Own fixture window not established'}
$windowId=[string]$windows[0].id
$script:observationNumber=0
function Invoke-OwnUi([string[]]$UiParameters) {
    $response=orca @UiParameters --json|ConvertFrom-Json
    $script:observationNumber=$script:observationNumber+1
    $response|ConvertTo-Json -Depth 100 -Compress|Set-Content -LiteralPath (Join-Path $outputPath ('ui-'+$script:observationNumber+'.json')) -Encoding UTF8
    if (-not $response.ok) {throw ('Own UI action failed: '+$response.error.code)}
    return $response
}
function Find-OwnElement($state,[string]$pattern) {
    foreach($line in ($state.result.snapshot.treeText -split "`n")) {if ($line -match $pattern) {return [int]$Matches[1]}}
    return $null
}
$state=Invoke-OwnUi -UiParameters @('computer','get-app-state','--app',$appSelector,'--window-id',$windowId,'--restore-window')
$index=Find-OwnElement $state '^\s*(\d+) .* Maximize\s*$'
if ($null -ne $index) {$state=Invoke-OwnUi -UiParameters @('computer','click','--app',$appSelector,'--window-id',$windowId,'--element-index',[string]$index)}
$index=Find-OwnElement $state '^\s*(\d+) .*Hide Secondary Side Bar.*$'
if ($null -ne $index) {$state=Invoke-OwnUi -UiParameters @('computer','click','--app',$appSelector,'--window-id',$windowId,'--element-index',[string]$index)}
if ($state.result.snapshot.treeText.Contains('Explorer Section: workspace')) {
    $index=Find-OwnElement $state '^\s*(\d+) .*Toggle Primary Side Bar.*$'
    if ($null -ne $index) {$state=Invoke-OwnUi -UiParameters @('computer','click','--app',$appSelector,'--window-id',$windowId,'--element-index',[string]$index)}
}
for($clearNumber=0;$clearNumber -lt 4;$clearNumber++) {
    $index=Find-OwnElement $state '^\s*(\d+) .*Clear Notification.*$'
    if ($null -eq $index) {break}
    $state=Invoke-OwnUi -UiParameters @('computer','click','--app',$appSelector,'--window-id',$windowId,'--element-index',[string]$index)
}
$first=Join-Path $outputPath 'visual-snapshot.png'
[IO.File]::Copy($state.result.screenshot.path,$first,$false)
$index=Find-OwnElement $state '^\s*(\d+) Registerkartenelement main\.rs, Secondary Actions: Select\s*$'
if ($null -eq $index) {throw 'Own main source tab not found'}
$state=Invoke-OwnUi -UiParameters @('computer','perform-secondary-action','--app',$appSelector,'--window-id',$windowId,'--element-index',[string]$index,'--action','Select')
$state=Invoke-OwnUi -UiParameters @('computer','get-app-state','--app',$appSelector,'--window-id',$windowId,'--restore-window')
$second=Join-Path $outputPath 'visual-source.png'
[IO.File]::Copy($state.result.screenshot.path,$second,$false)
[pscustomobject]@{Ready=$true;AppPid=$codeApps[0].pid;WindowId=$windowId;FirstImage=$first;SecondImage=$second;UiObservations=$script:observationNumber;AcknowledgementWritten=$false}|ConvertTo-Json -Compress
