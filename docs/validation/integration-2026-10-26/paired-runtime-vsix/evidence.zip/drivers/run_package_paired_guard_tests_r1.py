"""Run the reviewed paired package consumer's inert guards, never an actual app image."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import types

WORKTREE = Path("C:/Users/Lomi/.t3/worktrees/Yoke-CodeIntelligence/t3-b1973677")
REL = Path("validation/integration-20261025/platform-repairs")
SOURCE = "e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e"
CLI = WORKTREE / REL / "control-cli/cli_controller.py"
CLI_SHA = "d6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582"
CONSUMER = WORKTREE / REL / "control-package-paired"
PINS = {'package_vscode_controller.py': '3fbf6b6d1efa2b8029d882f191efc13d2895fa82277ad5541e3add811207d2c7', 'test_package_vscode_controller.py': 'a31f806307748759a2495b2f0e16e37a09699b7226fb2e59c8f6450ea0e6eaf9', 'README.md': '410427b17dc1cf1875ada8e41235b6ca991d28edd16690989b4b1a19cc0d704e', '.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'derived-launcher.patch': '7062ef388563aa589e53f9a13dc5fa9687ce9561361799725d7a23cd064f81dc', 'paired-provenance.patch': '4e0e23f7dc0a89bac898714ff16f20972aaa9588f32d21ce705f948a3122a406', 'review-manifest.json': '0a07498e074335bc0212f265e5755f94291209ea979a30b47efcd23bfe7fa05a'}


def source_bytes(path):
    assert path.suffix.lower() not in (".exe", ".pdb", ".dll", ".lib", ".obj", ".o")
    info = path.lstat()
    assert info.st_size <= 1_000_000 and info.st_nlink == 1
    assert not getattr(info, "st_file_attributes", 0) & 0x400
    return path.read_bytes()


def consumer_map():
    result = {}
    for name, expected in PINS.items():
        data = source_bytes(CONSUMER / name)
        digest = hashlib.sha256(data).hexdigest()
        assert digest == expected, name
        result[name] = {"bytes": len(data), "sha256": digest}
    return result


DEPENDENCIES = {'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\history_transaction_controller.py': '1608983241f4c83def5939cb994703e0955fabe8d8c7ae864555c0438d529684', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\test_history_transaction_controller.py': '71cfde520152dccc4f7121119b91337a92e6478bbbff40c9c942ffc33bbcafad', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\README.md': '655539d0363decae59ef9829c9d97a49485c4ebf7282ffd7a600ce7f33fb7fe9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\review-manifest.json': '5df3f94193fc318fccda5277f4b2d34b2d118a6128d6cafc95d0666afe67b27b', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\.gitattributes': '85e48d232edc7b02f6cecf8fbbf905f3b126c467b594d8dd16c4f8fa283a8320', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\cli_controller.py': 'd6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\base_controller.py': 'a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\test_metadata_pin.py': '6f555a7b29a85f17c404cba57474c682ae84adf28915ac8b1f10db73b9041aca', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\README.md': '1bbe94b3ac00dff9d1116ab8ccc8aadce545b14dd536888644d1cb92eac3cea6', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\review-manifest.json': '8dd48b1595220464fc638d458a6f8dd7b19f55454c35c0bda7eb7cea255b94f8', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\compiler_transaction_controller.py': '8a4e6a14b3354fa9e822ffaf3b43147b4bd3a1daba5b1a78f6d5df02fe8570db', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\compiler_transaction_worker.py': 'aa4d531fc5a4d4f8176ef6d61c7003375f573b8c6d0974a209f51aa1457a397f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\transaction_protocol.py': '1f36c8c159bbcee87dc5adcd8e2ef78372e046d082237faa8b24e4e26324010c', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\transaction_runtime.py': '00e02c00c22eb540eca9eb971b533bcc52566015e3a3963ccef76c7320401513', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\test_compiler_transaction.py': 'acfb8914cac9e4dc49cadb14044b5d45eedc7de3373f8c5def5029f6d2f53c0c', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\README.md': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\review-manifest.json': 'b1b681c3bb78b6f7117d37ea70e0b4129e08c16d730a5007e89b90293d783f37', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\runtime-fork.patch': '2a72d74ef199ca1cf8454df1ee8005e72b1debf926ee69d81e956d5f347df93f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\local_history_controller.py': '8d37fd4ca9c4f9d7b3320da6d628ff1b5537d880b4090289347d9df7f205d142', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\test_local_history_controller.py': '7ec89b7aa5e810d44d466c7150d1b0f7615defa78cc310617d8b4d5a239427f7', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\README.md': '628651bd06b1a37a90b03af8d85926991d0bc7f3029e9559a60c92db1c08bf5f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\review-manifest.json': '84e19772b5c90d6313cfb4902bc7d671f82eaa753d6279b8b9f787f422c055c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\scripts\\host_history_live.py': '3a3f5de28756ddcc383c3c92821f15fd5db24a72c324ef6a20d1ed6a24f819b2', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\scripts\\tests\\test_host_history_live.py': 'f37e7b419be242337d066678c3a8454156f3062bbb7578b33d14d001500b73db', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\scripts\\package-native.py': '74c6917af87916128b79f7306aa61a3b0b7ee186b11544a5b2e21bd8395d3897', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\scripts\\package-vscode.py': '3a4724c8e7b2fe431bdebad63f2b586da9e36a89511a9a0d31e982a4502591dd', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\scripts\\test-vscode.ps1': 'ff7fa431ca8139b3de5958aa12b7e5a1226a29079d1122410bb585b00ccd7b2d', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\extensions\\vscode\\test-host.cjs': '063bdd94d30440c757be0344a460ebba1167b32da3365e34bf4e73207ae352de', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\history_transaction_controller.py': '1608983241f4c83def5939cb994703e0955fabe8d8c7ae864555c0438d529684', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\test_history_transaction_controller.py': '71cfde520152dccc4f7121119b91337a92e6478bbbff40c9c942ffc33bbcafad', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\README.md': '655539d0363decae59ef9829c9d97a49485c4ebf7282ffd7a600ce7f33fb7fe9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\review-manifest.json': '5df3f94193fc318fccda5277f4b2d34b2d118a6128d6cafc95d0666afe67b27b', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history-transaction\\.gitattributes': '85e48d232edc7b02f6cecf8fbbf905f3b126c467b594d8dd16c4f8fa283a8320', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\cli_controller.py': 'd6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\base_controller.py': 'a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\test_metadata_pin.py': '6f555a7b29a85f17c404cba57474c682ae84adf28915ac8b1f10db73b9041aca', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\README.md': '1bbe94b3ac00dff9d1116ab8ccc8aadce545b14dd536888644d1cb92eac3cea6', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\review-manifest.json': '8dd48b1595220464fc638d458a6f8dd7b19f55454c35c0bda7eb7cea255b94f8', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\compiler_transaction_controller.py': '8a4e6a14b3354fa9e822ffaf3b43147b4bd3a1daba5b1a78f6d5df02fe8570db', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\compiler_transaction_worker.py': 'aa4d531fc5a4d4f8176ef6d61c7003375f573b8c6d0974a209f51aa1457a397f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\transaction_protocol.py': '1f36c8c159bbcee87dc5adcd8e2ef78372e046d082237faa8b24e4e26324010c', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\transaction_runtime.py': '00e02c00c22eb540eca9eb971b533bcc52566015e3a3963ccef76c7320401513', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\test_compiler_transaction.py': 'acfb8914cac9e4dc49cadb14044b5d45eedc7de3373f8c5def5029f6d2f53c0c', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\README.md': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\review-manifest.json': 'b1b681c3bb78b6f7117d37ea70e0b4129e08c16d730a5007e89b90293d783f37', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\runtime-fork.patch': '2a72d74ef199ca1cf8454df1ee8005e72b1debf926ee69d81e956d5f347df93f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\local_history_controller.py': '8d37fd4ca9c4f9d7b3320da6d628ff1b5537d880b4090289347d9df7f205d142', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\test_local_history_controller.py': '7ec89b7aa5e810d44d466c7150d1b0f7615defa78cc310617d8b4d5a239427f7', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\README.md': '628651bd06b1a37a90b03af8d85926991d0bc7f3029e9559a60c92db1c08bf5f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\review-manifest.json': '84e19772b5c90d6313cfb4902bc7d671f82eaa753d6279b8b9f787f422c055c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\scripts\\host_history_live.py': '3a3f5de28756ddcc383c3c92821f15fd5db24a72c324ef6a20d1ed6a24f819b2', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\scripts\\tests\\test_host_history_live.py': 'f37e7b419be242337d066678c3a8454156f3062bbb7578b33d14d001500b73db', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-package-vscode\\package_vscode_controller.py': 'fff33378edc22009f7cda54ab561da2784f86b39c89a23bdedb2244f9f0cf0f4', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-package-vscode\\test_package_vscode_controller.py': '3b29dfb7f7286f3b70e526ada25b4b262c7a09cfc2441dc29e3b991608792871', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-package-vscode\\README.md': '79c93747dc4c9508e233489595ae21c48b281a105b8e024208e629dc71bde41a', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-package-vscode\\review-manifest.json': '7ecf5f1428c140b62fa6c3690d46ccae9f942fb9b6d3bfdb41931a515f93ca24', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-package-vscode\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-package-vscode\\derived-launcher.patch': '7062ef388563aa589e53f9a13dc5fa9687ce9561361799725d7a23cd064f81dc'}

def dependencies_map():
    result = {}
    for name, expected in DEPENDENCIES.items():
        data=source_bytes(Path(name))
        actual=hashlib.sha256(data).hexdigest()
        assert actual==expected, name
        result[name]={"bytes":len(data),"sha256":actual}
    return result

def main():
    assert os.name == "nt" and len(sys.argv) == 1
    data = source_bytes(CLI)
    assert hashlib.sha256(data).hexdigest() == CLI_SHA
    module = types.ModuleType("reviewed_private_release_cli_for_inert_tests")
    module.__file__ = str(CLI)
    exec(compile(data, str(CLI), "exec"), module.__dict__)
    g = module.load_base()
    assert g["ROOT"] == WORKTREE
    g.update(RUNS=WORKTREE / REL / "runs-package-paired-tests", OWNER="package-paired-source-guard-tests-v1")
    api, extended = g["load_windows_api"]()
    out = g["new_output"]("package-paired-guard-tests-r1")
    result = {
        "sourceCommit": SOURCE, "completed": False, "testMethodsExpected": 62,
        "nativeImageRead": False, "nativeImageExecuted": False,
        "actualArchiveAcceptance": False, "releaseQualification": False,
    }
    before_driver = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    mutex = None
    owned = False
    runtime_mutex = None
    runtime_owned = False
    try:
        import _winapi
        name = "Local\\YokeValidation-" + hashlib.sha256(str(WORKTREE).encode()).hexdigest()[:24]
        mutex = api.CreateMutexW(None, False, name)
        assert mutex
        wait = _winapi.WaitForSingleObject(mutex, 0)
        assert wait in (0, 128), "Another validation controller is active"
        owned = True
        result["serialMutexAbandoned"] = wait == 128
        runtime_name = "Local\\YokeValidation-" + hashlib.sha256(str(Path(r"C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-d1694160")).encode()).hexdigest()[:24]
        runtime_mutex = api.CreateMutexW(None, False, runtime_name)
        assert runtime_mutex
        runtime_wait = _winapi.WaitForSingleObject(runtime_mutex, 0)
        assert runtime_wait in (0, 128), "Another runtime-root validation controller is active"
        runtime_owned = True
        result["runtimeMutexAbandoned"] = runtime_wait == 128
        environment = g["environment_for"]("build")
        sources = g["source_map"](api, extended, out, environment, SOURCE, "before")
        controls = g["controls_map"]()
        consumer = consumer_map()
        dependencies = dependencies_map()
        g["write_json"](out, "dependency-before.json", dependencies)
        g["write_json"](out, "control-before.json", controls)
        g["write_json"](out, "consumer-before.json", consumer)
        command = [sys.executable, "-B", "-m", "unittest", "discover", "-s", str(CONSUMER),
                   "-p", "test_package_vscode_controller.py", "-v"]
        job = g["run_owned"](api, extended, out, "tests", command, environment, 180)
        assert job["completed"] and job["exitCode"] == 0
        assert job["treeExitedBeforeCleanup"] and job["activeBeforeCleanup"] == 0
        assert job["activeAfterCleanup"] == 0 and job["rootExitedAfterCleanup"]
        assert job["cleanupUnproven"] is False
        stderr = (out / "tests.stderr").read_bytes()
        assert re.search(rb"Ran 62 tests in [0-9.]+s", stderr)
        assert re.search(rb"\nOK\r?\n", stderr) and b"skipped=" not in stderr
        after = g["source_map"](api, extended, out, environment, SOURCE, "after")
        after_controls = g["controls_map"]()
        after_consumer = consumer_map()
        after_dependencies = dependencies_map()
        g["write_json"](out, "dependency-after.json", after_dependencies)
        assert dependencies == after_dependencies
        g["write_json"](out, "control-after.json", after_controls)
        g["write_json"](out, "consumer-after.json", after_consumer)
        assert sources == after and controls == after_controls and consumer == after_consumer
        assert before_driver == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        result.update(completed=True, testsPassed=62, testsSkipped=0,
                      sourceInputs=len(sources), sourcesUnchanged=True,
                      originalControlsUnchanged=True, consumerControlsUnchanged=True, dependencyControlsUnchanged=True, dependencyFiles=68,
                      driverSha256=before_driver, jobTreeExitedBeforeCleanup=True)
    except BaseException as error:
        result.update(completed=False, errorType=type(error).__name__)
    finally:
        if runtime_owned and not api.ReleaseMutex(runtime_mutex):
            result.update(completed=False, runtimeMutexReleaseFailed=True)
        if runtime_mutex and not api.CloseHandle(runtime_mutex):
            result.update(completed=False, runtimeMutexCloseFailed=True)
        if owned:
            if not api.ReleaseMutex(mutex):
                result.update(completed=False, mutexReleaseFailed=True)
        if mutex:
            if not api.CloseHandle(mutex):
                result.update(completed=False, mutexCloseFailed=True)
        g["write_json"](out, "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
