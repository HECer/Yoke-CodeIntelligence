"""Run the reviewed history consumer's inert protocol tests, never a native image."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import types

WORKTREE = Path("C:/Users/Lomi/.t3/worktrees/Yoke-CodeIntelligence/t3-d1694160")
REL = Path("validation/integration-20261025/platform-repairs")
SOURCE = "f8b02d4eb0145de95f108e12df51786d368b6ef3"
CLI = WORKTREE / REL / "control-cli/cli_controller.py"
CLI_SHA = "d6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582"
CONSUMER = WORKTREE / REL / "control-history-transaction"
PINS = {'history_transaction_controller.py': 'a79c96e7aff153cf8236adda291961058509e79276ff2cd82f3cf08d5796162d', 'test_history_transaction_controller.py': '33bb2b3ed3d2f0aeaf570ac1adecff13eb9bf5e824b9e7fcf5b07bfe6de353e8', 'README.md': '08c024653cdb4b99f29f75dfe3943d71d5da13e8fd8e277ffb7fb72b2eee5614', '.gitattributes': '85e48d232edc7b02f6cecf8fbbf905f3b126c467b594d8dd16c4f8fa283a8320', 'review-manifest.json': '43b20bd10518c033dc1169030b599ab8450d1bb4b9cbe08c400d5c7403756b67'}


def source_bytes(path):
    assert path.suffix.lower() not in (".exe", ".pdb", ".dll", ".lib", ".obj", ".o")
    info = path.lstat()
    assert info.st_size <= 1_000_000 and info.st_nlink == 1
    assert not getattr(info, "st_file_attributes", 0) & 0x400
    return path.read_bytes()


def consumer_map():
    result = {}
    for name, expected in PINS.items():
        data = source_bytes(CONSUMER / name)
        digest = hashlib.sha256(data).hexdigest()
        assert digest == expected, name
        result[name] = {"bytes": len(data), "sha256": digest}
    return result


DEPENDENCIES = {'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\local_history_controller.py': '8d37fd4ca9c4f9d7b3320da6d628ff1b5537d880b4090289347d9df7f205d142', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\test_history_transaction_controller.py': '7ec89b7aa5e810d44d466c7150d1b0f7615defa78cc310617d8b4d5a239427f7', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\README.md': '628651bd06b1a37a90b03af8d85926991d0bc7f3029e9559a60c92db1c08bf5f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\review-manifest.json': '84e19772b5c90d6313cfb4902bc7d671f82eaa753d6279b8b9f787f422c055c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-history\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\compiler_transaction_controller.py': '8a4e6a14b3354fa9e822ffaf3b43147b4bd3a1daba5b1a78f6d5df02fe8570db', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\compiler_transaction_worker.py': 'aa4d531fc5a4d4f8176ef6d61c7003375f573b8c6d0974a209f51aa1457a397f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\transaction_protocol.py': '1f36c8c159bbcee87dc5adcd8e2ef78372e046d082237faa8b24e4e26324010c', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\transaction_runtime.py': '00e02c00c22eb540eca9eb971b533bcc52566015e3a3963ccef76c7320401513', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\test_compiler_transaction.py': 'acfb8914cac9e4dc49cadb14044b5d45eedc7de3373f8c5def5029f6d2f53c0c', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\README.md': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\review-manifest.json': 'b1b681c3bb78b6f7117d37ea70e0b4129e08c16d730a5007e89b90293d783f37', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-compiler-transaction\\runtime-fork.patch': '2a72d74ef199ca1cf8454df1ee8005e72b1debf926ee69d81e956d5f347df93f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\cli_controller.py': 'd6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\base_controller.py': 'a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\test_metadata_pin.py': '6f555a7b29a85f17c404cba57474c682ae84adf28915ac8b1f10db73b9041aca', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\README.md': '1bbe94b3ac00dff9d1116ab8ccc8aadce545b14dd536888644d1cb92eac3cea6', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\review-manifest.json': '8dd48b1595220464fc638d458a6f8dd7b19f55454c35c0bda7eb7cea255b94f8', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\validation\\integration-20261025\\platform-repairs\\control-cli\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\scripts\\host_history_live.py': '3a3f5de28756ddcc383c3c92821f15fd5db24a72c324ef6a20d1ed6a24f819b2', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-d1694160\\scripts\\tests\\test_host_history_live.py': 'f37e7b419be242337d066678c3a8454156f3062bbb7578b33d14d001500b73db'}

def dependencies_map():
    result = {}
    for name, expected in DEPENDENCIES.items():
        data=source_bytes(Path(name))
        actual=hashlib.sha256(data).hexdigest()
        assert actual==expected, name
        result[name]={"bytes":len(data),"sha256":actual}
    return result

def main():
    assert os.name == "nt" and len(sys.argv) == 1
    data = source_bytes(CLI)
    assert hashlib.sha256(data).hexdigest() == CLI_SHA
    module = types.ModuleType("reviewed_private_release_cli_for_inert_tests")
    module.__file__ = str(CLI)
    exec(compile(data, str(CLI), "exec"), module.__dict__)
    g = module.load_base()
    assert g["ROOT"] == WORKTREE
    g.update(RUNS=WORKTREE / REL / "runs-history-transaction-tests", OWNER="history-transaction-source-guard-tests-v1")
    api, extended = g["load_windows_api"]()
    out = g["new_output"]("history-transaction-guard-tests-r1")
    result = {
        "sourceCommit": SOURCE, "completed": False, "testMethodsExpected": 29,
        "nativeImageRead": False, "nativeImageExecuted": False,
        "actualArchiveAcceptance": False, "releaseQualification": False,
    }
    before_driver = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    mutex = None
    owned = False
    try:
        import _winapi
        name = "Local\\YokeValidation-" + hashlib.sha256(str(WORKTREE).encode()).hexdigest()[:24]
        mutex = api.CreateMutexW(None, False, name)
        assert mutex
        wait = _winapi.WaitForSingleObject(mutex, 0)
        assert wait in (0, 128), "Another validation controller is active"
        owned = True
        result["serialMutexAbandoned"] = wait == 128
        environment = g["environment_for"]("build")
        sources = g["source_map"](api, extended, out, environment, SOURCE, "before")
        controls = g["controls_map"]()
        consumer = consumer_map()
        dependencies = dependencies_map()
        g["write_json"](out, "dependency-before.json", dependencies)
        g["write_json"](out, "control-before.json", controls)
        g["write_json"](out, "consumer-before.json", consumer)
        command = [sys.executable, "-B", "-m", "unittest", "discover", "-s", str(CONSUMER),
                   "-p", "test_history_transaction_controller.py", "-v"]
        job = g["run_owned"](api, extended, out, "tests", command, environment, 180)
        assert job["completed"] and job["exitCode"] == 0
        assert job["treeExitedBeforeCleanup"] and job["activeBeforeCleanup"] == 0
        assert job["activeAfterCleanup"] == 0 and job["rootExitedAfterCleanup"]
        assert job["cleanupUnproven"] is False
        stderr = (out / "tests.stderr").read_bytes()
        assert re.search(rb"Ran 29 tests in [0-9.]+s", stderr)
        assert re.search(rb"\nOK\r?\n", stderr) and b"skipped=" not in stderr
        after = g["source_map"](api, extended, out, environment, SOURCE, "after")
        after_controls = g["controls_map"]()
        after_consumer = consumer_map()
        after_dependencies = dependencies_map()
        g["write_json"](out, "dependency-after.json", after_dependencies)
        assert dependencies == after_dependencies
        dependencies = dependencies_map()
        g["write_json"](out, "dependency-before.json", dependencies)
        g["write_json"](out, "control-after.json", after_controls)
        g["write_json"](out, "consumer-after.json", after_consumer)
        assert sources == after and controls == after_controls and consumer == after_consumer
        assert before_driver == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        result.update(completed=True, testsPassed=29, testsSkipped=0,
                      sourceInputs=len(sources), sourcesUnchanged=True,
                      originalControlsUnchanged=True, consumerControlsUnchanged=True, dependencyControlsUnchanged=True, dependencyFiles=24,
                      driverSha256=before_driver, jobTreeExitedBeforeCleanup=True)
    except BaseException as error:
        result.update(completed=False, errorType=type(error).__name__)
    finally:
        if owned:
            if not api.ReleaseMutex(mutex):
                result.update(completed=False, mutexReleaseFailed=True)
        if mutex:
            if not api.CloseHandle(mutex):
                result.update(completed=False, mutexCloseFailed=True)
        g["write_json"](out, "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
