"""Run reviewed compiler receipt and inert Windows lifecycle tests; no Yoke image."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import types

WORKTREE = Path("C:/Users/Lomi/.t3/worktrees/Yoke-CodeIntelligence/t3-d1694160")
REL = Path("validation/integration-20261025/platform-repairs")
SOURCE = "f8b02d4eb0145de95f108e12df51786d368b6ef3"
CLI = WORKTREE / REL / "control-cli/cli_controller.py"
CLI_SHA = "d6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582"
CONSUMER = WORKTREE / REL / "control-compiler-transaction"
PINS = {'compiler_transaction_controller.py': '8a4e6a14b3354fa9e822ffaf3b43147b4bd3a1daba5b1a78f6d5df02fe8570db', 'compiler_transaction_worker.py': 'aa4d531fc5a4d4f8176ef6d61c7003375f573b8c6d0974a209f51aa1457a397f', 'transaction_protocol.py': '1f36c8c159bbcee87dc5adcd8e2ef78372e046d082237faa8b24e4e26324010c', 'transaction_runtime.py': '00e02c00c22eb540eca9eb971b533bcc52566015e3a3963ccef76c7320401513', 'private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'test_compiler_transaction.py': 'acfb8914cac9e4dc49cadb14044b5d45eedc7de3373f8c5def5029f6d2f53c0c', 'review-manifest.json': 'b1b681c3bb78b6f7117d37ea70e0b4129e08c16d730a5007e89b90293d783f37', 'README.md': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0', '.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'runtime-fork.patch': '2a72d74ef199ca1cf8454df1ee8005e72b1debf926ee69d81e956d5f347df93f'}


def source_bytes(path):
    assert path.suffix.lower() not in (".exe", ".pdb", ".dll", ".lib", ".obj", ".o")
    info = path.lstat()
    assert info.st_size <= 1_000_000 and info.st_nlink == 1
    assert not getattr(info, "st_file_attributes", 0) & 0x400
    return path.read_bytes()


def consumer_map():
    result = {}
    for name, expected in PINS.items():
        data = source_bytes(CONSUMER / name)
        digest = hashlib.sha256(data).hexdigest()
        assert digest == expected, name
        result[name] = {"bytes": len(data), "sha256": digest}
    return result


def main():
    assert os.name == "nt" and len(sys.argv) == 1
    data = source_bytes(CLI)
    assert hashlib.sha256(data).hexdigest() == CLI_SHA
    module = types.ModuleType("reviewed_private_release_cli_for_compiler_inert_tests")
    module.__file__ = str(CLI)
    exec(compile(data, str(CLI), "exec"), module.__dict__)
    g = module.load_base()
    assert g["ROOT"] == WORKTREE
    g.update(RUNS=WORKTREE / REL / "runs-compiler-guard-tests", OWNER="compiler-source-guard-tests-v1")
    api, extended = g["load_windows_api"]()
    out = g["new_output"]("compiler-guard-tests-r1")
    result = {
        "sourceCommit": SOURCE, "completed": False, "testMethodsExpected": 35,
        "nativeImageRead": False, "nativeImageExecuted": False,
        "actualArchiveAcceptance": False, "releaseQualification": False,
    }
    before_driver = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    mutex = None
    owned = False
    try:
        import _winapi
        name = "Local\\YokeValidation-" + hashlib.sha256(str(WORKTREE).encode()).hexdigest()[:24]
        mutex = api.CreateMutexW(None, False, name)
        assert mutex
        wait = _winapi.WaitForSingleObject(mutex, 0)
        assert wait in (0, 128), "Another validation controller is active"
        owned = True
        result["serialMutexAbandoned"] = wait == 128
        environment = g["environment_for"]("build")
        sources = g["source_map"](api, extended, out, environment, SOURCE, "before")
        controls = g["controls_map"]()
        consumer = consumer_map()
        g["write_json"](out, "control-before.json", controls)
        g["write_json"](out, "consumer-before.json", consumer)
        command = [sys.executable, "-B", "-m", "unittest", "discover", "-s", str(CONSUMER),
                   "-p", "test_compiler_transaction.py", "-v"]
        job = g["run_owned"](api, extended, out, "tests", command, environment, 180)
        assert job["completed"] and job["exitCode"] == 0
        assert job["treeExitedBeforeCleanup"] and job["activeBeforeCleanup"] == 0
        assert job["activeAfterCleanup"] == 0 and job["rootExitedAfterCleanup"]
        assert job["cleanupUnproven"] is False
        stderr = (out / "tests.stderr").read_bytes()
        assert re.search(rb"Ran 35 tests in [0-9.]+s", stderr)
        assert re.search(rb"\nOK\r?\n", stderr) and b"skipped=" not in stderr
        after = g["source_map"](api, extended, out, environment, SOURCE, "after")
        after_controls = g["controls_map"]()
        after_consumer = consumer_map()
        g["write_json"](out, "control-after.json", after_controls)
        g["write_json"](out, "consumer-after.json", after_consumer)
        assert sources == after and controls == after_controls and consumer == after_consumer
        assert before_driver == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        result.update(completed=True, testsPassed=35, testsSkipped=0,
                      sourceInputs=len(sources), sourcesUnchanged=True,
                      originalControlsUnchanged=True, transactionControlsUnchanged=True, actualCargoBuild=False, actualVersion=False, actualHistory=False,
                      driverSha256=before_driver, jobTreeExitedBeforeCleanup=True)
    except BaseException as error:
        result.update(completed=False, errorType=type(error).__name__)
    finally:
        if owned:
            if not api.ReleaseMutex(mutex):
                result.update(completed=False, mutexReleaseFailed=True)
        if mutex:
            if not api.CloseHandle(mutex):
                result.update(completed=False, mutexCloseFailed=True)
        g["write_json"](out, "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
