"""Owned checks of the reviewed working-byte packaging patch; no native image."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import types

ROOT = Path('C:/Users/Lomi/Documents/NN-Developed/Yoke-CodeIntelligence')
BASE = ROOT / 'validation/integration-20261025/platform-repairs'
CLI = BASE / 'control-cli/cli_controller.py'
CLI_SHA = 'd6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582'
INVENTORY = BASE / 'runs/source-utility-fixture-r2/source-after.json'
INVENTORY_SHA = '59cbaf8c0e509504ff7262fbc0b1696739427156b6eb805c1c6cef2b2db6b0e1'
PATCH = ('scripts/package-vscode.py', 'scripts/tests/test_package_vscode.py', 'docs/ARCHITECTURE.md')
NODE = Path('C:/Program Files/nodejs/node.exe')
NPM = NODE.parent / 'node_modules/npm/bin/npm-cli.js'


def text_bytes(path, maximum=64_000_000):
    assert path.suffix.lower() not in ('.exe', '.pdb', '.dll', '.rlib', '.lib', '.obj', '.o')
    before = path.lstat()
    assert before.st_size <= maximum and before.st_nlink == 1
    assert not getattr(before, 'st_file_attributes', 0) & 0x400
    data = path.read_bytes()
    after = path.lstat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    return data


def source_map(names):
    return {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name in names for data in (text_bytes(ROOT / name),)}


def main():
    assert os.name == 'nt' and len(sys.argv) == 1
    data = text_bytes(CLI)
    assert hashlib.sha256(data).hexdigest() == CLI_SHA
    module = types.ModuleType('reviewed_capacity_check_runtime')
    module.__file__ = str(CLI)
    exec(compile(data, str(CLI), 'exec'), module.__dict__)
    g = module.load_base()
    assert g['ROOT'] == ROOT
    g.update(RUNS=BASE / 'runs-package-capacity', OWNER='package-capacity-working-source-checks-v1')
    api, extended = g['load_windows_api']()
    out = g['new_output']('capacity-checks-r1')
    inventory = text_bytes(INVENTORY)
    assert hashlib.sha256(inventory).hexdigest() == INVENTORY_SHA
    baseline = json.loads(inventory)
    names = sorted(set(baseline) | set(PATCH))
    assert 1135 <= len(names) <= 1140
    assert NODE.is_file() and NPM.is_file()
    result = {'completed': False, 'scope': 'reviewed-working-byte-patch',
              'parentHead': 'f8b02d4eb0145de95f108e12df51786d368b6ef3',
              'nativeImageRead': False, 'nativeImageExecuted': False,
              'releaseQualification': False, 'checks': []}
    mutex = None
    owned = False
    try:
        import _winapi
        mutex_name = 'Local\\YokeValidation-' + hashlib.sha256(str(ROOT).encode()).hexdigest()[:24]
        mutex = api.CreateMutexW(None, False, mutex_name)
        assert mutex
        wait = _winapi.WaitForSingleObject(mutex, 0)
        assert wait in (0, 128)
        owned = True
        result['mutexAbandoned'] = wait == 128
        sources = source_map(names)
        changed = {name for name in baseline if baseline[name] != sources[name]}
        assert changed <= set(PATCH), changed
        controls = g['controls_map']()
        driver_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        g['write_json'](out, 'source-before.json', sources)
        g['write_json'](out, 'control-before.json', controls)
        environment = g['environment_for']('test')
        commands = (
            ('python-package-vscode', [sys.executable, '-B', '-m', 'unittest', 'discover',
              '-s', 'scripts/tests', '-p', 'test_package_vscode.py', '-v']),
            ('typecheck', [str(NODE), str(NPM), 'run', 'typecheck']),
            ('npm-test', [str(NODE), str(NPM), 'test']),
        )
        for label, argv in commands:
            job = g['run_owned'](api, extended, out, label, argv, environment, 180)
            assert job['completed'] and job['exitCode'] == 0, label
            assert job['activeBeforeCleanup'] == 0 and job['activeAfterCleanup'] == 0
            assert job['treeExitedBeforeCleanup'] and job['rootExitedAfterCleanup']
            assert job['streamEOF'] == [True, True] and job['readerErrors'] == [False, False]
            assert job['cleanupUnproven'] is False
            if label == 'python-package-vscode':
                stderr = text_bytes(out / (label + '.stderr'), 16_000_000)
                assert re.search(rb'Ran 17 tests in [0-9.]+s', stderr)
                assert re.search(rb'\nOK\r?\n', stderr) and b'skipped=' not in stderr
            result['checks'].append({'name': label, 'exitCode': 0, 'naturalTreeExit': True})
        after = source_map(names)
        after_controls = g['controls_map']()
        assert sources == after and controls == after_controls
        assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == driver_hash
        g['write_json'](out, 'source-after.json', after)
        g['write_json'](out, 'control-after.json', after_controls)
        result.update(completed=True, sourceFiles=len(names), sourcesUnchanged=True,
                      controlsUnchanged=True, driverSha256=driver_hash,
                      pythonTestsPassed=17, pythonTestsSkipped=0)
    except BaseException as error:
        result.update(completed=False, errorType=type(error).__name__)
    finally:
        if owned and not api.ReleaseMutex(mutex):
            result.update(completed=False, mutexReleaseFailed=True)
        if mutex and not api.CloseHandle(mutex):
            result.update(completed=False, mutexCloseFailed=True)
        g['write_json'](out, 'result.json', result)
    print(json.dumps(result), flush=True)
    return 0 if result['completed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
