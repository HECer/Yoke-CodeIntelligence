"""Authored mocks and owned inert JSON only; no native image or live producer is selected."""
from contextlib import ExitStack
import base64
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock


SPEC = importlib.util.spec_from_file_location(
    "owned_history_transaction_controller", Path(__file__).with_name("history_transaction_controller.py"))
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)
# These pinned library sources have no main side effects. No worker/helper/API
# function is called by importing them, and the tests never select an EXE/PDB.
P = C.load_source(C.TRANSACTION / "transaction_protocol.py",
                  C.TRANSACTION_PINS["transaction_protocol.py"], "inert_transaction_protocol")
H = C.load_source(C.LEGACY / "local_history_controller.py",
                  C.LEGACY_PINS["local_history_controller.py"], "inert_history_validators")


def opt():
    return SimpleNamespace(source_commit=C.SOURCE_COMMIT, run_id="history-owned",
                           producer_run_id="build-owned", version_run_id="version-owned")


def maps():
    return {"original": {name: {"bytes": 1, "sha256": sha} for name, sha in C.ORIGINAL_PINS.items()},
            "transaction": {name: {"bytes": 1, "sha256": sha} for name, sha in C.TRANSACTION_PINS.items()},
            "legacy-history": {name: {"bytes": 1, "sha256": sha} for name, sha in C.LEGACY_PINS.items()},
            "harness": {name: {"bytes": 1, "sha256": sha} for name, sha in C.HARNESS_PINS.items()},
            "consumer": {name: {"bytes": 1, "sha256": "a" * 64} for name in C.CONTROL_NAMES}}


def sources():
    return {"Cargo.toml": {"bytes": 1, "sha256": "a" * 64}}


class MemoryPin:
    """A mock held receipt. Data is owned inert JSON, never an image file."""
    def __init__(self, data=b"", *, record=None, state=None, close_failure=False):
        self.data = data
        self.identity = record or {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
        self.state, self.close_failure = state, close_failure
        self.rechecks, self.fail_at = 0, None

    def bytes(self):
        return self.data

    def record(self):
        return copy.deepcopy(self.identity)

    def recheck(self):
        self.rechecks += 1
        if self.fail_at is not None and self.rechecks >= self.fail_at:
            raise C.Refusal("drift")
        return self.record()

    def __enter__(self):
        if self.state is not None:
            self.state["openPins"] += 1
        return self

    def __exit__(self, *_):
        if self.state is not None:
            self.state["openPins"] -= 1
        if self.close_failure:
            raise RuntimeError("private capability at pin close")
        self.recheck()


def admission():
    image = P.image_path(opt().producer_run_id)
    record = {"path": str(image), "sha256": "a" * 64, "fileIdentity": [1, 2],
              "bytes": 100, "mtimeNs": 3, "links": 1, "noReparseAncestors": True,
              "writersAndDeletionDeniedThroughRecheck": True}
    return {"image": image, "record": record, "imagePin": MemoryPin(record=record), "receiptPins": {},
            "protectedPins": {}, "protectedBefore": {"owned/protected": {"present": False}},
            "artifact": {"ownedArtifact": "inert-source-bound-fixture"}}


def version_fixture():
    args, admitted, controls = opt(), admission(), maps()
    stdout = b"yoke 0.5.0\n"
    request = P.request_record("version", args.version_run_id, args.source_commit, args.producer_run_id,
                                sources(), controls["original"], controls["transaction"])
    outer = {key: None for key in P.OUTER_KEYS}
    outer.update(command=request["command"], deadlineSeconds=30, logCapBytes=P.MAX_LOG, stdinClosed=True,
                 startedSuspended=True, assignedBeforeResume=True, completed=True, treeExitedBeforeCleanup=True,
                 minimumFreeObserved=P.RUN_FREE, cleanupErrors=[], streamEOF=[True, True], readerErrors=[False, False],
                 startedMonotonicNs=1_000_000_000, absoluteDeadlineNs=31_000_000_000, jobName=None,
                 namedJobCreatedNew=False, pid=101, resumePreviousSuspendCount=1, exitCode=0,
                 rootObservedMonotonicNs=2_000_000_000, membersAtRootObservation=[], rootExitedAtObservation=True,
                 activeAtRootObservation=0, originalDrainSeconds=1, activeBeforeCleanup=0,
                 membersAfterOriginalDrain=[], treeObservedMonotonicNs=2_100_000_000, cleanupSeconds=2,
                 activeAfterCleanup=0, rootExitedAfterCleanup=True, elapsedSeconds=1.1,
                 capturedLogBytes=len(stdout), outputExceeded=False, cleanupUnproven=False)
    row = {"owner": P.OWNER, "schema": 2, "mode": "version", "runId": args.version_run_id,
           "sourceCommit": args.source_commit, "completed": True, "inputsUnchanged": True,
           "protectedMetadataUnchanged": True, "nativeImageReadAttempted": True, "nativeImageRead": True,
           "selectedImage": admitted["record"], "selectedArtifact": admitted["artifact"], "observedVersion": "yoke 0.5.0",
           "errorCode": None, "releaseQualification": False, "vsixQualification": False,
           "qualification": "compiler-transaction/version-only", "freeAfter": P.RUN_FREE}
    values = {"request.json": request, "result.json": row, "outer.job.json": outer,
              "selected-image.json": admitted["record"], "selected-image-after.json": admitted["record"]}
    for stem, value in (("source", sources()), ("original-control", controls["original"]),
                        ("transaction-control", controls["transaction"]), ("protected", admitted["protectedBefore"])):
        for phase in ("before", "after", "final"):
            values[stem + "-" + phase + ".json"] = copy.deepcopy(value)
    return args, admitted, controls, values, stdout


def check_version(values, stdout=None, stderr=b""):
    args, admitted, controls, _, good = version_fixture()
    C.validate_version(P, args, sources(), controls["original"], controls["transaction"],
                       admitted, values, good if stdout is None else stdout, stderr)


def good_job():
    return {"startedSuspended": True, "assignedBeforeResume": True, "complete": True, "pid": 123,
            "exitCode": 0, "activeAtParentExit": 1, "activeBeforeCleanup": 0,
            "treeExitedBeforeCleanup": True, "activeAfterCleanup": 0}


def good_live():
    variants = []
    for name in H.VARIANTS:
        variants.append({"variant": name, "complete": True, "packages": 2, "originalRecords": 33,
                         "allOriginalsReadBack": True, "oldAndCurrentAuthorityRefusedDuringPending": True,
                         "configurationAndOwnerExactDuringArchival": True, "freshSameHostSaveAfterArchival": True,
                         "actualJournalCurrentGeneration": True, "bothArchiveFramesRemainExact": True,
                         "persistent45Retained": name == "persistent-python",
                         "runtimeExitBeforeJobCleanup": name == "persistent-python",
                         "currentExit": {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True},
                         "oldExit": {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True},
                         "analyzedSourceUnchanged": True})
    return {"product": "Code Intelligence", "version": "0.5.0", "complete": True, "nativeSha256": "a" * 64,
            "variants": variants, "workerJobAdmission": {"specificJobMembershipConfirmed": True,
                                                         "queryHandleClosedBeforeNativeRead": True},
            "modelCalls": 0, "analyzedSourceExecuted": False, "existingCredentialsSelected": False,
            "nativeBrowserAcceptanceClaimed": False}


def archive_evidence():
    result = {"job.json": good_job(), "live-result.json": good_live()}
    for label in H.VARIANTS:
        for tag, numbers in (("first", range(32)), ("second", range(32, 33))):
            records = []
            for index, number in enumerate(numbers):
                data = ("\ufeffowned \u03c0 \U0001f980 e\u0301 " + str(number) + "\r\n").encode("utf8")
                record = {"name": "yoke-doc-" + "b" * 64 + "-" + format(number, "064x") + ".plan.json",
                          "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                records.append(record)
                result[label + "/" + tag + "-read-" + str(index) + ".stdout"] = {
                    "planId": ("c" if tag == "first" else "d") * 64, "recordName": record["name"],
                    "originalIdentity": "owned-inert-original", "originalSecuritySha256": "e" * 64,
                    "sha256": record["sha256"], "byteLength": record["bytes"],
                    "bytesBase64": base64.b64encode(data).decode("ascii"), "immutableRecordEvidenceOnly": True,
                    "fileChanged": False, "sourceWritten": False}
            result[label + "/" + tag + "-frame-proof.json"] = {"sha256": "f" * 64, "records": records}
    return result


class ClosedSelectorsAndMapsTests(unittest.TestCase):
    def args(self):
        return ["--source-commit", C.SOURCE_COMMIT, "--run-id", "history-owned",
                "--producer-run-id", "build-owned", "--version-run-id", "version-owned"]

    def test_version_selector_is_required_and_all_three_ids_are_distinct(self):
        self.assertEqual(C.options(self.args()).version_run_id, "version-owned")
        cases = [self.args()[:-2], self.args() + ["--native", "foreign.exe"], self.args() + self.args()[-2:],
                 ["--source", C.SOURCE_COMMIT, *self.args()[2:]],
                 [*self.args()[:-1], "build-owned"], [*self.args()[:-1], "history-owned"],
                 [*self.args()[:-1], "../foreign"], [*self.args()[:-1], "C:/foreign"],
                 [*self.args()[:-1], "x" * 97], [self.args()[0], "b" * 40, *self.args()[2:]]]
        for args in cases:
            with self.subTest(args=args), self.assertRaises(C.Refusal):
                C.options(args)

    def test_json_rejects_duplicate_fields_nonfinite_values_and_overflow(self):
        self.assertEqual(C.unique_json(b'{"a":1}'), {"a": 1})
        for value, cap in [(b'{"a":1,"a":2}', 100), (b'{"a":{"b":1,"b":2}}', 100),
                           (b'{"x":NaN}', 100), (b'{"x":Infinity}', 100), (b"\xff", 100),
                           (b"null trailing", 100), (b" " * 101, 100)]:
            with self.subTest(value=value), self.assertRaises(C.Refusal):
                C.unique_json(value, cap)

    def test_manifest_keeps_all_five_source_groups_distinct(self):
        own = maps()["consumer"]
        manifest = {"owner": C.OWNER, "schema": 1, "scope": "original-archive-only", "sourceCommit": C.SOURCE_COMMIT,
                    "consumerSources": {n: "a" * 64 for n in C.CONTROL_NAMES if n != "review-manifest.json"},
                    "legacySources": C.LEGACY_PINS, "transactionSources": C.TRANSACTION_PINS,
                    "originalSources": C.ORIGINAL_PINS, "harnessSources": C.HARNESS_PINS, "budgets": C.BUDGETS}
        C.validate_manifest(manifest, own)
        mutations = [lambda x: x.update(schema=True), lambda x: x.update(scope="release"),
                     lambda x: x.update(extra=True), lambda x: x["budgets"].update(workerSeconds=181),
                     lambda x: x["budgets"].update(workerDrainSeconds=True),
                     lambda x: x["legacySources"].update({"history_transaction_controller.py": "a" * 64}),
                     lambda x: x["transactionSources"].update({"history_transaction_controller.py": "a" * 64}),
                     lambda x: x["originalSources"].update({"transaction_protocol.py": "a" * 64}),
                     lambda x: x["harnessSources"].update({"scripts/host_history_live.py": "b" * 64}),
                     lambda x: x["consumerSources"].update({"history_transaction_controller.py": "b" * 64})]
        for mutate in mutations:
            changed = copy.deepcopy(manifest)
            mutate(changed)
            with self.subTest(mutate=mutate), self.assertRaises(C.Refusal):
                C.validate_manifest(changed, own)

    def test_final_broader_source_observation_uses_separate_fixed_git_label(self):
        g = {"git_capture": mock.Mock(return_value=b"Cargo.toml\0src/owned.ts\0"),
             "source_digest": mock.Mock(return_value={"bytes": 1, "sha256": "a" * 64})}
        mapping = C.history_source_map(H, g, None, None, None, {}, "final")
        self.assertEqual(set(mapping), {"Cargo.toml", "src/owned.ts"})
        self.assertEqual(g["git_capture"].call_args.args[4], "history-files-final")
        self.assertEqual(g["git_capture"].call_args.args[5], ["ls-files", "-z", "--", *H.HISTORY_SELECTOR])
        self.assertNotEqual(mapping, sources())

    def test_occupied_output_and_text_reader_never_adopt_an_image(self):
        with tempfile.TemporaryDirectory(prefix="owned-history-transaction-") as directory:
            parent = Path(directory).resolve()
            (parent / "occupied").mkdir()
            with self.assertRaises(C.Refusal):
                C.fresh_directory(parent, "occupied")
            for suffix in (".exe", ".pdb", ".dll", ".obj"):
                with self.subTest(suffix=suffix), self.assertRaises(C.Refusal):
                    C.text_bytes(parent / ("never-created" + suffix))
            with self.assertRaises(C.Refusal):
                C.fresh_directory(parent, "../escape")


class ShortFixtureTests(unittest.TestCase):
    def test_original_worker_budgets_remain_exact(self):
        self.assertEqual(C.BUDGETS, H.BUDGETS)
        self.assertEqual(C.MAX_FIXTURE_UTF16_UNITS, 70)

    def test_missing_relative_network_and_long_temp_refuse_before_creation(self):
        bad = ("", "relative", r"\\server\share", "C:/" + "a" * 80, "C:/" + "\U0001f9ed" * 30)
        for value in bad:
            with self.subTest(value=value), mock.patch.dict(C.os.environ, {"TEMP": value}), \
                    mock.patch.object(C, "ordinary") as inspect, \
                    mock.patch.object(C, "fresh_directory") as create:
                with self.assertRaises(C.Refusal):
                    C.fresh_fixture()
                inspect.assert_not_called()
                create.assert_not_called()
        with mock.patch.dict(C.os.environ, {}, clear=True), \
                mock.patch.object(C, "fresh_directory") as create:
            with self.assertRaises(C.Refusal):
                C.fresh_fixture()
            create.assert_not_called()

    def test_unavailable_or_linked_temp_parent_never_creates_a_fixture(self):
        with mock.patch.dict(C.os.environ, {"TEMP": "C:/owned-temp"}), \
                mock.patch.object(C, "ordinary", side_effect=C.Refusal("path")), \
                mock.patch.object(C, "fresh_directory") as create:
            with self.assertRaises(C.Refusal):
                C.fresh_fixture()
            create.assert_not_called()

    def test_short_owned_fixture_supports_original_long_journal_names_and_refuses_collision(self):
        with tempfile.TemporaryDirectory(prefix="h-") as directory, \
                mock.patch.dict(C.os.environ, {"TEMP": str(Path(directory).resolve())}), \
                mock.patch.object(C.os, "urandom", return_value=b"\0" * 8):
            fixture = C.fresh_fixture()
            self.assertLessEqual(len(str(fixture).encode("utf-16-le")) // 2, 70)
            journal = fixture / "persistent-python" / "old" / (
                "yoke-doc-" + "a" * 64 + "-" + "b" * 64 + ".e0001.json")
            journal.parent.mkdir(parents=True)
            journal.write_bytes(b"Owned inert journal path fixture\n")
            self.assertEqual(journal.read_bytes(), b"Owned inert journal path fixture\n")
            self.assertLess(len(str(journal).encode("utf-16-le")) // 2, 260)
            with self.assertRaises(C.Refusal):
                C.fresh_fixture()
            self.assertEqual(journal.read_bytes(), b"Owned inert journal path fixture\n")


class VersionReceiptTests(unittest.TestCase):
    def test_complete_version_is_bound_to_new_build_image_sources_and_artifact(self):
        _, _, _, values, _ = version_fixture()
        check_version(values)

    def test_same_version_text_cannot_replay_a_foreign_or_legacy_request(self):
        for mutate in [lambda x: x["request.json"].update(producerRunId="foreign-build"),
                       lambda x: x["request.json"].update(runId="foreign-version"),
                       lambda x: x["request.json"].update(sourceCommit="b" * 40),
                       lambda x: x["request.json"].update(owner="legacy-release-cli"),
                       lambda x: x["request.json"].update(schema=1),
                       lambda x: x["request.json"].update(command=["foreign.exe", "--version"]),
                       lambda x: x["request.json"].update(deadlineSeconds=31),
                       lambda x: x["request.json"].update(cleanupSeconds=10),
                       lambda x: x["request.json"].update(sourceDigest="b" * 64),
                       lambda x: x["request.json"].update(transactionControlsDigest="b" * 64),
                       lambda x: x["request.json"].update(originalControlsDigest="b" * 64),
                       lambda x: x["request.json"].update(preparationInventoryIsSeparate=False),
                       lambda x: x["request.json"].update(extra=True)]:
            values = copy.deepcopy(version_fixture()[3])
            mutate(values)
            with self.subTest(mutate=mutate), self.assertRaises((C.Refusal, P.Refusal)):
                check_version(values)

    def test_completed_flags_are_typed_and_unqualified(self):
        for key, bad in [("completed", False), ("completed", 1), ("schema", True), ("mode", "build"),
                         ("runId", "foreign"), ("sourceCommit", "b" * 40), ("owner", "legacy"),
                         ("inputsUnchanged", False), ("protectedMetadataUnchanged", False),
                         ("nativeImageReadAttempted", False), ("nativeImageRead", False),
                         ("observedVersion", "yoke 0.4.0"), ("errorCode", "recovered-failure"),
                         ("releaseQualification", True), ("vsixQualification", True),
                         ("qualification", "release"), ("freeAfter", True), ("freeAfter", P.RUN_FREE - 1)]:
            values = copy.deepcopy(version_fixture()[3])
            values["result.json"][key] = bad
            with self.subTest(key=key, bad=bad), self.assertRaises((C.Refusal, P.Refusal)):
                check_version(values)

    def test_image_rename_default_path_identity_and_artifact_replays_refuse(self):
        for mutate in [lambda x: x["result.json"]["selectedImage"].update(path=str(C.ROOT / "target/release/yoke.exe")),
                       lambda x: x["result.json"]["selectedImage"].update(path=str(C.BASE / "runs-cli/build-owned/owned-release-cli.exe")),
                       lambda x: x["result.json"]["selectedImage"].update(sha256="b" * 64),
                       lambda x: x["result.json"]["selectedImage"].update(fileIdentity=[1, 99]),
                       lambda x: x["result.json"]["selectedImage"].update(links=2),
                       lambda x: x["result.json"]["selectedImage"].update(bytes=C.BUDGETS["imageBytes"] + 1),
                       lambda x: x["result.json"]["selectedImage"].update(writersAndDeletionDeniedThroughRecheck=False),
                       lambda x: x["selected-image-after.json"].update(mtimeNs=999),
                       lambda x: x.update({"selected-image-after.json": dict(x["selected-image-after.json"], bytes=100.0)}),
                       lambda x: x["result.json"].update(selectedArtifact={"ownedArtifact": "foreign"})]:
            values = copy.deepcopy(version_fixture()[3])
            mutate(values)
            with self.subTest(mutate=mutate), self.assertRaises((C.Refusal, P.Refusal)):
                check_version(values)

    def test_every_source_control_and_protected_phase_must_match_current_admission(self):
        for stem in ("source", "original-control", "transaction-control", "protected"):
            for phase in ("before", "after", "final"):
                values = copy.deepcopy(version_fixture()[3])
                values[stem + "-" + phase + ".json"] = {"foreign": "observed"}
                with self.subTest(stem=stem, phase=phase), self.assertRaises(C.Refusal):
                    check_version(values)

    def test_numeric_aliases_do_not_forge_exact_source_control_or_protected_maps(self):
        for mutate in [lambda x: x["source-before.json"]["Cargo.toml"].update(bytes=True),
                       lambda x: x["source-final.json"]["Cargo.toml"].update(bytes=1.0),
                       lambda x: x["original-control-after.json"]["cli_controller.py"].update(bytes=1.0),
                       lambda x: x["transaction-control-final.json"]["transaction_protocol.py"].update(bytes=True),
                       lambda x: x["protected-before.json"]["owned/protected"].update(present=0)]:
            values = copy.deepcopy(version_fixture()[3])
            mutate(values)
            with self.subTest(mutate=mutate), self.assertRaises(C.Refusal):
                check_version(values)

    def test_lifecycle_cannot_be_repaired_by_forced_cleanup_or_longer_budgets(self):
        for key, bad in [("completed", False), ("treeExitedBeforeCleanup", False), ("activeBeforeCleanup", 1),
                         ("activeAfterCleanup", 1), ("cleanupUnproven", True), ("cleanupErrors", ["close"]),
                         ("streamEOF", [True, False]), ("readerErrors", [True, False]),
                         ("deadlineSeconds", 31), ("originalDrainSeconds", 60), ("cleanupSeconds", 10),
                         ("startedSuspended", False), ("assignedBeforeResume", False), ("exitCode", 17),
                         ("exitCode", False), ("resumePreviousSuspendCount", 0), ("namedJobCreatedNew", True),
                         ("jobName", "Local\\YokeHistoryCI-" + "a" * 64), ("elapsedSeconds", float("nan")),
                         ("rootObservedMonotonicNs", 31_000_000_000), ("capturedLogBytes", 0)]:
            values = copy.deepcopy(version_fixture()[3])
            values["outer.job.json"][key] = bad
            with self.subTest(key=key, bad=bad), self.assertRaises((C.Refusal, P.Refusal)):
                check_version(values)

    def test_streams_have_exact_length_version_output_and_no_stderr(self):
        values = version_fixture()[3]
        for stdout, stderr in [(b"yoke 0.5.0\nextra", b""), (b"yoke 0.5.0\n", b"private capability"),
                               (b"yoke 0.4.0\n", b""), ("yoke 0.5.0\n", b""),
                               (b"x" * (P.MAX_LOG + 1), b"")]:
            with self.subTest(length=len(stdout)), self.assertRaises(C.Refusal):
                check_version(values, stdout, stderr)

    def test_missing_duplicate_and_unknown_version_evidence_refuse(self):
        for mutate in [lambda x: x.pop("protected-final.json"), lambda x: x.update({"unknown.json": {}}),
                       lambda x: x["result.json"].update(extra=True)]:
            values = copy.deepcopy(version_fixture()[3])
            mutate(values)
            with self.subTest(mutate=mutate), self.assertRaises(C.Refusal):
                check_version(values)

    def test_version_receipt_capacity_refuses_before_any_pin(self):
        g = {"ReadPin": mock.Mock(side_effect=AssertionError("No receipt/image should be read"))}
        with mock.patch.object(C, "ordinary", return_value=SimpleNamespace(st_size=64_000_001)):
            with ExitStack() as stack, self.assertRaises(C.Refusal):
                C.version_admission(P, g, None, stack, opt(), sources(), {}, {}, admission())
        g["ReadPin"].assert_not_called()

    def test_version_namespace_selectors_refuse_before_filesystem_or_pin(self):
        for run_id in ("../foreign", "C:/foreign", "same", "\u03c0", "a" * 97):
            args = opt()
            args.version_run_id = run_id
            if run_id == "same":
                args.producer_run_id = run_id
            with mock.patch.object(C, "ordinary") as lookup:
                with ExitStack() as stack, self.assertRaises((C.Refusal, P.Refusal)):
                    C.version_admission(P, {}, None, stack, args, sources(), {}, {}, admission())
            lookup.assert_not_called()

    def test_version_admission_pins_every_receipt_and_rechecks_late(self):
        args, admitted, controls, values, stdout = version_fixture()
        data = {name: json.dumps(value).encode("ascii") for name, value in values.items()}
        data.update({"outer.stdout": stdout, "outer.stderr": b""})
        seen = []

        def read_pin(api, path, maximum):
            seen.append((path, maximum))
            return MemoryPin(data[path.name])
        with mock.patch.object(C, "ordinary", return_value=SimpleNamespace(st_size=100)), ExitStack() as stack:
            pins, before = C.version_admission(P, {"ReadPin": read_pin}, None, stack, args, sources(),
                                               controls["original"], controls["transaction"], admitted)
            self.assertEqual(set(pins), set(C.VERSION_FILES))
            self.assertEqual(len(seen), len(C.VERSION_FILES))
            self.assertTrue(all(path.parent == P.RUNS / args.version_run_id for path, _ in seen))
            self.assertTrue(all(cap == (P.MAX_LOG if path.name in ("outer.stdout", "outer.stderr")
                                       else C.BUDGETS["jsonBytes"]) for path, cap in seen))
            C.recheck_snapshot(pins, before)
            pins["result.json"].identity["sha256"] = "b" * 64
            with self.assertRaises(C.Refusal):
                C.recheck_snapshot(pins, before)


class ProducerBoundaryTests(unittest.TestCase):
    def test_incomplete_new_producer_never_reaches_version_or_worker(self):
        result = C.initial_result(opt())
        with mock.patch.object(P, "producer_admission", side_effect=P.Refusal("incomplete")), \
             mock.patch.object(C, "version_admission") as version:
            with ExitStack() as stack, self.assertRaises(P.Refusal):
                C.admit_pair(P, {}, None, {}, stack, opt(), sources(), {}, {}, result)
        version.assert_not_called()
        self.assertFalse(result["nativeImageReadAttempted"])
        self.assertFalse(result["nativeImageRead"])
        self.assertFalse(result["nativeExecutionRequested"])

    def test_legacy_tuple_and_foreign_admitted_image_have_no_fallback(self):
        for value in [(Path("foreign.exe"), {}, {}, {}), dict(admission(), image=C.ROOT / "target/release/yoke.exe")]:
            result = C.initial_result(opt())
            with mock.patch.object(P, "producer_admission", return_value=value), \
                 mock.patch.object(C, "version_admission") as version:
                with ExitStack() as stack, self.assertRaises(C.Refusal):
                    C.admit_pair(P, {}, None, {}, stack, opt(), sources(), {}, {}, result)
            version.assert_not_called()
            self.assertFalse(result["nativeExecutionRequested"])

    def test_missing_or_rejected_version_does_not_authorize_worker_after_valid_build(self):
        result = C.initial_result(opt())

        def producer(*args, **kwargs):
            kwargs["on_image_attempt"]()
            return admission()
        with mock.patch.object(P, "producer_admission", side_effect=producer), \
             mock.patch.object(C, "version_admission", side_effect=RuntimeError("private URL")):
            with ExitStack() as stack, self.assertRaises(RuntimeError):
                C.admit_pair(P, {}, None, {}, stack, opt(), sources(), {}, {}, result)
        self.assertTrue(result["nativeImageReadAttempted"])
        self.assertTrue(result["nativeImageRead"])
        self.assertFalse(result["nativeExecutionRequested"])

    def test_late_admission_image_or_receipt_failure_is_not_salvaged(self):
        result = C.initial_result(opt())
        pin = MemoryPin(b"owned-version")
        expected = C.pin_snapshot({"version": pin})
        with mock.patch.object(P, "producer_admission", return_value=admission()), \
             mock.patch.object(C, "version_admission", return_value=({"version": pin}, expected)), \
             mock.patch.object(P, "recheck_admission", side_effect=P.Refusal("image-drift")):
            with ExitStack() as stack, self.assertRaises(P.Refusal):
                C.admit_pair(P, {}, None, {}, stack, opt(), sources(), {}, {}, result)
        self.assertFalse(result["nativeExecutionRequested"])

    def test_pair_recheck_requires_both_image_and_version_receipts(self):
        pin = MemoryPin(b"owned-version")
        before = C.pin_snapshot({"version": pin})
        with mock.patch.object(P, "recheck_admission") as image:
            C.recheck_pair(P, {}, admission(), {"version": pin}, before)
            self.assertEqual(image.call_count, 1)
            pin.identity["sha256"] = "b" * 64
            with self.assertRaises(C.Refusal):
                C.recheck_pair(P, {}, admission(), {"version": pin}, before)
            self.assertEqual(image.call_count, 2)


class OwnedInertControllerTests(unittest.TestCase):
    def run_inert(self, *, pin_close=False, mutex_close=False, version_late=False, bad_evidence=None):
        with tempfile.TemporaryDirectory(prefix="owned-history-transaction-flow-") as directory:
            root = Path(directory).resolve()
            runs, private = root / "runs", root / "private"
            state = {"openPins": 0, "workerCalls": 0, "releaseCalls": 0, "nativeByteReads": 0}
            admitted, current = admission(), maps()
            version_pin = MemoryPin(b"owned-version")
            version_before = C.pin_snapshot({"version": version_pin})
            if version_late:
                version_pin.fail_at = 3

            def read_pin(api, path, maximum):
                if path.suffix.lower() in (".exe", ".pdb"):
                    state["nativeByteReads"] += 1
                    raise AssertionError("No native bytes belong in an inert test")
                data = path.read_bytes()
                self.assertLessEqual(len(data), maximum)
                return MemoryPin(data, state=state, close_failure=pin_close and path.name == "spec.json")

            def control_pins(g, api, stack):
                return {"owned/control": stack.enter_context(MemoryPin(b"owned-control", state=state))}

            def worker(spec_path, fixture, evidence, environment, name):
                state["workerCalls"] += 1
                self.assertEqual(name, json.loads(spec_path.read_bytes())["workerJobName"])
                self.assertRegex(name, r"Local\\YokeHistoryCI-[0-9a-f]{64}")
                self.assertNotIn("GITHUB_ACTIONS", environment)
                data = archive_evidence()
                if bad_evidence is not None:
                    bad_evidence(data)
                for relative, value in data.items():
                    path = evidence / relative
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_bytes(json.dumps(value).encode("ascii"))
                (evidence / "worker.stderr").write_text("private bearer URL must remain private", encoding="ascii")

            def release(p, api, handle):
                state["releaseCalls"] += 1
                self.assertEqual(state["openPins"], 0)
                if mutex_close:
                    raise RuntimeError("private mutex error")

            compiler = SimpleNamespace(acquire_mutex=mock.Mock(return_value=17), release_mutex=release)
            live = SimpleNamespace(bounded_worker=worker, output_size=lambda path: 0)
            g = {"ReadPin": read_pin, "source_map": mock.Mock(return_value=sources()),
                 "environment_for": mock.Mock(return_value={})}
            with mock.patch.object(C, "RUNS", runs), mock.patch.object(C, "PRIVATE", private), \
                 mock.patch.object(C, "os", SimpleNamespace(name="nt", path=os.path, urandom=os.urandom)), \
                 mock.patch.object(C.shutil, "disk_usage", return_value=SimpleNamespace(free=C.BUDGETS["imageAdmissionBytes"])), \
                 mock.patch.object(C, "source_map", return_value=current["consumer"]), \
                 mock.patch.object(C, "text_bytes", return_value=b"{}"), mock.patch.object(C, "validate_manifest"), \
                 mock.patch.object(C, "checked_map"), mock.patch.object(C, "current_maps", return_value=current), \
                 mock.patch.object(C, "load_dependencies", return_value=(compiler, P, g, {}, H, None, None)), \
                 mock.patch.object(C, "load_source", return_value=live), mock.patch.object(C, "pin_sources", return_value={}), \
                 mock.patch.object(P, "pin_control_files", side_effect=control_pins), \
                 mock.patch.object(P, "recheck_admission"), \
                 mock.patch.object(C, "admit_pair", return_value=(admitted, {"version": version_pin}, version_before)), \
                 mock.patch.object(C, "history_source_map", return_value={"owned.ts": "a" * 64}), \
                 mock.patch.object(C, "fresh_fixture", side_effect=lambda: C.fresh_directory(root, "fixture")):
                value = C.execute(opt())
            serialized = json.dumps(value)
            self.assertNotIn("private bearer", serialized)
            self.assertNotIn("private mutex", serialized)
            self.assertEqual(state["nativeByteReads"], 0)
            self.assertEqual(state["workerCalls"], 1)
            self.assertEqual(state["releaseCalls"], 1)
            self.assertEqual(state["openPins"], 0)
            receipt = json.loads((runs / opt().run_id / "result.json").read_bytes())
            self.assertEqual(receipt, value)
            return value

    def test_owned_inert_flow_closes_pins_and_mutex_before_success(self):
        value = self.run_inert()
        self.assertTrue(value["completed"])
        self.assertEqual(value["phase"], "complete")
        self.assertTrue(value["matchingVersionReceiptAdmitted"])
        self.assertEqual([v["variant"] for v in value["variants"]], list(H.VARIANTS))
        self.assertEqual([v["originalRecordsReadBack"] for v in value["variants"]], [33, 33, 33])
        self.assertFalse(value["ownerRetirementQualification"])
        self.assertFalse(value["archivePurgeQualification"])
        self.assertFalse(value["releaseQualification"])

    def test_pin_close_failure_prevents_terminal_success(self):
        value = self.run_inert(pin_close=True)
        self.assertFalse(value["completed"])
        self.assertFalse(value["sourceInputsUnchanged"])
        self.assertFalse(value["allOriginalRecordsIndependentlyReadBack"])

    def test_mutex_release_failure_prevents_terminal_success(self):
        value = self.run_inert(mutex_close=True)
        self.assertFalse(value["completed"])
        self.assertFalse(value["treeExitedBeforeCleanup"])

    def test_late_version_receipt_failure_prevents_terminal_success(self):
        value = self.run_inert(version_late=True)
        self.assertFalse(value["completed"])
        self.assertEqual(value["failureCode"], "drift")

    def test_missing_reordered_or_incomplete_history_variants_refuse(self):
        for mutate in [lambda x: x["live-result.json"]["variants"].pop(),
                       lambda x: x["live-result.json"]["variants"].reverse(),
                       lambda x: x["live-result.json"]["variants"][2].update(runtimeExitBeforeJobCleanup=False),
                       lambda x: x["job.json"].update(activeBeforeCleanup=1),
                       lambda x: x["native/first-read-0.stdout"].update(sourceWritten=True),
                       lambda x: x.pop("serena/second-read-0.stdout")]:
            with self.subTest(mutate=mutate):
                value = self.run_inert(bad_evidence=mutate)
                self.assertFalse(value["completed"])
                self.assertFalse(value["allOriginalRecordsIndependentlyReadBack"])

    def test_low_disk_refuses_before_loading_protocol_or_reading_image(self):
        with mock.patch.object(C, "os", SimpleNamespace(name="nt")), \
             mock.patch.object(C.shutil, "disk_usage", return_value=SimpleNamespace(free=1)), \
             mock.patch.object(C, "load_dependencies") as load:
            value = C.execute(opt())
        load.assert_not_called()
        self.assertFalse(value["nativeImageReadAttempted"])
        self.assertFalse(value["nativeExecutionRequested"])
        self.assertEqual(value["failureCode"], "disk")

    def test_public_summary_contains_only_closed_codes(self):
        with mock.patch.object(C, "os", SimpleNamespace(name="nt")), \
             mock.patch.object(C.shutil, "disk_usage", return_value=SimpleNamespace(free=C.BUDGETS["imageAdmissionBytes"])), \
             mock.patch.object(C, "source_map", side_effect=RuntimeError("private bearer URL")):
            value = C.execute(opt())
        output = io.StringIO()
        with mock.patch.object(C, "execute", return_value=value), mock.patch("sys.stdout", output):
            args = ClosedSelectorsAndMapsTests().args()
            self.assertEqual(C.main(args), 1)
        self.assertNotIn("bearer", json.dumps(value) + output.getvalue())
        self.assertNotIn("fixture", output.getvalue())
        self.assertEqual(set(json.loads(output.getvalue())), {"owner", "completed", "phase", "failureCode"})


if __name__ == "__main__":
    unittest.main()
