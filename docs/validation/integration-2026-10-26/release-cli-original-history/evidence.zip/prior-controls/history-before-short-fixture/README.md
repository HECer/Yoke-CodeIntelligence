# Separate local archive consumer for compiler transaction v2

This source-prepared adapter accepts only a completed matching build and a
completed matching version run from `integration-20261026-compiler-transaction-v2`.
It does not accept the earlier direct-Cargo producer or its failed receipts.
The original five `control-history` files, original seven `control-cli` files,
all ten compiler-transaction files, tracked product source and history harness
remain unchanged. This folder and its run namespaces are separate ignored data.

The parent must review the final manifest and source hashes before execution.
No function, test, native image, controller, helper or worker was executed while
preparing this folder. Authored tests describe intended coverage; they are not
execution evidence. AST parsing, source pins and whitespace checks are the only
preparation checks. The parent's separate old history/compiler guard results do
not certify this new adapter.

## Closed invocation

The only accepted selectors are the exact source commit and three distinct,
bounded lowercase run IDs. A version run ID is required explicitly; there is no
directory search, latest-run selection, fallback producer or caller native path.

```powershell
python validation/integration-20261025/platform-repairs/control-history-transaction/history_transaction_controller.py --source-commit f8b02d4eb0145de95f108e12df51786d368b6ef3 --run-id history-reviewed-new --producer-run-id build-reviewed-new --version-run-id version-reviewed-new
```

The example IDs are placeholders, not admitted execution evidence. The source
does not spoof `GITHUB_ACTIONS`/`GITHUB_SHA` or select `target/release/yoke.exe`.
Each output is create-only under `runs-history-transaction/<run-id>` and
`private-history-transaction/<run-id>`. Occupied output or mutex roles refuse.
The shared per-checkout mutex uses the frozen compiler controller's acquire and
release functions. Host-wide serialization remains the parent's responsibility.

## Admission and source maps

Bootstrap loads only exact hash-pinned non-main library source. The new protocol
supplies `load_runtime()`, its namespace-dict `load_original()`, and its explicit
`producer_admission`. The immutable old history controller is used only for its
spec/fixture/source/evidence validators. Its `execute`, `admit_image`,
`validate_image_role`, `load_runtime` and old mutex are never called.

The new producer admission pins every required build receipt, validates inner
and outer natural completion, and independently pins the fresh private image
with Windows read sharing that denies writers/deletion. Its `image_path` and
closed image identity select only
`runs-compiler-transaction/<producer-run-id>/owned-release-cli.exe`.
The image pin, build receipts, protected metadata and source controls remain held
through history admission, execution and all final checks.

Version admission is separate because the compiler protocol's `validate_result`
is build-only. The adapter pins all 19 required version files and closes the
version request/result against the selected producer ID, source commit, command,
budgets, selected artifact and exact held image identity. It requires the source,
original-seven controls, compiler-ten controls and protected metadata to match
all before/after/final observations. It validates the version outer Job with the
original 30-second deadline, one-second drain and two-second cleanup, exact
captured stream length, `yoke 0.5.0` stdout and empty stderr. A version string or
worker initialization alone cannot satisfy this gate. Missing, incomplete,
foreign, stale, unknown-field or changed evidence refuses before a history worker
request. A valid build may already authorize its image pin before version receipt
refusal; this does not authorize history execution.

Five control groups retain independent exact maps: original CLI seven, compiler
transaction ten, immutable old history five, this consumer five and two tracked
harness files. The current 1050 selected producer inputs are checked by the
unchanged producer selector. The preparation inventory of 1135 files is separate.
The broader history selector additionally includes retained TypeScript/Python,
package metadata and the original workflow. It has its original 2048-file,
16-MB per-file, 96-MB total, 1-MB listing and 120-second observation bounds.
Before/after/final observations remain distinct; a final observation uses a new
fixed Git receipt label without altering the legacy selector or tracked harness.
No new control is appended to any original producer or compiler control map.

## Fixed worker and private evidence

After both admissions the controller creates a five-field private immutable spec:
`native`, `nativeSha256`, `fixture`, `output`, `workerJobName`. All paths are fresh,
canonical, host-created and disjoint. The sole worker call is the unchanged
`host_history_live.bounded_worker` route. It creates a fresh named
`Local\YokeHistoryCI-<64-lowercase-hex>` Job and launches only the fixed isolated
Python `--worker <spec>` branch. An occupied name is refused; the worker proves
membership in that exact Job before reading the native image.

History retains its original 180-second worker deadline, one-second natural
drain within that deadline and ten-second cleanup. Compiler quiescence and its
two-second abort budget do not replace these history limits. Success requires
root exit, owning stdio/HTTP Sessions and the persistent Python runtime to exit,
and an empty owned tree before forced cleanup. Forced cleanup cannot repair an
incomplete run. Every read-pin close, late receipt/source/image/protected recheck,
mutex release and final reserve check must pass before terminal success.

The image remains capped at 512 MB, image admission at 1.2 GB and runtime reserve
at 500 MB. Original per-tree 32-MB/1024-entry output limits, 16-MB archive frame,
64-KB spec, 1-MB JSON, CLI 40-second, RPC 10-second and HTTP six-second bounds stay.
Version receipt aggregate admission is 64 MB with original 16-MB stream limits;
individual version JSON is capped at 1 MB. No arbitrary path, command or runtime
approval is accepted from a caller.

All fixture streams, spec, source bytes, actor stderr and capability URLs stay
under the private namespace. Public evidence contains bounded closed reason
codes, scalar maps/counts, image digest and reviewed archive summaries. Exception
messages and raw fixture output never reach public errors or the console.
There is no automatic salvage or acceptance retry.

## Original archive acceptance only

The unchanged harness requires the exact ordered variants `native`, `serena`,
`persistent-python`. Each performs real archive plan/apply/inspect/read/recovery,
owning stdio and HTTP Sessions, pending refusal under both authorities, two bounded
archive packages, every original record readback and a fresh same-host save.
The adapter independently admits each frame proof and reconstructs every returned
canonical base64 byte sequence/hash. Duplicate, missing, reordered, truncated or
incomplete variants/readbacks and missing Session/runtime exit proof refuse.

This does not qualify new owner retirement, archive purge, browser behavior,
VSIX, full release, all platforms or overall project completion. Inert fixtures
cannot replace actual native history execution. Tools, dependencies, environment,
global caches and equal-privilege host processes remain trusted; this is not an
equal-privilege sandbox or independent security attestation.

## Reusable explicit admission interface

An independently reviewed consumer may load this exact pinned source non-main
and use these functions under its own held `ExitStack`, mutex, controls and maps:

```text
admit_pair(p, g, api, original, stack, opt, sources, originals, transactions, result)
  -> (admitted, version_pins, version_snapshot)
recheck_pair(p, original, admitted, version_pins, version_snapshot)
```

`p` is the exact new protocol, `g` its exact runtime namespace, and `original`
the original CLI namespace dict. `opt` provides `source_commit`,
`producer_run_id`, `version_run_id`; selectors are validated before receipt-path
lookups. `sources`, `originals`, `transactions` are the independent current maps,
never a combined inventory. `result` receives the two image-read accounting flags.
`admitted` retains the new protocol's image/imagePin/receiptPins/protectedPins,
record, protectedBefore and artifact. Both returned pin sets must remain held;
recheck before execution and before success, and allow all context exits to
refuse. Calling this helper does not supply another consumer's scope, source or
execution authority. No legacy fallback is provided.

## Authored checks and unrun gates

The new tests use mocks and owned inert JSON only: source/control separation,
closed selectors/JSON/path/budget checks, forged producer/version/identity/artifact
bindings, before/after/final drift, lifecycle/stream mutations, missing evidence,
late image/version/pin failures, mutex close failures, exact archive readbacks and
private-error redaction. The original 22 history guards remain separate.

Required next gates are independent source review, guarded execution of all new
inert tests with natural root/tree exit, unchanged old guard regressions, a
missing/invalid producer-version negative before history execution, and actual
matching fresh build/version/history consumption. Retain all failed runs as
incomplete. Source freeze and an active parent lease are required for execution.
No build, test, native run or product/Node/Python suite was run by this author.
