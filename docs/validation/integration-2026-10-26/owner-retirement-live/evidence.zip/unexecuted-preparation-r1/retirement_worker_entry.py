"""Fixed owned retirement worker, with unchanged Windows Job lifecycle."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import types

ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
CONTROL = Path(__file__).absolute().parent
MAX_JSON = 1_000_000
MAX_OUTPUT = 32_000_000
MIN_FREE = 500_000_000
HARNESS_SHA = "3a3f5de28756ddcc383c3c92821f15fd5db24a72c324ef6a20d1ed6a24f819b2"
WORKER_SHA = '8ae198b52ee84dfe11919298253717ae6fd41213bd1799003481fe74dedaf4b2'

def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1_000_000), b""):
            value.update(block)
    return value.hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON field")
        result[key] = value
    return result


def decode(data, maximum=MAX_JSON):
    require(len(data) <= maximum, "JSON capacity exceeded")
    return json.loads(data, object_pairs_hook=unique_object)


def read_json(path, maximum=MAX_JSON):
    require(path.is_file() and not path.is_symlink() and not path.is_junction()
            and path.stat().st_size <= maximum, "JSON file admission failed")
    with path.open("rb") as source:
        return decode(source.read(maximum + 1), maximum)


def write_json(path, value):
    data = json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8") + b"\n"
    require(len(data) <= MAX_JSON, "Evidence JSON capacity exceeded")
    with Path(path).open("xb") as target:
        target.write(data)


def output_size(root):
    total = count = 0
    for path in root.rglob("*"):
        require(not path.is_symlink() and not path.is_junction(), "Unexpected evidence link")
        count += 1
        require(count <= 1024, "Evidence entry capacity exceeded")
        if path.is_file():
            try:
                total += path.stat().st_size
            except FileNotFoundError:
                # SQLite sidecars in private fixtures can close concurrently.
                continue
            require(total <= MAX_OUTPUT, "Evidence byte capacity exceeded")
    return total


def worker_job_name(value):
    require(isinstance(value, str) and re.fullmatch(r"Local\\YokeHistoryCI-[0-9a-f]{64}", value),
            "Explicit owned worker Job name required")
    return value


def require_worker_job(name):
    """Prove membership in this parent's specific Job before any native read.

    Query access cannot assign this process to a Job. Close the non-inheritable
    query handle before continuing so it cannot retain kill-on-close ownership.
    """
    name = worker_job_name(name)
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    for function, args, result in (
        ("OpenJobObjectW", [ctypes.c_uint32, ctypes.c_int, ctypes.c_wchar_p], ctypes.c_void_p),
        ("GetCurrentProcess", [], ctypes.c_void_p),
        ("IsProcessInJob", [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)], ctypes.c_int),
        ("CloseHandle", [ctypes.c_void_p], ctypes.c_int),
    ):
        entry = getattr(api, function)
        entry.argtypes, entry.restype = args, result
    handle = api.OpenJobObjectW(0x0004, False, name)
    require(bool(handle), "Owned worker Job unavailable")
    try:
        assigned = ctypes.c_int()
        require(api.IsProcessInJob(api.GetCurrentProcess(), handle, ctypes.byref(assigned))
                and assigned.value, "Worker is outside its assigned Job")
    finally:
        require(api.CloseHandle(handle), "Owned worker Job query handle close failed")
    return {"specificJobMembershipConfirmed": True, "queryHandleClosedBeforeNativeRead": True}


def bounded_worker(spec_path, fixture, output, environment, job_name):
    # The layout and suspended-assignment ordering follow the already exercised
    # repository Windows runner, with explicit 64-bit admission and cleanup proof.
    import _winapi
    import msvcrt

    class Basic(ctypes.Structure):
        _fields_ = [("processTime", ctypes.c_int64), ("jobTime", ctypes.c_int64), ("flags", ctypes.c_uint32),
                    ("minWorking", ctypes.c_size_t), ("maxWorking", ctypes.c_size_t),
                    ("activeLimit", ctypes.c_uint32), ("affinity", ctypes.c_size_t),
                    ("priority", ctypes.c_uint32), ("scheduling", ctypes.c_uint32)]

    class Extended(ctypes.Structure):
        _fields_ = [("basic", Basic), ("io", ctypes.c_uint64 * 6), ("processMemory", ctypes.c_size_t),
                    ("jobMemory", ctypes.c_size_t), ("peakProcessMemory", ctypes.c_size_t),
                    ("peakJobMemory", ctypes.c_size_t)]

    require(ctypes.sizeof(Extended) == 144, "Unsupported Windows Job layout")
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    for name, args, result in (
        ("CreateJobObjectW", [ctypes.c_void_p, ctypes.c_wchar_p], ctypes.c_void_p),
        ("SetInformationJobObject", [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32], ctypes.c_int),
        ("AssignProcessToJobObject", [ctypes.c_void_p, ctypes.c_void_p], ctypes.c_int),
        ("QueryInformationJobObject", [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p], ctypes.c_int),
        ("TerminateJobObject", [ctypes.c_void_p, ctypes.c_uint32], ctypes.c_int),
        ("ResumeThread", [ctypes.c_void_p], ctypes.c_uint32), ("CloseHandle", [ctypes.c_void_p], ctypes.c_int),
    ):
        function = getattr(api, name)
        function.argtypes, function.restype = args, result
    require(shutil.disk_usage(ROOT).free >= MIN_FREE, "Native live acceptance disk reserve unavailable")
    job_name = worker_job_name(job_name)
    ctypes.set_last_error(0)
    job = api.CreateJobObjectW(None, job_name)
    require(bool(job), "Windows Job unavailable")
    if ctypes.get_last_error() == 183:
        require(api.CloseHandle(job), "Occupied Job handle close failed")
        raise RuntimeError("Owned worker Job name is already occupied")
    process = thread = None
    row = {"startedSuspended": True, "assignedBeforeResume": False, "complete": False}

    def active():
        info = ctypes.create_string_buffer(48)
        require(api.QueryInformationJobObject(job, 1, info, 48, None), "Windows Job query failed")
        return int.from_bytes(info.raw[40:44], "little")

    try:
        limits = Extended()
        limits.basic.flags = 0x2000
        require(api.SetInformationJobObject(job, 9, ctypes.byref(limits), ctypes.sizeof(limits)), "Job limit failed")
        with open(os.devnull, "rb") as stdin, (output / "worker.stdout").open("xb") as stdout, (output / "worker.stderr").open("xb") as stderr:
            handles = [msvcrt.get_osfhandle(stream.fileno()) for stream in (stdin, stdout, stderr)]
            for handle in handles:
                os.set_handle_inheritable(handle, True)
            startup = subprocess.STARTUPINFO()
            startup.dwFlags = subprocess.STARTF_USESTDHANDLES
            startup.hStdInput, startup.hStdOutput, startup.hStdError = handles
            startup.lpAttributeList = {"handle_list": handles}
            argv = [sys.executable, "-I", str(Path(__file__).resolve()), "--worker", str(spec_path)]
            process, thread, pid, _ = _winapi.CreateProcess(
                None, subprocess.list2cmdline(argv), None, None, True,
                subprocess.CREATE_NO_WINDOW | 0x00000004, environment, str(fixture), startup)
            row["pid"] = pid
            require(api.AssignProcessToJobObject(job, process), "Suspended Job assignment failed")
            row["assignedBeforeResume"] = True
            require(api.ResumeThread(thread) != 0xffffffff, "Worker resume failed")
            deadline = time.monotonic() + 180
            while _winapi.WaitForSingleObject(process, 100) == 258:
                require(time.monotonic() < deadline, "Owned live acceptance deadline")
                require(shutil.disk_usage(ROOT).free >= MIN_FREE, "Owned disk-headroom stop")
                output_size(output)
                output_size(fixture)
            row["exitCode"] = _winapi.GetExitCodeProcess(process)
            row["activeAtParentExit"] = active()
            # A signalled root alone does not prove that its assigned tree has
            # exited. Observe accounting settling before forced cleanup, using
            # at most one second within the original worker deadline.
            drain_deadline = min(deadline, time.monotonic() + 1)
            remaining_active = row["activeAtParentExit"]
            while remaining_active and time.monotonic() < drain_deadline:
                time.sleep(.01)
                remaining_active = active()
            row["activeBeforeCleanup"] = remaining_active
            row["treeExitedBeforeCleanup"] = remaining_active == 0
    finally:
        if process is not None and not row["assignedBeforeResume"]:
            _winapi.TerminateProcess(process, 124)
        require(api.TerminateJobObject(job, 125), "Owned Job termination failed")
        deadline = time.monotonic() + 10
        while active() and time.monotonic() < deadline:
            time.sleep(.05)
        row["activeAfterCleanup"] = active()
        for handle in (thread, process, job):
            if handle is not None:
                require(api.CloseHandle(handle), "Owned Job handle close failed")
        row["complete"] = (row.get("exitCode") == 0
                           and row.get("treeExitedBeforeCleanup") is True
                           and row["activeAfterCleanup"] == 0)
        write_json(output / "job.json", row)
    require(row["complete"], "Owned live worker did not complete")


def source_module(path, expected, name):
    require(path.suffix == ".py" and path.is_file() and not path.is_symlink()
            and not path.is_junction() and path.stat().st_size <= 1_000_000,
            "Bounded pinned worker source required")
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected, "Worker source changed")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(data, str(path), "exec"), module.__dict__)
    return module


def worker(spec_path):
    require(os.name == "nt" and shutil.disk_usage(ROOT).free >= MIN_FREE,
            "Native live worker platform or disk reserve unavailable")
    spec = read_json(spec_path, 64000)
    require(type(spec) is dict and set(spec) == {"native", "nativeSha256", "fixture", "output", "workerJobName"},
            "Closed retirement worker spec required")
    admission = require_worker_job(spec.get("workerJobName"))
    native, fixture, output = (Path(spec[key]) for key in ("native", "fixture", "output"))
    require(all(type(spec[key]) is str for key in spec) and native.is_absolute()
            and fixture.is_absolute() and output.is_absolute()
            and re.fullmatch("[0-9a-f]{64}", spec["nativeSha256"]), "Explicit fixed worker spec required")
    harness = source_module(ROOT / "scripts/host_history_live.py", HARNESS_SHA, "pinned_history_actor")
    live = source_module(CONTROL / "owner_retirement_live.py", WORKER_SHA, "owned_retirement_live")
    require(harness.ROOT == ROOT and sha(native) == spec["nativeSha256"], "Selected native bytes differ")
    variants = []
    complete = False
    try:
        for label, protocol in (("native", "native"), ("serena", "serena")):
            row = live.exercise(harness, native, fixture / label, output / label, label, protocol)
            live.validate_summary(row, label)
            variants.append(row)
        require(sha(native) == spec["nativeSha256"], "Native executable changed")
        complete = True
    finally:
        write_json(output / "live-result.json", {"product": "Code Intelligence", "version": "0.5.0",
            "scope": "single-selection-owner-retirement-live", "complete": complete,
            "nativeSha256": spec["nativeSha256"], "variants": variants,
            "workerJobAdmission": admission, "modelCalls": 0, "analyzedSourceExecuted": False,
            "existingCredentialsSelected": False, "nativeBrowserAcceptanceClaimed": False,
            "actualInterruptedRetirementQualification": False})
    return 0


def main(arguments=None):
    parser = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    parser.add_argument("--worker", required=True, type=Path)
    value = parser.parse_args(arguments)
    return worker(value.worker)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BaseException:
        # Exceptions may carry private capability/fixture/protocol content.
        # SystemExit(0) must retain success without exposing any exception text.
        if sys.exc_info()[0] is SystemExit and sys.exc_info()[1].code == 0:
            raise
        sys.exit(1)
