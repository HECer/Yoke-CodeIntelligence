# Separate owned owner-retirement live consumer

Owner `local-owner-retirement-lld-consumer-v1`, schema 2. Actual native source is
`704b647d625dcc5f359386b20834d329ffb6cdf4`. This is a separate closed consumer of
that admitted release CLI, not a relabelled current-head build and not an extension
of the immutable `original-archive-only` history receipt.

Before any selected image read, retain all 27 matching compiler producer files,
the actual held BuildInputsGuard and its current observations; then retain all
22 matching version files, exact artifact/image, original controls, native source,
protected metadata and all new consumer/old archive/helper source pins. Existing
producer/version/late recheck logic is retained. The original archive consumer is
independently hash-pinned and never redirected or mutated.

The new worker entry contains the original ten launcher/helper function bodies
unchanged. Its own `__file__` therefore selects the new fixed retirement entry,
not the old archive worker. It proves membership in the parent's fresh specific
Job before native image hashing. The entry admits only the fixed spec and two
owning protocol variants, native and Serena. No generic native command, fake CI
environment or source-code execution is introduced.

## Fixed acceptance recipe

Each private, create-only Unicode/BOM/CRLF fixture starts an owning Session with
explicit host document and shutdown grants. One real HTTP save creates an active
owner and closed journal. A second proposal stays cached. Actual CLI planning uses
only the complete original `--from-selection`; exact plan stdout is reviewed and
used unchanged. Missing write permission and an invalid second selection refuse.

A separately labelled owned foreign pending marker checks presence-based HTTP
blocking (`blockedByOwnerRetirement:true`, `complete:false`, empty blocked journal
view), exact independent reads and cached/new write/ordinary recovery refusal.
All original bytes and the foreign marker stay exact. Only that exact owned
sentinel is removed before the real retirement. This is not an interrupted native
transaction or recovery qualification.

Actual CLI apply commits the retirement; inspect must prove the terminal schema-3
tombstone, matching event, retained terminal marker and `complete:true`. The fixed
owner identity, configuration bytes/identity, original journal evidence, analyzed
source and owning Session configuration remain unchanged. Post-retirement reads
continue while cached/new writes, ordinary recovery and repeated apply refuse.
Both Sessions separately acknowledge shutdown and actually exit while stdin was
still open, before the Job cleanup. Acknowledgement alone never proves exit.

Only closed scalar/boolean summaries are admitted; capabilities, plans,
configuration bodies and native stderr stay private. Public qualification is
limited to these original-selection terminal cases. Interrupted retirement,
event-reviewed retirement recovery, generation-bearing migration/retirement,
older-binary refusal, retained archive reads after retirement, browser/mobile
visual inspection, physical owner deletion and all-host release remain separate.

## Original bounds and preparation status

Image admission remains 1,200,000,000 free bytes; continuous reserve is 500,000,000.
The image ceiling is 512,000,000; JSON is 1,000,000; spec is 64,000. Each output
tree stays within 1,024 entries/32,000,000 bytes. The worker retains 180 seconds,
one-second natural drain and ten-second cleanup. Native CLI retains 30-second
request lifetime and 40-second owner wait, RPC ten seconds, HTTP six seconds.
Source observations retain their existing limits and 120-second owned timeout.
Forced cleanup cannot qualify. All final rechecks, context closes and mutex
release precede success.

This README and manifest describe prepared source only. Actual guard and live
results must be recorded in separate fresh directories after independent review.
Installed tools, external dependencies/caches and equal-privilege host processes
remain trusted inputs. No native-image/PDB payload is present in this bundle;
no full platform, current release, VSIX or project acceptance is implied.
