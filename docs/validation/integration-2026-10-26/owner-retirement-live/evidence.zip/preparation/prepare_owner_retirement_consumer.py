"""Prepare a separate source-only retirement consumer; never execute its controls."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
BASE = ROOT / 'validation/integration-20261025/platform-repairs'
ORIGIN = Path(r'C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-b1973677')
OLD = ORIGIN / 'validation/integration-20261025/platform-repairs/control-history-lld-704'
NEW = BASE / 'control-owner-retirement-live-704'


def function(source, name):
    tree = ast.parse(source)
    node = next(node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name == name)
    return ast.get_source_segment(source, node)


def replace_once(source, before, after):
    assert source.count(before) == 1, before[:90]
    return source.replace(before, after)


def write(name, source):
    path = NEW / name
    assert not path.exists(), name
    path.write_bytes(source.encode('utf-8'))
    if path.suffix == '.py':
        ast.parse(source)


def main():
    assert ROOT == Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence')
    NEW.mkdir(exist_ok=True)
    source = (OLD / 'history_transaction_controller.py').read_text(encoding='utf-8')
    archive = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in OLD.iterdir()
               if p.is_file() and p.name != '__pycache__'}
    assert len(archive) == 5
    for before, after in [
        ('"control-history-lld-704"', '"control-owner-retirement-live-704"'),
        ('"runs-history-lld-704"', '"runs-owner-retirement-live-704"'),
        ('"private-history-lld-704"', '"private-owner-retirement-live-704"'),
        ('"local-original-archive-history-lld-consumer-v1"', '"local-owner-retirement-lld-consumer-v1"'),
    ]:
        source = replace_once(source, before, after)
    source = replace_once(source,
        'CONTROL_NAMES = ("history_transaction_controller.py", "test_history_transaction_controller.py",\n                 "README.md", "review-manifest.json", ".gitattributes")',
        'CONTROL_NAMES = ("retirement_transaction_controller.py", "test_retirement_transaction_controller.py",\n'
        '                 "README.md", "review-manifest.json", ".gitattributes",\n'
        '                 "owner_retirement_live.py", "test_owner_retirement_live.py", "retirement_worker_entry.py")\n'
        'ARCHIVE_CONSUMER = BASE / "control-history-lld-704"\n'
        'ARCHIVE_CONSUMER_PINS = ' + repr(archive))
    source = replace_once(source, '"transactionSources", "originalSources", "harnessSources", "budgets"), "manifest")',
                          '"transactionSources", "originalSources", "harnessSources", "archiveConsumerSources", "budgets"), "manifest")')
    source = replace_once(source, 'value["schema"] == 1\n            and value["scope"] == "original-archive-only"',
                          'value["schema"] == 2\n            and value["scope"] == "single-selection-owner-retirement-live"')
    source = replace_once(source, 'and value["originalSources"] == ORIGINAL_PINS and value["harnessSources"] == HARNESS_PINS,',
                          'and value["originalSources"] == ORIGINAL_PINS and value["harnessSources"] == HARNESS_PINS\n'
                          '            and value["archiveConsumerSources"] == ARCHIVE_CONSUMER_PINS,')
    source = replace_once(source, '"owner": OWNER, "schema": 1, "sourceCommit": opt.source_commit',
                          '"owner": OWNER, "schema": 2, "sourceCommit": opt.source_commit')
    source = replace_once(source, '"allOriginalRecordsIndependentlyReadBack": False, "treeExitedBeforeCleanup": False,',
                          '"independentDocumentReadsExact": False, "treeExitedBeforeCleanup": False,\n'
                          '            "actualInterruptedRetirementQualification": False, "olderBinaryQualification": False,')
    source = replace_once(source, '"harness": harness, "consumer": own}',
                          '"harness": harness, "consumer": own,\n'
                          '            "archive-consumer": checked_map(ARCHIVE_CONSUMER, ARCHIVE_CONSUMER_PINS)}')
    source = replace_once(source, '(ORIGINAL, ORIGINAL_PINS), (ROOT, HARNESS_PINS)):',
                          '(ORIGINAL, ORIGINAL_PINS), (ROOT, HARNESS_PINS),\n'
                          '                                  (ARCHIVE_CONSUMER, ARCHIVE_CONSUMER_PINS)):')
    source = replace_once(source, '"scope": "original-archive-only", "budgets": BUDGETS',
                          '"scope": "single-selection-owner-retirement-live", "budgets": BUDGETS')
    source = replace_once(source, '("harness", ROOT, before["harness"]))))',
                          '("harness", ROOT, before["harness"]),\n'
                          '                ("archive-consumer", ARCHIVE_CONSUMER, before["archive-consumer"]))))')
    source = replace_once(source,
        'live = load_source(ROOT / "scripts/host_history_live.py", HARNESS_PINS["scripts/host_history_live.py"],\n                               "unchanged_history_transaction_worker")',
        'live = load_source(CONTROL / "retirement_worker_entry.py",\n'
        '                               own["retirement_worker_entry.py"]["sha256"], "owned_retirement_worker_entry")\n'
        '            validator = load_source(CONTROL / "owner_retirement_live.py",\n'
        '                                    own["owner_retirement_live.py"]["sha256"], "owned_retirement_summary")\n'
        '            require(live.ROOT == ROOT and live.HARNESS_SHA == HARNESS_PINS["scripts/host_history_live.py"]\n'
        '                    and live.WORKER_SHA == own["owner_retirement_live.py"]["sha256"], "control")')
    source = replace_once(source, 'result["phase"] = "owned-history-worker"',
                          'result["phase"] = "owned-retirement-worker"')
    source = replace_once(source,
        '# This exact harness alone creates the named history Job. No generic\n'
        '            # runner, direct worker call, fake CI or caller-supplied command exists.',
        '# This new fixed retirement entry alone creates its named Job.\n'
        '            # The immutable archive entry and its schema are not redirected.')
    source = replace_once(source,
        'legacy.validate_live(live_result, record["sha256"])\n            summaries = legacy.validate_archives(live_result, private_json)',
        'summaries = validate_retirement_live(live_result, record["sha256"], validator)')
    source = replace_once(source,
        'protectedMetadataUnchanged=True, allOriginalRecordsIndependentlyReadBack=True,\n                          treeExitedBeforeCleanup=True)',
        'protectedMetadataUnchanged=True, independentDocumentReadsExact=True,\n'
        '                          ownerRetirementQualification=True,\n'
        '                          treeExitedBeforeCleanup=True)')
    source = replace_once(source, 'allOriginalRecordsIndependentlyReadBack=False, treeExitedBeforeCleanup=False,',
                          'independentDocumentReadsExact=False, ownerRetirementQualification=False,\n'
                          '                      treeExitedBeforeCleanup=False,')
    validator = '''def validate_retirement_live(value, native_sha, worker):
    closed(value, ("product", "version", "scope", "complete", "nativeSha256", "variants",
                   "workerJobAdmission", "modelCalls", "analyzedSourceExecuted", "existingCredentialsSelected",
                   "nativeBrowserAcceptanceClaimed", "actualInterruptedRetirementQualification"), "evidence")
    require(value["product"] == "Code Intelligence" and value["version"] == "0.5.0"
            and value["scope"] == "single-selection-owner-retirement-live"
            and value["complete"] is True and type(value["nativeSha256"]) is str
            and value["nativeSha256"] == native_sha and type(value["modelCalls"]) is int
            and value["modelCalls"] == 0
            and all(value[key] is False for key in ("analyzedSourceExecuted", "existingCredentialsSelected",
                "nativeBrowserAcceptanceClaimed", "actualInterruptedRetirementQualification")), "evidence")
    closed(value["workerJobAdmission"], ("specificJobMembershipConfirmed", "queryHandleClosedBeforeNativeRead"), "job")
    require(all(item is True for item in value["workerJobAdmission"].values()), "job")
    require(type(value["variants"]) is list and len(value["variants"]) == 2, "variants")
    for label, row in zip(("native", "serena"), value["variants"]):
        try:
            worker.validate_summary(row, label)
        except BaseException:
            raise Refusal("variants") from None
    return value["variants"]


'''
    source = replace_once(source, 'def execute(opt):', validator + 'def execute(opt):')
    write('retirement_transaction_controller.py', source)
    history = (ORIGIN / 'scripts/host_history_live.py').read_text(encoding='utf-8')
    names = ('require', 'sha', 'unique_object', 'decode', 'read_json', 'write_json',
             'output_size', 'worker_job_name', 'require_worker_job', 'bounded_worker')
    header = '''"""Fixed owned retirement worker, with unchanged Windows Job lifecycle."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import types

ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
CONTROL = Path(__file__).absolute().parent
MAX_JSON = 1_000_000
MAX_OUTPUT = 32_000_000
MIN_FREE = 500_000_000
HARNESS_SHA = "3a3f5de28756ddcc383c3c92821f15fd5db24a72c324ef6a20d1ed6a24f819b2"
WORKER_SHA = "PARENT_SEAL_REQUIRED"

'''
    body = '\n\n\n'.join(function(history, name) for name in names)
    tail = '''


def source_module(path, expected, name):
    require(path.suffix == ".py" and path.is_file() and not path.is_symlink()
            and not path.is_junction() and path.stat().st_size <= 1_000_000,
            "Bounded pinned worker source required")
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected, "Worker source changed")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(data, str(path), "exec"), module.__dict__)
    return module


def worker(spec_path):
    require(os.name == "nt" and shutil.disk_usage(ROOT).free >= MIN_FREE,
            "Native live worker platform or disk reserve unavailable")
    spec = read_json(spec_path, 64000)
    require(type(spec) is dict and set(spec) == {"native", "nativeSha256", "fixture", "output", "workerJobName"},
            "Closed retirement worker spec required")
    admission = require_worker_job(spec.get("workerJobName"))
    native, fixture, output = (Path(spec[key]) for key in ("native", "fixture", "output"))
    require(all(type(spec[key]) is str for key in spec) and native.is_absolute()
            and fixture.is_absolute() and output.is_absolute()
            and re.fullmatch("[0-9a-f]{64}", spec["nativeSha256"]), "Explicit fixed worker spec required")
    harness = source_module(ROOT / "scripts/host_history_live.py", HARNESS_SHA, "pinned_history_actor")
    live = source_module(CONTROL / "owner_retirement_live.py", WORKER_SHA, "owned_retirement_live")
    require(harness.ROOT == ROOT and sha(native) == spec["nativeSha256"], "Selected native bytes differ")
    variants = []
    complete = False
    try:
        for label, protocol in (("native", "native"), ("serena", "serena")):
            row = live.exercise(harness, native, fixture / label, output / label, label, protocol)
            live.validate_summary(row, label)
            variants.append(row)
        require(sha(native) == spec["nativeSha256"], "Native executable changed")
        complete = True
    finally:
        write_json(output / "live-result.json", {"product": "Code Intelligence", "version": "0.5.0",
            "scope": "single-selection-owner-retirement-live", "complete": complete,
            "nativeSha256": spec["nativeSha256"], "variants": variants,
            "workerJobAdmission": admission, "modelCalls": 0, "analyzedSourceExecuted": False,
            "existingCredentialsSelected": False, "nativeBrowserAcceptanceClaimed": False,
            "actualInterruptedRetirementQualification": False})
    return 0


def main(arguments=None):
    parser = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    parser.add_argument("--worker", required=True, type=Path)
    value = parser.parse_args(arguments)
    return worker(value.worker)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BaseException:
        # Exceptions may carry private capability/fixture/protocol content.
        # SystemExit(0) must retain success without exposing any exception text.
        if sys.exc_info()[0] is SystemExit and sys.exc_info()[1].code == 0:
            raise
        sys.exit(1)
'''
    write('retirement_worker_entry.py', header + body + tail)
    write('.gitattributes', '*.py -text\n*.json -text\n*.md text eol=lf\n.gitattributes text eol=lf\n')
    print(json.dumps({'preparedSourceOnly': True, 'nativeExecuted': False,
                      'controllerBytes': len(source.encode()), 'copiedLifecycleFunctions': list(names)}))


if __name__ == '__main__':
    main()
