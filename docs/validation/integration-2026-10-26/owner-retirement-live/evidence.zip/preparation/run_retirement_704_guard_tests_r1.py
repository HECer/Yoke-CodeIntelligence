"""Run the reviewed history consumer's inert protocol tests, never a native image."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import types

WORKTREE = Path("C:/Users/Lomi/.t3/worktrees/Yoke-CodeIntelligence/t3-b1973677")
REL = Path("validation/integration-20261025/platform-repairs")
SOURCE = "704b647d625dcc5f359386b20834d329ffb6cdf4"
CLI = WORKTREE / REL / "control-cli/cli_controller.py"
CLI_SHA = "d6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582"
CONSUMER = WORKTREE / REL / "control-owner-retirement-live-704"
PINS = {'retirement_transaction_controller.py': '0daf107290c6105cca78f29605930b1e7121826e507250c3ad48e8dbaa2ff543', 'test_retirement_transaction_controller.py': '1292797797231989b49a4839c30041f0d5e97371db39d5779709f66d0b1a215a', 'README.md': 'cdf5d5d5a5cb652a4b7088f0ae02ecf0ee2778d3a29f8c99b67958ce874fa33f', 'review-manifest.json': '0b0f26ca905164973faa3fc263807952a976cb738be473d9e48ebb0b918f100e', '.gitattributes': '2772963d25d715c4a88465d05d8628800277fa393e1631d7e112ab4a92a21511', 'owner_retirement_live.py': '8ae198b52ee84dfe11919298253717ae6fd41213bd1799003481fe74dedaf4b2', 'test_owner_retirement_live.py': '82357e6324d42f6dbfd237779f2e7328798ace23b5ba2c0d2e0580bbc70e211e', 'retirement_worker_entry.py': 'ce450f5cfaf0cd259458ed5ff85a1d69e322bdf9b3c0774f721a8b1aeb0572e7'}


def source_bytes(path):
    assert path.suffix.lower() not in (".exe", ".pdb", ".dll", ".lib", ".obj", ".o")
    info = path.lstat()
    assert info.st_size <= 1_000_000 and info.st_nlink == 1
    assert not getattr(info, "st_file_attributes", 0) & 0x400
    return path.read_bytes()


def consumer_map():
    result = {}
    for name, expected in PINS.items():
        data = source_bytes(CONSUMER / name)
        digest = hashlib.sha256(data).hexdigest()
        assert digest == expected, name
        result[name] = {"bytes": len(data), "sha256": digest}
    return result


DEPENDENCIES = {'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\local_history_controller.py': '8d37fd4ca9c4f9d7b3320da6d628ff1b5537d880b4090289347d9df7f205d142', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\test_local_history_controller.py': '7ec89b7aa5e810d44d466c7150d1b0f7615defa78cc310617d8b4d5a239427f7', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\README.md': '628651bd06b1a37a90b03af8d85926991d0bc7f3029e9559a60c92db1c08bf5f', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\review-manifest.json': '84e19772b5c90d6313cfb4902bc7d671f82eaa753d6279b8b9f787f422c055c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\compiler_transaction_controller.py': 'd6ab4fe93432a74a769e9abcdddcef40e87ef274e98fea498a219d95c2c9f29d', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\compiler_transaction_worker.py': 'cf24492dafb4c30ce057a0885c5021339fc76fa3dba1e1efdddaf111fa1285fb', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\transaction_protocol.py': 'eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\transaction_runtime.py': '1608c69131ab3374812496ee9ff855e2c906ac172d31f9899331aa33f2e98de8', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\test_compiler_transaction.py': 'da422d730d3db84b4967fe422d8b8106ed5bb2faac05fa95b012ec5c5ee4bed9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\review-manifest.json': '141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\README.md': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\runtime-fork.patch': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\v2-fork.patch': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\cli_controller.py': 'd6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\base_controller.py': 'a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\test_metadata_pin.py': '6f555a7b29a85f17c404cba57474c682ae84adf28915ac8b1f10db73b9041aca', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\README.md': '1bbe94b3ac00dff9d1116ab8ccc8aadce545b14dd536888644d1cb92eac3cea6', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\review-manifest.json': '8dd48b1595220464fc638d458a6f8dd7b19f55454c35c0bda7eb7cea255b94f8', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\scripts\\host_history_live.py': '3a3f5de28756ddcc383c3c92821f15fd5db24a72c324ef6a20d1ed6a24f819b2', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\scripts\\tests\\test_host_history_live.py': 'f37e7b419be242337d066678c3a8454156f3062bbb7578b33d14d001500b73db', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-lld-704\\.gitattributes': '85e48d232edc7b02f6cecf8fbbf905f3b126c467b594d8dd16c4f8fa283a8320', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-lld-704\\history_transaction_controller.py': 'b6b60d9a37c27946ad1a7e8f6818d1363d1dede39d5ed5503d132db41938b81c', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-lld-704\\README.md': 'aef3bcfbee3eab9d1e3a6f2d320733163464867be23b58c5eb223af49ee40237', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-lld-704\\review-manifest.json': '5c378d5ed7295a8b828429ceb3d0f802b269053bf7625ec614cd26244642a40a', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-lld-704\\test_history_transaction_controller.py': 'ffdc1add5d27f4acf1864c3f22dba4e5ffb46b22f4ad751a84e6b5b5d62b28cf'}

def dependencies_map():
    result = {}
    for name, expected in DEPENDENCIES.items():
        data=source_bytes(Path(name))
        actual=hashlib.sha256(data).hexdigest()
        assert actual==expected, name
        result[name]={"bytes":len(data),"sha256":actual}
    return result

def main():
    assert os.name == "nt" and len(sys.argv) == 1
    data = source_bytes(CLI)
    assert hashlib.sha256(data).hexdigest() == CLI_SHA
    module = types.ModuleType("reviewed_private_release_cli_for_inert_tests")
    module.__file__ = str(CLI)
    exec(compile(data, str(CLI), "exec"), module.__dict__)
    g = module.load_base()
    assert g["ROOT"] == WORKTREE
    g.update(RUNS=WORKTREE / REL / "runs-retirement-704-guard-tests", OWNER="retirement-lld-source-guard-tests-v1")
    api, extended = g["load_windows_api"]()
    out = g["new_output"]("retirement-704-guard-tests-r1")
    result = {
        "sourceCommit": SOURCE, "completed": False, "testMethodsExpected": 65,
        "nativeImageRead": False, "nativeImageExecuted": False,
        "actualRetirementAcceptance": False, "releaseQualification": False,
    }
    before_driver = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    mutex = None
    owned = False
    try:
        import _winapi
        name = "Local\\YokeValidation-" + hashlib.sha256(str(WORKTREE).encode()).hexdigest()[:24]
        mutex = api.CreateMutexW(None, False, name)
        assert mutex
        wait = _winapi.WaitForSingleObject(mutex, 0)
        assert wait in (0, 128), "Another validation controller is active"
        owned = True
        result["serialMutexAbandoned"] = wait == 128
        environment = g["environment_for"]("build")
        sources = g["source_map"](api, extended, out, environment, SOURCE, "before")
        controls = g["controls_map"]()
        consumer = consumer_map()
        dependencies = dependencies_map()
        g["write_json"](out, "dependency-before.json", dependencies)
        g["write_json"](out, "control-before.json", controls)
        g["write_json"](out, "consumer-before.json", consumer)
        command = [sys.executable, "-B", "-m", "unittest", "discover", "-s", str(CONSUMER),
                   "-p", "test_*.py", "-v"]
        job = g["run_owned"](api, extended, out, "tests", command, environment, 180)
        assert job["completed"] and job["exitCode"] == 0
        assert job["treeExitedBeforeCleanup"] and job["activeBeforeCleanup"] == 0
        assert job["activeAfterCleanup"] == 0 and job["rootExitedAfterCleanup"]
        assert job["cleanupUnproven"] is False
        stderr = (out / "tests.stderr").read_bytes()
        assert re.search(rb"Ran 65 tests in [0-9.]+s", stderr)
        assert re.search(rb"\nOK\r?\n", stderr) and b"skipped=" not in stderr
        after = g["source_map"](api, extended, out, environment, SOURCE, "after")
        after_controls = g["controls_map"]()
        after_consumer = consumer_map()
        after_dependencies = dependencies_map()
        g["write_json"](out, "dependency-after.json", after_dependencies)
        assert dependencies == after_dependencies
        g["write_json"](out, "control-after.json", after_controls)
        g["write_json"](out, "consumer-after.json", after_consumer)
        assert sources == after and controls == after_controls and consumer == after_consumer
        assert before_driver == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        result.update(completed=True, testsPassed=65, testsSkipped=0,
                      sourceInputs=len(sources), sourcesUnchanged=True,
                      originalControlsUnchanged=True, consumerControlsUnchanged=True, dependencyControlsUnchanged=True, dependencyFiles=30,
                      driverSha256=before_driver, jobTreeExitedBeforeCleanup=True)
    except BaseException as error:
        result.update(completed=False, errorType=type(error).__name__)
    finally:
        if owned:
            if not api.ReleaseMutex(mutex):
                result.update(completed=False, mutexReleaseFailed=True)
        if mutex:
            if not api.CloseHandle(mutex):
                result.update(completed=False, mutexCloseFailed=True)
        g["write_json"](out, "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
