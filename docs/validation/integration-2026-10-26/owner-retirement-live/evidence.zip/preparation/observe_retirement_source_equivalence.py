"""Bounded source-byte comparison, not current-build or runtime qualification."""
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path.cwd()
OLD = Path(r'C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-b1973677')
BASE = ROOT / 'validation/integration-20261025/platform-repairs'
RECEIPT = OLD / 'validation/integration-20261025/platform-repairs/runs-compiler-lld/release-cli-compiler-lld-704-r2/source-before.json'


def source_bytes(root, relative):
    assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
    path = root / relative
    assert path.suffix in ('.rs', '.html', '.py')
    for parent in [path, *path.parents]:
        info = parent.lstat()
        assert not info.st_file_attributes & 0x400
        if parent == root:
            break
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode) and first.st_nlink == 1 and first.st_size <= 1_000_000
    raw = path.read_bytes()
    last = path.lstat()
    assert (first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns) == (last.st_dev, last.st_ino, last.st_size, last.st_mtime_ns)
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main():
    mapping = json.loads(RECEIPT.read_text(encoding='utf-8'))
    selected = [name for name in mapping if (name.startswith('native/src/') or name.startswith('native/tests/'))
                and Path(name).suffix in ('.rs', '.html')]
    selected += ['scripts/host_history_live.py', 'scripts/tests/test_host_history_live.py']
    rows = {}
    for name in selected:
        old, current = source_bytes(OLD, name), source_bytes(ROOT, name)
        assert old == mapping[name]
        rows[name] = {'producerSource': old, 'currentSource': current, 'equal': old == current}
    changed = sorted(name for name, row in rows.items() if not row['equal'])
    assert changed == ['native/src/editor_http.rs', 'native/tests/agent_diagnostic_boundaries.rs', 'native/tests/github_app_ingress.rs']
    relevant = [name for name in rows if name.startswith('native/src/host_documents')
                or name.startswith('native/src/session_dashboard')
                or name.startswith('scripts/')]
    assert all(rows[name]['equal'] for name in relevant)
    result = {'comparisonOnly': True, 'producerSourceCommit': '704b647d625dcc5f359386b20834d329ffb6cdf4',
              'currentSourceCommit': '2c49bf18201326495c1712fd7bcd6273bfbd8ac8',
              'currentReleaseQualification': False, 'nativePayloadRead': False,
              'comparedFiles': len(rows), 'identicalFiles': len(rows) - len(changed),
              'differentFiles': changed, 'relevantFiles': relevant, 'rows': rows}
    output = BASE / 'owner-retirement-source-equivalence-r1.json'
    assert not output.exists()
    output.write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({key: value for key, value in result.items() if key not in ('rows', 'relevantFiles')}))


if __name__ == '__main__':
    main()
