"""Seal/install new source-only controls and prepare the fixed inert test driver."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
REL = Path('validation/integration-20261025/platform-repairs')
BASE = ROOT / REL
NEW = BASE / 'control-owner-retirement-live-704'
WORKTREE = Path(r'C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-b1973677')
OLD = WORKTREE / REL / 'control-history-lld-704'
NAMES = ('retirement_transaction_controller.py', 'test_retirement_transaction_controller.py',
         'README.md', 'review-manifest.json', '.gitattributes', 'owner_retirement_live.py',
         'test_owner_retirement_live.py', 'retirement_worker_entry.py')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def text(path):
    assert path.suffix in ('.py', '.md', '.json') or path.name == '.gitattributes'
    info = path.lstat()
    assert info.st_nlink == 1 and not info.st_file_attributes & 0x400 and info.st_size < 1_000_000
    return path.read_bytes()


def constant(source, name):
    tree = ast.parse(source)
    node = next(n for n in tree.body if isinstance(n, ast.Assign)
                and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name)
    return ast.literal_eval(node.value)


def replace_once(source, before, after):
    assert source.count(before) == 1, before[:80]
    return source.replace(before, after)


def main():
    assert ROOT == Path(r'C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence')
    entry = NEW / 'retirement_worker_entry.py'
    worker_hash = sha(text(NEW / 'owner_retirement_live.py'))
    entry_source = text(entry).decode('utf-8')
    entry_source = replace_once(entry_source, 'WORKER_SHA = "PARENT_SEAL_REQUIRED"',
                               'WORKER_SHA = ' + repr(worker_hash))
    entry.write_bytes(entry_source.encode('utf-8'))
    source = text(NEW / 'retirement_transaction_controller.py').decode('utf-8')
    old_source = text(OLD / 'history_transaction_controller.py').decode('utf-8')
    definitions = lambda source: {node.name: ast.dump(node, include_attributes=False)
                                 for node in ast.parse(source).body
                                 if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
    before, after = definitions(old_source), definitions(source)
    allowed = {'validate_manifest', 'initial_result', 'current_maps', 'execute'}
    unchanged = sorted(set(before) - allowed)
    assert all(before[name] == after[name] for name in unchanged)
    entry_defs = definitions(entry_source)
    harness_defs = definitions(text(WORKTREE / 'scripts/host_history_live.py').decode('utf-8'))
    lifecycle = ('require', 'sha', 'unique_object', 'decode', 'read_json', 'write_json',
                 'output_size', 'worker_job_name', 'require_worker_job', 'bounded_worker')
    assert all(entry_defs[name] == harness_defs[name] for name in lifecycle)
    manifest = {'owner': 'local-owner-retirement-lld-consumer-v1', 'schema': 2,
                'scope': 'single-selection-owner-retirement-live',
                'sourceCommit': '704b647d625dcc5f359386b20834d329ffb6cdf4',
                'consumerSources': {name: sha(text(NEW / name)) for name in NAMES if name != 'review-manifest.json'},
                'legacySources': constant(source, 'LEGACY_PINS'),
                'transactionSources': constant(source, 'TRANSACTION_PINS'),
                'originalSources': constant(source, 'ORIGINAL_PINS'),
                'harnessSources': constant(source, 'HARNESS_PINS'),
                'archiveConsumerSources': constant(source, 'ARCHIVE_CONSUMER_PINS'),
                'budgets': constant(source, 'BUDGETS')}
    manifest_path = NEW / 'review-manifest.json'
    assert not manifest_path.exists()
    manifest_path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode('utf-8'))
    target = WORKTREE / REL / NEW.name
    assert not target.exists()
    target.mkdir()
    pins = {}
    methods = 0
    for name in NAMES:
        raw = text(NEW / name)
        if name.endswith('.py'):
            tree = ast.parse(raw)
            if name.startswith('test_'):
                methods += sum(1 for node in ast.walk(tree)
                               if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'))
        destination = target / name
        with destination.open('xb') as stream:
            stream.write(raw)
        assert text(destination) == raw
        pins[name] = sha(raw)
    driver_path = BASE / 'run_history_704_guard_tests_r1.py'
    driver = text(driver_path).decode('utf-8')
    tree = ast.parse(driver)
    def replace_assignment(name, value):
        nonlocal driver
        node = next(n for n in tree.body if isinstance(n, ast.Assign)
                    and isinstance(n.targets[0], ast.Name) and n.targets[0].id == name)
        segment = ast.get_source_segment(text(driver_path).decode('utf-8'), node)
        driver = replace_once(driver, segment, name + ' = ' + repr(value))
    replace_assignment('PINS', pins)
    dependencies = constant(driver, 'DEPENDENCIES')
    for name, digest in manifest['archiveConsumerSources'].items():
        dependencies[str(OLD / name)] = digest
    replace_assignment('DEPENDENCIES', dependencies)
    driver = replace_once(driver, '"control-history-lld-704"', '"control-owner-retirement-live-704"')
    driver = driver.replace('runs-history-704-guard-tests', 'runs-retirement-704-guard-tests')
    driver = driver.replace('history-lld-source-guard-tests-v1', 'retirement-lld-source-guard-tests-v1')
    driver = driver.replace('history-704-guard-tests-r1', 'retirement-704-guard-tests-r1')
    driver = driver.replace('"test_history_transaction_controller.py", "-v"', '"test_*.py", "-v"')
    driver = driver.replace('testMethodsExpected": 41', 'testMethodsExpected": ' + str(methods))
    driver = driver.replace('Ran 41 tests in ', 'Ran ' + str(methods) + ' tests in ')
    driver = driver.replace('testsPassed=41', 'testsPassed=' + str(methods))
    driver = driver.replace('dependencyFiles=25', 'dependencyFiles=' + str(len(dependencies)))
    driver = driver.replace('actualArchiveAcceptance', 'actualRetirementAcceptance')
    ast.parse(driver)
    guard_path = BASE / 'run_retirement_704_guard_tests_r1.py'
    assert not guard_path.exists()
    guard_path.write_bytes(driver.encode('utf-8'))
    receipt = {'sourcePreparationOnly': True, 'nativeExecuted': False, 'testsExecuted': False,
               'sourceCommit': manifest['sourceCommit'], 'files': pins, 'expectedGuardTests': methods,
               'unchangedAdmissionFunctionsAndClasses': unchanged,
               'unchangedLaunchFunctions': list(lifecycle),
               'guardDriverSha256': sha(text(guard_path)), 'installedControlRoot': str(target)}
    receipt_path = BASE / 'owner-retirement-consumer-preparation-r1.json'
    assert not receipt_path.exists()
    receipt_path.write_bytes((json.dumps(receipt, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'sourceOnly': True, 'files': len(pins), 'guardTestsExpected': methods,
                      'unchangedAdmissionDefinitions': len(unchanged), 'unchangedLifecycleDefinitions': len(lifecycle),
                      'manifestSha256': pins['review-manifest.json'], 'guardDriverSha256': receipt['guardDriverSha256']}))


if __name__ == '__main__':
    main()
