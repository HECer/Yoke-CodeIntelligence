"""Derive source-only inert controller tests for the distinct retirement contract."""
import ast
from pathlib import Path

BASE = Path.cwd() / 'validation/integration-20261025/platform-repairs'
OLD = Path(r'C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-b1973677') / BASE.relative_to(Path.cwd()) / 'control-history-lld-704'
NEW = BASE / 'control-owner-retirement-live-704'


def replace(source, before, after):
    assert source.count(before) == 1, before[:90]
    return source.replace(before, after)


def swap_function(source, name, replacement):
    node = next(item for item in ast.parse(source).body if isinstance(item, ast.FunctionDef) and item.name == name)
    return replace(source, ast.get_source_segment(source, node), replacement)


def main():
    source = (OLD / 'test_history_transaction_controller.py').read_text(encoding='utf-8')
    source = source.replace('"history_transaction_controller.py"', '"retirement_transaction_controller.py"')
    source = replace(source, '"consumer": {name: {"bytes": 1, "sha256": "a" * 64} for name in C.CONTROL_NAMES}}',
        '"consumer": {name: {"bytes": 1, "sha256": "a" * 64} for name in C.CONTROL_NAMES},\n'
        '            "archive-consumer": {name: {"bytes": 1, "sha256": sha} for name, sha in C.ARCHIVE_CONSUMER_PINS.items()}}')
    source = replace(source, '"schema": 1, "scope": "original-archive-only"',
                     '"schema": 2, "scope": "single-selection-owner-retirement-live"')
    source = replace(source, '"originalSources": C.ORIGINAL_PINS, "harnessSources": C.HARNESS_PINS, "budgets": C.BUDGETS}',
                     '"originalSources": C.ORIGINAL_PINS, "harnessSources": C.HARNESS_PINS,\n'
                     '                    "archiveConsumerSources": C.ARCHIVE_CONSUMER_PINS, "budgets": C.BUDGETS}')
    # Load only bounded source definitions; none of their worker/API functions runs.
    source = replace(source, '\n\ndef opt():', '''

W_SPEC = importlib.util.spec_from_file_location("inert_retirement_recipe", Path(__file__).with_name("owner_retirement_live.py"))
W = importlib.util.module_from_spec(W_SPEC)
W_SPEC.loader.exec_module(W)
E_SPEC = importlib.util.spec_from_file_location("inert_retirement_entry", Path(__file__).with_name("retirement_worker_entry.py"))
E = importlib.util.module_from_spec(E_SPEC)
E_SPEC.loader.exec_module(E)


def golden_summary(label):
    return {**{name: True for name in W.TRUE_FIELDS}, **{name: False for name in W.FALSE_FIELDS},
            "variant": label, "protocol": label, "markerEvidenceKind": "owned-foreign-marker-presence-only",
            "originalJournalRecords": 4, "cliCases": 8,
            "owningExit": {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True}}


def opt():''')
    source = swap_function(source, 'good_live', '''def good_live():
    return {"product": "Code Intelligence", "version": "0.5.0",
            "scope": "single-selection-owner-retirement-live", "complete": True,
            "nativeSha256": admission()["record"]["sha256"],
            "variants": [golden_summary(label) for label in ("native", "serena")],
            "workerJobAdmission": {"specificJobMembershipConfirmed": True,
                                   "queryHandleClosedBeforeNativeRead": True},
            "modelCalls": 0, "analyzedSourceExecuted": False, "existingCredentialsSelected": False,
            "nativeBrowserAcceptanceClaimed": False, "actualInterruptedRetirementQualification": False}''')
    source = swap_function(source, 'archive_evidence', '''def archive_evidence():
    # Historical helper name retained only inside these inert tests; payload is
    # now the distinct closed retirement receipt, never an archive receipt.
    return {"job.json": good_job(), "live-result.json": good_live()}''')
    source = replace(source, 'live = SimpleNamespace(bounded_worker=worker, output_size=lambda path: 0)',
                     'live = SimpleNamespace(ROOT=C.ROOT, HARNESS_SHA=C.HARNESS_PINS["scripts/host_history_live.py"],\n'
                     '                                   WORKER_SHA=current["consumer"]["owner_retirement_live.py"]["sha256"],\n'
                     '                                   bounded_worker=worker, output_size=lambda path: 0)')
    source = replace(source, 'mock.patch.object(C, "load_source", return_value=live)',
                     'mock.patch.object(C, "load_source", side_effect=lambda path, *_: W if path.name == "owner_retirement_live.py" else live)')
    source = replace(source, 'self.assertEqual([v["variant"] for v in value["variants"]], list(H.VARIANTS))',
                     'self.assertEqual([v["variant"] for v in value["variants"]], ["native", "serena"])')
    source = replace(source, 'self.assertEqual([v["originalRecordsReadBack"] for v in value["variants"]], [33, 33, 33])',
                     'self.assertTrue(all(v["independentReadBytesExact"] for v in value["variants"]))')
    source = replace(source, 'self.assertFalse(value["ownerRetirementQualification"])',
                     'self.assertTrue(value["ownerRetirementQualification"])\n'
                     '        self.assertFalse(value["actualInterruptedRetirementQualification"])')
    source = source.replace('value["allOriginalRecordsIndependentlyReadBack"]', 'value["independentDocumentReadsExact"]')
    source = replace(source, 'lambda x: x["live-result.json"]["variants"][2].update(runtimeExitBeforeJobCleanup=False)',
                     'lambda x: x["live-result.json"]["variants"][1].update(owningSessionExitedBeforeJobCleanup=False)')
    source = replace(source, 'lambda x: x["native/first-read-0.stdout"].update(sourceWritten=True)',
                     'lambda x: x["live-result.json"].update(actualInterruptedRetirementQualification=True)')
    source = replace(source, 'lambda x: x.pop("serena/second-read-0.stdout")',
                     'lambda x: x["live-result.json"]["variants"][1].update(markerEvidenceKind="actual-native-interruption")')
    extra = '''

class RetirementScopeTests(unittest.TestCase):
    def test_new_receipt_refuses_archive_schema_and_numeric_qualified_flags(self):
        good = good_live()
        C.validate_retirement_live(good, admission()["record"]["sha256"], W)
        for mutate in (lambda x: x.update(scope="original-archive-only"),
                       lambda x: x.update(complete=1), lambda x: x.update(modelCalls=False),
                       lambda x: x.update(actualInterruptedRetirementQualification=0),
                       lambda x: x["workerJobAdmission"].update(specificJobMembershipConfirmed=1),
                       lambda x: x.update(unknown=False),
                       lambda x: x["variants"][0].update(allHostsReleased=True),
                       lambda x: x["variants"][0]["owningExit"].update(nativeExitCode=False)):
            value = copy.deepcopy(good)
            mutate(value)
            with self.subTest(mutate=mutate), self.assertRaises(C.Refusal):
                C.validate_retirement_live(value, admission()["record"]["sha256"], W)

    def test_worker_membership_refusal_precedes_any_native_read_or_source_loading(self):
        spec = {"native": str(Path(tempfile.gettempdir()).resolve() / "inert-never-read.exe"),
                "nativeSha256": "a" * 64, "fixture": str(Path(tempfile.gettempdir()).resolve()),
                "output": str(Path(tempfile.gettempdir()).resolve()), "workerJobName": "owned-inert"}
        with mock.patch.object(E.os, "name", "nt"), \\
                mock.patch.object(E.shutil, "disk_usage", return_value=SimpleNamespace(free=2_000_000_000)), \\
                mock.patch.object(E, "read_json", return_value=spec), \\
                mock.patch.object(E, "require_worker_job", side_effect=RuntimeError("denied")), \\
                mock.patch.object(E, "source_module") as source, mock.patch.object(E, "sha") as native:
            with self.assertRaises(RuntimeError):
                E.worker(Path("inert.json"))
            source.assert_not_called()
            native.assert_not_called()

    def test_new_worker_has_no_ci_escape_or_arbitrary_native_selector(self):
        import ast
        source = Path(E.__file__).read_text(encoding="utf-8")
        tree = ast.parse(source)
        bounded = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "bounded_worker")
        text = ast.get_source_segment(source, bounded)
        self.assertIn('str(Path(__file__).resolve()), "--worker", str(spec_path)', text)
        self.assertNotIn('host_history_live.py', text)
        self.assertNotIn('GITHUB_ACTIONS', source)
        self.assertNotIn('parser.add_argument("--native"', source)

    def test_original_launch_and_cleanup_function_bodies_remain_exact(self):
        import ast
        original = (C.ROOT / "scripts/host_history_live.py").read_text(encoding="utf-8")
        current = Path(E.__file__).read_text(encoding="utf-8")
        functions = lambda source: {n.name: ast.dump(n, include_attributes=False)
                                   for n in ast.parse(source).body if isinstance(n, ast.FunctionDef)}
        before, after = functions(original), functions(current)
        for name in ("require", "sha", "unique_object", "decode", "read_json", "write_json",
                     "output_size", "worker_job_name", "require_worker_job", "bounded_worker"):
            with self.subTest(name=name):
                self.assertEqual(before[name], after[name])

'''
    source = replace(source, '\n\nif __name__ == "__main__":', extra + '\nif __name__ == "__main__":')
    ast.parse(source)
    target = NEW / 'test_retirement_transaction_controller.py'
    assert not target.exists()
    target.write_bytes(source.encode('utf-8'))
    print('Prepared controller test source only; no tests or native image executed')


if __name__ == '__main__':
    main()
