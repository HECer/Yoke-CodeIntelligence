"""Prepare ignored public text/metadata evidence, excluding private fixture bodies."""
import hashlib
import json
from pathlib import Path
import re
import stat
import zipfile

ROOT = Path.cwd()
REL = Path('validation/integration-20261025/platform-repairs')
BASE = ROOT / REL
OLD = Path(r'C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-b1973677')
OB = OLD / REL
OUT = BASE / 'evidence-retirement-live-704-r2'
LIVE = OB / 'runs-owner-retirement-live-704/retirement-704-live-r1'
GUARD = OB / 'runs-retirement-704-guard-tests/retirement-704-guard-tests-r2'
PRIVATE = OB / 'private-owner-retirement-live-704/retirement-704-live-r1/worker-evidence'
ALLOWED = {'.py', '.json', '.md', '.patch', '.stdout', '.stderr'}
SOURCE = '704b647d625dcc5f359386b20834d329ffb6cdf4'
CONTROL = OB / 'control-owner-retirement-live-704'
CASES = ('retirement-plan', 'missing-write-permission', 'second-selection-plan',
         'second-selection-apply', 'marker-apply', 'retirement-apply', 'retirement-inspect', 'repeat-apply')
MARKERS = {
    'missing-write-permission': b'Host owner retirement requires --allow-host-writes',
    'second-selection-plan': b'Standalone owner retirement accepts only the original --from-selection',
    'second-selection-apply': b'Standalone owner retirement accepts only the original --from-selection',
    'marker-apply': b'Host document owner retirement is pending; use explicit host retirement recovery',
    'repeat-apply': None,
}


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def raw(path):
    root = OLD if path.is_relative_to(OLD) else ROOT
    require(path.is_relative_to(root), 'Outside explicit source root')
    require(path.suffix in ALLOWED or path.name == '.gitattributes', 'Native payload refused')
    for parent in [path, *path.parents]:
        info = parent.lstat()
        require(not info.st_file_attributes & 0x400, 'Reparse route refused')
        if parent == root:
            break
    first = path.lstat()
    require(stat.S_ISREG(first.st_mode) and first.st_size <= 16_000_000, 'Bounded regular text required')
    data = path.read_bytes()
    data.decode('utf-8')
    last = path.lstat()
    require((first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns, first.st_nlink)
            == (last.st_dev, last.st_ino, last.st_size, last.st_mtime_ns, last.st_nlink), 'Source changed')
    return data


def load(path):
    return json.loads(raw(path))


def main():
    require(not OUT.exists(), 'Fresh ignored staging required')
    result, guards = load(LIVE / 'result.json'), load(GUARD / 'result.json')
    require(result['completed'] is True and result['sourceCommit'] == SOURCE
            and result['ownerRetirementQualification'] is True
            and result['actualInterruptedRetirementQualification'] is False
            and all(result[key] is True for key in ('sourceInputsUnchanged', 'protectedMetadataUnchanged',
                'matchingVersionReceiptAdmitted', 'independentDocumentReadsExact', 'treeExitedBeforeCleanup')),
            'Accepted actual retirement result required')
    require(guards['completed'] is True and guards['testsPassed'] == 66 and guards['testsSkipped'] == 0,
            'Actual guard result required')
    job = load(PRIVATE / 'job.json')
    require(job['complete'] is True and job['exitCode'] == 0 and job['activeBeforeCleanup'] == 0
            and job['treeExitedBeforeCleanup'] is True and job['activeAfterCleanup'] == 0,
            'Natural owned tree required')
    entries, omissions = [], []
    def add(path, name):
        entries.append((name, path, raw(path), False))
    for folder in ('control-owner-retirement-live-704', 'control-history-lld-704', 'control-history',
                   'control-compiler-lld', 'control-cli'):
        for path in sorted((OB / folder).iterdir()):
            if path.is_file() and (path.suffix in ALLOWED or path.name == '.gitattributes'):
                add(path, 'controls/' + folder + '/' + path.name)
    for name in ('scripts/host_history_live.py', 'scripts/tests/test_host_history_live.py'):
        add(OLD / name, 'unchanged-harness/' + name)
    for directory, prefix in ((LIVE, 'live-admission'), (GUARD, 'guard-tests'),
            (OB / 'runs-compiler-lld/release-cli-compiler-lld-704-r2', 'producer-704'),
            (OB / 'runs-compiler-lld/release-cli-compiler-lld-version-704-r1', 'version-704')):
        for path in sorted(directory.iterdir()):
            if not path.is_file() or path.suffix not in ALLOWED:
                continue
            if path.name in ('worker-spec.json', 'spec.json'):
                omissions.append({'origin': str(path.relative_to(OLD)), 'reason': 'private worker specification'})
                continue
            data = raw(path)
            if path.name.startswith('git-files-') and path.suffix == '.stdout':
                omissions.append({'origin': str(path.relative_to(OLD)), 'bytes': len(data),
                                  'sha256': sha(data), 'reason': 'redundant full Git inventory'})
                continue
            add(path, prefix + '/' + path.name)
    add(PRIVATE / 'job.json', 'actual-worker/job.json')
    add(PRIVATE / 'live-result.json', 'actual-worker/live-result.json')
    proofs = {}
    for label in ('native', 'serena'):
        directory = PRIVATE / label
        add(directory / 'variant-result.json', 'actual-worker/' + label + '/variant-result.json')
        for name in CASES:
            status_path = directory / (name + '.result.json')
            status = load(status_path)
            success = name not in MARKERS
            require(status == {'case': name, 'exitCode': 0 if success else 1, 'expectedSuccess': success},
                    'CLI case did not have exact expected raw exit')
            stdout, stderr = raw(directory / (name + '.stdout')), raw(directory / (name + '.stderr'))
            if not success:
                require(stdout == b'' and bool(stderr)
                        and (MARKERS[name] is None or MARKERS[name] in stderr), 'Causal refusal not proved')
            add(status_path, 'actual-cli/' + label + '/' + status_path.name)
            proofs[label + '/' + name] = {**status, 'stdoutBytes': len(stdout), 'stdoutSha256': sha(stdout),
                'stderrBytes': len(stderr), 'stderrSha256': sha(stderr),
                'expectedPrivateCausePresent': (True if not success and MARKERS[name] is not None else None),
                'stdoutExported': name in ('retirement-apply', 'retirement-inspect'),
                'stderrExported': False}
            # Committed apply/inspect contain only closed hash/scalar receipts.
            if name == 'retirement-apply':
                value = json.loads(stdout)
                require(set(value) == {'planId', 'eventId', 'outcome', 'metadataChanged', 'fileChanged', 'sourceWritten'}
                        and value['outcome'] == 'committed' and value['metadataChanged'] is True
                        and value['fileChanged'] is False and value['sourceWritten'] is False, 'Closed committed receipt differs')
                add(directory / (name + '.stdout'), 'actual-cli/' + label + '/' + name + '.stdout')
            if name == 'retirement-inspect':
                value = json.loads(stdout)
                require(set(value) == {'planId', 'eventId', 'phase', 'direction', 'ownerState', 'markerPresent',
                    'terminalEvidencePresent', 'complete', 'fileChanged', 'sourceWritten'}
                    and value['phase'] == 'committed' and value['ownerState'] == 'retired'
                    and value['complete'] is True and value['terminalEvidencePresent'] is True,
                    'Closed terminal inspection differs')
                add(directory / (name + '.stdout'), 'actual-cli/' + label + '/' + name + '.stdout')
    entries.append(('actual-cli/causal-proofs.json', None, encode(proofs), True))
    for name in ('prepare_owner_retirement_consumer.py', 'prepare_retirement_controller_tests.py',
                 'seal_retirement_consumer.py', 'reseal_retirement_consumer_r2.py',
                 'run_retirement_704_guard_tests_r1.py', 'run_retirement_704_guard_tests_r2.py',
                 'owner-retirement-consumer-preparation-r1.json', 'owner-retirement-consumer-preparation-r2.json',
                 'observe_retirement_source_equivalence.py', 'owner-retirement-source-equivalence-r1.json',
                 'export_retirement_live_evidence.py'):
        add(BASE / name, 'preparation/' + name)
    for path in sorted((BASE / 'retirement-source-preparation-r1').iterdir()):
        add(path, 'unexecuted-preparation-r1/' + path.name)
    nonce = re.compile(r'Local\\+Yoke[A-Za-z0-9]+-[0-9a-f]{48,128}')
    records, public = [], []
    for name, path, data, derived in sorted(entries):
        require('..' not in Path(name).parts and not Path(name).is_absolute(), 'Unsafe ZIP member')
        text = data.decode('utf-8')
        sanitized = nonce.sub('<private-owned-job-name-redacted>', text).encode('utf-8')
        require(not re.search(r'https?://127\.0\.0\.1:[0-9]+/#[0-9a-f]{64}', sanitized.decode('utf-8')),
                'Private capability URL refused')
        representation = 'derived-causal-proof' if derived else ('job-name-redacted-public-view' if sanitized != data else 'byte-exact')
        records.append({'name': name, 'bytes': len(sanitized), 'sha256': sha(sanitized),
                        'origin': str(path) if path else 'derived from exact admitted CLI output/private cause checks',
                        'representation': representation, 'originalBytes': len(data), 'originalSha256': sha(data)})
        public.append((name, sanitized))
    require(len({name for name, _ in public}) == len(public) and len(public) < 1000
            and sum(len(data) for _, data in public) <= 40_000_000, 'Packet budget or duplicate member')
    OUT.mkdir()
    archive = OUT / 'evidence.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, data in public:
            info = zipfile.ZipInfo(name, (2026, 10, 26, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            zipped.writestr(info, data)
    with zipfile.ZipFile(archive) as zipped:
        require(zipped.namelist() == [r['name'] for r in records], 'Index differs')
        for record in records:
            data = zipped.read(record['name'])
            require(len(data) == record['bytes'] and sha(data) == record['sha256'], 'Member bytes differ')
    index = {'sourceCommit': SOURCE, 'archive': {'name': 'evidence.zip', 'members': len(records),
             'expandedBytes': sum(r['bytes'] for r in records), 'bytes': archive.stat().st_size,
             'sha256': sha(archive.read_bytes())}, 'members': records, 'omissions': omissions,
             'privateBodiesNotExported': ['worker specifications', 'fixture configuration and owner/journal bodies',
                                         'private retirement plans', 'capabilities and raw native stderr'],
             'publicPacketAloneIsNotCompleteProducerAdmission': True}
    (OUT / 'index.json').write_bytes(encode(index))
    checks = {'actualNativeSourceCommit': SOURCE, 'currentSourceComparisonCommit': '2c49bf18201326495c1712fd7bcd6273bfbd8ac8',
              'actualResult': result, 'guards': guards, 'actualWorkerJob': job,
              'cliRawExitAndCauseProofs': proofs, 'currentReleaseQualification': False,
              'actualInterruptedRetirementQualification': False, 'fullProjectComplete': False}
    (OUT / 'checks.json').write_bytes(encode(checks))
    (OUT / '.gitattributes').write_bytes(b'evidence.zip binary\n*.json -text\n*.md text eol=lf\n.gitattributes text eol=lf\n')
    print(json.dumps(index['archive']))


if __name__ == '__main__':
    main()
