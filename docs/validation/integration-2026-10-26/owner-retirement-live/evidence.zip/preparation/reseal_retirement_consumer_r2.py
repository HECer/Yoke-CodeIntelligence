"""Preserve unexecuted preparation r1 and seal its reviewed strict-refusal repair."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
BASE = ROOT / 'validation/integration-20261025/platform-repairs'
NEW = BASE / 'control-owner-retirement-live-704'
OLD_ROOT = Path(r'C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-b1973677')
INSTALLED = OLD_ROOT / NEW.relative_to(ROOT)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    before = json.loads((BASE / 'owner-retirement-consumer-preparation-r1.json').read_text(encoding='utf-8'))
    snapshot = BASE / 'retirement-source-preparation-r1'
    assert not snapshot.exists()
    snapshot.mkdir()
    for name, expected in before['files'].items():
        raw = (INSTALLED / name).read_bytes()
        assert sha(raw) == expected
        (snapshot / name).write_bytes(raw)
    entry_path = NEW / 'retirement_worker_entry.py'
    source = entry_path.read_text(encoding='utf-8')
    assignment = next(n for n in ast.parse(source).body if isinstance(n, ast.Assign)
                      and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'WORKER_SHA')
    segment = ast.get_source_segment(source, assignment)
    source = source.replace(segment, 'WORKER_SHA = ' + repr(sha((NEW / 'owner_retirement_live.py').read_bytes())))
    ast.parse(source)
    entry_path.write_bytes(source.encode('utf-8'))
    manifest_path = NEW / 'review-manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    manifest['consumerSources'] = {name: sha((NEW / name).read_bytes()) for name in before['files'] if name != manifest_path.name}
    manifest_path.write_bytes((json.dumps(manifest, indent=2) + '\n').encode('utf-8'))
    pins = {}
    methods = 0
    for name in before['files']:
        raw = (NEW / name).read_bytes()
        if name.endswith('.py'):
            tree = ast.parse(raw)
            if name.startswith('test_'):
                methods += sum(1 for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_'))
        (INSTALLED / name).write_bytes(raw)
        assert (INSTALLED / name).read_bytes() == raw
        pins[name] = sha(raw)
    driver = (BASE / 'run_retirement_704_guard_tests_r1.py').read_text(encoding='utf-8')
    assignment = next(n for n in ast.parse(driver).body if isinstance(n, ast.Assign)
                      and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'PINS')
    driver = driver.replace(ast.get_source_segment(driver, assignment), 'PINS = ' + repr(pins))
    driver = driver.replace('retirement-704-guard-tests-r1', 'retirement-704-guard-tests-r2')
    driver = driver.replace('testMethodsExpected": 65', 'testMethodsExpected": ' + str(methods))
    driver = driver.replace('Ran 65 tests in ', 'Ran ' + str(methods) + ' tests in ')
    driver = driver.replace('testsPassed=65', 'testsPassed=' + str(methods))
    ast.parse(driver)
    output = BASE / 'run_retirement_704_guard_tests_r2.py'
    assert not output.exists()
    output.write_bytes(driver.encode('utf-8'))
    result = {**before, 'files': pins, 'expectedGuardTests': methods,
              'guardDriverSha256': sha(output.read_bytes()),
              'supersedesPreparationOnly': 'owner-retirement-consumer-preparation-r1.json',
              'reviewRepair': 'Exact native exit1/private causal refusal markers; version admission wording clarified',
              'priorPreparedSourcesRetained': str(snapshot), 'testsExecuted': False, 'nativeExecuted': False}
    receipt = BASE / 'owner-retirement-consumer-preparation-r2.json'
    assert not receipt.exists()
    receipt.write_bytes((json.dumps(result, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'sourceOnly': True, 'guardTestsExpected': methods,
                      'manifestSha256': pins['review-manifest.json'], 'workerSha256': pins['owner_retirement_live.py'],
                      'entrySha256': pins['retirement_worker_entry.py'], 'guardDriverSha256': result['guardDriverSha256']}))


if __name__ == '__main__':
    main()
