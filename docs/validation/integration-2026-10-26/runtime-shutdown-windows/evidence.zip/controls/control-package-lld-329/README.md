# Exact-source LLD native package and bundled-host consumer

This is a source-only preparation for `704b647d625dcc5f359386b20834d329ffb6cdf4`.
The directory's `329` label records the original task identity; it does not
replace exact full-commit admission. No prepared validation module/function, test, worker, compiler or native/tool
image was imported or executed during preparation; no native/tool image bytes
were read. Source parsing, literal/hash
comparison and whitespace checks establish no execution acceptance.

The parent must review these six frozen files, run all 53 inert tests through
its reviewed owner guard, select clean byte-matching 704 source, build a fresh
matching release and version, and run the actual package/host stages serially.
Neither old F8/E89 output, unit harnesses nor a failed compiler result may supply
this consumer's executable. Source preparation grants no later execution by
itself. Main, remote publication, all-platform contracts and release remain open.

## Closed entry point

```powershell
python -B validation/integration-20261025/platform-repairs/control-package-lld-329/package_vscode_controller.py `
  --source-commit 704b647d625dcc5f359386b20834d329ffb6cdf4 `
  --run-id package-lld-704-r1 `
  --producer-run-id release-cli-compiler-lld-704-r1 `
  --version-run-id release-cli-compiler-lld-version-704-r1 `
  --code-executable C:/Users/Lomi/AppData/Local/Temp/yc-ab5b6c783f90/Code.exe
```

The parent must supply its actual matching fresh run IDs. Every output is
create-only under `runs-package-lld-329`; an occupied run or stage refuses.
`--fetch-missing-licenses` remains a separate explicit option and defaults to
false. There is no arbitrary image, target, interpreter, source root, script,
compiler argument, profile, force cleanup or output-directory option.

## Fresh release and version admission

The runtime root derives from this file's location in `t3-b1973677`. Exact clean
HEAD and selected native/script/Cargo/workflow source bytes must match 704
before and after operation. The unchanged eleven-file release compiler-LLD
schema 3 is independently loaded from `control-compiler-lld`; all eleven
source hashes and the original seven controls are held and rechecked. Its
manifest pin remains `141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9`.

Complete `producer_admission` must retain all 27 producer file receipts plus
its actual typed `BuildInputsGuard`. The guard retains root/native manifest
source pins and the metadata-only fixed LLD pin, including context-exit checks.
The original fresh final-bin output role, selected Cargo artifact, tool/profile
proofs, natural inner/outer completion and unchanged protected metadata remain
mandatory. This consumer supplies no alias, cached/default-output adoption,
legacy fallback or unit-protocol exception.

All 22 matching version receipts are held, including before/after/final
build-input proofs. Source, producer, image, profile, output, cleanup and actual
`yoke 0.5.0` result are revalidated by the unchanged frozen history helper.
Only `H.validate_version` and `H.recheck_pair` are called. Its fixed-E89 entry
points, runtime loaders, executors and globals are never used or changed.
Local load/Mutex/pin/map helpers bind this consumer separately.

The current compiler environment and untracked Cargo-configuration refusal
repeat before each packaging-source observation and at native source checks.
All held source, image, receipt, tool metadata and protected-role observations
must survive final checks and successful context/mutex closure before completion.
Installed tools, SDKs, dependency caches and equal-privilege host actors remain
trusted; this is not an equal-privilege sandbox or compiler-content attestation.

## Original package and host assertions

The manifest-selected Windows `yoke.exe` retains 160,000,000 bytes capacity.
Ordinary and Unix entries retain 128,000,000; each archive and aggregate payload
retain 256,000,000. Entries are bounded at 8,192 and archive manifests at 1 MB.
An oversized unselected lookalike refuses before its native payload is inflated.
Staging reads only the admitted held new image, into a fresh short ordinary
private output. The default release path remains absent/protected and is never
adopted. Existing stage occupants, reparses, hard links and overlong paths refuse.

The exact target/version, native/extension source membership, binary checksum,
Cargo dependency closure, license texts and provenance are checked independently.
The native ZIP and native-only VSIX must contain the same selected bytes;
TypeScript mixing, aliases, traversal, unknown/duplicate metadata, substituted
content and missing or forged license evidence refuse. Extraction is create-only
and each extracted payload is held and rechecked.

The public `scripts/test-vscode.ps1` and original JavaScript host assertions
remain unchanged. `derived-launcher.patch` records only the inherited replacement
of internal taskkill cleanup with natural wait/refusal. The derived launcher
pin remains `6e71f3e6faa38fd15c9d3f033435e71e9ed20eb6cfc167b270520f5b92f6e1e8`.
Successful host evidence must report actual bundled Rust runtime, unsaved source
binding, ignored workspace executable, excluded protected buffer and unchanged
saved source. The command retains `-UseBundledRuntime`; internal or outer forced
cleanup cannot become a successful host receipt.

The host Code executable is an explicit caller selection with ordinary local
metadata continuity. PowerShell is a separate fixed, previously established
trusted portable tool:
`C:/Users/Lomi/AppData/Local/Temp/ps7-154f888176a7/pwsh.exe`.
It is checked by ordinary path/identity/size/time/link/reparse metadata only.
Its directory is prefixed solely in the owned host child's PATH; the parent's
and compiler/packager environments remain unchanged. Missing or changed metadata
refuses. There is no Windows PowerShell 5 fallback, policy/registry change, IEX,
execution-policy bypass, installer or global PATH mutation. The historical
Restricted-policy refusal is neither retried nor relabeled.

## Preserved budgets and result limits

Native package 900 seconds; VSIX package 300; metadata 30; owning host outer 190
with original inner request 180; pipeline 1,800. Every stage shares the existing
absolute pipeline ceiling, original one-second outer natural drain and sole
two-second abort. The original derived host launcher retains its five-second
natural task wait. Nonzero exits, stream faults, incomplete output, remaining
members, deadline/disk/accounting failures and late context errors refuse.
The original 500 MB running reserve, 16 MB outer log cap and stage-boundary
private-output accounting remain. Code's redirected logs are outside the outer
pipe cap, and stage-boundary accounting is not a continuous disk quota.

A successful result may qualify the scoped native archive, VSIX and derived
actual bundled extension-host stage. `visualAcceptance`, `releaseQualification`
and `wholeProjectComplete` remain false. Actual desktop visual inspection and
a separately reviewed visual acknowledgement are required afterward. This
preparation performs neither that inspection nor any native execution.

## Tests and derivation

This fork retains all 45 methods from the current six-file single-source
package gate, with role/fixture adaptation to the LLD protocol; three historical
interop method/class labels are updated. Existing assertion-call counts are
preserved. Eight new methods cover all producer-proof keys and the typed guard,
three version input-proof phases, old/unit/Boolean schemas before image I/O,
failed version rows, late environment refusal before source reads, fixed PS7
metadata-only selection and child-only environment, and the two pure H calls.
All 53 tests are authored, not run by this agent.

The accepted old single-source/paired packages and original six-file controls
remain unchanged. The source/code-derived patches here are not proof of actual
API, compiler, ownership, archive, editor or visual acceptance. Parent review,
guarded tests, the full required project checks and actual matching execution
remain necessary.

The copied single-source baseline had these exact SHA-256 pins at preparation:

```text
package_vscode_controller.py fff33378edc22009f7cda54ab561da2784f86b39c89a23bdedb2244f9f0cf0f4
test_package_vscode_controller.py 3b29dfb7f7286f3b70e526ada25b4b262c7a09cfc2441dc29e3b991608792871
README.md 79c93747dc4c9508e233489595ae21c48b281a105b8e024208e629dc71bde41a
review-manifest.json 7ecf5f1428c140b62fa6c3690d46ccae9f942fb9b6d3bfdb41931a515f93ca24
.gitattributes a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9
derived-launcher.patch 7062ef388563aa589e53f9a13dc5fa9687ce9561361799725d7a23cd064f81dc
```
