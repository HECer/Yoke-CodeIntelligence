"use strict";
const fs=require("node:fs"),path=require("node:path"),crypto=require("node:crypto");
const SOURCE="704b647d625dcc5f359386b20834d329ffb6cdf4";
const ACK_NS=90000000000n;
function closed(value,keys){
 if(value===null||typeof value!=="object"||Array.isArray(value)||Object.keys(value).sort().join(",")!==keys.slice().sort().join(","))throw Error("Visual context fields");
}
function stableFile(file,maximum){
 const before=fs.lstatSync(file);
 if(!before.isFile()||before.isSymbolicLink()||before.nlink!==1||before.size>maximum)throw Error("Visual private file unavailable");
 const data=fs.readFileSync(file),after=fs.lstatSync(file);
 if(before.dev!==after.dev||before.ino!==after.ino||before.size!==after.size||before.mtimeMs!==after.mtimeMs||data.length!==before.size)throw Error("Visual private file changed");
 return data;
}
exports.run=async function(){
 const specFile=process.env.YOKE_VISUAL_OPERATOR_SPEC;
 if(typeof specFile!=="string"||!path.isAbsolute(specFile)||path.basename(specFile)!=="operator-spec.json")throw Error("Visual operator context unavailable");
 const context=JSON.parse(stableFile(specFile,65536));
 closed(context,["schema","sourceCommit","runId","nonce","ready","ack","observed"]);
 if(context.schema!==1||context.sourceCommit!==SOURCE||typeof context.runId!=="string"||!(/^[a-z][a-z0-9-]{0,95}$/).test(context.runId)||typeof context.nonce!=="string"||!(/^[a-f0-9]{64}$/).test(context.nonce))throw Error("Visual operator binding");
 for(const [key,name] of [["ready","visual-ready.json"],["ack","visual-ack.json"],["observed","visual-observed.json"]]){
  if(typeof context[key]!=="string"||!path.isAbsolute(context[key])||path.dirname(context[key])!==path.dirname(specFile)||path.basename(context[key])!==name)throw Error("Visual operator path");
 }
 const original=path.join(__dirname,"original-host.cjs");
 if(crypto.createHash("sha256").update(fs.readFileSync(original)).digest("hex")!=="063bdd94d30440c757be0344a460ebba1167b32da3365e34bf4e73207ae352de")throw Error("Original host drift");
 const result=process.env.YOKE_VSCODE_RESULT;
 if(typeof result!=="string"||!path.isAbsolute(result))throw Error("Original host result unavailable");
 const intermediate=result+".visual-original.json";
 process.env.YOKE_VSCODE_RESULT=intermediate;
 try{await require(original).run();}finally{process.env.YOKE_VSCODE_RESULT=result;}
 const data=stableFile(intermediate,65536),value=JSON.parse(data);
 if(value.passed!==true||value.bundledRuntime!==true)throw Error("Original host did not pass");
 if(fs.existsSync(context.ack))throw Error("Visual acknowledgement already occupied");
 const readyNs=process.hrtime.bigint(),deadline=readyNs+ACK_NS;
 fs.writeFileSync(context.ready,JSON.stringify({kind:"owned-code-visual-ready",sourceCommit:SOURCE,runId:context.runId,nonce:context.nonce,originalHostPassed:true,vscodeVersion:value.vscodeVersion})+"\n",{flag:"wx"});
 while(!fs.existsSync(context.ack)&&process.hrtime.bigint()<deadline)await new Promise(resolve=>setTimeout(resolve,100));
 const observedNs=process.hrtime.bigint();
 if(observedNs>=deadline||!fs.existsSync(context.ack))throw Error("Visual inspection deadline");
 const raw=stableFile(context.ack,16384),review=JSON.parse(raw);
 closed(review,["nonce","inspected","screenshots"]);
 if(review.nonce!==context.nonce||review.inspected!==true||!Array.isArray(review.screenshots)||review.screenshots.length<2||review.screenshots.length>8)throw Error("Visual acknowledgement refused");
 const validatedNs=process.hrtime.bigint();
 if(validatedNs>=deadline)throw Error("Visual inspection deadline");
 fs.writeFileSync(context.observed,JSON.stringify({schema:1,sourceCommit:SOURCE,runId:context.runId,nonce:context.nonce,readyNs:readyNs.toString(),observedNs:observedNs.toString(),validatedNs:validatedNs.toString(),ackSha256:crypto.createHash("sha256").update(raw).digest("hex")})+"\n",{flag:"wx"});
 fs.writeFileSync(result,data,{flag:"wx"});
};
