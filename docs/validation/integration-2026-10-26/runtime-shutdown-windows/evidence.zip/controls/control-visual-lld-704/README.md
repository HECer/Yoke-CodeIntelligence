# Separate actual desktop visual acknowledgement for 704

This seven-file source-only consumer binds
`704b647d625dcc5f359386b20834d329ffb6cdf4` and the frozen
`control-package-lld-329` controller
`c393e2c86c6589ef0df5e90d8c87a03612827b395fc2c1ac635bd6381d465b54`,
manifest `838e773444b80d71b9f74e9ea39103168c600b96e40bc4d81544f824c9231627`.
The package directory's 329 label is historical; its exact source is 704.
All 20 initial tests were authored and unrun by the preparer. Parent review added
one clock regression and moved the readiness epoch before ready-file publication.
The regression executes the wrapper in an inert Node VM: a simulated 10-second
publication pause accepts, while a 95-second pause consumes the original window
and refuses. No prepared validation
module/function, test, worker, editor, compiler, native or tool image was
executed during preparation, and no native/tool image bytes were read.

## Closed admission

The parent must independently review and run guarded inert tests first, then
select the actual successful 704 package, release producer and version IDs:

```powershell
python -B validation/integration-20261025/platform-repairs/control-visual-lld-704/visual_controller.py `
  --source-commit 704b647d625dcc5f359386b20834d329ffb6cdf4 `
  --run-id native-vsix-visual-lld-704-r1 `
  --package-run-id native-vsix-lld-704-r2 `
  --producer-run-id release-cli-compiler-lld-704-r2 `
  --version-run-id <the-actual-matching-704-version-id>
```

The example's version placeholder must be replaced with the real matching ID.
All four run IDs must be distinct. There is no caller-selected image, archive,
VSIX, stage, source root, Code executable, interpreter, script, timeout, force
cleanup or pre-acknowledgement option. Output is fresh/create-only under
`runs-visual-lld-704`; operator material is fresh/create-only under
`private-visual-lld-704`. Existing occupants remain untouched.

The unchanged package loader/Mutex/admission helpers retain all 27 release
producer receipts and the typed held BuildInputsGuard, plus all 22 matching
version receipts. Unit builds, rejected producers, old F8/E89 packages and
mixed-source/version evidence cannot satisfy these checks. Exact clean 704
HEAD, source bytes, original controls and compiler inputs are rechecked.

The consumer additionally holds all 60 fixed package/source/job receipts:
48 root receipts and 12 receipts for the four functional package stages. It
checks exact request/result roles and Boolean completion flags, current native
and packaging source maps, control maps, raw Git observations, actual stage
arguments and zero-exit/natural-root-and-tree completion. No raw failed job is
normalized to success. The original package result remains unchanged.

`fetchMissingLicenses` is admitted as an exact Boolean from the held package
request. True retains the exact `--fetch-missing-licenses` native-package argv
and the corresponding archive-license validation; it is never defaulted to
false or used to relabel a rejected earlier package. The locked dependency
metadata, stage copy, native archive, native-only VSIX and every extracted
payload are independently checked again against the fresh admitted release and
current source. Original 160 MB selected-Windows, 128 MB ordinary/Unix and
256 MB archive/payload limits remain the frozen package policy.

The existing selected Code and fixed portable PS7 paths must reproduce the
accepted package's metadata. The consumer calls the frozen package gate's
explicit per-child PS7 environment helper; no old module globals change and no
interpreter fallback, registry, global PATH, execution-policy or IEX bypass
exists. The previously denied optional `inspect-owned-code.ps1` is neither
copied nor invoked. Parent Orca actions remain separate and explicit.

## Actual visible fixture and manual acknowledgement

`test-vscode-visual.ps1` is byte-identical to the accepted visible launcher,
SHA `ada2fec27ecaf94ee720eba70810ee23392f1738e9ed29f7f23ac3834ef44664`.
It retains `-WindowStyle Normal`, `-UseBundledRuntime`, the original 180-second
request and five-second natural task wait, and no internal taskkill cleanup.

The source-host assertions in the original JavaScript remain unchanged at
`063bdd94d30440c757be0344a460ebba1167b32da3365e34bf4e73207ae352de`.
A wrapper first executes that exact original host and requires its successful
bundled-runtime result. It then writes a private ready event and waits at most
90 real monotonic seconds for the parent's manual inspection acknowledgement.
The owning host's original 190-second outer limit and one-second natural drain
with sole two-second abort remain. The complete recipe retains the prior
1,800-second ceiling; these limits are not added to or renewed by the ack wait.
The package gate's other resource and synchronous-observation limits remain.

The public request contains only ready/ack path locators, run/source IDs and
limits. A fresh 256-bit nonce is generated only during actual execution in a
held private operator specification. It is not embedded in source or printed
in the public result. The wrapper receives only that file locator in the owned
host child's environment. Spec, ready, ack, observed completion, raw logs and
operator material must remain local/private; only reviewed image/hash summaries
and channel hashes belong in shareable evidence.

When the ready file appears, the parent must use its already selected Orca
surface to establish the owning Extension Development Host window. Inspect the
actual generated overlay and dirty source at separate points, save at least
two distinct real PNG screenshots directly in this run's public output folder,
and actually view them. File existence or an accessibility snapshot alone is
not visual inspection. Refuse ambiguity or visible problems; fix the cause and
start a fresh qualified run. Do not run the old optional PowerShell UI helper.

Only after that actual inspection, read the private spec in local memory and
write the private `visual-ack.json` once, with exactly:

```json
{"nonce":"<private current nonce>","inspected":true,"screenshots":[
  {"path":"<absolute path inside this run to the first PNG>","sha256":"<actual SHA-256>"},
  {"path":"<absolute path inside this run to the second PNG>","sha256":"<actual SHA-256>"}
]}
```

The acknowledgement is not a new user permission prompt or an automatic action.
It records the parent's actual inspection. No convenience auto-ack mode exists.
The parent must not print/publish the private nonce. The wrapper rejects an ack
already present before ready, expired observation/validation, false inspection
and wrong nonce/fields. Its private observed receipt binds the exact raw ack
hash and monotonic timestamps. Python independently checks that binding and
90-second bound, then holds/rechecks 2?8 unique PNG paths and hashes inside the
current run. PNG signature/hash admission is not image-content review; the
parent's actual viewing remains mandatory.

The final host must exit naturally with an empty owned Job before forced
cleanup. All source, controls, package/build/version receipts, extracted payloads,
private operator files, image pins and tool metadata are rechecked before
contexts and mutex close successfully. Only then may `completed:true` and the
scoped `visualInspection:true` be published. Any expiry, stream, identity,
cleanup, late context or publication failure refuses.

`exactHeadBuild`, `currentPlatformAcceptance`, `releaseQualification` and
`wholeProjectComplete` remain false. This fixture cannot qualify all project
contracts, general editor accessibility, macOS, release or remote publication.

## Source preparation and tests

The old paired visual controller had no standalone test module. This new suite
contains 21 focused inert methods for closed source/role selectors, control
pins before source execution, package request/result/fetch semantics, all 60
receipt roles, pre-read capacities, exact package commands and raw stage
lifecycle, strict Git observation bounds, late-pin refusal, private nonce/source/
run/raw-ack binding, the exact 90-second edge, unique contained PNG hashes and
unchanged visible launcher/original-host assertions. Test fixtures are labelled
inert text/PNG-magic bytes and are not actual editor or visual acceptance.

Parent review, guarded tests, a real complete matching package and actual
Orca image inspection/acknowledgement remain unrun by this preparer. No default
model calls, analyzed-project execution, old output adoption or remote calls are
introduced by this source-only preparation.
