"""Inert protocol/PNG-magic fixtures only; no actual editor or native image."""
from contextlib import ExitStack
import ast
import base64
import copy
import hashlib
import json
import os
import subprocess
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock

HERE=Path(__file__).absolute().parent

def policy():
    path=HERE/"visual_controller.py"
    value=types.ModuleType("inert_desktop_visual_policy")
    value.__file__=str(path)
    exec(compile(path.read_bytes(),str(path),"exec"),value.__dict__)
    return value

def options(v):
    return types.SimpleNamespace(source_commit=v.SOURCE_COMMIT,run_id="visual-inert",package_run_id="package-inert",producer_run_id="producer-inert",version_run_id="version-inert")

def host():
    return {"kind":"actual-vscode-extension-host","passed":True,"runtime":"rust","bundledRuntime":True,"vscodeVersion":"1.143.1","unsavedSourceBound":True,"workspaceExecutableIgnored":True,"protectedOpenBufferExcluded":True,"savedSourceUnchanged":True}

class Pin:
    def __init__(self,data=b"",record=None):
        self.data=data;self.value={"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()} if record is None else record
        self.fail=False
    def __enter__(self):
        return self
    def __exit__(self,*args):
        self.recheck()
    def bytes(self):
        return self.data
    def record(self):
        return copy.deepcopy(self.value)
    def recheck(self):
        if self.fail:
            raise RuntimeError("owned late proof failure")
        return self.record()

def valid_job(p, command=None, seconds=190):
    command = ["fixed-inert-host"] if command is None else command
    start = 100_000_000_000
    deadline = start + seconds * 1_000_000_000
    return {"command": command, "deadlineSeconds": seconds, "logCapBytes": 16_000_000,
            "stdinClosed": True, "startedSuspended": True, "assignedBeforeResume": True,
            "completed": True, "treeExitedBeforeCleanup": True, "minimumFreeObserved": 2_000_000_000,
            "cleanupErrors": [], "streamEOF": [True, True], "readerErrors": [False, False],
            "startedMonotonicNs": start, "absoluteDeadlineNs": deadline, "jobName": None,
            "namedJobCreatedNew": False, "pid": 123, "resumePreviousSuspendCount": 1, "exitCode": 0,
            "rootObservedMonotonicNs": start + 1_000_000_000, "membersAtRootObservation": [],
            "rootExitedAtObservation": True, "activeAtRootObservation": 0, "originalDrainSeconds": 1,
            "activeBeforeCleanup": 0, "membersAfterOriginalDrain": [], "treeObservedMonotonicNs": start + 1_000_000_001,
            "cleanupSeconds": 2, "activeAfterCleanup": 0, "rootExitedAfterCleanup": True,
            "elapsedSeconds": 1.1, "capturedLogBytes": 0, "outputExceeded": False, "cleanupUnproven": False}


def package_fixture(v,c,code,fetch=True):
    visual=options(v)
    path,metadata=c.code_selector(code)
    package=types.SimpleNamespace(source_commit=v.SOURCE_COMMIT,run_id=visual.package_run_id,producer_run_id=visual.producer_run_id,version_run_id=visual.version_run_id,fetch_missing_licenses=fetch,code_executable=path,code_metadata=metadata)
    initial=c.initial_result(package)
    request={**initial,"budgets":c.BUDGETS,"derivedLauncherOnly":True}
    result=copy.deepcopy(initial)
    for key in ("completed","nativeImageReadAttempted","nativeImageRead","stagedImageCreated","matchingVersionReceiptAdmitted","nativeArchiveQualified","nativeVsixQualified","derivedBundledHostQualified","sourceInputsUnchanged","protectedMetadataUnchanged"):
        result[key]=True
    result.update(hostPowerShellMetadata={"inert":True},nativeImageBytes=123,selectedWindowsBinaryByteLimit=160000000,generalNativeEntryByteLimit=128000000,nativeSha256="b"*64,nativeArchive={"inert":"native"},nativeVsix={"inert":"vsix"},originalHostLauncherUnchangedEvidence=False,derivedLauncherSha256=c.DERIVED_LAUNCHER_SHA,bundledRuntime=True,treeExitedBeforeCleanup=True,packagingSourceCount=2,phase="complete",failureCode=None)
    return visual,package,request,result

def operator_fixture(v):
    private=Path(v.ROOT.anchor)/"owned-private"
    context=v.operator_spec("visual-inert",private,"a"*64)
    ready={"kind":"owned-code-visual-ready","sourceCommit":v.SOURCE_COMMIT,"runId":context["runId"],"nonce":context["nonce"],"originalHostPassed":True,"vscodeVersion":"1.143.1"}
    ack={"nonce":context["nonce"],"inspected":True,"screenshots":[{"path":"first.png","sha256":"b"*64},{"path":"second.png","sha256":"c"*64}]}
    raw=json.dumps(ack,sort_keys=True).encode()
    observed={"schema":1,"sourceCommit":v.SOURCE_COMMIT,"runId":context["runId"],"nonce":context["nonce"],"readyNs":"1000","observedNs":"2000","validatedNs":"3000","ackSha256":hashlib.sha256(raw).hexdigest()}
    return context,ready,ack,observed,raw

class AdmissionTests(unittest.TestCase):
    def setUp(self):
        self.v=policy();self.c=self.v.load_package()
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.code=Path(self.temp.name).resolve()/"Code.exe"
        self.code.write_bytes(b"Owned inert host selector, never executed")

    def test_closed_options_bind704_and_all_four_distinct_roles(self):
        v=self.v
        args=["--source-commit",v.SOURCE_COMMIT,"--run-id","visual-inert","--package-run-id","package-inert","--producer-run-id","producer-inert","--version-run-id","version-inert"]
        self.assertEqual(v.options(args).package_run_id,"package-inert")
        changes=[args+["--image","foreign"],args+["--run-id","foreign"],args[:-2],
                 ["--source-commit","e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e",*args[2:]],
                 [*args[:3],"../escape",*args[4:]],[*args[:5],"visual-inert",*args[6:]]]
        for values in changes:
            with self.subTest(values=values),self.assertRaises(v.Refusal):
                v.options(values)

    def test_changed_package_pin_refuses_before_source_execution(self):
        v=self.v
        pins=dict(v.PACKAGE_PINS);pins["package_vscode_controller.py"]="f"*64
        with mock.patch.object(v,"PACKAGE_PINS",pins),mock.patch("builtins.exec",side_effect=AssertionError("No unpinned source execution")),self.assertRaises(v.Refusal):
            v.load_package()

    def test_complete_package_identity_preserves_both_fetch_selections(self):
        v,c=self.v,self.c
        for fetch in (False,True):
            visual,package,request,result=package_fixture(v,c,self.code,fetch)
            admitted=v.validate_package_identity(c,visual,request,result)
            self.assertIs(admitted.fetch_missing_licenses,fetch)
            self.assertEqual(admitted.producer_run_id,visual.producer_run_id)
            self.assertFalse(result["visualAcceptance"])
            self.assertFalse(result["releaseQualification"])

    def test_old_source_or_wrong_package_roles_refuse_before_tool_observation(self):
        v,c=self.v,self.c
        visual,_,request,result=package_fixture(v,c,self.code)
        for key,value in (("sourceCommit","e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e"),("runId","foreign"),("producerRunId","unit-inert"),("versionRunId","old-version")):
            changed=copy.deepcopy(request);changed[key]=value
            with self.subTest(key=key),mock.patch.object(c,"code_selector",side_effect=AssertionError("Old package cannot select tools")),self.assertRaises(v.Refusal):
                v.validate_package_identity(c,visual,changed,result)

    def test_failed_partial_boolean_alias_and_extra_package_claims_refuse(self):
        v,c=self.v,self.c
        visual,_,request,result=package_fixture(v,c,self.code)
        mutations=[("completed",False),("derivedBundledHostQualified",False),("treeExitedBeforeCleanup",False),("nativeArchiveQualified",1),("schema",True),("nativeImageBytes",True),("releaseQualification",True),("visualAcceptance",True),("unknown",True)]
        for key,value in mutations:
            changed=copy.deepcopy(result);changed[key]=value
            with self.subTest(key=key,value=value),self.assertRaises(v.Refusal):
                v.validate_package_identity(c,visual,request,changed)
        changed=copy.deepcopy(request);changed["fetchMissingLicenses"]=1
        with self.assertRaises(v.Refusal):
            v.validate_package_identity(c,visual,changed,result)

    def test_receipt_inventory_has_all60_fixed_root_and_four_stage_roles(self):
        v=self.v
        base=Path(self.temp.name).resolve()
        paths=v.receipt_names(base/"package",base/"stage")
        self.assertEqual(len(paths),60)
        self.assertEqual(sum(name.startswith("root/") for name in paths),48)
        self.assertEqual(sum(name.startswith("jobs/") for name in paths),12)
        for phase in ("before","after","final"):
            self.assertIn("root/source-"+phase+".json",paths)
            self.assertIn("root/git-head-"+phase+".job.json",paths)
            self.assertIn("root/package-tracked-"+phase+".stdout",paths)

    def test_receipt_total_budget_refuses_before_any_file_pin(self):
        v,c=self.v,self.c
        read=mock.Mock(side_effect=AssertionError("No over-budget receipt reads"))
        with mock.patch.object(c,"ordinary",return_value=types.SimpleNamespace(st_size=2000000)),ExitStack() as stack:
            with self.assertRaises(v.Refusal):
                v.pin_receipts(c,{"ReadPin":read},None,stack,Path(self.temp.name)/"package",Path(self.temp.name)/"stage")
        read.assert_not_called()

    def test_native_stage_command_preserves_explicit_license_fetch_without_relabeling(self):
        v,c=self.v,self.c
        stage=Path(self.temp.name).resolve()/"stage";p=types.SimpleNamespace(CARGO=stage/"cargo.exe")
        for fetch in (True,False):
            _,package,_,_=package_fixture(v,c,self.code,fetch)
            commands=v.stage_commands(c,p,stage,package)
            argv,seconds=commands["native-package"]
            self.assertEqual("--fetch-missing-licenses" in argv,fetch)
            self.assertEqual(seconds,900)
            self.assertIn("-UseBundledRuntime",commands["vscode-host"][0])
            self.assertEqual(commands["vscode-host"][1],190)
            self.assertEqual(commands["vscode-host"][0][-1],"180")

class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.v=policy();self.c=self.v.load_package()

    def stage_fixture(self):
        v,c=self.v,self.c
        stage=Path(v.ROOT.anchor)/"owned-stage"
        package=types.SimpleNamespace(fetch_missing_licenses=True,code_executable=stage/"Code.exe")
        p=types.SimpleNamespace(CARGO=stage/"cargo.exe")
        receipts={}
        for label,(command,seconds) in v.stage_commands(c,p,stage,package).items():
            stdout=json.dumps(host()).encode() if label=="vscode-host" else b"{}"
            row=valid_job(c,command,seconds);row["capturedLogBytes"]=len(stdout)
            receipts["jobs/"+label+".job.json"]=Pin(json.dumps(row).encode())
            receipts["jobs/"+label+".stdout"]=Pin(stdout)
            receipts["jobs/"+label+".stderr"]=Pin()
        return p,stage,package,receipts

    def test_all_four_raw_package_stages_require_natural_completion(self):
        v,c=self.v,self.c
        p,stage,package,pins=self.stage_fixture()
        v.validate_package_stages(c,p,pins,stage,package,{"host":host()})
        for label in v.STAGES:
            for key,value in (("completed",False),("treeExitedBeforeCleanup",False),("activeBeforeCleanup",1),("exitCode",1),("streamEOF",[True,False])):
                changed=dict(pins);name="jobs/"+label+".job.json"
                row=json.loads(pins[name].bytes());row[key]=value
                changed[name]=Pin(json.dumps(row).encode())
                with self.subTest(label=label,key=key),self.assertRaises((v.Refusal,c.Refusal)):
                    v.validate_package_stages(c,p,changed,stage,package,{"host":host()})

    def test_host_result_and_complete_stream_lengths_must_match_held_artifacts(self):
        v,c=self.v,self.c
        p,stage,package,pins=self.stage_fixture()
        altered=host();altered["bundledRuntime"]=False
        with self.assertRaises(v.Refusal):
            v.validate_package_stages(c,p,pins,stage,package,{"host":altered})
        changed=dict(pins);changed["jobs/native-package.stderr"]=Pin(b"unaccounted")
        with self.assertRaises(v.Refusal):
            v.validate_package_stages(c,p,changed,stage,package,{"host":host()})

    def test_git_job_keeps_2mb_cap_and_original_natural_drain_abort_bounds(self):
        v,c=self.v,self.c
        command=["owned-git","rev-parse","--verify","HEAD"]
        row=valid_job(c,command,30);row["logCapBytes"]=2000000
        v.validate_git_job(c,row,command)
        for key,value in (("logCapBytes",16000000),("exitCode",False),("activeBeforeCleanup",1),("cleanupSeconds",3),("originalDrainSeconds",2),("absoluteDeadlineNs",None)):
            changed=copy.deepcopy(row);changed[key]=value
            with self.subTest(key=key),self.assertRaises(v.Refusal):
                v.validate_git_job(c,changed,command)

    def test_late_pin_failure_cannot_be_converted_to_successful_snapshot(self):
        c=self.c
        good=Pin(b"owned");bad=Pin(b"late");bad.fail=True
        with self.assertRaises(RuntimeError):
            c.pin_snapshot({"good":good,"bad":bad})

class AcknowledgementTests(unittest.TestCase):
    def setUp(self):
        self.v=policy()

    def test_bound_private_ready_ack_and_observation_accept_only_exact_raw_bytes(self):
        v=self.v;context,ready,ack,observed,raw=operator_fixture(v)
        self.assertEqual(v.validate_acknowledgement(context,ready,ack,observed,raw),ack["screenshots"])
        with self.assertRaises(v.Refusal):
            v.validate_acknowledgement(context,ready,ack,observed,raw+b" ")

    def test_nonce_source_run_inspection_and_unknown_fields_cannot_be_replayed(self):
        v=self.v;context,ready,ack,observed,raw=operator_fixture(v)
        for area,key,value in (("ready","sourceCommit","f"*40),("ready","runId","old-visual"),("ready","nonce","b"*64),("ready","originalHostPassed",1),("ack","nonce","b"*64),("ack","inspected",1),("ack","unknown",True),("observed","nonce","b"*64),("observed","schema",True)):
            parts={"ready":copy.deepcopy(ready),"ack":copy.deepcopy(ack),"observed":copy.deepcopy(observed)}
            parts[area][key]=value
            with self.subTest(area=area,key=key),self.assertRaises(v.Refusal):
                v.validate_acknowledgement(context,parts["ready"],parts["ack"],parts["observed"],raw)

    def test_90second_deadline_is_absolute_without_a_late_ack_grace_period(self):
        v=self.v;context,ready,ack,observed,raw=operator_fixture(v)
        limit=1000+90000000000
        for changes in ({"observedNs":str(limit),"validatedNs":str(limit)},
                        {"validatedNs":str(limit)}, {"observedNs":"999"},
                        {"readyNs":True},{"validatedNs":"9"*25}):
            changed=copy.deepcopy(observed);changed.update(changes)
            with self.subTest(changes=changes),self.assertRaises(v.Refusal):
                v.validate_acknowledgement(context,ready,ack,changed,raw)
        last=copy.deepcopy(observed);last.update(observedNs=str(limit-2),validatedNs=str(limit-1))
        self.assertEqual(v.validate_acknowledgement(context,ready,ack,last,raw),ack["screenshots"])

    def test_images_require_two_distinct_bound_pngs_inside_this_run(self):
        v=self.v;c=v.load_package()
        out=Path(v.ROOT.anchor)/"owned-images"
        data={out/"first.png":b"\x89PNG\r\n\x1a\nfirst-inert",out/"second.png":b"\x89PNG\r\n\x1a\nsecond-inert"}
        entries=[{"path":str(path),"sha256":hashlib.sha256(raw).hexdigest()} for path,raw in data.items()]
        def read(api,path,maximum):
            self.assertEqual(maximum,16000000)
            return Pin(data[path])
        with ExitStack() as stack:
            pins,summary=v.pin_images(c,{"ReadPin":read},None,stack,out,entries)
            self.assertEqual(len(pins),2);self.assertEqual(len(summary),2)
        for changed in ([entries[0]],[entries[0],entries[0]],
                        [dict(entries[0],path=str(out.parent/"foreign.png")),entries[1]],
                        [dict(entries[0],sha256="f"*64),entries[1]]):
            with self.subTest(entries=changed),ExitStack() as stack,self.assertRaises(v.Refusal):
                v.pin_images(c,{"ReadPin":read},None,stack,out,changed)

    def test_unknown_image_fields_nonpng_and_too_many_images_refuse(self):
        v=self.v;c=v.load_package();out=Path(v.ROOT.anchor)/"owned-images"
        item={"path":str(out/"first.png"),"sha256":"b"*64}
        with ExitStack() as stack,self.assertRaises(v.Refusal):
            v.pin_images(c,{"ReadPin":mock.Mock()},None,stack,out,[item]*9)
        with ExitStack() as stack,self.assertRaises(v.Refusal):
            v.pin_images(c,{"ReadPin":mock.Mock()},None,stack,out,[dict(item,extra=True),item])
        invalid=b"not-a-PNG";item["sha256"]=hashlib.sha256(invalid).hexdigest()
        with ExitStack() as stack,self.assertRaises(v.Refusal):
            v.pin_images(c,{"ReadPin":lambda *a:Pin(invalid)},None,stack,out,[item,dict(item,path=str(out/"second.png"))])

class SourceAndManifestTests(unittest.TestCase):
    def test_manifest_is_closed_and_cannot_change_source_pins_or_budgets(self):
        v=policy();c=v.load_package()
        own={n:{"bytes":1,"sha256":"a"*64} for n in v.CONTROL_NAMES}
        m={"owner":v.OWNER,"schema":v.SCHEMA,"sourceCommit":v.SOURCE_COMMIT,"controlNames":list(v.CONTROL_NAMES),"sourceHashes":{n:r for n,r in own.items() if n!="review-manifest.json"},"packagePins":v.PACKAGE_PINS,"budgets":v.BUDGETS,"visibleLauncherSha256":v.VISIBLE_LAUNCHER_SHA,"originalHostSha256":v.ORIGINAL_HOST_SHA,"scope":"separate-actual-desktop-visual-acknowledgement","checks":{},"unrun":[]}
        v.validate_manifest(c,m,own)
        for changes in ({"schema":True},{"sourceCommit":"f"*40},{"packagePins":{}},{"budgets":dict(v.BUDGETS,visualAckSeconds=180)},{"unknown":True}):
            changed=copy.deepcopy(m);changed.update(changes)
            with self.subTest(changes=changes),self.assertRaises(v.Refusal):
                v.validate_manifest(c,changed,own)

    def test_visible_launcher_is_byte_exact_and_never_uses_internal_force_cleanup(self):
        v=policy();data=(HERE/"test-vscode-visual.ps1").read_bytes()
        self.assertEqual(hashlib.sha256(data).hexdigest(),v.VISIBLE_LAUNCHER_SHA)
        self.assertIn(b"-WindowStyle Normal",data)
        self.assertNotIn(b"taskkill",data)
        self.assertIn(b"WaitForExit(5000)",data)
        self.assertIn(b"if ($UseBundledRuntime)",data)
        self.assertNotIn(b"ExecutionPolicy",data)

    def test_wrapper_preserves_original_host_and_private_90second_operator_binding(self):
        v=policy();source=(HERE/"visual-host.cjs").read_text()
        self.assertIn(v.ORIGINAL_HOST_SHA,source)
        self.assertIn('await require(original).run()',source)
        self.assertIn('ACK_NS=90000000000n',source)
        self.assertIn('observedNs>=deadline',source)
        self.assertIn('validatedNs>=deadline',source)
        self.assertIn('ackSha256:crypto.createHash',source)
        self.assertIn('process.env.YOKE_VISUAL_OPERATOR_SPEC',source)
        self.assertNotIn('inspect-owned-code.ps1',source)
        tree=ast.parse((HERE/"visual_controller.py").read_text())
        forbidden=[n for n in ast.walk(tree) if isinstance(n,ast.Attribute) and n.attr in ("RUNTIME_COMMIT","load_pair_dependencies","acquire_pair_mutexes","observe_equivalence")]
        self.assertFalse(forbidden)

    def test_scheduler_delay_during_ready_publication_consumes_the_existing_window(self):
        v=policy()
        wrapper=(HERE/"visual-host.cjs").read_bytes()
        original=(v.ROOT/"extensions/vscode/test-host.cjs").read_bytes()
        manifest=json.loads((HERE/"review-manifest.json").read_text())
        self.assertEqual(hashlib.sha256(wrapper).hexdigest(),manifest["sourceHashes"]["visual-host.cjs"]["sha256"])
        self.assertEqual(hashlib.sha256(original).hexdigest(),v.ORIGINAL_HOST_SHA)
        program=r'''
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path').posix,crypto=require('node:crypto');
const input=JSON.parse(fs.readFileSync(0,'utf8'));
async function trial(delaySeconds){
 const nonce='a'.repeat(64),root='/owned',result=root+'/result.json',spec=root+'/operator-spec.json';
 const context={schema:1,sourceCommit:input.source,runId:'visual-clock',nonce,
  ready:root+'/visual-ready.json',ack:root+'/visual-ack.json',observed:root+'/visual-observed.json'};
 const files=new Map([[spec,Buffer.from(JSON.stringify(context))],
  [root+'/original-host.cjs',Buffer.from(input.original,'base64')]]);
 let now=1000000000n;
 const fakeProcess={env:{YOKE_VISUAL_OPERATOR_SPEC:spec,YOKE_VSCODE_RESULT:result},hrtime:{bigint:()=>now}};
 const fakeFs={
  existsSync:file=>files.has(file),
  lstatSync:file=>{if(!files.has(file))throw Error('Absent fixture');return {isFile:()=>true,isSymbolicLink:()=>false,nlink:1,size:files.get(file).length,dev:1,ino:file,mtimeMs:0};},
  readFileSync:file=>{if(!files.has(file))throw Error('Unexpected fixture read');return files.get(file);},
  writeFileSync:(file,data,options)=>{
   if(options.flag!=='wx'||files.has(file))throw Error('Occupied fixture');
   files.set(file,Buffer.from(data));
   if(file===context.ready){
    // Simulate descheduling after readiness becomes visible, before publish returns.
    now+=BigInt(delaySeconds)*1000000000n;
    files.set(context.ack,Buffer.from(JSON.stringify({nonce,inspected:true,screenshots:[{path:'one.png',sha256:'b'.repeat(64)},{path:'two.png',sha256:'c'.repeat(64)}]})));
   }
  }
 };
 const originalStub={run:async()=>files.set(fakeProcess.env.YOKE_VSCODE_RESULT,Buffer.from(JSON.stringify({passed:true,bundledRuntime:true,vscodeVersion:'clock-fixture'})))};
 const exports={};
 const sandbox={Buffer,exports,process:fakeProcess,__dirname:root,
  require:name=>{if(name==='node:fs')return fakeFs;if(name==='node:path')return path;if(name==='node:crypto')return crypto;if(name===root+'/original-host.cjs')return originalStub;throw Error('Unexpected fixture module');},
  setTimeout:()=>{throw Error('Unexpected fixture wait');}};
 vm.runInNewContext(Buffer.from(input.wrapper,'base64').toString('utf8'),sandbox);
 let error=null;try{await exports.run();}catch(e){error=e.message;}
 return {delaySeconds,error,published:files.has(result),observed:files.has(context.observed)};
}
(async()=>{console.log(JSON.stringify([await trial(10),await trial(95)]));})().catch(e=>{console.error(e.message);process.exitCode=1;});
'''
        payload={"source":v.SOURCE_COMMIT,"wrapper":base64.b64encode(wrapper).decode(),"original":base64.b64encode(original).decode()}
        run=subprocess.run([r"C:\Program Files\nodejs\node.exe","-e",program],input=json.dumps(payload).encode(),capture_output=True,timeout=5,check=False)
        self.assertEqual(run.returncode,0,run.stderr.decode(errors="replace"))
        self.assertLess(len(run.stdout)+len(run.stderr),64000)
        self.assertEqual(json.loads(run.stdout),[
            {"delaySeconds":10,"error":None,"published":True,"observed":True},
            {"delaySeconds":95,"error":"Visual inspection deadline","published":False,"observed":False},
        ])

if __name__=="__main__":
    unittest.main(verbosity=2)
