"""Separate real desktop visual acknowledgement of a fully admitted 704 package."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import math
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import sys
import time
import types

ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
BASE = ROOT / "validation/integration-20261025/platform-repairs"
CONTROL = BASE / "control-visual-lld-704"
PACKAGE = BASE / "control-package-lld-329"
RUNS = BASE / "runs-visual-lld-704"
PRIVATE = BASE / "private-visual-lld-704"
SOURCE_COMMIT = "704b647d625dcc5f359386b20834d329ffb6cdf4"
OWNER = "local-package-lld-desktop-visual-v1"
SCHEMA = 1
PYTHON = Path("C:/Python314/python.exe")
PACKAGE_PINS = {"package_vscode_controller.py":"c393e2c86c6589ef0df5e90d8c87a03612827b395fc2c1ac635bd6381d465b54","test_package_vscode_controller.py":"c3d00eba5cd5c8f2cd6351820f8c4928b4d680045722e2d5dc4297ea6bca2324","README.md":"7aace23ed885e25f385795a3c315493fd1bf75b4de8c9b71c245117b8e21cc62","review-manifest.json":"838e773444b80d71b9f74e9ea39103168c600b96e40bc4d81544f824c9231627",".gitattributes":"a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9","derived-launcher.patch":"7062ef388563aa589e53f9a13dc5fa9687ce9561361799725d7a23cd064f81dc"}
CONTROL_NAMES = ("visual_controller.py","test_visual_controller.py","visual-host.cjs","test-vscode-visual.ps1","README.md","review-manifest.json",".gitattributes")
VISIBLE_LAUNCHER_SHA = "ada2fec27ecaf94ee720eba70810ee23392f1738e9ed29f7f23ac3834ef44664"
ORIGINAL_HOST_SHA = "063bdd94d30440c757be0344a460ebba1167b32da3365e34bf4e73207ae352de"
BUDGETS = {"pipelineSeconds":1800,"hostRequestSeconds":180,"hostOuterSeconds":190,"visualAckSeconds":90,"outerDrainSeconds":1,"outerCleanupSeconds":2,"gitSeconds":30,"gitLogBytes":2000000,"logBytes":16000000,"receiptBytes":96000000,"jsonBytes":1000000,"operatorBytes":65536,"ackBytes":16384,"imageBytes":16000000,"screenshots":8}
RUN_PATTERN = re.compile(r"[a-z][a-z0-9-]{0,95}")
SHA_PATTERN = re.compile(r"[a-f0-9]{64}")
ROOT_FILES = ("request.json","result.json","dependency-controls-before.json","package-controls-before.json","package-controls-after.json","packaging-inputs-before.json","packaging-inputs-after.json","staged-image.json","artifacts.json")
STAGES = ("package-metadata","native-package","vsix-package","vscode-host")
PACKAGE_ROOT_FILES = ROOT_FILES + tuple("source-"+phase+".json" for phase in ("before","after","final")) + tuple(prefix+"-"+phase+suffix for phase in ("before","after","final") for prefix in ("git-head","git-status","git-files","package-tracked") for suffix in (".job.json",".stdout",".stderr"))

class Refusal(RuntimeError):
    pass

def need(condition, code):
    if not condition:
        raise Refusal(code)

def closed(value, keys, code):
    need(type(value) is dict and set(value)==set(keys),code)

def canonical(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(",",":")).encode()

def equal(actual, expected, code):
    need(canonical(actual)==canonical(expected),code)

def source_bytes(path):
    need(path.suffix.lower() not in (".exe",".pdb",".dll",".rlib",".lib",".obj",".o"),"source-role")
    for parent in (path.parent,*path.parents):
        st=parent.lstat()
        need(stat.S_ISDIR(st.st_mode) and not getattr(st,"st_file_attributes",0)&0x400,"source-path")
    before=path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink==1 and before.st_size<=1000000 and not getattr(before,"st_file_attributes",0)&0x400,"source-file")
    data=path.read_bytes();after=path.lstat()
    need((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns),"source-drift")
    return data

def load_package():
    for name,pin in PACKAGE_PINS.items():
        need(hashlib.sha256(source_bytes(PACKAGE/name)).hexdigest()==pin,"package-control")
    path=PACKAGE/"package_vscode_controller.py"
    module=types.ModuleType("frozen_lld_package_for_visual")
    module.__file__=str(path)
    exec(compile(source_bytes(path),str(path),"exec"),module.__dict__)
    need(module.ROOT==ROOT and module.CONTROL==PACKAGE and module.SOURCE_COMMIT==SOURCE_COMMIT and module.SCHEMA==3,"package-policy")
    return module

class Arguments(argparse.ArgumentParser):
    def error(self, message):
        raise Refusal("arguments")

def options(arguments=None):
    args=sys.argv[1:] if arguments is None else list(arguments)
    names=("--source-commit","--run-id","--package-run-id","--producer-run-id","--version-run-id")
    need(all(args.count(name)==1 for name in names),"arguments")
    parser=Arguments(add_help=False,allow_abbrev=False)
    for name in names:
        parser.add_argument(name,required=True)
    opt=parser.parse_args(args)
    ids=(opt.run_id,opt.package_run_id,opt.producer_run_id,opt.version_run_id)
    need(opt.source_commit==SOURCE_COMMIT and len(set(ids))==4 and all(RUN_PATTERN.fullmatch(name) for name in ids),"arguments")
    return opt

def own_map(c):
    return c.source_map(CONTROL,CONTROL_NAMES)

def validate_manifest(c, value, own):
    closed(value,("owner","schema","sourceCommit","controlNames","sourceHashes","packagePins","budgets","visibleLauncherSha256","originalHostSha256","scope","checks","unrun"),"manifest")
    need(value["owner"]==OWNER and type(value["schema"]) is int and value["schema"]==SCHEMA and value["sourceCommit"]==SOURCE_COMMIT and value["controlNames"]==list(CONTROL_NAMES) and value["scope"]=="separate-actual-desktop-visual-acknowledgement","manifest")
    equal(value["packagePins"],PACKAGE_PINS,"manifest")
    equal(value["budgets"],BUDGETS,"manifest")
    need(value["visibleLauncherSha256"]==VISIBLE_LAUNCHER_SHA and value["originalHostSha256"]==ORIGINAL_HOST_SHA,"manifest")
    closed(value["sourceHashes"],set(CONTROL_NAMES)-{"review-manifest.json"},"manifest")
    need(set(own)==set(CONTROL_NAMES),"manifest")
    for name,row in value["sourceHashes"].items():
        equal(row,own[name],"manifest")

def stage_path(c, run_id):
    parent=Path(os.environ.get("TEMP",""))
    need(parent.is_absolute() and parent.drive.lower()==ROOT.drive.lower(),"stage-parent")
    c.ordinary(parent,directory=True)
    result=parent/("yp-"+c.digest(run_id.encode("utf8"))[:12])
    need(len(str(result).encode("utf-16-le"))//2<=c.BUDGETS["stageRootUtf16Units"],"stage-length")
    c.ordinary(result,directory=True)
    return result

def receipt_names(package, stage):
    result={"root/"+name:package/name for name in PACKAGE_ROOT_FILES}
    result.update({"jobs/"+label+suffix:stage/"j"/(label+suffix) for label in STAGES for suffix in (".job.json",".stdout",".stderr")})
    need(len(result)==60,"receipt-inventory")
    return result

def pin_receipts(c,g,api,stack,package,stage):
    paths=receipt_names(package,stage)
    sizes={name:c.ordinary(path).st_size for name,path in paths.items()}
    need(sum(sizes.values())<=BUDGETS["receiptBytes"],"receipt-capacity")
    return {name:stack.enter_context(g["ReadPin"](api,path,BUDGETS["logBytes"] if name.endswith((".stdout",".stderr")) else BUDGETS["jsonBytes"])) for name,path in paths.items()}

def json_receipt(c,pins,name):
    need(name in pins and name.endswith(".json"),"receipt-role")
    return c.unique_json(pins[name].bytes())

def validate_package_identity(c,opt,request,result):
    need(type(request) is dict and request.get("sourceCommit")==SOURCE_COMMIT
         and request.get("runId")==opt.package_run_id and request.get("producerRunId")==opt.producer_run_id
         and request.get("versionRunId")==opt.version_run_id,"package-request")
    need(type(request.get("fetchMissingLicenses")) is bool,"package-request")
    metadata=request.get("codeExecutableMetadata")
    need(type(metadata) is dict and type(metadata.get("path")) is str,"package-tool")
    code,record=c.code_selector(metadata["path"])
    equal(metadata,record,"package-tool")
    package_opt=types.SimpleNamespace(source_commit=SOURCE_COMMIT,run_id=opt.package_run_id,producer_run_id=opt.producer_run_id,version_run_id=opt.version_run_id,fetch_missing_licenses=request["fetchMissingLicenses"],code_executable=code,code_metadata=record)
    equal(request,{**c.initial_result(package_opt),"budgets":c.BUDGETS,"derivedLauncherOnly":True},"package-request")
    extra={"hostPowerShellMetadata","nativeImageBytes","selectedWindowsBinaryByteLimit","generalNativeEntryByteLimit","nativeSha256","nativeArchive","nativeVsix","originalHostLauncherUnchangedEvidence","derivedLauncherSha256","bundledRuntime","treeExitedBeforeCleanup","packagingSourceCount"}
    closed(result,set(c.initial_result(package_opt))|extra,"package-result")
    for name in ("owner","schema","sourceCommit","runId","producerRunId","versionRunId","fetchMissingLicenses","codeExecutableMetadata"):
        equal(result[name],request[name],"package-result")
    for key in ("completed","nativeImageReadAttempted","nativeImageRead","stagedImageCreated","matchingVersionReceiptAdmitted","nativeArchiveQualified","nativeVsixQualified","derivedBundledHostQualified","sourceInputsUnchanged","protectedMetadataUnchanged","bundledRuntime","treeExitedBeforeCleanup"):
        need(result[key] is True,"package-result")
    for key in ("visualAcceptance","releaseQualification","wholeProjectComplete","originalHostLauncherUnchangedEvidence"):
        need(result[key] is False,"package-result")
    need(result["failureCode"] is None and result["phase"]=="complete" and result["derivedLauncherSha256"]==c.DERIVED_LAUNCHER_SHA,"package-result")
    need(type(result["nativeImageBytes"]) is int and 0<result["nativeImageBytes"]<=c.BUDGETS["windowsBinaryBytes"] and type(result["packagingSourceCount"]) is int and result["packagingSourceCount"]>0,"package-result")
    need(type(result["nativeSha256"]) is str and SHA_PATTERN.fullmatch(result["nativeSha256"])
         and type(result["nativeArchive"]) is dict and type(result["nativeVsix"]) is dict,"package-result")
    equal(result["selectedWindowsBinaryByteLimit"],c.BUDGETS["windowsBinaryBytes"],"package-result")
    equal(result["generalNativeEntryByteLimit"],c.BUDGETS["nativeEntryBytes"],"package-result")
    return package_opt

def validate_git_job(c, row, command):
    seconds = 30
    absolute_deadline = row.get("absoluteDeadlineNs")
    need(type(absolute_deadline) is int and absolute_deadline > 0,"git-job")
    required = {"command", "deadlineSeconds", "logCapBytes", "stdinClosed", "startedSuspended",
        "assignedBeforeResume", "completed", "treeExitedBeforeCleanup", "minimumFreeObserved", "cleanupErrors",
        "streamEOF", "readerErrors", "startedMonotonicNs", "absoluteDeadlineNs", "jobName", "namedJobCreatedNew",
        "pid", "resumePreviousSuspendCount", "exitCode", "rootObservedMonotonicNs", "membersAtRootObservation",
        "rootExitedAtObservation", "activeAtRootObservation", "originalDrainSeconds", "activeBeforeCleanup",
        "membersAfterOriginalDrain", "treeObservedMonotonicNs", "cleanupSeconds", "activeAfterCleanup",
        "rootExitedAfterCleanup", "elapsedSeconds", "capturedLogBytes", "outputExceeded", "cleanupUnproven"}
    closed(row, required, "git-job")
    need(row["command"] == command and type(row["deadlineSeconds"]) is int and row["deadlineSeconds"] == seconds
         and type(row["logCapBytes"]) is int and row["logCapBytes"] == BUDGETS["gitLogBytes"]
         and row["absoluteDeadlineNs"] == absolute_deadline and c.integer(row["startedMonotonicNs"], 1)
         and row["startedMonotonicNs"] < absolute_deadline <= row["startedMonotonicNs"] + seconds * 1_000_000_000
         and row["jobName"] is None and row["namedJobCreatedNew"] is False, "job")
    need(all(row[key] is True for key in ("stdinClosed", "startedSuspended", "assignedBeforeResume", "completed",
         "treeExitedBeforeCleanup", "rootExitedAtObservation", "rootExitedAfterCleanup"))
         and all(row[key] is False for key in ("outputExceeded", "cleanupUnproven"))
         and row["streamEOF"] == [True, True] and all(type(value) is bool for value in row["streamEOF"])
         and row["readerErrors"] == [False, False] and all(type(value) is bool for value in row["readerErrors"])
         and row["cleanupErrors"] == [] and row["membersAfterOriginalDrain"] == []
         and type(row["membersAtRootObservation"]) is list and len(row["membersAtRootObservation"]) <= 256, "job")
    need(all(type(row[key]) is int and row[key] == expected for key, expected in
         (("exitCode", 0), ("resumePreviousSuspendCount", 1), ("activeBeforeCleanup", 0), ("activeAfterCleanup", 0),
          ("originalDrainSeconds", 1), ("cleanupSeconds", 2))) and c.integer(row["activeAtRootObservation"])
         and c.integer(row["pid"], 1) and c.integer(row["minimumFreeObserved"], c.BUDGETS["reserveBytes"])
         and c.integer(row["capturedLogBytes"], 0, BUDGETS["gitLogBytes"])
         and c.integer(row["rootObservedMonotonicNs"], row["startedMonotonicNs"], absolute_deadline - 1)
         and c.integer(row["treeObservedMonotonicNs"], row["rootObservedMonotonicNs"], absolute_deadline - 1)
         and type(row["elapsedSeconds"]) in (int, float) and math.isfinite(row["elapsedSeconds"])
         and 0 <= row["elapsedSeconds"] <= seconds + 2.5, "job")


def check_package_git(c,pins,environment,opt,current_listing):
    git=shutil.which("git.exe",path=environment["PATH"])
    need(git and Path(git).is_absolute(),"git-tool")
    prefix=[git,"--no-optional-locks","-c","core.fsmonitor=false","-c","core.untrackedCache=false"]
    recipes={"git-head":["rev-parse","--verify","HEAD"],"git-status":["status","--porcelain=v1","-z","--untracked-files=no"],"git-files":["ls-files","-z"],"package-tracked":["ls-files","-z"]}
    for phase in ("before","after","final"):
        for label,arguments in recipes.items():
            stem="root/"+label+"-"+phase
            row=json_receipt(c,pins,stem+".job.json")
            validate_git_job(c,row,prefix+arguments)
            stdout,stderr=pins[stem+".stdout"].bytes(),pins[stem+".stderr"].bytes()
            need(stderr==b"" and len(stdout)+len(stderr)==row["capturedLogBytes"],"git-capture")
            if label=="git-head":
                need(stdout.strip()==SOURCE_COMMIT.encode(),"package-source")
            elif label=="git-status":
                need(stdout==b"","package-source")
            else:
                need(stdout==current_listing,"package-source")

def stage_commands(c,p,stage,package_opt):
    native=stage/"a/yoke-0.5.0-x86_64-pc-windows-msvc.zip"
    vsix=stage/"a/code-intelligence-0.5.0-win32-x64.vsix"
    package=[str(PYTHON),"-I",str(ROOT/"scripts/package-native.py"),"--skip-build","--output",str(native)]
    if package_opt.fetch_missing_licenses:
        package.append("--fetch-missing-licenses")
    return {"package-metadata":([str(p.CARGO),"metadata","--manifest-path",str(ROOT/"Cargo.toml"),"--locked","--offline","--format-version","1","--filter-platform",c.TARGET],c.BUDGETS["metadataSeconds"]),"native-package":(package,c.BUDGETS["nativePackageSeconds"]),"vsix-package":([str(PYTHON),"-I",str(ROOT/"scripts/package-vscode.py"),"--native-archive",str(native),"--output",str(vsix)],c.BUDGETS["vsixPackageSeconds"]),"vscode-host":([str(c.POWERSHELL),"-NoProfile","-NonInteractive","-File",str(stage/"scripts/test-vscode-owned.ps1"),"-CodeExecutable",str(package_opt.code_executable),"-ExtensionDirectory",str(stage/"x/extension"),"-UseBundledRuntime","-TimeoutSeconds",str(c.BUDGETS["hostRequestSeconds"])],c.BUDGETS["hostOuterSeconds"])}

def validate_package_stages(c,p,pins,stage,package_opt,artifacts):
    for label,(command,seconds) in stage_commands(c,p,stage,package_opt).items():
        row=json_receipt(c,pins,"jobs/"+label+".job.json")
        c.validate_job(row,command,seconds,row.get("absoluteDeadlineNs"))
        stdout,stderr=pins["jobs/"+label+".stdout"].bytes(),pins["jobs/"+label+".stderr"].bytes()
        need(len(stdout)+len(stderr)==row["capturedLogBytes"],"package-capture")
        if label=="vscode-host":
            host=c.unique_json(stdout.strip(),65536)
            c.validate_host(host)
            equal(host,artifacts["host"],"package-host")


def operator_spec(run_id,private,nonce):
    need(type(nonce) is str and SHA_PATTERN.fullmatch(nonce),"nonce")
    return {"schema":1,"sourceCommit":SOURCE_COMMIT,"runId":run_id,"nonce":nonce,"ready":str(private/"visual-ready.json"),"ack":str(private/"visual-ack.json"),"observed":str(private/"visual-observed.json")}

def validate_acknowledgement(context,ready,ack,observed,ack_bytes):
    closed(ready,("kind","sourceCommit","runId","nonce","originalHostPassed","vscodeVersion"),"visual-ready")
    need(type(ready["vscodeVersion"]) is str and re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?",ready["vscodeVersion"]),"visual-ready")
    need(ready["kind"]=="owned-code-visual-ready" and ready["sourceCommit"]==SOURCE_COMMIT and ready["runId"]==context["runId"] and ready["nonce"]==context["nonce"] and ready["originalHostPassed"] is True,"visual-ready")
    closed(ack,("nonce","inspected","screenshots"),"visual-ack")
    need(ack["nonce"]==context["nonce"] and ack["inspected"] is True and type(ack["screenshots"]) is list and 2<=len(ack["screenshots"])<=BUDGETS["screenshots"],"visual-ack")
    closed(observed,("schema","sourceCommit","runId","nonce","readyNs","observedNs","validatedNs","ackSha256"),"visual-observation")
    need(type(observed["schema"]) is int and observed["schema"]==1 and observed["sourceCommit"]==SOURCE_COMMIT and observed["runId"]==context["runId"] and observed["nonce"]==context["nonce"] and observed["ackSha256"]==hashlib.sha256(ack_bytes).hexdigest(),"visual-observation")
    values=[]
    for name in ("readyNs","observedNs","validatedNs"):
        value=observed[name]
        need(type(value) is str and re.fullmatch(r"[0-9]{1,24}",value),"visual-time")
        values.append(int(value))
    need(0<values[0]<=values[1]<=values[2]<values[0]+BUDGETS["visualAckSeconds"]*1000000000,"visual-time")
    return ack["screenshots"]

def pin_images(c,g,api,stack,out,entries):
    need(type(entries) is list and 2<=len(entries)<=BUDGETS["screenshots"],"visual-images")
    names=set();hashes=set();pins={};summary=[]
    for item in entries:
        closed(item,("path","sha256"),"visual-image")
        need(type(item["path"]) is str and type(item["sha256"]) is str and SHA_PATTERN.fullmatch(item["sha256"]),"visual-image")
        path=Path(item["path"])
        need(path.is_absolute() and path.parent==out and path.suffix==".png" and path.name not in names and item["sha256"] not in hashes,"visual-image")
        pin=stack.enter_context(g["ReadPin"](api,path,BUDGETS["imageBytes"]))
        need(pin.bytes().startswith(b"\x89PNG\r\n\x1a\n") and pin.record()["sha256"]==item["sha256"],"visual-image")
        names.add(path.name);hashes.add(item["sha256"]);pins[path.name]=pin
        summary.append({"path":path.name,"sha256":item["sha256"]})
    return pins,summary


def execute(opt):
    result={"owner":OWNER,"schema":SCHEMA,"sourceCommit":SOURCE_COMMIT,"runId":opt.run_id,"packageRunId":opt.package_run_id,"producerRunId":opt.producer_run_id,"versionRunId":opt.version_run_id,"completed":False,"visualInspection":False,"exactHeadBuild":False,"currentPlatformAcceptance":False,"releaseQualification":False,"wholeProjectComplete":False,"phase":"admission","nativeImageReadAttempted":False,"nativeImageRead":False}
    out=None
    try:
        need(os.name=="nt","platform")
        c=load_package()
        own=own_map(c)
        validate_manifest(c,c.unique_json(source_bytes(CONTROL/"review-manifest.json")),own)
        deadline=time.monotonic_ns()+BUDGETS["pipelineSeconds"]*1000000000
        compiler,p,g,original,h,api,extended=c.load_dependencies()
        with c.Mutex(compiler,p,api),ExitStack() as stack:
            c.fresh_parent(RUNS);c.fresh_parent(PRIVATE)
            out=c.fresh_directory(RUNS,opt.run_id);private=c.fresh_directory(PRIVATE,opt.run_id)
            for name in ("source","inputs","jobs"):
                c.fresh_directory(out,name)
            own_pins=c.pin_sources(g,api,stack,(("visual",CONTROL,own),("package",PACKAGE,c.source_map(PACKAGE,c.CONTROL_NAMES)),("helper",c.ADAPTER,c.checked_map(c.ADAPTER,c.ADAPTER_PINS)),("scripts",ROOT,c.checked_map(ROOT,c.SCRIPT_PINS))))
            own_before=c.pin_snapshot(own_pins)
            controls=p.pin_control_files(g,api,stack)
            environment=g["environment_for"]("build")
            maps=c.current_maps(p,g)
            sources=g["source_map"](api,extended,out/"source",environment,SOURCE_COMMIT,"before")
            admitted,version_pins,version_before=c.admit_pair(h,p,g,api,original,stack,opt,sources,maps["original"],maps["transaction"],result)
            inputs=c.public_inputs(g,api,extended,out/"inputs",environment,"before",deadline)
            input_pins=c.pin_inputs(g,api,stack,inputs);input_before=c.pin_snapshot(input_pins)
            package=c.RUNS/opt.package_run_id;c.ordinary(package,directory=True)
            stage=stage_path(c,opt.package_run_id)
            receipts=pin_receipts(c,g,api,stack,package,stage)
            receipt_before=c.pin_snapshot(receipts)
            request=json_receipt(c,receipts,"root/request.json")
            accepted=json_receipt(c,receipts,"root/result.json")
            package_opt=validate_package_identity(c,opt,request,accepted)
            for phase in ("before","after","final"):
                equal(json_receipt(c,receipts,"root/source-"+phase+".json"),sources,"package-source")
            for name in ("packaging-inputs-before.json","packaging-inputs-after.json"):
                equal(json_receipt(c,receipts,"root/"+name),inputs,"package-inputs")
            equal(json_receipt(c,receipts,"root/dependency-controls-before.json"),maps,"package-controls")
            package_map=c.source_map(PACKAGE,c.CONTROL_NAMES)
            c.validate_manifest(c.unique_json(source_bytes(PACKAGE/"review-manifest.json")),package_map)
            for name in ("package-controls-before.json","package-controls-after.json"):
                equal(json_receipt(c,receipts,"root/"+name),package_map,"package-controls")
            listing_pin=stack.enter_context(g["ReadPin"](api,out/"source/git-files-before.stdout",BUDGETS["gitLogBytes"]))
            check_package_git(c,receipts,environment,opt,listing_pin.bytes())
            staged=json_receipt(c,receipts,"root/staged-image.json")
            closed(staged,("producerImage","stagedCopy"),"package-staged")
            equal(staged["producerImage"],admitted["record"],"package-staged")
            need(staged["stagedCopy"].get("path")==str(stage/"t/release/yoke.exe"),"package-staged")
            staged_pin=stack.enter_context(g["ReadPin"](api,stage/"t/release/yoke.exe",c.BUDGETS["windowsBinaryBytes"],image=True))
            equal(staged_pin.recheck(),staged["stagedCopy"],"package-staged")
            need(staged["stagedCopy"]["sha256"]==admitted["record"]["sha256"] and staged["stagedCopy"]["bytes"]==admitted["record"]["bytes"],"package-staged")
            artifacts=json_receipt(c,receipts,"root/artifacts.json")
            closed(artifacts,("native","vsix","derivedLauncherSha256","originalLauncherSha256","host","privateOutputAccounting","privateOutputAccountingMode","outerPipeCaptureBytes","codeRedirectedLogsWithinOuterPipeCap","naturalTreeExitBeforeForce"),"package-artifacts")
            need(artifacts["derivedLauncherSha256"]==c.DERIVED_LAUNCHER_SHA and artifacts["originalLauncherSha256"]==c.ORIGINAL_LAUNCHER_SHA and artifacts["naturalTreeExitBeforeForce"] is True and artifacts["codeRedirectedLogsWithinOuterPipeCap"] is False,"package-artifacts")
            equal(artifacts["outerPipeCaptureBytes"],c.BUDGETS["logBytes"],"package-artifacts")
            need(artifacts["privateOutputAccountingMode"]=="stage-boundary observations; not a continuous quota","package-artifacts")
            equal(c.private_size(stage),artifacts["privateOutputAccounting"],"package-accounting")
            validate_package_stages(c,p,receipts,stage,package_opt,artifacts)
            code,code_record=c.code_selector(package_opt.code_executable)
            pwsh,pwsh_record=c.powershell_selector()
            equal(pwsh_record,accepted["hostPowerShellMetadata"],"package-tool")
            metadata=c.metadata_json(receipts["jobs/package-metadata.stdout"].bytes())
            dependencies=c.validate_metadata(metadata,stage/"t",admitted)
            pv=c.load_source(ROOT/"scripts/package-vscode.py",c.SCRIPT_PINS["scripts/package-vscode.py"],"visual_archive_validator")
            archive=stage/"a/yoke-0.5.0-x86_64-pc-windows-msvc.zip";vsix=stage/"a/code-intelligence-0.5.0-win32-x64.vsix"
            archive_pin=stack.enter_context(g["ReadPin"](api,archive,c.BUDGETS["archiveBytes"]))
            vsix_pin=stack.enter_context(g["ReadPin"](api,vsix,c.BUDGETS["archiveBytes"]))
            native_files,native_summary=c.inspect_native(pv,archive_pin.bytes(),inputs,admitted["record"],package_opt.fetch_missing_licenses,dependencies)
            files,vsix_summary=c.inspect_vsix(pv,vsix_pin.bytes(),native_files,inputs)
            equal(native_summary,accepted["nativeArchive"],"package-archive");equal(native_summary,artifacts["native"],"package-archive")
            equal(vsix_summary,accepted["nativeVsix"],"package-vsix");equal(vsix_summary,artifacts["vsix"],"package-vsix")
            need(accepted["nativeSha256"]==admitted["record"]["sha256"] and accepted["nativeImageBytes"]==admitted["record"]["bytes"] and accepted["packagingSourceCount"]==len(inputs["files"]),"package-result")
            extracted={}
            for name,data in files.items():
                path=(stage/"x").joinpath(*name.split("/"))
                selected=name=="extension/runtime/native/yoke.exe"
                pin=stack.enter_context(g["ReadPin"](api,path,c.BUDGETS["windowsBinaryBytes"] if selected else c.BUDGETS["nativeEntryBytes"],image=selected))
                need(pin.record()["sha256"]==c.digest(data) and pin.record()["bytes"]==len(data),"package-extraction")
                extracted[name]=pin
            visual_stage=c.fresh_stage(opt.run_id)
            for name in ("scripts","extensions","extensions/vscode","z"):
                (visual_stage/name).mkdir(mode=0o700)
            c.write_bytes(visual_stage/"scripts/test-vscode-visual.ps1",own_pins["visual/test-vscode-visual.ps1"].bytes())
            c.write_bytes(visual_stage/"extensions/vscode/test-host.cjs",own_pins["visual/visual-host.cjs"].bytes())
            original_host=input_pins["extensions/vscode/test-host.cjs"].bytes()
            need(c.digest(original_host)==ORIGINAL_HOST_SHA,"original-host")
            c.write_bytes(visual_stage/"extensions/vscode/original-host.cjs",original_host)
            context=operator_spec(opt.run_id,private,secrets.token_hex(32))
            c.write_json(private/"operator-spec.json",context)
            operator_pin=stack.enter_context(g["ReadPin"](api,private/"operator-spec.json",BUDGETS["operatorBytes"]))
            c.write_json(out/"request.json",{"owner":OWNER,"schema":SCHEMA,"scope":"Separate actual desktop inspection; original package result unchanged","sourceCommit":SOURCE_COMMIT,"runId":opt.run_id,"packageRunId":opt.package_run_id,"producerRunId":opt.producer_run_id,"versionRunId":opt.version_run_id,"visualAckSeconds":90,"hostRequestSeconds":180,"hostOuterSeconds":190,"operatorReadyPath":context["ready"],"operatorAckPath":context["ack"]})
            host_environment=c.host_environment(environment,visual_stage,pwsh)
            host_environment["YOKE_VISUAL_OPERATOR_SPEC"]=str(private/"operator-spec.json")
            command=[str(pwsh),"-NoProfile","-NonInteractive","-File",str(visual_stage/"scripts/test-vscode-visual.ps1"),"-CodeExecutable",str(code),"-ExtensionDirectory",str(stage/"x/extension"),"-UseBundledRuntime","-TimeoutSeconds","180"]
            result["phase"]="visible-original-host"
            c.default_release_absent(original,admitted)
            job,host_pins=c.run_stage(g,api,extended,stack,out/"jobs","visual-host",command,host_environment,190,deadline)
            host=c.unique_json(host_pins[".stdout"].bytes().strip(),65536);c.validate_host(host)
            operator={name:stack.enter_context(g["ReadPin"](api,private/name,BUDGETS["ackBytes"])) for name in ("visual-ready.json","visual-ack.json","visual-observed.json")}
            ready=c.unique_json(operator["visual-ready.json"].bytes(),BUDGETS["ackBytes"])
            ack_bytes=operator["visual-ack.json"].bytes();ack=c.unique_json(ack_bytes,BUDGETS["ackBytes"])
            observed=c.unique_json(operator["visual-observed.json"].bytes(),BUDGETS["ackBytes"])
            entries=validate_acknowledgement(context,ready,ack,observed,ack_bytes)
            need(ready["vscodeVersion"]==host["vscodeVersion"],"visual-host")
            image_pins,images=pin_images(c,g,api,stack,out,entries)
            result["phase"]="final-recheck"
            for phase in ("after","final"):
                equal(c.public_inputs(g,api,extended,out/"inputs",environment,phase,deadline),inputs,"source-drift")
                equal(g["source_map"](api,extended,out/"source",environment,SOURCE_COMMIT,phase),sources,"source-drift")
            equal(c.current_maps(p,g),maps,"control-drift")
            equal(c.source_map(PACKAGE,c.CONTROL_NAMES),package_map,"control-drift")
            equal(own_map(c),own,"control-drift")
            c.recheck_snapshot(own_pins,own_before);c.recheck_snapshot(input_pins,input_before);c.recheck_snapshot(receipts,receipt_before)
            h.recheck_pair(p,original,admitted,version_pins,version_before)
            for pin in (*controls.values(),*extracted.values(),*operator.values(),*image_pins.values(),*host_pins.values(),archive_pin,vsix_pin,operator_pin,listing_pin,staged_pin):
                pin.recheck()
            equal(c.code_selector(code)[1],code_record,"host-drift")
            equal(c.powershell_selector()[1],pwsh_record,"host-drift")
            c.check_deadline(deadline)
            c.write_json(out/"proofs.json",{"packageReceipts":receipt_before,"packageReceiptCount":len(receipts),"visualControls":own,"packageControls":package_map,"nativeVsixSha256":vsix_summary["sha256"],"nativeBinarySha256":admitted["record"]["sha256"],"screenshots":images,"operatorChannelsPrivate":True,"operatorFileHashes":{name:pin.record()["sha256"] for name,pin in operator.items()}})
            result.update(phase="complete",visualInspection=True,operator="codex actual-image inspection",screenshots=images,host=host,treeExitedBeforeCleanup=job["treeExitedBeforeCleanup"],nativeVsixSha256=vsix_summary["sha256"],nativeBinarySha256=admitted["record"]["sha256"],packageReceiptCount=len(receipts))
        c.check_deadline(deadline)
        result["completed"]=True
    except BaseException as error:
        result.update(completed=False,visualInspection=False,failureType=type(error).__name__)
    finally:
        if out is not None:
            try:
                c.write_json(out/"result.json",result)
            except BaseException as error:
                result.update(completed=False,visualInspection=False,failureType=type(error).__name__)
    return result

def main(arguments=None):
    try:
        result=execute(options(arguments))
    except BaseException as error:
        result={"completed":False,"visualInspection":False,"phase":"arguments","failureType":type(error).__name__}
    print(json.dumps({key:result.get(key) for key in ("completed","visualInspection","phase","failureType")}),flush=True)
    return 0 if result["completed"] else 1

if __name__=="__main__":
    raise SystemExit(main())
