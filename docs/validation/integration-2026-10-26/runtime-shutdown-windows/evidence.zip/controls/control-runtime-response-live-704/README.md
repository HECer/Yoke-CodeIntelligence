# Matching-release runtime response cases

This is source preparation, not execution evidence. No controller, helper,
worker, test, compiler, native image or Python runtime case was executed during
preparation. AST and source/hash checks are reported separately. Parent review,
guarded inert tests, a fresh matching release producer/version, and actual case
execution remain required.

The closed consumer accepts only clean source commit
`704b647d625dcc5f359386b20834d329ffb6cdf4` at the root derived from its own
location. It is prepared in `t3-b1973677`; every dependency must derive that same
root. The original e59 bundle remains unchanged. This derivative binds the parent
704 test-only callback-type follow-up; production code and the six tracked fixture recipes
remain identical. The parent must retain clean matching source bytes before execution. The consumer has no caller-selected native image, interpreter, working directory,
case, argument vector, flags, environment profile or fallback. Preparation does
not authorize any later run automatically.

## Admission

The release protocol is the unchanged compiler-LLD schema 3 bundle: eleven files,
manifest `141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9`,
protocol `eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a`.
The separate unit-build policy is unrelated and cannot satisfy this gate.

Before actual CLI execution, the consumer:

- Checks its closed manifest and pins the original seven controls, all eleven
  release controls, its six files, the selected fixture source and the frozen
  history helper source.
- Observes the exact clean HEAD and selected raw source bytes. Source selection
  preserves the release producer's native/scripts/Cargo/workflow inventory.
  Existing environment and Cargo-configuration refusal runs before and after
  every source observation and again at stable checkpoints.
- Calls the complete release `producer_admission`, requiring all 27 producer
  receipts and the actual `BuildInputsGuard`. The five original build-input
  proofs and all other producer checks remain mandatory. No failed output or
  prior E89 producer is adopted.
- Pins all 22 matching version receipts. Only the frozen history controller's
  pure `validate_version` and `recheck_pair` are reused with explicit current
  protocol/options/maps. Its E89 options, execute and version-admission entry
  points are never called; no module global is patched.
- Holds the admitted image, both receipt sets, build-input guard, protected-role
  observations, source/control/spec/evidence pins and fixed Python metadata
  through repeated checks and context closure. Every close and mutex release
  must succeed before completed acceptance is published.

The fixed host interpreter is `C:\Python314\python.exe`. A non-inherited
`FILE_EXECUTE|FILE_READ_ATTRIBUTES` handle excludes `FILE_READ_DATA` and denies
writes/deletion of the selected name while held. Exact common identity and
separate path/handle modes are retained and rechecked. The tool is trusted:
metadata is not executable-content attestation or an all-alias namespace fence.
No interpreter image bytes are read or hashed by this consumer.

## Six fixed cases

The source strings, requests, explicit grants, 10,000-ms CLI lifetime and original
assertions come from the pinned `native/tests/workflow_cli.rs` fixture.

| Case | User requests | Raw CLI exit | Original events |
|---|---|---:|---:|
| Empty paused batch | none | 0 | 1 paused |
| Stack paused batch | stack | 0 | 2 paused |
| Owned close refusal | explicit authorized REPL fixture | 1 | no stdout |
| Terminal program | continue | 0 | 2, last finished/true |
| Explicit close | close | 0 | 2, last closed/false |
| Complete nonclosed reply | explicit authorized REPL fixture | 1 | no stdout |

All cases retain `--trust-runtime`; only the two owned negative cases receive
`--allow-evaluation`. Their exact code alters only the private worker's in-memory
emit function so a later Close fails or returns a complete nonclosed response.
Program/source/code data remains inert
until that distinct explicit test authority is applied by the selected CLI.
No original user event or successful observation is synthesized.

Each worker starts in a newly named outer Job and proves its own membership
before launching the fixed admitted CLI command. The CLI working directory is
the fresh owned source fixture. Its stdout/stderr inherit the parent's private
capture. The worker records the actual CLI exit and exits with that same code.
It has no kill, breakaway, retry, additional cleanup wait or deadline refresh.
The parent remains the sole abort/cleanup owner.

The negative raw Job remains `exitCode:1`, `completed:false`. The validator
checks that unchanged row, complete streams, actual shutdown-refusal stderr,
empty stdout, root exit and zero Job membership before forced cleanup. The sixth
case preserves the original five and rewrites only the later `closed` response
to `paused` with empty frames. It additionally requires the exact bounded text
`Close response did not confirm closed state` alongside the shutdown refusal.
`expectedFailureObserved:true` is a separate scoped observation; it does not
turn the raw CLI failure into successful execution. All other cases require
raw exit 0 and completed natural ownership.

## Bounds and retained evidence

The absolute recipe deadline is 180 seconds and is never refreshed. Every Git
subprocess and each 20-second case is clipped to its remaining time. The case
window includes worker startup, CLI wait and the original one-second natural
drain. The sole abort/cleanup window remains two seconds. Existing source,
receipt, metadata and image pin I/O is synchronous on the trusted local host;
the recipe checks its ceiling around those bounded calls, not an OS scheduler
or filesystem sandbox.

The original stream admission limits remain 1,000,000 stdout and 128,000 stderr
bytes, with an aggregate parent capture ceiling of 1,128,000. The parent admits
each stream independently after complete capture; it does not claim a separate
continuous per-stream cutoff. Each owned fixture remains below 1,024 entries
and 32,000,000 logical file bytes. The private evidence tree is checked against
the same entry/byte bounds after each case and final observation. Those totals are not measured allocated or
reclaimed filesystem space. Start admission is 1.2 GB and the reserve 500 MB.

Fresh fixture roots use a validated ordinary local TEMP route, a short random
create-only name and a source path of at most 70 UTF-16 units. Links, reparse
routes, occupied names, foreign replacements, long spec paths and unavailable
observations refuse. Nothing is recursively deleted or reused. TEMP/TMP are
selected only in each owned child's copied environment.

Raw source maps, specifications, captured CLI responses, session identifiers,
stderr and untouched Job receipts stay under `private-runtime-response-live-704` or
the retained owned TEMP fixtures. Public `runs-runtime-response-live-704` summaries
carry fixed scope/selector context and only bounded counts/booleans for case
observations. No raw session payload or capability is copied into a public
summary. Full source/live-maintenance/VSIX/platform/release/project flags remain
false even if all six named case expectations later qualify.

## Parent execution

After review and guarded inert tests, use fresh selectors for a new matching
e59 release producer and version. Neither E89 nor 809 receipts can substitute.

```powershell
$control = 'validation/integration-20261025/platform-repairs/control-runtime-response-live-704/runtime_response_live_controller.py'
C:\Python314\python.exe -B $control --source-commit 704b647d625dcc5f359386b20834d329ffb6cdf4 --run-id runtime-response-live-e59-r1 --producer-run-id <matching-release-producer> --version-run-id <matching-version>
```

The parent must serialize all native/Cargo/controller runs across worktrees.
The inherited mutex is per-root, not host-wide. The authored inert tests load
only pinned Python policy source and use owned text/JSON fixtures and scripted
metadata/receipts; they do not launch native images, workers or interpreters.
Their test count describes coverage intent until actually executed. No RED
mutation result, actual runtime result or complete qualification is claimed by
this source bundle.

There are 25 authored inert test functions. Source-only AST/LF/whitespace and
dependency-hash checks do not establish that those tests pass. Their later
execution must remain inside the parent's reviewed ownership guards.
