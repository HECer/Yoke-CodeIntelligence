"""Inert policy/receipt tests; never execute a native CLI or worker."""
from contextlib import ExitStack
import copy
import hashlib
import json
from pathlib import Path
import stat
import tempfile
import types
import unittest
from unittest import mock

HERE = Path(__file__).absolute().parent


def policy():
    value = types.ModuleType("inert_runtime_live_policy")
    value.__file__ = str(HERE / "runtime_response_live_controller.py")
    exec(compile(Path(value.__file__).read_bytes(), value.__file__, "exec"), value.__dict__)
    return value


def opt(c):
    return types.SimpleNamespace(source_commit=c.SOURCE_COMMIT, run_id="inert-consumer",
                                 producer_run_id="inert-producer", version_run_id="inert-version")


class Pin:
    def __init__(self, data=b"", record=None):
        self.data = data
        self.value = {} if record is None else record
        self.fail = False
        self.closed = False

    def bytes(self):
        return self.data

    def record(self):
        return copy.deepcopy(self.value)

    def recheck(self):
        if self.fail:
            raise RuntimeError("owned late pin refusal")
        return self.record()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        try:
            self.recheck()
        finally:
            self.closed = True


def record(path, data, inode=1):
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "fileIdentity": [1, inode],
            "bytes": len(data), "mtimeNs": 1, "links": 1, "noReparseAncestors": True,
            "writersAndDeletionDeniedThroughRecheck": True}


def replay_fixture(c):
    # Only these two pure source modules are loaded; no runtime/API/image loader.
    p = c.load_source(c.TRANSACTION / "transaction_protocol.py",
                      c.TRANSACTION_PINS["transaction_protocol.py"], "inert_lld_protocol")
    h = c.load_source(c.HISTORY / "history_transaction_controller.py",
                      c.HISTORY_PINS["history_transaction_controller.py"], "inert_pure_version_helpers")
    root = b"[profile.release]\nlto='thin'\ncodegen-units=1\nstrip='symbols'\n"
    native = b"[package]\nname='owned'\nversion='0.0.0'\n"
    root_record, native_record = record(c.ROOT / "Cargo.toml", root), record(c.ROOT / "native/Cargo.toml", native, 2)
    tool = {"path": str(p.LINKER), "metadata": {"exists": True, "device": 1, "inode": 3,
            "bytes": p.LINKER_BYTES, "mtimeNs": 1, "links": 1, "mode": stat.S_IFREG | 0o755, "attributes": 0},
            "handleMode": stat.S_IFREG | 0o666, "handleAttributes": None,
            "ancestors": [{"path": str(path), "exists": True, "device": 1, "inode": index + 10,
                           "mode": stat.S_IFDIR | 0o755, "attributes": 0}
                          for index, path in enumerate(reversed(p.LINKER.parents))],
            "imageBytesRead": False, "imageExecuted": False,
            "desiredAccess": "FILE_EXECUTE|FILE_READ_ATTRIBUTES (no FILE_READ_DATA)",
            "fileWritesDenied": True, "heldPathDeletionDenied": True, "allAliasNamespaceDenialClaimed": False}
    root_pin, native_pin, tool_pin = Pin(root, root_record), Pin(native, native_record), Pin(record=tool)
    guard = p.BuildInputsGuard(root_pin, native_pin, tool_pin)
    sources = {"Cargo.toml": {"sha256": root_record["sha256"], "bytes": len(root)},
               "native/Cargo.toml": {"sha256": native_record["sha256"], "bytes": len(native)}}
    maps = {"original": {}, "transaction": {}}
    options = opt(c)
    image = record(p.image_path(options.producer_run_id), b"owned-inert-image-record")
    receipts = {name: Pin() for name in p.PRODUCER_FILES}
    receipts["held-build-inputs"] = guard
    admitted = {"image": p.image_path(options.producer_run_id), "imagePin": Pin(record=image),
                "receiptPins": receipts, "record": image, "protectedPins": {}, "protectedBefore": {},
                "artifact": {"fixture": "selected-final-bin"}}
    stdout, stderr = b"yoke 0.5.0\r\n", b""
    job = {key: None for key in p.OUTER_KEYS}
    request = p.request_record("version", options.version_run_id, options.source_commit,
                               options.producer_run_id, sources, maps["original"], maps["transaction"])
    job.update(command=request["command"], deadlineSeconds=30, logCapBytes=p.MAX_LOG,
               stdinClosed=True, startedSuspended=True, assignedBeforeResume=True, completed=True,
               treeExitedBeforeCleanup=True, minimumFreeObserved=p.START_FREE, cleanupErrors=[],
               streamEOF=[True, True], readerErrors=[False, False], startedMonotonicNs=1000000000,
               absoluteDeadlineNs=31000000000, jobName=None, namedJobCreatedNew=False, pid=100,
               resumePreviousSuspendCount=1, exitCode=0, rootObservedMonotonicNs=2000000000,
               membersAtRootObservation=[], rootExitedAtObservation=True, activeAtRootObservation=0,
               originalDrainSeconds=1, activeBeforeCleanup=0, membersAfterOriginalDrain=[],
               treeObservedMonotonicNs=2000000001, cleanupSeconds=2, activeAfterCleanup=0,
               rootExitedAfterCleanup=True, elapsedSeconds=1.1, capturedLogBytes=len(stdout),
               outputExceeded=False, cleanupUnproven=False)
    result = {key: None for key in p.RESULT_KEYS}
    result.update(owner=p.OWNER, schema=3, mode="version", runId=options.version_run_id,
                  sourceCommit=options.source_commit, completed=True, inputsUnchanged=True,
                  protectedMetadataUnchanged=True, nativeImageReadAttempted=True, nativeImageRead=True,
                  selectedImage=image, selectedArtifact=admitted["artifact"], observedVersion="yoke 0.5.0",
                  errorCode=None, releaseQualification=False, vsixQualification=False,
                  qualification="compiler-transaction/version-only", freeAfter=p.START_FREE)
    values = {"request.json": request, "result.json": result, "outer.job.json": job,
              "selected-image.json": image, "selected-image-after.json": copy.deepcopy(image)}
    for stem, mapping in (("source", sources), ("original-control", maps["original"]),
                          ("transaction-control", maps["transaction"]), ("protected", {})):
        for phase in ("before", "after", "final"):
            values[stem + "-" + phase + ".json"] = copy.deepcopy(mapping)
    for phase in ("before", "after", "final"):
        values["build-inputs-" + phase + ".json"] = guard.recheck()
    return p, h, options, sources, maps, admitted, values, stdout, stderr, (root_pin, native_pin, tool_pin)


def case_spec(c, index=0):
    return {"owner": c.OWNER, "schema": 1, "sourceCommit": c.SOURCE_COMMIT,
            "runId": "inert-consumer", "producerRunId": "inert-producer", "versionRunId": "inert-version",
            "caseIndex": index, "fixture": str(Path(c.ROOT.anchor) / "Temp" / ("yr-" + "a" * 16)),
            "caseDirectory": str(c.PRIVATE / "inert-consumer" / ("case-" + str(index))),
            "native": str(c.native_image_path("inert-producer")), "python": str(c.PYTHON),
            "jobName": "Local\\YokeCompilerLLD-" + "b" * 64, "startedNs": 1000000000,
            "deadlineNs": 21000000000, "recipeDeadlineNs": 181000000000}


def case_job(c, p, spec, stdout=b"", stderr=b""):
    row = {key: None for key in p.OUTER_KEYS}
    expected = c.case_plan(spec["caseIndex"])["exit"]
    command = [str(c.PYTHON), "-I", "-B", str(c.CONTROL / "runtime_response_live_worker.py"), "owned-spec.json"]
    row.update(command=command, deadlineSeconds=20, logCapBytes=c.BUDGETS["logBytes"],
               stdinClosed=True, startedSuspended=True, assignedBeforeResume=True, completed=expected == 0,
               treeExitedBeforeCleanup=True, minimumFreeObserved=c.BUDGETS["startBytes"], cleanupErrors=[],
               streamEOF=[True, True], readerErrors=[False, False], startedMonotonicNs=1000000001,
               absoluteDeadlineNs=spec["deadlineNs"], jobName=spec["jobName"], namedJobCreatedNew=True,
               pid=101, resumePreviousSuspendCount=1, exitCode=expected, rootObservedMonotonicNs=2000000000,
               membersAtRootObservation=[], rootExitedAtObservation=True, activeAtRootObservation=0,
               originalDrainSeconds=1, activeBeforeCleanup=0, membersAfterOriginalDrain=[],
               treeObservedMonotonicNs=2000000001, cleanupSeconds=2, activeAfterCleanup=0,
               rootExitedAfterCleanup=True, elapsedSeconds=1.1, capturedLogBytes=len(stdout) + len(stderr),
               outputExceeded=False, cleanupUnproven=False)
    return command, row


class SelectorAndManifestTests(unittest.TestCase):
    def test_only_current_commit_and_distinct_closed_selectors_are_accepted(self):
        c = policy()
        args = ["--source-commit", c.SOURCE_COMMIT, "--run-id", "owned", "--producer-run-id", "producer",
                "--version-run-id", "version"]
        self.assertEqual(c.options(args).source_commit, c.SOURCE_COMMIT)
        for changed in (args[:1] + ["e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e"] + args[2:],
                        args[:1] + ["809bac07e1074a198a1f81448fc97f7ee2f97fe7"] + args[2:],
                        args + ["--python", "foreign.exe"], args + ["--case", "0"], args[:-1] + ["producer"]):
            with self.subTest(args=changed), self.assertRaises(c.Refusal):
                c.options(changed)

    def test_bad_helper_selectors_refuse_before_producer_or_image_access(self):
        c = policy()
        producer = mock.Mock(side_effect=AssertionError("producer must remain uncalled"))
        p = types.SimpleNamespace(producer_admission=producer)
        for key, value in (("source_commit", "e" * 40), ("version_run_id", "../foreign"),
                           ("producer_run_id", "inert-version")):
            options = opt(c)
            setattr(options, key, value)
            with self.subTest(key=key), self.assertRaises(c.Refusal), ExitStack() as stack:
                c.admit_pair(p, {}, None, {}, None, stack, options, {}, {}, {})
            producer.assert_not_called()

    def test_manifest_closes_every_source_budget_and_case_digest(self):
        c = policy()
        own = {name: {"sha256": "a" * 64, "bytes": 1} for name in c.CONTROL_NAMES}
        value = {"owner": c.OWNER, "schema": 1, "sourceCommit": c.SOURCE_COMMIT,
                 "scope": "six-runtime-response-cases",
                 "consumerSources": {name: "a" * 64 for name in c.CONTROL_NAMES if name != "review-manifest.json"},
                 "transactionSources": c.TRANSACTION_PINS, "originalSources": c.ORIGINAL_PINS,
                 "historyHelperSources": c.HISTORY_PINS, "fixtureSources": c.FIXTURE_PINS,
                 "budgets": c.BUDGETS, "casesDigest": hashlib.sha256(c.encoded(c.CASES)).hexdigest()}
        c.validate_manifest(value, own)
        for key, replacement in (("extra", True), ("schema", True), ("sourceCommit", "e" * 40),
                                 ("casesDigest", "0" * 64), ("budgets", {**c.BUDGETS, "soleAbortSeconds": 3})):
            changed = copy.deepcopy(value)
            changed[key] = replacement
            with self.subTest(key=key), self.assertRaises(c.Refusal):
                c.validate_manifest(changed, own)

    def test_case_data_is_fixed_copied_and_only_owned_negative_cases_have_evaluation_authority(self):
        c = policy()
        cases = [c.case_plan(index) for index in range(6)]
        self.assertEqual([case["evaluation"] for case in cases], [False, False, True, False, False, True])
        self.assertEqual([case["exit"] for case in cases], [0, 0, 1, 0, 0, 1])
        cases[0]["requests"].append({"command": "continue"})
        self.assertEqual(c.case_plan(0)["requests"], [])
        for bad in (-1, 6, True, "0"):
            with self.subTest(index=bad), self.assertRaises(c.Refusal):
                c.case_plan(bad)

    def test_fixed_commands_preserve_inner_timeout_and_explicit_grants(self):
        c = policy()
        with mock.patch.object(c, "ordinary", return_value=None):
            for index in range(6):
                command = c.native_command(case_spec(c, index))
                self.assertIn("--trust-runtime", command)
                self.assertEqual(command[command.index("--timeout") + 1], "10000")
                self.assertEqual(command.count("--allow-evaluation"), int(index in (2, 5)))
                self.assertEqual(command[0], str(c.native_image_path("inert-producer")))
                self.assertEqual(command[command.index("--python") + 1], str(c.PYTHON))
            for key, value in (("native", "C:\\foreign.exe"), ("python", "C:\\foreign.exe"),
                               ("caseIndex", True), ("jobName", "Local\\foreign"), ("deadlineNs", 30000000000)):
                changed = case_spec(c)
                changed[key] = value
                with self.subTest(key=key), self.assertRaises(c.Refusal):
                    c.validate_spec(changed)


class ProducerAndVersionTests(unittest.TestCase):
    def test_pair_admission_forwards_exact_current_inputs_and_rechecks_both_receipt_sets(self):
        c = policy()
        p, h, options, sources, maps, admitted, _, _, _, _ = replay_fixture(c)
        original = {"checked_protected": lambda before, after: c.need(before == after, "protected")}
        version = {"owned-version": Pin(record={"receipt": True})}
        before = c.pin_snapshot(version)
        result = c.initial_result(options)
        def producer(g, api, raw_original, stack, run_id, commit, selected, originals, transactions, **kwargs):
            self.assertIs(raw_original, original)
            self.assertEqual((run_id, commit), (options.producer_run_id, c.SOURCE_COMMIT))
            self.assertEqual((selected, originals, transactions), (sources, maps["original"], maps["transaction"]))
            kwargs["on_image_attempt"]()
            return admitted
        with mock.patch.object(p, "producer_admission", side_effect=producer) as called, \
             mock.patch.object(c, "version_receipts", return_value=(version, before)) as version_call, ExitStack() as stack:
            got, pins, snapshot = c.admit_pair(p, {}, None, original, h, stack, options, sources, maps, result)
            self.assertIs(got, admitted)
            self.assertIs(pins, version)
            self.assertEqual(snapshot, before)
            called.assert_called_once()
            version_call.assert_called_once()
        self.assertTrue(result["nativeImageReadAttempted"])
        self.assertTrue(result["nativeImageRead"])

    def test_complete_pure_version_replay_accepts_current_commit_without_changing_history_globals(self):
        c = policy()
        p, h, options, sources, maps, admitted, values, stdout, stderr, _ = replay_fixture(c)
        original_commit = h.SOURCE_COMMIT
        h.validate_version(p, options, sources, maps["original"], maps["transaction"], admitted, values, stdout, stderr)
        self.assertEqual(options.source_commit, c.SOURCE_COMMIT)
        self.assertEqual(h.SOURCE_COMMIT, original_commit)
        self.assertNotEqual(h.SOURCE_COMMIT, options.source_commit)
        self.assertEqual(len(c.VERSION_FILES), 22)
        self.assertEqual(len(p.PRODUCER_FILES), 27)
        self.assertIs(c.held_inputs(p, admitted), admitted["receiptPins"]["held-build-inputs"])

    def test_missing_guard_wrong_guard_and_missing_producer_proofs_refuse(self):
        c = policy()
        p, _, _, _, _, admitted, _, _, _, _ = replay_fixture(c)
        for missing in ("held-build-inputs", *p.PRODUCER_FILES):
            pins = dict(admitted["receiptPins"])
            del pins[missing]
            with self.subTest(missing=missing), self.assertRaises(c.Refusal):
                c.held_inputs(p, {**admitted, "receiptPins": pins})
        pins = {**admitted["receiptPins"], "held-build-inputs": Pin()}
        with self.assertRaises(c.Refusal):
            c.held_inputs(p, {**admitted, "receiptPins": pins})

    def test_current_source_version_image_and_input_proof_drift_refuse(self):
        c = policy()
        p, h, options, sources, maps, admitted, values, stdout, stderr, _ = replay_fixture(c)
        mutations = [
            ("result.json", "sourceCommit", "e" * 40), ("result.json", "completed", False),
            ("result.json", "releaseQualification", True), ("selected-image-after.json", "sha256", "0" * 64),
            ("build-inputs-final.json", "linkerFlavor", "foreign"),
        ]
        for name, key, value in mutations:
            changed = copy.deepcopy(values)
            changed[name][key] = value
            with self.subTest(name=name, key=key), self.assertRaises(Exception):
                h.validate_version(p, options, sources, maps["original"], maps["transaction"], admitted,
                                   changed, stdout, stderr)
        for missing in (name for name in c.VERSION_FILES if name.endswith(".json")):
            changed = copy.deepcopy(values)
            del changed[missing]
            with self.subTest(missing=missing), self.assertRaises(h.Refusal):
                h.validate_version(p, options, sources, maps["original"], maps["transaction"], admitted,
                                   changed, stdout, stderr)

    def test_version_pins_all_22_receipts_and_retains_them_in_the_parent_stack(self):
        c = policy()
        p, h, options, sources, maps, admitted, values, stdout, stderr, _ = replay_fixture(c)
        data = {name: c.encoded(value) for name, value in values.items()}
        data.update({"outer.stdout": stdout, "outer.stderr": stderr})
        opened = {}
        def read_pin(api, path, maximum):
            pin = Pin(data[path.name], {"name": path.name, "bytes": len(data[path.name])})
            opened[path.name] = pin
            return pin
        with mock.patch.object(c, "ordinary", return_value=types.SimpleNamespace(st_size=1)), ExitStack() as stack:
            pins, before = c.version_receipts(p, {"ReadPin": read_pin}, None, stack, options,
                                              sources, maps, admitted, h)
            self.assertEqual(set(pins), set(c.VERSION_FILES))
            self.assertTrue(all(not pin.closed for pin in pins.values()))
            c.recheck_snapshot(pins, before)
        self.assertTrue(all(pin.closed for pin in opened.values()))

    def test_late_build_guard_or_version_pin_failure_propagates(self):
        c = policy()
        p, h, _, _, _, admitted, _, _, _, input_pins = replay_fixture(c)
        original = {"checked_protected": lambda before, after: c.need(before == after, "protected")}
        version = {"owned": Pin(record={"owned": True})}
        before = c.pin_snapshot(version)
        h.recheck_pair(p, original, admitted, version, before)
        for pin in (input_pins[0], version["owned"]):
            pin.fail = True
            with self.subTest(pin=pin), self.assertRaises(RuntimeError):
                h.recheck_pair(p, original, admitted, version, before)
            pin.fail = False

    def test_python_context_closure_never_swallows_late_failure_or_leaks_its_handle(self):
        c = policy()
        pin = object.__new__(c.PythonMetadataPin)
        pin.fd = 123
        with mock.patch.object(pin, "recheck", side_effect=c.Refusal("python-drift")), \
             mock.patch.object(c.os, "close") as close:
            with self.assertRaises(c.Refusal):
                pin.__exit__(None, None, None)
            close.assert_called_once_with(123)
        self.assertIsNone(pin.fd)

    def test_python_metadata_keeps_both_modes_and_refuses_identity_or_route_drift(self):
        c = policy()
        pin = object.__new__(c.PythonMetadataPin)
        pin.fd = 123
        pin.ancestors = []
        pin.observe_ancestors = lambda _: []
        path = types.SimpleNamespace(st_dev=1, st_ino=2, st_size=100000, st_mtime_ns=1,
                                     st_nlink=1, st_mode=stat.S_IFREG | 0o755, st_file_attributes=0)
        held = types.SimpleNamespace(st_dev=1, st_ino=2, st_size=100000, st_mtime_ns=1,
                                     st_nlink=1, st_mode=stat.S_IFREG | 0o666)
        with mock.patch.object(c, "ordinary", return_value=path), \
             mock.patch.object(c.os, "fstat", return_value=held):
            pin.initial = pin.observe()
            self.assertEqual(pin.recheck()["pathMode"], path.st_mode)
            self.assertEqual(pin.recheck()["handleMode"], held.st_mode)
            held.st_size += 1
            with self.assertRaises(c.Refusal):
                pin.recheck()
            held.st_size -= 1
            pin.observe_ancestors = lambda _: [{"changed": True}]
            with self.assertRaises(c.Refusal):
                pin.recheck()
        pin.fd = None


class CaseOutputAndLifecycleTests(unittest.TestCase):
    def test_expected_exit_one_is_accepted_only_with_its_unchanged_failed_raw_row(self):
        c = policy()
        p = c.load_source(c.TRANSACTION / "transaction_protocol.py",
                          c.TRANSACTION_PINS["transaction_protocol.py"], "inert_job_schema")
        spec = case_spec(c, 2)
        stderr = b"yoke: Runtime session batch shutdown was not confirmed\n"
        command, row = case_job(c, p, spec, stderr=stderr)
        before = copy.deepcopy(row)
        c.validate_case_job(p, row, command, spec, b"", stderr)
        summary = c.validate_case_payload(2, b"", stderr)
        self.assertEqual(row, before)
        self.assertEqual(row["exitCode"], 1)
        self.assertIs(row["completed"], False)
        self.assertIs(summary["expectedFailureObserved"], True)
        self.assertNotIn("rawJobCompleted", summary)
        self.assertNotIn("rawExitCode", summary)

    def test_forced_cleanup_missing_streams_and_missing_root_receipt_never_qualify_negative(self):
        c = policy()
        p = c.load_source(c.TRANSACTION / "transaction_protocol.py",
                          c.TRANSACTION_PINS["transaction_protocol.py"], "inert_job_schema")
        spec = case_spec(c, 2)
        command, row = case_job(c, p, spec)
        for key, value in (("completed", True), ("exitCode", 0), ("treeExitedBeforeCleanup", False),
                           ("activeBeforeCleanup", 1), ("rootExitedAtObservation", False),
                           ("streamEOF", [True, False]), ("cleanupUnproven", True),
                           ("namedJobCreatedNew", False), ("cleanupSeconds", 3),
                           ("absoluteDeadlineNs", spec["deadlineNs"] + 1)):
            changed = copy.deepcopy(row)
            changed[key] = value
            with self.subTest(key=key), self.assertRaises(c.Refusal):
                c.validate_case_job(p, changed, command, spec, b"", b"")

    def test_original_positive_event_counts_status_and_completion_assertions_are_preserved(self):
        c = policy()
        for index in (0, 1, 3, 4):
            case = c.case_plan(index)
            events = [{"status": "paused"} for _ in range(case["events"])]
            if case["terminal"]:
                events[-1] = {"status": case["terminal"], "programCompleted": case["terminal"] == "finished"}
            c.validate_case_payload(index, c.encoded({"events": events}), b"")
            with self.subTest(index=index), self.assertRaises(c.Refusal):
                c.validate_case_payload(index, c.encoded({"events": events + [{"status": "closed"}]}), b"")
            changed = copy.deepcopy(events)
            changed[-1]["status"] = "foreign"
            with self.subTest(index=index, mutation="status"), self.assertRaises(c.Refusal):
                c.validate_case_payload(index, c.encoded({"events": changed}), b"")

    def test_negative_requires_empty_stdout_and_the_actual_shutdown_refusal(self):
        c = policy()
        for stdout, stderr in ((b"{}", b"shutdown was not confirmed"), (b"", b"ordinary failure"),
                               (b"partial", b"shutdown was not confirmed")):
            with self.subTest(stdout=stdout), self.assertRaises(c.Refusal):
                c.validate_case_payload(2, stdout, stderr)

    def test_complete_but_nonclosed_reply_requires_both_specific_refusal_observations(self):
        c = policy()
        complete = b"shutdown was not confirmed: Close response did not confirm closed state"
        self.assertTrue(c.validate_case_payload(5, b"", complete)["expectedFailureObserved"])
        for raw in (b"ordinary failure", b"shutdown was not confirmed", b"Close response did not confirm closed state"):
            with self.subTest(stderr=raw), self.assertRaises(c.Refusal):
                c.validate_case_payload(5, b"", raw)

    def test_stream_caps_unknown_fields_and_boolean_counters_refuse(self):
        c = policy()
        p = c.load_source(c.TRANSACTION / "transaction_protocol.py",
                          c.TRANSACTION_PINS["transaction_protocol.py"], "inert_job_schema")
        spec = case_spec(c)
        command, row = case_job(c, p, spec)
        for change in ({"unknown": True}, {"pid": True}, {"capturedLogBytes": True},
                       {"streamEOF": [1, 1]}, {"readerErrors": [0, 0]}):
            with self.subTest(change=change), self.assertRaises(c.Refusal):
                c.validate_case_job(p, {**row, **change}, command, spec, b"", b"")
        oversized = b"x" * (c.BUDGETS["stdoutBytes"] + 1)
        row["capturedLogBytes"] = len(oversized)
        with self.assertRaises(c.Refusal):
            c.validate_case_job(p, row, command, spec, oversized, b"")

    def test_worker_membership_and_cli_command_receipt_are_required(self):
        c = policy()
        spec = case_spec(c)
        with mock.patch.object(c, "ordinary", return_value=None):
            command = c.native_command(spec)
            row = {"owner": c.OWNER, "schema": 1, "sourceCommit": c.SOURCE_COMMIT, "runId": spec["runId"],
                   "caseIndex": 0, "command": command, "cwd": str(Path(spec["fixture"]) / "s"),
                   "exitCode": 0, "startedNs": 1500000000, "finishedNs": 1600000000,
                   "workerInJobBeforeCLI": True, "stdinClosed": True,
                   "sourceUnchanged": True, "requestsUnchanged": True}
            job = {"startedMonotonicNs": 1000000001, "rootObservedMonotonicNs": 2000000000}
            c.validate_child(row, spec, job)
            for key, value in (("workerInJobBeforeCLI", False), ("sourceUnchanged", False),
                               ("command", ["foreign"]), ("exitCode", 1), ("finishedNs", spec["deadlineNs"])):
                with self.subTest(key=key), self.assertRaises(c.Refusal):
                    c.validate_child({**row, **{key: value}}, spec, job)


class SourceAndBudgetTests(unittest.TestCase):
    def test_occupied_and_reparse_roles_preserve_foreign_bytes_before_read(self):
        c = policy()
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            target = root / "occupied.txt"
            target.write_bytes(b"owned foreign occupant")
            occupied = root / "occupied"
            occupied.write_bytes(b"owned occupied role")
            with self.assertRaises(c.Refusal):
                c.fresh_directory(root, "occupied")
            original_lstat = Path.lstat
            def lstat(path):
                info = original_lstat(path)
                if path == target:
                    return types.SimpleNamespace(st_mode=info.st_mode, st_file_attributes=0x400,
                                                 st_nlink=info.st_nlink, st_ino=info.st_ino)
                return info
            with mock.patch.object(Path, "lstat", lstat), mock.patch.object(Path, "read_bytes") as read:
                with self.assertRaises(c.Refusal):
                    c.source_bytes(target)
                read.assert_not_called()
            self.assertEqual(target.read_bytes(), b"owned foreign occupant")
            self.assertEqual(occupied.read_bytes(), b"owned occupied role")

    def test_recipe_clock_is_absolute_and_not_refreshed(self):
        c = policy()
        now = [1000]
        with mock.patch.object(c.shutil, "disk_usage", return_value=types.SimpleNamespace(free=2000000000)):
            budget = c.Budget(clock=lambda: now[0])
            end = budget.end_ns
            now[0] = end - 1
            budget.check()
            self.assertEqual(budget.end_ns, end)
            now[0] = end
            with self.assertRaises(c.Refusal):
                budget.check()

    def test_environment_or_wrong_head_refuses_before_source_or_image_observation(self):
        c = policy()
        for wrong_environment in (True, False):
            with self.subTest(environment=wrong_environment), tempfile.TemporaryDirectory() as temporary:
                out = Path(temporary).resolve()
                observed = mock.Mock(side_effect=AssertionError("source bytes must remain unread"))
                def owned(api, extended, folder, label, command, env, seconds, **kwargs):
                    (folder / (label + ".stdout")).write_bytes(b"e" * 40 + b"\n")
                    return {"completed": True, "exitCode": 0, "treeExitedBeforeCleanup": True,
                            "activeBeforeCleanup": 0, "activeAfterCleanup": 0,
                            "rootExitedAfterCleanup": True, "cleanupUnproven": False}
                runner = mock.Mock(side_effect=owned)
                g = {"environment_for": mock.Mock(return_value={} if wrong_environment else {"PATH": "owned"}),
                     "run_owned": runner, "source_digest": observed}
                with mock.patch.object(c.shutil, "which", return_value=str(c.ROOT / "owned-git.exe")), \
                     self.assertRaises(c.Refusal):
                    c.observe_sources(None, g, None, None, out, {"PATH": "owned"}, opt(c), "before",
                                      types.SimpleNamespace(check=lambda: None, end_ns=10**18))
                observed.assert_not_called()
                self.assertEqual(runner.call_count, 0 if wrong_environment else 1)

    def test_late_configuration_refusal_prevents_every_source_phase_publication(self):
        c = policy()
        names = ["Cargo.toml", "Cargo.lock", "native/Cargo.toml", "scripts/host_powershell_probe.py",
                 "scripts/run_native_tests.py", "scripts/ci_windows_temp.py", "scripts/native_shards.py",
                 ".github/workflows/rust.yml", "native/tests/workflow_cli.rs"]
        for phase in ("before", "after", "final"):
            with self.subTest(phase=phase), tempfile.TemporaryDirectory() as temporary:
                out = Path(temporary).resolve()
                foreign = out / "owned-config.toml"
                foreign.write_bytes(b"[build]\njobs=1\n")
                def owned(api, extended, folder, label, command, env, seconds, **kwargs):
                    data = c.SOURCE_COMMIT.encode() if "git-head" in label else b"" if "git-status" in label else "\0".join(names).encode() + b"\0"
                    (folder / (label + ".stdout")).write_bytes(data)
                    return {"completed": True, "exitCode": 0, "treeExitedBeforeCleanup": True,
                            "activeBeforeCleanup": 0, "activeAfterCleanup": 0,
                            "rootExitedAfterCleanup": True, "cleanupUnproven": False}
                environment = {"PATH": "owned"}
                g = {"environment_for": mock.Mock(side_effect=[environment, c.Refusal("environment-drift")]),
                     "run_owned": owned, "MAX_SOURCE_FILES": 10000, "MAX_SOURCE_BYTES": 512000000,
                     "source_digest": lambda path: {"bytes": 1, "sha256": c.FIXTURE_PINS.get(path.relative_to(c.ROOT).as_posix(), "a" * 64)}}
                with mock.patch.object(c.shutil, "which", return_value=str(c.ROOT / "owned-git.exe")), \
                     self.assertRaises(c.Refusal):
                    c.observe_sources(None, g, None, None, out, environment, opt(c), phase,
                                      types.SimpleNamespace(check=lambda: None, end_ns=10**18))
                self.assertFalse((out / ("source-" + phase + ".json")).exists())
                self.assertEqual(foreign.read_bytes(), b"[build]\njobs=1\n")

    def test_duplicate_json_and_nonfinite_numbers_are_not_admitted(self):
        c = policy()
        for raw in (b'{"x":1,"x":2}', b'{"x":NaN}', b'\xff', b"{" * 2000):
            with self.subTest(raw=raw[:20]), self.assertRaises(c.Refusal):
                c.unique_json(raw)


if __name__ == "__main__":
    unittest.main()
