"""Closed actual runtime CLI response consumer. Importing starts nothing."""
import argparse
from contextlib import ExitStack
import ctypes as c
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import time
import types

ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
BASE = ROOT / "validation/integration-20261025/platform-repairs"
CONTROL = BASE / "control-runtime-response-live-704"
TRANSACTION = BASE / "control-compiler-lld"
ORIGINAL = BASE / "control-cli"
HISTORY = BASE / "control-history-lld-e89"
RUNS = BASE / "runs-runtime-response-live-704"
PRIVATE = BASE / "private-runtime-response-live-704"
OWNER = "local-runtime-response-live-v1"
SCHEMA = 1
SOURCE_COMMIT = "704b647d625dcc5f359386b20834d329ffb6cdf4"
PYTHON = Path(r"C:\Python314\python.exe")
CONTROL_NAMES = ("runtime_response_live_controller.py", "runtime_response_live_worker.py",
                 "test_runtime_response_live.py", "README.md", "review-manifest.json", ".gitattributes")
TRANSACTION_PINS = {'compiler_transaction_controller.py': 'd6ab4fe93432a74a769e9abcdddcef40e87ef274e98fea498a219d95c2c9f29d', 'compiler_transaction_worker.py': 'cf24492dafb4c30ce057a0885c5021339fc76fa3dba1e1efdddaf111fa1285fb', 'transaction_protocol.py': 'eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a', 'transaction_runtime.py': '1608c69131ab3374812496ee9ff855e2c906ac172d31f9899331aa33f2e98de8', 'private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'test_compiler_transaction.py': 'da422d730d3db84b4967fe422d8b8106ed5bb2faac05fa95b012ec5c5ee4bed9', 'review-manifest.json': '141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9', 'README.md': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0', '.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'runtime-fork.patch': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6', 'v2-fork.patch': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5'}
ORIGINAL_PINS = {'cli_controller.py': 'd6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582', 'base_controller.py': 'a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7', 'private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'test_metadata_pin.py': '6f555a7b29a85f17c404cba57474c682ae84adf28915ac8b1f10db73b9041aca', 'README.md': '1bbe94b3ac00dff9d1116ab8ccc8aadce545b14dd536888644d1cb92eac3cea6', 'review-manifest.json': '8dd48b1595220464fc638d458a6f8dd7b19f55454c35c0bda7eb7cea255b94f8', '.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9'}
HISTORY_PINS = {'history_transaction_controller.py': 'c86f8117d37557ad3daf08e6bd1ee1b15a48c7d85e33bb16e09e4954a1933487'}
FIXTURE_PINS = {'native/tests/workflow_cli.rs': '76aff7d9fde0de4e9a94ea84b70deac33c5df8a0d036a8aa6d806f23875e9149'}
BUDGETS = {"recipeSeconds": 180, "caseSeconds": 20, "cliTimeoutMs": 10000,
           "naturalDrainSeconds": 1, "soleAbortSeconds": 2, "gitSeconds": 30,
           "startBytes": 1200000000, "reserveBytes": 500000000,
           "stdoutBytes": 1000000, "stderrBytes": 128000, "logBytes": 1128000,
           "jsonBytes": 1000000, "specBytes": 64000, "treeBytes": 32000000,
           "treeEntries": 1024, "fixtureUtf16Units": 70}
VERSION_FILES = ("request.json", "result.json", "outer.job.json", "outer.stdout", "outer.stderr",
                 "source-before.json", "source-after.json", "source-final.json",
                 "original-control-before.json", "original-control-after.json", "original-control-final.json",
                 "transaction-control-before.json", "transaction-control-after.json", "transaction-control-final.json",
                 "protected-before.json", "protected-after.json", "protected-final.json",
                 "selected-image.json", "selected-image-after.json",
                 "build-inputs-before.json", "build-inputs-after.json", "build-inputs-final.json")
INSTALL = "import sys\n_owned_worker = sys.modules['__main__']\n_owned_emit = _owned_worker.emit\ndef _owned_refuse_closed(event, data):\n if event == 'closed':\n  raise _owned_worker.WorkerFailure('owned close refusal')\n return _owned_emit(event, data)\n_owned_worker.emit = _owned_refuse_closed\n"
FALSE_CLOSE = "import sys\n_owned_worker = sys.modules['__main__']\n_owned_emit = _owned_worker.emit\ndef _owned_nonclosed(event, data):\n if event == 'closed':\n  return _owned_emit('paused', {'status': 'paused', 'frames': []})\n return _owned_emit(event, data)\n_owned_worker.emit = _owned_nonclosed\n"
CASES = (
    {"name": "empty-paused", "source": "raise RuntimeError('owned paused payload must remain inert')\n",
     "requests": [], "evaluation": False, "exit": 0, "events": 1, "terminal": None},
    {"name": "stack-paused", "source": "raise RuntimeError('owned paused payload must remain inert')\n",
     "requests": [{"command": "stack"}], "evaluation": False, "exit": 0, "events": 2, "terminal": None},
    {"name": "close-refusal", "source": "value = 1\n",
     "requests": [{"command": "repl", "code": INSTALL, "frame": 0}], "evaluation": True,
     "exit": 1, "events": 0, "terminal": None},
    {"name": "terminal-continue", "source": "print('owned terminal response')\n",
     "requests": [{"command": "continue"}], "evaluation": False, "exit": 0, "events": 2,
     "terminal": "finished"},
    {"name": "explicit-close", "source": "print('owned terminal response')\n",
     "requests": [{"command": "close"}], "evaluation": False, "exit": 0, "events": 2,
     "terminal": "closed"},
    {"name": "false-close", "source": "value = 1\n",
     "requests": [{"command": "repl", "code": FALSE_CLOSE, "frame": 0}], "evaluation": True,
     "exit": 1, "events": 0, "terminal": None},
)
SPEC_KEYS = {"owner", "schema", "sourceCommit", "runId", "producerRunId", "versionRunId",
             "caseIndex", "fixture", "caseDirectory", "native", "python", "jobName",
             "startedNs", "deadlineNs", "recipeDeadlineNs"}
CHILD_KEYS = {"owner", "schema", "sourceCommit", "runId", "caseIndex", "command", "cwd",
              "exitCode", "startedNs", "finishedNs", "workerInJobBeforeCLI", "stdinClosed",
              "sourceUnchanged", "requestsUnchanged"}


class Refusal(RuntimeError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def need(value, code):
    if not value:
        raise Refusal(code)


def closed(value, keys, code):
    need(type(value) is dict and set(value) == set(keys), code)


def integer(value, minimum=0, maximum=(1 << 63) - 1):
    return type(value) is int and minimum <= value <= maximum


def run_name(value):
    need(type(value) is str and re.fullmatch(r"[a-z][a-z0-9-]{0,95}", value), "arguments")
    return value


def ordinary(path, directory=False):
    path = Path(path)
    need(path.is_absolute() and os.path.normpath(str(path)) == str(path), "path")
    for ancestor in reversed(path.parents):
        info = ancestor.lstat()
        need(stat.S_ISDIR(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400, "path")
    info = path.lstat()
    need(not getattr(info, "st_file_attributes", 0) & 0x400
         and (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)), "path")
    if not directory:
        need(info.st_nlink == 1 and info.st_ino > 0, "path")
    return info


def source_bytes(path, maximum=1000000):
    need(path.suffix.lower() not in (".exe", ".pdb", ".dll", ".lib", ".obj", ".o"), "source-role")
    before = ordinary(path)
    need(before.st_size <= maximum, "budget")
    data = path.read_bytes()
    after = ordinary(path)
    need(len(data) == before.st_size <= maximum and identity(before) == identity(after), "source-drift")
    return data


def identity(info):
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_nlink)


def unique_json(data, maximum=1000000):
    need(type(data) is bytes and len(data) <= maximum, "json")
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "json")
            result[key] = value
        return result
    try:
        return json.loads(data.decode("utf-8", "strict"), object_pairs_hook=pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(Refusal("json")))
    except (ValueError, UnicodeError, RecursionError):
        raise Refusal("json") from None


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode("utf-8")


def write_json(path, value, maximum=1000000):
    data = encoded(value) + b"\n"
    need(len(data) <= maximum, "budget")
    ordinary(path.parent, directory=True)
    with path.open("xb") as stream:
        stream.write(data)


class Budget:
    def __init__(self, clock=time.monotonic_ns):
        self.clock = clock
        self.started_ns = clock()
        self.end_ns = self.started_ns + BUDGETS["recipeSeconds"] * 1000000000

    def check(self):
        need(self.clock() < self.end_ns, "recipe-deadline")
        need(shutil.disk_usage(ROOT).free >= BUDGETS["reserveBytes"], "disk")


class Arguments(argparse.ArgumentParser):
    def error(self, message):
        raise Refusal("arguments")


def options(arguments):
    parser = Arguments(allow_abbrev=False)
    for name in ("source-commit", "run-id", "producer-run-id", "version-run-id"):
        parser.add_argument("--" + name, required=True)
    opt = parser.parse_args(arguments)
    validate_options(opt)
    return opt


def validate_options(opt):
    need(opt.source_commit == SOURCE_COMMIT, "arguments")
    ids = [run_name(value) for value in (opt.run_id, opt.producer_run_id, opt.version_run_id)]
    need(len(set(ids)) == 3, "arguments")


def checked_map(folder, pins):
    rows = {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for name in pins for data in (source_bytes(folder / name),)}
    need(all(rows[name]["sha256"] == digest for name, digest in pins.items()), "control")
    return rows


def own_map():
    return {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for name in CONTROL_NAMES for data in (source_bytes(CONTROL / name),)}


def validate_manifest(value, own):
    closed(value, {"owner", "schema", "sourceCommit", "scope", "consumerSources", "transactionSources",
                   "originalSources", "historyHelperSources", "fixtureSources", "budgets", "casesDigest"}, "manifest")
    need(value["owner"] == OWNER and type(value["schema"]) is int and value["schema"] == SCHEMA
         and value["sourceCommit"] == SOURCE_COMMIT and value["scope"] == "six-runtime-response-cases", "manifest")
    closed(value["consumerSources"], set(CONTROL_NAMES) - {"review-manifest.json"}, "manifest")
    need(set(own) == set(CONTROL_NAMES)
         and all(type(sha) is str and re.fullmatch(r"[0-9a-f]{64}", sha)
                 and own[name]["sha256"] == sha for name, sha in value["consumerSources"].items()), "manifest")
    need(value["transactionSources"] == TRANSACTION_PINS and value["originalSources"] == ORIGINAL_PINS
         and value["historyHelperSources"] == HISTORY_PINS and value["fixtureSources"] == FIXTURE_PINS
         and value["budgets"] == BUDGETS and all(type(x) is int for x in value["budgets"].values())
         and value["casesDigest"] == hashlib.sha256(encoded(CASES)).hexdigest(), "manifest")


def load_source(path, expected, name):
    data = source_bytes(path)
    need(hashlib.sha256(data).hexdigest() == expected, "control")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(data, str(path), "exec"), module.__dict__)
    return module


def load_dependencies():
    compiler = load_source(TRANSACTION / "compiler_transaction_controller.py",
                           TRANSACTION_PINS["compiler_transaction_controller.py"], "runtime_live_compiler")
    p = compiler.protocol()
    g, original = p.load_runtime(), p.load_original()
    h = load_source(HISTORY / "history_transaction_controller.py",
                    HISTORY_PINS["history_transaction_controller.py"], "runtime_live_pure_history_helpers")
    need(p.ROOT == ROOT and p.CONTROL == TRANSACTION and p.RUNS == BASE / "runs-compiler-lld"
         and p.OWNER == "integration-20261026-compiler-lld-v1" and type(p.SCHEMA) is int and p.SCHEMA == 3
         and p.ORIGINAL_PINS == ORIGINAL_PINS and g["ROOT"] == ROOT and original["ROOT"] == ROOT
         and set(g["CONTROL_NAMES"]) == set(TRANSACTION_PINS)
         and h.ROOT == ROOT and h.TRANSACTION_OWNER == p.OWNER and h.VERSION_FILES == VERSION_FILES, "control")
    api, extended = g["load_windows_api"]()
    return compiler, p, g, original, h, api, extended


class Mutex:
    def __init__(self, compiler, p, api):
        self.compiler, self.p, self.api, self.handle = compiler, p, api, None

    def __enter__(self):
        self.handle = self.compiler.acquire_mutex(self.p, self.api)
        return self

    def __exit__(self, *_):
        handle, self.handle = self.handle, None
        self.compiler.release_mutex(self.p, self.api, handle)


def pin_snapshot(pins):
    return {name: pin.recheck() for name, pin in pins.items()}


def recheck_snapshot(pins, expected):
    need(pin_snapshot(pins) == expected, "pin-drift")


def held_inputs(p, admitted):
    closed(admitted, {"image", "imagePin", "receiptPins", "record", "protectedPins", "protectedBefore", "artifact"}, "producer")
    need(type(admitted["receiptPins"]) is dict
         and set(admitted["receiptPins"]) == set(p.PRODUCER_FILES) | {"held-build-inputs"}, "producer")
    guard = admitted["receiptPins"]["held-build-inputs"]
    need(isinstance(guard, p.BuildInputsGuard), "producer")
    return guard


def version_receipts(p, g, api, stack, opt, sources, maps, admitted, h):
    folder = p.RUNS / opt.version_run_id
    ordinary(folder, directory=True)
    need(sum(ordinary(folder / name).st_size for name in VERSION_FILES) <= 64000000, "version")
    pins = {name: stack.enter_context(g["ReadPin"](api, folder / name,
            p.MAX_LOG if name in ("outer.stdout", "outer.stderr") else BUDGETS["jsonBytes"]))
            for name in VERSION_FILES}
    values = {name: unique_json(pin.bytes()) for name, pin in pins.items() if name.endswith(".json")}
    # Pure helper takes this explicit p/opt; its fixed-E89 entry points are never called.
    h.validate_version(p, opt, sources, maps["original"], maps["transaction"], admitted, values,
                       pins["outer.stdout"].bytes(), pins["outer.stderr"].bytes())
    return pins, pin_snapshot(pins)


def admit_pair(p, g, api, original, h, stack, opt, sources, maps, result):
    validate_options(opt)
    admitted = p.producer_admission(
        g, api, original, stack, opt.producer_run_id, opt.source_commit, sources,
        maps["original"], maps["transaction"],
        on_image_attempt=lambda: result.update(nativeImageReadAttempted=True))
    result["nativeImageRead"] = True
    held_inputs(p, admitted)
    need(admitted["image"] == p.image_path(opt.producer_run_id), "producer")
    pins, before = version_receipts(p, g, api, stack, opt, sources, maps, admitted, h)
    h.recheck_pair(p, original, admitted, pins, before)
    return admitted, pins, before


def current_maps(p, g):
    original = p.original_map(g)
    transaction = g["controls_map"]()
    own = own_map()
    need(original == checked_map(ORIGINAL, ORIGINAL_PINS)
         and transaction == checked_map(TRANSACTION, TRANSACTION_PINS), "control")
    history = checked_map(HISTORY, HISTORY_PINS)
    fixture = checked_map(ROOT, FIXTURE_PINS)
    validate_manifest(unique_json(source_bytes(CONTROL / "review-manifest.json", 64000)), own)
    return {"original": original, "transaction": transaction, "consumer": own,
            "history-helper": history, "fixture": fixture}


def pin_controls(p, g, api, stack, maps):
    pins = p.pin_control_files(g, api, stack)
    for prefix, folder in (("consumer", CONTROL), ("history-helper", HISTORY), ("fixture", ROOT)):
        for name, expected in maps[prefix].items():
            pin = stack.enter_context(g["ReadPin"](api, folder / name, 1000000))
            need(pin.record()["sha256"] == expected["sha256"], "control")
            pins[prefix + "/" + name] = pin
    return pins


def observe_sources(p, g, api, extended, out, environment, opt, phase, budget):
    budget.check()
    need(g["environment_for"]("build") == environment, "environment-drift")
    git = shutil.which("git.exe", path=environment["PATH"])
    need(git and Path(git).is_absolute(), "source")
    def capture(label, arguments):
        budget.check()
        argv = [git, "--no-optional-locks", "-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false", *arguments]
        now = time.monotonic_ns()
        row = g["run_owned"](api, extended, out, label, argv, environment, 30, cap=2000000,
                              absolute_deadline_ns=min(budget.end_ns, now + 30000000000))
        need(row["completed"] is True and row["exitCode"] == 0
             and row["treeExitedBeforeCleanup"] is True and row["activeBeforeCleanup"] == 0
             and row["activeAfterCleanup"] == 0 and row["rootExitedAfterCleanup"] is True
             and row["cleanupUnproven"] is False, "source")
        budget.check()
        return source_bytes(out / (label + ".stdout"), 2000000)
    head = capture("git-head-" + phase, ["rev-parse", "--verify", "HEAD"]).decode("ascii").strip()
    need(head == opt.source_commit == SOURCE_COMMIT, "source-head")
    need(not capture("git-status-" + phase, ["status", "--porcelain=v1", "-z", "--untracked-files=no"]), "source")
    names = capture("git-files-" + phase, ["ls-files", "-z"]).decode("utf-8", "strict").split("\0")
    names = [name for name in names if name]
    need(len(names) == len(set(names)) and len(names) <= 100000, "source")
    selected = sorted(name for name in names if name.startswith(("native/", "scripts/", ".cargo/"))
                      or Path(name).name in ("Cargo.toml", "Cargo.lock", "rust-toolchain", "rust-toolchain.toml")
                      or name == ".github/workflows/rust.yml")
    required = {"Cargo.toml", "Cargo.lock", "native/Cargo.toml", "scripts/host_powershell_probe.py",
                "scripts/run_native_tests.py", "scripts/ci_windows_temp.py", "scripts/native_shards.py",
                ".github/workflows/rust.yml"}
    need(required.issubset(selected) and len(selected) <= g["MAX_SOURCE_FILES"], "source")
    result, total = {}, 0
    for name in selected:
        budget.check()
        need(not Path(name).is_absolute() and ".." not in Path(name).parts and "\\" not in name
             and ":" not in name and all(ord(ch) >= 32 for ch in name)
             and all(part.rstrip(" .") == part for part in Path(name).parts), "source")
        row = g["source_digest"](ROOT / name)
        total += row["bytes"]
        need(total <= g["MAX_SOURCE_BYTES"], "source")
        result[name] = row
    need(all(result[name]["sha256"] == sha for name, sha in FIXTURE_PINS.items()), "fixture-drift")
    need(g["environment_for"]("build") == environment, "environment-drift")
    budget.check()
    write_json(out / ("source-" + phase + ".json"), result, 4000000)
    return result


class PythonMetadataPin:
    """Fixed trusted tool; attributes/execute-right handle only, no content read."""
    def __init__(self, api, ancestors):
        import msvcrt
        self.api, self.observe_ancestors, self.fd = api, ancestors, None
        self.ancestors = ancestors(PYTHON)
        ordinary(PYTHON)
        handle = api.CreateFileW(str(PYTHON), 0xA0, 1, None, 3, 0x00200000, None)
        need(handle not in (None, -1, (1 << 64) - 1), "python-metadata")
        try:
            self.fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
        except BaseException:
            need(api.CloseHandle(handle), "python-handle-close")
            raise
        try:
            self.initial = self.observe()
        except BaseException:
            os.close(self.fd)
            self.fd = None
            raise

    def observe(self):
        need(self.fd is not None and self.observe_ancestors(PYTHON) == self.ancestors, "python-drift")
        path, held = ordinary(PYTHON), os.fstat(self.fd)
        need(identity(path) == identity(held) and stat.S_ISREG(held.st_mode)
             and not getattr(held, "st_file_attributes", 0) & 0x400
             and 0 < path.st_size <= 128000000, "python-drift")
        return {"path": str(PYTHON), "identity": list(identity(path)), "pathMode": path.st_mode,
                "handleMode": held.st_mode, "pathAttributes": getattr(path, "st_file_attributes", 0),
                "handleAttributes": getattr(held, "st_file_attributes", None), "ancestors": self.ancestors,
                "desiredAccess": "FILE_EXECUTE|FILE_READ_ATTRIBUTES", "contentRead": False,
                "contentAttested": False, "allAliasDenialClaimed": False}

    def recheck(self):
        observed = self.observe()
        need(observed == self.initial, "python-drift")
        return observed

    def __enter__(self):
        return self

    def __exit__(self, *_):
        try:
            self.recheck()
        finally:
            if self.fd is not None:
                os.close(self.fd)
                self.fd = None


def fresh_directory(parent, name):
    run_name(name)
    ordinary(parent, directory=True)
    path = parent / name
    need(not os.path.lexists(path), "occupied")
    path.mkdir(mode=0o700)
    ordinary(path, directory=True)
    return path


def fixed_parent(path):
    need(path in (RUNS, PRIVATE), "path")
    ordinary(BASE, directory=True)
    try:
        path.mkdir(mode=0o700)
    except FileExistsError:
        pass
    ordinary(path, directory=True)


def fresh_fixture():
    value = os.environ.get("TEMP")
    need(type(value) is str and bool(value), "path")
    parent = Path(value)
    need(parent.is_absolute() and parent.drive.lower() == ROOT.drive.lower(), "path")
    name = "yr-" + os.urandom(8).hex()
    candidate = parent / name
    need(len(str(candidate / "s").encode("utf-16-le")) // 2 <= BUDGETS["fixtureUtf16Units"], "path")
    ordinary(parent, directory=True)
    return fresh_directory(parent, name)


def tree_size(root, budget):
    count, total = 0, 0
    pending = [root]
    while pending:
        budget.check()
        directory = pending.pop()
        ordinary(directory, directory=True)
        for path in directory.iterdir():
            budget.check()
            info = path.lstat()
            need(not getattr(info, "st_file_attributes", 0) & 0x400, "path")
            count += 1
            need(count <= BUDGETS["treeEntries"], "budget")
            if stat.S_ISDIR(info.st_mode):
                pending.append(path)
            else:
                ordinary(path)
                total += info.st_size
                need(total <= BUDGETS["treeBytes"], "budget")
    return count, total


def case_plan(index):
    need(integer(index, 0, 5), "case")
    return json.loads(encoded(CASES[index]))


def native_image_path(producer_run_id):
    return BASE / "runs-compiler-lld" / run_name(producer_run_id) / "owned-release-cli.exe"


def validate_spec(spec):
    closed(spec, SPEC_KEYS, "spec")
    need(spec["owner"] == OWNER and type(spec["schema"]) is int and spec["schema"] == SCHEMA
         and spec["sourceCommit"] == SOURCE_COMMIT, "spec")
    ids = [run_name(spec[key]) for key in ("runId", "producerRunId", "versionRunId")]
    need(len(set(ids)) == 3 and integer(spec["caseIndex"], 0, 5), "spec")
    fixture, directory = Path(spec["fixture"]), Path(spec["caseDirectory"])
    need(directory == PRIVATE / spec["runId"] / ("case-" + str(spec["caseIndex"]))
         and fixture.is_absolute() and fixture.drive.lower() == ROOT.drive.lower()
         and re.fullmatch(r"yr-[0-9a-f]{16}", fixture.name)
         and len(str(fixture / "s").encode("utf-16-le")) // 2 <= BUDGETS["fixtureUtf16Units"]
         and spec["native"] == str(native_image_path(spec["producerRunId"]))
         and spec["python"] == str(PYTHON), "spec")
    need(type(spec["jobName"]) is str and re.fullmatch(r"Local\\YokeCompilerLLD-[0-9a-f]{64}", spec["jobName"]), "spec")
    need(all(integer(spec[key], 1) for key in ("startedNs", "deadlineNs", "recipeDeadlineNs"))
         and spec["startedNs"] < spec["deadlineNs"] <= spec["recipeDeadlineNs"]
         and spec["deadlineNs"] - spec["startedNs"] <= BUDGETS["caseSeconds"] * 1000000000, "spec")
    for path in (fixture, fixture / "s", fixture / "t", directory):
        ordinary(path, directory=True)
    for path in (fixture / "s/main.py", fixture / "requests.json"):
        ordinary(path)
    need(len(str(directory / "worker-spec.json").encode("utf-16-le")) // 2 <= 248, "path")
    return spec


def native_command(spec):
    validate_spec(spec)
    command = [spec["native"], "--root", str(Path(spec["fixture"]) / "s"), "--timeout", "10000",
               "runtime", "main.py", "--python", str(PYTHON), "--requests",
               str(Path(spec["fixture"]) / "requests.json"), "--trust-runtime"]
    if case_plan(spec["caseIndex"])["evaluation"]:
        command.append("--allow-evaluation")
    return command


def validate_case_job(p, row, command, spec, stdout, stderr):
    # The negative row is validated as-is: no completed/exit-code substitution.
    closed(row, p.OUTER_KEYS, "case-job")
    case = case_plan(spec["caseIndex"])
    need(row["command"] == command and row["exitCode"] == case["exit"]
         and type(row["completed"]) is bool and row["completed"] is (case["exit"] == 0), "case-job")
    for key in ("stdinClosed", "startedSuspended", "assignedBeforeResume", "treeExitedBeforeCleanup",
                "rootExitedAtObservation", "rootExitedAfterCleanup", "namedJobCreatedNew"):
        need(row[key] is True, "case-job")
    need(row["outputExceeded"] is False and row["cleanupUnproven"] is False
         and row["cleanupErrors"] == [] and row["streamEOF"] == [True, True]
         and row["readerErrors"] == [False, False] and row["membersAfterOriginalDrain"] == [], "case-job")
    need(type(row["streamEOF"]) is list and type(row["readerErrors"]) is list
         and all(type(x) is bool for x in row["streamEOF"] + row["readerErrors"]), "case-job")
    for key in ("deadlineSeconds", "logCapBytes", "minimumFreeObserved", "startedMonotonicNs", "absoluteDeadlineNs",
                "pid", "resumePreviousSuspendCount", "exitCode", "rootObservedMonotonicNs", "activeAtRootObservation",
                "originalDrainSeconds", "activeBeforeCleanup", "treeObservedMonotonicNs", "cleanupSeconds",
                "activeAfterCleanup", "capturedLogBytes"):
        need(integer(row[key]), "case-job")
    need(row["pid"] > 0 and row["resumePreviousSuspendCount"] == 1
         and row["activeBeforeCleanup"] == row["activeAfterCleanup"] == 0
         and row["deadlineSeconds"] == BUDGETS["caseSeconds"]
         and row["originalDrainSeconds"] == BUDGETS["naturalDrainSeconds"]
         and row["cleanupSeconds"] == BUDGETS["soleAbortSeconds"]
         and row["logCapBytes"] == BUDGETS["logBytes"]
         and row["minimumFreeObserved"] >= BUDGETS["reserveBytes"]
         and row["jobName"] == spec["jobName"]
         and row["absoluteDeadlineNs"] == spec["deadlineNs"], "case-job")
    need(type(row["elapsedSeconds"]) in (int, float) and math.isfinite(row["elapsedSeconds"])
         and 0 <= row["elapsedSeconds"] <= BUDGETS["caseSeconds"] + BUDGETS["soleAbortSeconds"]
         and spec["startedNs"] <= row["startedMonotonicNs"] <= row["rootObservedMonotonicNs"]
         <= row["treeObservedMonotonicNs"] < row["absoluteDeadlineNs"], "case-job")
    observations = row["membersAtRootObservation"]
    need(type(observations) is list and len(observations) <= 2048, "case-job")
    seen = set()
    for member in observations:
        need(type(member) is dict and {"pid", "imageBytesRead", "imageIdentityKnown"}.issubset(member)
             and set(member).issubset({"pid", "imageBytesRead", "imageIdentityKnown", "membershipConfirmed",
                                      "imagePathMetadata", "imageQueryError", "membershipQueryError", "openError"})
             and integer(member["pid"], 1) and member["pid"] not in seen
             and member["imageBytesRead"] is False and member["imageIdentityKnown"] is False, "case-job")
        seen.add(member["pid"])
        if "membershipConfirmed" in member:
            need(type(member["membershipConfirmed"]) is bool, "case-job")
        if "imagePathMetadata" in member:
            need(member.get("membershipConfirmed") is True and type(member["imagePathMetadata"]) is str
                 and 0 < len(member["imagePathMetadata"]) <= 32768, "case-job")
        need(all(integer(member[key]) for key in ("imageQueryError", "membershipQueryError", "openError") if key in member), "case-job")
    need(type(stdout) is bytes and type(stderr) is bytes and len(stdout) <= BUDGETS["stdoutBytes"]
         and len(stderr) <= BUDGETS["stderrBytes"]
         and len(stdout) + len(stderr) == row["capturedLogBytes"] <= BUDGETS["logBytes"], "case-output")


def validate_case_payload(index, stdout, stderr):
    case = case_plan(index)
    if case["exit"] == 1:
        need(stdout == b"" and b"shutdown was not confirmed" in stderr, "case-output")
        if index == 5:
            need(b"Close response did not confirm closed state" in stderr, "case-output")
    else:
        report = unique_json(stdout)
        need(type(report) is dict and type(report.get("events")) is list
             and len(report["events"]) == case["events"], "case-output")
        events = report["events"]
        need(all(type(event) is dict for event in events), "case-output")
        if case["terminal"] is None:
            need(all(event.get("status") == "paused" for event in events), "case-output")
        else:
            need(events[0].get("status") == "paused" and events[1].get("status") == case["terminal"]
                 and events[1].get("programCompleted") is (case["terminal"] == "finished"), "case-output")
    return {"caseIndex": index, "userEventCount": case["events"], "expectedFailureObserved": case["exit"] == 1,
            "originalOutputAssertionsObserved": True}


def validate_child(value, spec, job):
    closed(value, CHILD_KEYS, "case-child")
    need(value["owner"] == OWNER and type(value["schema"]) is int and value["schema"] == SCHEMA
         and value["sourceCommit"] == SOURCE_COMMIT and value["runId"] == spec["runId"]
         and type(value["caseIndex"]) is int and value["caseIndex"] == spec["caseIndex"]
         and value["command"] == native_command(spec) and value["cwd"] == str(Path(spec["fixture"]) / "s")
         and type(value["exitCode"]) is int and value["exitCode"] == case_plan(spec["caseIndex"])["exit"]
         and all(value[key] is True for key in ("workerInJobBeforeCLI", "stdinClosed", "sourceUnchanged", "requestsUnchanged"))
         and integer(value["startedNs"], 1) and integer(value["finishedNs"], 1)
         and job["startedMonotonicNs"] <= value["startedNs"] <= value["finishedNs"]
         <= job["rootObservedMonotonicNs"] < spec["deadlineNs"], "case-child")


def initial_result(opt):
    return {"owner": OWNER, "schema": SCHEMA, "sourceCommit": opt.source_commit, "runId": opt.run_id,
            "producerRunId": opt.producer_run_id, "versionRunId": opt.version_run_id,
            "completed": False, "phase": "preflight", "failureCode": None,
            "nativeImageReadAttempted": False, "nativeImageRead": False,
            "matchingVersionReceiptAdmitted": False, "nativeExecutionRequested": False,
            "cases": [], "sourceInputsUnchanged": False, "protectedMetadataUnchanged": False,
            "treeExitedBeforeCleanup": False, "runtimeResponseCasesObserved": False,
            "completeSourceAcceptance": False, "liveMaintenanceAcceptance": False,
            "vsixQualification": False, "platformQualification": False,
            "releaseQualification": False, "wholeProjectComplete": False}


def execute(opt):
    result = initial_result(opt)
    out = None
    budget = Budget()
    try:
        validate_options(opt)
        need(os.name == "nt", "arguments")
        need(shutil.disk_usage(ROOT).free >= BUDGETS["startBytes"], "disk")
        own = own_map()
        validate_manifest(unique_json(source_bytes(CONTROL / "review-manifest.json", 64000)), own)
        for folder, pins in ((TRANSACTION, TRANSACTION_PINS), (ORIGINAL, ORIGINAL_PINS),
                             (HISTORY, HISTORY_PINS), (ROOT, FIXTURE_PINS)):
            checked_map(folder, pins)
        compiler, p, g, original, h, api, extended = load_dependencies()
        with Mutex(compiler, p, api), ExitStack() as stack:
            budget.check()
            fixed_parent(RUNS)
            fixed_parent(PRIVATE)
            out = fresh_directory(RUNS, opt.run_id)
            private = fresh_directory(PRIVATE, opt.run_id)
            write_json(out / "request.json", {"owner": OWNER, "schema": SCHEMA,
                       "sourceCommit": opt.source_commit, "runId": opt.run_id,
                       "producerRunId": opt.producer_run_id, "versionRunId": opt.version_run_id,
                       "budgets": BUDGETS, "caseCount": 6})
            maps = current_maps(p, g)
            need(maps["consumer"] == own, "control")
            controls = pin_controls(p, g, api, stack, maps)
            control_before = pin_snapshot(controls)
            python = stack.enter_context(PythonMetadataPin(api, original["protected_ancestors"]))
            python_before = python.recheck()
            write_json(private / "python-before.json", python_before)
            environment = g["environment_for"]("build")
            sources = observe_sources(p, g, api, extended, private, environment, opt, "before", budget)
            write_json(private / "controls-before.json", maps)
            result["phase"] = "producer-and-version-admission"
            admitted, version_pins, version_before = admit_pair(
                p, g, api, original, h, stack, opt, sources, maps, result)
            result["matchingVersionReceiptAdmitted"] = True
            budget.check()

            def stable():
                budget.check()
                need(g["environment_for"]("build") == environment and current_maps(p, g) == maps, "control-drift")
                held_inputs(p, admitted)
                h.recheck_pair(p, original, admitted, version_pins, version_before)
                recheck_snapshot(controls, control_before)
                need(python.recheck() == python_before, "python-drift")
                budget.check()

            summaries = []
            for index in range(6):
                stable()
                case = case_plan(index)
                directory = fresh_directory(private, "case-" + str(index))
                fixture = fresh_fixture()
                fresh_directory(fixture, "s")
                fresh_directory(fixture, "t")
                with (fixture / "s/main.py").open("xb") as stream:
                    stream.write(case["source"].encode("utf-8"))
                write_json(fixture / "requests.json", case["requests"], 64000)
                source_pin = stack.enter_context(g["ReadPin"](api, fixture / "s/main.py", 64000))
                request_pin = stack.enter_context(g["ReadPin"](api, fixture / "requests.json", 64000))
                fixture_before = (source_pin.recheck(), request_pin.recheck())
                now = time.monotonic_ns()
                spec = {"owner": OWNER, "schema": SCHEMA, "sourceCommit": SOURCE_COMMIT,
                        "runId": opt.run_id, "producerRunId": opt.producer_run_id,
                        "versionRunId": opt.version_run_id, "caseIndex": index,
                        "fixture": str(fixture), "caseDirectory": str(directory),
                        "native": str(admitted["image"]), "python": str(PYTHON),
                        "jobName": "Local\\YokeCompilerLLD-" + os.urandom(32).hex(),
                        "startedNs": now,
                        "deadlineNs": min(budget.end_ns, now + BUDGETS["caseSeconds"] * 1000000000),
                        "recipeDeadlineNs": budget.end_ns}
                validate_spec(spec)
                spec_path = directory / "worker-spec.json"
                write_json(spec_path, spec, BUDGETS["specBytes"])
                spec_pin = stack.enter_context(g["ReadPin"](api, spec_path, BUDGETS["specBytes"]))
                spec_before = spec_pin.recheck()
                need(unique_json(spec_pin.bytes()) == spec, "spec")
                case_env = dict(environment)
                case_env.update(TEMP=str(fixture / "t"), TMP=str(fixture / "t"))
                command = [str(PYTHON), "-I", "-B", str(CONTROL / "runtime_response_live_worker.py"), str(spec_path)]
                result.update(phase="case-" + str(index), nativeExecutionRequested=True)
                job = g["run_owned"](api, extended, directory, "case", command, case_env,
                                     BUDGETS["caseSeconds"], cap=BUDGETS["logBytes"],
                                     absolute_deadline_ns=spec["deadlineNs"], job_name=spec["jobName"])
                # Pin the untouched raw row/streams; negative completed:false is retained.
                evidence = {name: stack.enter_context(g["ReadPin"](api, directory / name, BUDGETS["logBytes"]))
                            for name in ("case.job.json", "case.stdout", "case.stderr", "child.json")}
                evidence_before = pin_snapshot(evidence)
                need(unique_json(evidence["case.job.json"].bytes()) == job, "case-job")
                stdout, stderr = evidence["case.stdout"].bytes(), evidence["case.stderr"].bytes()
                validate_case_job(p, job, command, spec, stdout, stderr)
                validate_child(unique_json(evidence["child.json"].bytes()), spec, job)
                need(source_pin.recheck() == fixture_before[0] and request_pin.recheck() == fixture_before[1]
                     and source_pin.bytes() == case["source"].encode("utf-8")
                     and unique_json(request_pin.bytes()) == case["requests"], "fixture-drift")
                need(spec_pin.recheck() == spec_before, "spec-drift")
                summary = validate_case_payload(index, stdout, stderr)
                count, byte_count = tree_size(fixture, budget)
                summary.update(sourceUnchanged=True, treeExitedBeforeCleanup=True,
                               fixtureEntries=count, fixtureBytes=byte_count,
                               rawExitCode=job["exitCode"], rawJobCompleted=job["completed"])
                summaries.append(summary)
                recheck_snapshot(evidence, evidence_before)
                tree_size(private, budget)
                stable()

            result["phase"] = "final-recheck"
            for phase in ("after", "final"):
                need(observe_sources(p, g, api, extended, private, environment, opt, phase, budget) == sources, "source-drift")
                stable()
                write_json(private / ("controls-" + phase + ".json"), current_maps(p, g))
                write_json(private / ("python-" + phase + ".json"), python.recheck())
                tree_size(private, budget)
            need(len(summaries) == 6 and sum(row["expectedFailureObserved"] for row in summaries) == 2, "case")
            budget.check()
        # Every held input, source/spec/evidence pin and mutex closes before acceptance.
        budget.check()
        result.update(completed=True, phase="complete", cases=summaries, sourceInputsUnchanged=True,
                      protectedMetadataUnchanged=True, treeExitedBeforeCleanup=True,
                      runtimeResponseCasesObserved=True)
    except BaseException as error:
        code = getattr(error, "code", None)
        known = {"arguments", "disk", "control", "control-drift", "producer", "version", "source-head", "source-drift",
                 "fixture-drift", "python-drift", "recipe-deadline", "case-job", "case-child", "case-output",
                 "case", "spec", "spec-drift", "occupied", "path", "budget", "manifest", "environment-drift", "pin-drift"}
        result.update(completed=False, failureCode=code if code in known else "external-refusal",
                      sourceInputsUnchanged=False, protectedMetadataUnchanged=False,
                      treeExitedBeforeCleanup=False, runtimeResponseCasesObserved=False, cases=[])
    finally:
        if out is not None:
            try:
                write_json(out / "result.json", result)
            except BaseException:
                result.update(completed=False, failureCode="result-publication", cases=[],
                              runtimeResponseCasesObserved=False, treeExitedBeforeCleanup=False,
                              sourceInputsUnchanged=False, protectedMetadataUnchanged=False)
    return result


def main(arguments=None):
    try:
        result = execute(options(sys.argv[1:] if arguments is None else arguments))
        print("runtime-response-live-complete" if result["completed"] else "runtime-response-live-refused", flush=True)
        return 0 if result["completed"] else 1
    except BaseException:
        print("runtime-response-live-refused", flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
