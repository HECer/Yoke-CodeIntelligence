"""Fixed one-case child; parent owns its named Job and sole cleanup authority."""
import ctypes as c
import hashlib
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
import types

CONTROLLER_SHA = '3e819939f32ce58101ae0f63472b5f3ef281a1c5360da3a89ab750b25de4fbd7'


def controller():
    path = Path(__file__).absolute().parent / "runtime_response_live_controller.py"
    for parent in reversed(path.parents):
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("source-route")
    before = path.lstat()
    if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_ino <= 0
            or getattr(before, "st_file_attributes", 0) & 0x400 or before.st_size > 1000000):
        raise RuntimeError("source-role")
    data = path.read_bytes()
    after = path.lstat()
    if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) !=
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            or hashlib.sha256(data).hexdigest() != CONTROLLER_SHA):
        raise RuntimeError("source-pin")
    module = types.ModuleType("runtime_response_live_worker_policy")
    module.__file__ = str(path)
    exec(compile(data, str(path), "exec"), module.__dict__)
    return module


def run(spec_path):
    policy = controller()
    spec_path = Path(spec_path)
    policy.need(spec_path.is_absolute() and spec_path.name == "worker-spec.json", "spec")
    spec = policy.validate_spec(policy.unique_json(policy.source_bytes(spec_path, 64000)))
    policy.need(spec_path == Path(spec["caseDirectory"]) / "worker-spec.json", "spec")
    case = policy.case_plan(spec["caseIndex"])
    source = Path(spec["fixture"]) / "s/main.py"
    requests = Path(spec["fixture"]) / "requests.json"
    policy.need(policy.source_bytes(source) == case["source"].encode("utf-8")
                and policy.unique_json(policy.source_bytes(requests)) == case["requests"], "fixture-drift")
    api = c.WinDLL("kernel32", use_last_error=True)
    for name, args, result in (
        ("OpenJobObjectW", [c.c_ulong, c.c_int, c.c_wchar_p], c.c_void_p),
        ("GetCurrentProcess", [], c.c_void_p),
        ("IsProcessInJob", [c.c_void_p, c.c_void_p, c.POINTER(c.c_int)], c.c_int),
        ("CloseHandle", [c.c_void_p], c.c_int),
    ):
        function = getattr(api, name)
        function.argtypes, function.restype = args, result
    handle = api.OpenJobObjectW(4, False, spec["jobName"])
    policy.need(handle not in (None, -1, (1 << 64) - 1), "worker-membership")
    try:
        member = c.c_int()
        policy.need(api.IsProcessInJob(api.GetCurrentProcess(), handle, c.byref(member)) and member.value == 1,
                    "worker-membership")
        started = time.monotonic_ns()
        policy.need(started < spec["deadlineNs"], "case-deadline")
        command = policy.native_command(spec)
        # No arbitrary argv, breakaway, inner kill, retry or extra cleanup wait.
        child = subprocess.Popen(command, cwd=str(source.parent), stdin=subprocess.DEVNULL,
                                 stdout=None, stderr=None, close_fds=True, creationflags=0)
        remaining = (spec["deadlineNs"] - time.monotonic_ns()) / 1000000000
        policy.need(remaining > 0, "case-deadline")
        exit_code = child.wait(timeout=remaining)
        finished = time.monotonic_ns()
        policy.need(finished < spec["deadlineNs"], "case-deadline")
        row = {"owner": policy.OWNER, "schema": policy.SCHEMA, "sourceCommit": policy.SOURCE_COMMIT,
               "runId": spec["runId"], "caseIndex": spec["caseIndex"], "command": command,
               "cwd": str(source.parent), "exitCode": exit_code, "startedNs": started, "finishedNs": finished,
               "workerInJobBeforeCLI": True, "stdinClosed": True,
               "sourceUnchanged": policy.source_bytes(source) == case["source"].encode("utf-8"),
               "requestsUnchanged": policy.unique_json(policy.source_bytes(requests)) == case["requests"]}
    finally:
        policy.need(api.CloseHandle(handle), "worker-handle-close")
    policy.write_json(Path(spec["caseDirectory"]) / "child.json", row, 64000)
    return exit_code


if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            raise RuntimeError("arguments")
        status = run(sys.argv[1])
    except BaseException:
        status = 125
    raise SystemExit(status)
