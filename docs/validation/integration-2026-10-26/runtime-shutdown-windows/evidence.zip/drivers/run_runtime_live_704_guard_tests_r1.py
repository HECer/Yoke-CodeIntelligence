"""Run the reviewed history consumer's inert protocol tests, never a native image."""
from pathlib import Path
import hashlib
import json
import os
import re
import sys
import types

WORKTREE = Path("C:/Users/Lomi/.t3/worktrees/Yoke-CodeIntelligence/t3-b1973677")
REL = Path("validation/integration-20261025/platform-repairs")
SOURCE = "704b647d625dcc5f359386b20834d329ffb6cdf4"
CLI = WORKTREE / REL / "control-cli/cli_controller.py"
CLI_SHA = "d6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582"
CONSUMER = WORKTREE / REL / "control-runtime-response-live-704"
PINS = {'.gitattributes': '85e48d232edc7b02f6cecf8fbbf905f3b126c467b594d8dd16c4f8fa283a8320', 'README.md': 'bcc97dca3112110601cb9a855fd55390c4cf9b3538b3cb676d1cf82a5133bfa8', 'review-manifest.json': 'a7fd3ba09818fda08db38272f6b1eee0fbd2723c4594b5e889911d19167a61b7', 'runtime_response_live_controller.py': '3e819939f32ce58101ae0f63472b5f3ef281a1c5360da3a89ab750b25de4fbd7', 'runtime_response_live_worker.py': '88f062408595fafaaf520629ab46eabd5960df104da9acec5a215a23896443ab', 'test_runtime_response_live.py': 'f46450c28da8969f12a8cf9426533109b57c770412e2678091d5de07805b89e7'}


def source_bytes(path):
    assert path.suffix.lower() not in (".exe", ".pdb", ".dll", ".lib", ".obj", ".o")
    info = path.lstat()
    assert info.st_size <= 1_000_000 and info.st_nlink == 1
    assert not getattr(info, "st_file_attributes", 0) & 0x400
    return path.read_bytes()


def consumer_map():
    result = {}
    for name, expected in PINS.items():
        data = source_bytes(CONSUMER / name)
        digest = hashlib.sha256(data).hexdigest()
        assert digest == expected, name
        result[name] = {"bytes": len(data), "sha256": digest}
    return result


DEPENDENCIES = {'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\compiler_transaction_controller.py': 'd6ab4fe93432a74a769e9abcdddcef40e87ef274e98fea498a219d95c2c9f29d', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\compiler_transaction_worker.py': 'cf24492dafb4c30ce057a0885c5021339fc76fa3dba1e1efdddaf111fa1285fb', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\transaction_protocol.py': 'eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\transaction_runtime.py': '1608c69131ab3374812496ee9ff855e2c906ac172d31f9899331aa33f2e98de8', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\test_compiler_transaction.py': 'da422d730d3db84b4967fe422d8b8106ed5bb2faac05fa95b012ec5c5ee4bed9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\review-manifest.json': '141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\README.md': 'a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\runtime-fork.patch': '93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-compiler-lld\\v2-fork.patch': '006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\cli_controller.py': 'd6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\base_controller.py': 'a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\private_windows_api.py': 'd9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\test_metadata_pin.py': '6f555a7b29a85f17c404cba57474c682ae84adf28915ac8b1f10db73b9041aca', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\README.md': '1bbe94b3ac00dff9d1116ab8ccc8aadce545b14dd536888644d1cb92eac3cea6', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\review-manifest.json': '8dd48b1595220464fc638d458a6f8dd7b19f55454c35c0bda7eb7cea255b94f8', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-cli\\.gitattributes': 'a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\validation\\integration-20261025\\platform-repairs\\control-history-lld-e89\\history_transaction_controller.py': 'c86f8117d37557ad3daf08e6bd1ee1b15a48c7d85e33bb16e09e4954a1933487', 'C:\\Users\\Lomi\\.t3\\worktrees\\Yoke-CodeIntelligence\\t3-b1973677\\native\\tests\\workflow_cli.rs': '76aff7d9fde0de4e9a94ea84b70deac33c5df8a0d036a8aa6d806f23875e9149'}

def dependencies_map():
    result = {}
    for name, expected in DEPENDENCIES.items():
        data=source_bytes(Path(name))
        actual=hashlib.sha256(data).hexdigest()
        assert actual==expected, name
        result[name]={"bytes":len(data),"sha256":actual}
    return result

def main():
    assert os.name == "nt" and len(sys.argv) == 1
    data = source_bytes(CLI)
    assert hashlib.sha256(data).hexdigest() == CLI_SHA
    module = types.ModuleType("reviewed_private_release_cli_for_inert_tests")
    module.__file__ = str(CLI)
    exec(compile(data, str(CLI), "exec"), module.__dict__)
    g = module.load_base()
    assert g["ROOT"] == WORKTREE
    g.update(RUNS=WORKTREE / REL / "runs-runtime-live-704-guard-tests", OWNER="history-lld-source-guard-tests-v1")
    api, extended = g["load_windows_api"]()
    out = g["new_output"]("runtime-live-704-guard-tests-r1")
    result = {
        "sourceCommit": SOURCE, "completed": False, "testMethodsExpected": 25,
        "nativeImageRead": False, "nativeImageExecuted": False,
        "actualArchiveAcceptance": False, "releaseQualification": False,
    }
    before_driver = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    mutex = None
    owned = False
    try:
        import _winapi
        name = "Local\\YokeValidation-" + hashlib.sha256(str(WORKTREE).encode()).hexdigest()[:24]
        mutex = api.CreateMutexW(None, False, name)
        assert mutex
        wait = _winapi.WaitForSingleObject(mutex, 0)
        assert wait in (0, 128), "Another validation controller is active"
        owned = True
        result["serialMutexAbandoned"] = wait == 128
        environment = g["environment_for"]("build")
        sources = g["source_map"](api, extended, out, environment, SOURCE, "before")
        controls = g["controls_map"]()
        consumer = consumer_map()
        dependencies = dependencies_map()
        g["write_json"](out, "dependency-before.json", dependencies)
        g["write_json"](out, "control-before.json", controls)
        g["write_json"](out, "consumer-before.json", consumer)
        command = [sys.executable, "-B", "-m", "unittest", "discover", "-s", str(CONSUMER),
                   "-p", "test_runtime_response_live.py", "-v"]
        job = g["run_owned"](api, extended, out, "tests", command, environment, 180)
        assert job["completed"] and job["exitCode"] == 0
        assert job["treeExitedBeforeCleanup"] and job["activeBeforeCleanup"] == 0
        assert job["activeAfterCleanup"] == 0 and job["rootExitedAfterCleanup"]
        assert job["cleanupUnproven"] is False
        stderr = (out / "tests.stderr").read_bytes()
        assert re.search(rb"Ran 25 tests in [0-9.]+s", stderr)
        assert re.search(rb"\nOK\r?\n", stderr) and b"skipped=" not in stderr
        after = g["source_map"](api, extended, out, environment, SOURCE, "after")
        after_controls = g["controls_map"]()
        after_consumer = consumer_map()
        after_dependencies = dependencies_map()
        g["write_json"](out, "dependency-after.json", after_dependencies)
        assert dependencies == after_dependencies
        g["write_json"](out, "control-after.json", after_controls)
        g["write_json"](out, "consumer-after.json", after_consumer)
        assert sources == after and controls == after_controls and consumer == after_consumer
        assert before_driver == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        result.update(completed=True, testsPassed=25, testsSkipped=0,
                      sourceInputs=len(sources), sourcesUnchanged=True,
                      originalControlsUnchanged=True, consumerControlsUnchanged=True, dependencyControlsUnchanged=True, dependencyFiles=20,
                      driverSha256=before_driver, jobTreeExitedBeforeCleanup=True)
    except BaseException as error:
        result.update(completed=False, errorType=type(error).__name__)
    finally:
        if owned:
            if not api.ReleaseMutex(mutex):
                result.update(completed=False, mutexReleaseFailed=True)
        if mutex:
            if not api.CloseHandle(mutex):
                result.update(completed=False, mutexCloseFailed=True)
        g["write_json"](out, "result.json", result)
    print(json.dumps(result), flush=True)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
