"""Closed metadata-only invocation of the unchanged reviewed Clippy controller."""
from pathlib import Path
import hashlib
import json
import os
import sys
import types
ROOT = Path('C:/Users/Lomi/.t3/worktrees/Yoke-CodeIntelligence/t3-b1973677')
BASE = ROOT / 'validation/integration-20261025/platform-repairs'
CLI = BASE / 'control-cli/cli_controller.py'
CLI_SHA = 'd6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582'
SOURCE = '704b647d625dcc5f359386b20834d329ffb6cdf4'
RUN = 'clippy-704-r1'
def main():
    assert os.name == 'nt' and len(sys.argv) == 1
    assert CLI.is_file() and not CLI.is_symlink() and CLI.stat().st_nlink == 1
    data = CLI.read_bytes()
    assert hashlib.sha256(data).hexdigest() == CLI_SHA
    module = types.ModuleType('reviewed_closed_clippy_loader')
    module.__file__ = str(CLI)
    exec(compile(data, str(CLI), 'exec'), module.__dict__)
    g = module.load_base()
    assert g['ROOT'] == ROOT and g['CLIPPY_SECONDS'] == 1200
    expected = [str(g['CARGO']), 'clippy', '--workspace', '--all-targets', '--locked', '--keep-going', '-j2', '--message-format=json', '--', '-D', 'warnings']
    assert g['cargo_command']('clippy', None) == expected
    g.update(RUNS=BASE / 'runs-clippy-704', OWNER='closed-clippy-704-metadata-only')
    before = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    saved = sys.argv
    try:
        sys.argv = [str(CLI), 'clippy', '--source-commit', SOURCE, '--run-id', RUN]
        code = g['main']()
    finally:
        sys.argv = saved
    result_path = g['RUNS'] / RUN / 'result.json'
    result = json.loads(result_path.read_text())
    assert result['mode'] == 'clippy' and result['metadataOnly'] is True
    assert result['nativeImageRead'] is False and result['nativeImageReadAttempted'] is False
    assert result['testExecutionRequested'] is False
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == before
    envelope = {'sourceCommit':SOURCE,'completed':code == 0 and result['completed'] is True,'driverSha256':before,'metadataOnly':True,'nativeImageRead':False,'wholeProjectAcceptance':False}
    with (result_path.parent / 'closed-driver.json').open('x',encoding='utf-8',newline='\n') as f:
        f.write(json.dumps(envelope,indent=2)+'\n')
    print(json.dumps(envelope),flush=True)
    return 0 if envelope['completed'] else 1
if __name__ == '__main__':
    raise SystemExit(main())
