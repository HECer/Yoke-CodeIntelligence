# Explicit E89 LLD original-history consumer

This is a separately named, source-prepared consumer for the fixed LLD compiler
protocol. Preparation executed no authored module, function, test, controller,
worker, tool or native image. Parent review and serial guarded validation remain
required. The 41 authored tests establish coverage intent, not runtime evidence.

The fixed source is `e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e`. The
consumer owner is `local-original-archive-history-lld-consumer-v1`; its own
manifest schema remains integer 1. It accepts only compiler owner
`integration-20261026-compiler-lld-v1`, integer schema 3, under sibling
`control-compiler-lld` and `runs-compiler-lld`. No old receipt is relabeled.

Only these five new files belong to this bundle. The existing E89/F8 history,
legacy history, original CLI and LLD compiler controls remain unchanged. The
LLD compiler bundle's historical v2 README is not this consumer's operating
guide. The actual hash-pinned LLD source and its closed protocol are authoritative.

## Explicit producer and version admission

Bootstrap checks bind the exact five consumer files and separate legacy-history,
LLD transaction, original CLI and unchanged history-harness source groups before
loading non-main source. There is no fallback, generic command selector, module
global mutation or legacy image-admission call. `review-manifest.json` closes
all source groups and original budgets; its own hash is reported externally to
avoid a self-hash cycle. Runtime source maps include the manifest itself.

The selected LLD controller's real pinned loader supplies the protocol, runtime
and original CLI adapter. Their roots, owners, schema, run directory, exact
control membership and original pins must match this consumer. Its complete
`producer_admission` runs unchanged, including all 27 producer file receipts,
five build-input proofs, natural inner/outer completion and held current
tool/profile/source observations before private-image admission. Failed E89
images from other producers remain unadmitted.

The seven-key admitted interface retains all 27 file pins plus the actual
non-file `BuildInputsGuard` at `receiptPins["held-build-inputs"]`. The consumer
requires this closed 28-member pin map and the protocol's guard type; a file-only
replacement, missing guard or extra adapter entry refuses. The original
`recheck_admission` remains responsible for image, receipt, protected-role and
current build-input rechecks. This consumer also requires the guard to remain
present at each pair recheck.

Version admission requires 22 files: the original 19 source/control/protected,
result, image and capture receipts, plus `build-inputs-before.json`,
`build-inputs-after.json` and `build-inputs-final.json`. Every JSON object uses
duplicate-key/nonfinite refusal and the existing byte bounds. Request, result,
exact image/artifact, source maps, `yoke 0.5.0` output and natural whole-Job
completion remain bound to the same new producer/version pair. Each additional
proof passes the LLD protocol's `validate_build_inputs` against the selected
source map and must equal the currently held guard, including canonical digest
equality. Identically forged phase proofs cannot replace current held evidence.
The producer's five proofs have already been admitted by the full protocol.

All version files stay pinned through history execution and final observations.
The held build-input context remains in the caller's `ExitStack`; its late
recheck/close failure prevents terminal success. Matching version text by itself
cannot authorize the history worker. Old-v2 owners, schema, commands, maps or
receipts refuse without an adapter fallback.

## Unchanged original-history operation

The actual worker remains the hash-selected `scripts/host_history_live.py`
(`3a3f5de28756ddcc383c3c92821f15fd5db24a72c324ef6a20d1ed6a24f819b2`).
Its native, Serena and persistent-Python variants, original configuration and
owner bytes, archive records/frames and independent exact readback remain intact.
The original harness's real fixture produces 42 records per variant; preparation
has not executed or certified those results for an LLD image. The older inert
33-record mock fixture remains unchanged and is not a live acceptance receipt.

Both original owning stdio Sessions, and the persistent runtime where selected,
must exit before Job cleanup. Pending refusal under old and current authorities,
configuration/owner exactness, retained frames, a fresh destination save and
unchanged analyzed source remain requirements. The existing legacy validators
and their distinction between independent original bytes and reported summaries
are reused unchanged. No owner-retirement or archive-purge qualification is added.

Worker arguments, named history Job, placement, timer positions and resource
bounds remain the originals. The worker admits its named Job before its own
native image read. The fixture uses an ordinary local TEMP parent of at most 70 UTF-16
units; long/nonlocal/linked/occupied locations refuse without alternate placement.
The producer's build/cleanup bounds remain distinct from the history worker's
180-second operation, one-second drain and ten-second cleanup. Forced cleanup
never establishes natural acceptance. No GITHUB_ACTIONS/GITHUB_SHA fabrication,
internal taskkill, deadline enlargement or assertion removal is introduced.

Git and selected-source observations use the LLD runtime's canonical build
environment, allowing its unchanged repeated build-environment/configuration
check to compare like for like. The separately derived original fixture
environment still governs the actual worker; it is unchanged. This does not
forward arbitrary source settings, credentials, model authority or execution
permission into the product.

Before, after and final selected/broader-source maps, all control groups, held
receipts, selected image, protected roles, private spec and evidence pins must
remain exact. Every pin context and the shared per-root mutex must close before
the terminal `completed:true` receipt. The parent additionally owns host-wide
serialization across checkouts; no equal-privilege sandbox is claimed.

## Parent validation

After independent source/hash review, run the authored inert tests serially
under the existing owned validation guard. All 33 original test methods remain
AST-identical. Eight additions cover required/foreign phase proofs, numeric
aliases, old-v2 refusal, lost or file-only guards, actual late guard failure,
bootstrap source refusal, held-context close failure and control drift before
worker execution. No authored test ran during preparation.

Only a completed matching new LLD producer and version may be selected:

```powershell
python validation/integration-20261025/platform-repairs/control-history-lld-e89/history_transaction_controller.py --source-commit e89ae42cbb925a9e0cf6f36d9d451f34d0ac6f6e --run-id '<fresh-history-run>' --producer-run-id '<completed-lld-producer>' --version-run-id '<matching-lld-version>'
```

All three IDs are required, canonical and distinct. The consumer has no native
path override. A failed producer/version ends admission; its image is never
salvaged or pointed at an older consumer.

Private fixture bodies, exact record bytes, raw protocol/capability logs and
worker stderr remain private. Public summaries contain closed error codes and
bounded provenance only. Dependencies, tools, default target/global caches and
other host inputs outside the frozen source boundary remain trusted, not attested.

Even successful future execution would qualify only this E89 original archive
history scope. Current-head/platform, logical owner retirement, physical purge,
desktop/mobile/browser, VSIX/bundled editor, main, publication, release and full
project completion remain separate unqualified gates.
