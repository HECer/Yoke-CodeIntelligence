# Separate compiler transaction, source preparation only

This is a new producer protocol, owner `integration-20261026-compiler-transaction-v2`, schema 2. No controller, worker, helper, test, build or native image was executed during preparation. It establishes no producer, version, history, platform, VSIX or release acceptance.

The direct-Cargo producer `release-cli-isolated-f8-r2` remains terminally invalid. Its one-second post-Cargo tree-empty criterion failed. This bundle neither reads nor adopts that producer's image, and its implementation does not change the seven original `control-cli` files.

## Deliberate lifecycle change

The outer root is now a fixed Python transaction worker. Inside an initially empty nested Job it launches exactly:

```text
C:\Users\Lomi\.cargo\bin\cargo.exe rustc --package yoke-code-intelligence --bin yoke --release --locked --offline -j2 --message-format=json -- -o <fresh-private-run>\owned-release-cli.exe
```

Cargo is created suspended, confirmed in the named outer Job, assigned to the inner Job, confirmed in that inner Job, and resumed once. Before any Cargo launch, the worker must prove its own membership in the exact outer Job selected by the owner. Direct worker invocation outside that Job refuses. The production CLI and worker spec expose no executable, native argument, timeout, environment, exception or test-hook override.

Cargo exit zero alone is insufficient. The worker observes the actual root exit and then awaits **natural emptiness of every inner Job member**, for at most 60 seconds, clipped to the remaining original build deadline. It names no compiler helper exception and permits no breakaway. It does not ignore, kill, preseed or terminate a surviving helper to qualify a build. This changes the old post-Cargo timing criterion; it must not be described as passing that old direct-Cargo gate.

One absolute monotonic 3600-second deadline is created before wrapper launch and retained unchanged in the pinned spec, worker receipt and outer receipt. The worker gets no new 3600-second interval. Its 60-second quiescence interval cannot extend this deadline. After the wrapper exits, the original outer one-second natural drain remains clipped to that same build deadline. The outer owner's two-second total cleanup interval includes root wait, Job accounting and stream joins; the inner worker adds no cleanup wait.

The inner Job has flags zero, including no kill-on-close. On an error the worker fails promptly and closes handles; it neither terminates the Job nor waits for a fresh cleanup budget. Cargo already inherits the outer Job before inner assignment, so assignment/resume failures remain within outer containment. The outer Job retains kill-on-close and is the sole whole-tree abort authority. The owner checks natural emptiness before its unconditional final cleanup call. Any occupied tree, forced removal, missing receipt, failed observation, output error or cleanup uncertainty remains a failed producer even if subsequent cleanup reaches zero. A named-Job collision closes its unowned handle and refuses; it never terminates or queries the occupied Job.

This is a bounded build-lifecycle model, not an equal-privilege sandbox. Installed tools, Python and dependencies, global caches and equal-privilege processes remain trusted. No unproved VCTIP environment flag, registry change or toolchain alteration is made. A surviving helper beyond 60 seconds still fails.

## Admission and receipt boundaries

Build admission retains 4,000,000,000 bytes of free-space admission, continuous 500,000,000-byte reserve observations and one aggregate 16,000,000-byte stdout/stderr cap. Fresh selected-image admission retains the separate 1,200,000,000-byte free-space floor and 512,000,000-byte image ceiling. Lower space, reader/output failure or deadline expiry fails closed.

The old seven controls are recorded in their own map with exact immutable hashes. The new ten-file map includes the controller, worker, protocol, forked runtime, byte-identical Windows ABI helper, adversarial tests, this README, manifest, `.gitattributes` and runtime diff. The selected source map is the original native/script/Cargo/workflow scope. It is explicitly separate from the worktree's 1,135-file preparation inventory; neither map is a substitute for the other.

Before the first fresh private-image read the owner requires both successful Job receipts, complete bounded streams, exact fixed Cargo/package/source/bin/release-profile/fresh compilation observations, unchanged selected sources and both control maps, and unchanged held metadata for every protected role. The Cargo default `executable` field is only a metadata observation. The private fixed `-o` argument, initial absence and selected-image identity/read pin bind the actual output role. Default-path, old-r2, foreign, aliased, hardlinked or reparse substitutions refuse.

Source, control, protected-role, receipt and selected-image checks repeat while their relevant pins are retained. A terminal `completed:true` result is published only after all context rechecks and mutex release succeed. Earlier image-read flags retain actual attempts; they never authorize a later consumer after a failed result.

`transaction_protocol.producer_admission` is the reusable **new-protocol-only** admission function. It pins all producer receipts, validates closed schemas/types/counters, command/profile/maps/deadlines, natural inner and outer emptiness, and then pins the exact private image. Consumers must retain the returned pins and call `recheck_admission` before publishing their own success. There is no legacy/default/r2 fallback. The immutable d6 version/history admission must continue to refuse this protocol. A future history consumer needs a separate explicitly reviewed adapter; this bundle supplies no history execution.

The version command accepts only a completed matching new producer and executes its pinned image with `--version` for 30 seconds under the unchanged one-second drain and two-second cleanup. It requires exact `yoke 0.5.0` output and empty stderr, then rechecks producer, source, control, protected and image pins. It accepts no generic native arguments.

## Review and future verification

The entry point is `compiler_transaction_controller.py` with fixed modes `build` or `version`, required `--source-commit` and `--run-id`, and a `--producer-run-id` required only for version. All run IDs are fresh and create-only. The selected producer path is reconstructed internally. The root mutex is shared with the original controllers; the owner must also exclude producers in other worktrees on this host.

The authored `test_compiler_transaction.py` covers receipt forgery and type confusion, Cargo failure hidden by wrapper zero, deadline reset/clamping, source/control drift, output/disk/stream refusal, launch/assignment/resume/query/crash cleanup, namespace/image substitution, and late pin/protected failures. Windows lifecycle challenges use inert Python children only. A retained wait handle ensures the delayed helper starts its 1.6-second sleep after the actual inert compiler exits; the new transaction should finish naturally while the old direct one-second criterion should fail. A 30-second inert helper intentionally outlives the six-second remaining challenge deadline. No test uses a real native image. Test-only argv/fault hooks are internal functions and never production CLI/spec fields.

The tests themselves, owner-guard smoke tests, live nested-Job/stream/disk failures, source/image pinning, an actual fresh Cargo producer, version, history and all release gates remain unrun. Parent review must precede those separately owned serial executions. Inert captures and raw compiler logs stay private; public errors expose bounded closed codes. The original failed producer's evidence must remain retained.

The runtime fork changes only new owner/paths/control map, optional absolute deadline and named-Job parameters/observations, collision ownership handling, and its disabled generic entry point. `runtime-fork.patch` records every source difference against the exact a226 runtime. All original control hashes are in `review-manifest.json`; the manifest's own final hash is reported externally to avoid a self-hash cycle.
