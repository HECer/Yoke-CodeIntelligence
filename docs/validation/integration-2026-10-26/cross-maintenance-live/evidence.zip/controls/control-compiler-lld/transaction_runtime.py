"""Host-invoked Windows validation only. Preparation does not execute this file.

Fixed Cargo commands, fresh producer admission, private Jobs, and create-only
receipts. This is a lifecycle guard, not an equal-privilege host sandbox.
"""
import argparse
from contextlib import ExitStack
import ctypes as c
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import threading
import time


OWNER = "integration-20261026-compiler-lld-v1"
SCHEMA = 3
ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
CONTROL = ROOT / "validation/integration-20261025/platform-repairs/control-compiler-lld"
RUNS = CONTROL.parent / "runs-compiler-lld"
CARGO = Path(r"C:\Users\Lomi\.cargo\bin\cargo.exe")
HELPER_SHA = "d9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500"
CONTROL_NAMES = ("compiler_transaction_controller.py", "compiler_transaction_worker.py",
                 "transaction_protocol.py", "transaction_runtime.py", "private_windows_api.py",
                 "test_compiler_transaction.py", "review-manifest.json", "README.md",
                 ".gitattributes", "runtime-fork.patch", "v2-fork.patch")
START_FREE = 1_200_000_000
RUN_FREE = 500_000_000
MAX_LOG = 16_000_000
MAX_SOURCE_FILES = 10_000
MAX_SOURCE_BYTES = 512_000_000
BUILD_SECONDS = 1200
CLIPPY_SECONDS = 1200
TARGETS = {
    "lib": ("yoke", "lib", "native/src/lib.rs", 1200),
    "repository_discovery": ("repository_discovery", "test", "native/tests/repository_discovery.rs", 120),
    "github_app_ingress": ("github_app_ingress", "test", "native/tests/github_app_ingress.rs", 120),
    "process": ("process", "test", "native/tests/process.rs", 120),
    "agent_repl": ("agent_repl", "test", "native/tests/agent_repl.rs", 300),
}
PROTECTED = {"yoke.exe", "yoke.pdb", "capture_options-784339a4da3fe379.exe",
             "capture_options-784339a4da3fe379.pdb", "session_fixed_tools-0671ac4d8f474009.exe",
             "session_fixed_tools-0671ac4d8f474009.pdb"}
QUALIFICATION = (
    "Selected tracked source bytes and private controls are mapped before/after. "
    "External dependency/tool binaries, caches, all environment values and the entire host "
    "are not frozen. No broader platform, hosted CI, release or universal acceptance is implied. "
    "The host must execute these controllers serially and exclude other target-directory producers."
)


def require(value, message):
    if not value:
        raise RuntimeError(message)


def emit(value):
    print(json.dumps(value, ensure_ascii=True), flush=True)


def identity(info):
    return [info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_nlink]


def ordinary(path, directory=False):
    path = Path(path)
    require(path.is_absolute() and os.path.normpath(str(path)) == str(path), "Noncanonical absolute path")
    for ancestor in reversed(path.parents):
        info = ancestor.lstat()
        require(stat.S_ISDIR(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400,
                "Reparse or non-directory ancestor refused")
    info = path.lstat()
    require(not getattr(info, "st_file_attributes", 0) & 0x400, "Reparse point refused")
    require(stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode),
            "Unexpected filesystem object")
    if not directory:
        require(info.st_nlink == 1 and info.st_ino != 0, "Single-link file identity required")
    return info


def source_digest(path, maximum=64_000_000):
    # This generic byte reader can never hash any EXE/PDB, including a byproduct.
    require(path.suffix.lower() not in (".exe", ".pdb"), "Executable/PDB source read forbidden")
    before = ordinary(path)
    require(0 <= before.st_size <= maximum, "Source/control byte budget exceeded")
    digest = hashlib.sha256()
    count = 0
    with path.open("rb") as stream:
        while data := stream.read(1_048_576):
            count += len(data)
            require(count <= maximum, "Growing source/control byte budget exceeded")
            digest.update(data)
    require(identity(before) == identity(ordinary(path)) and count == before.st_size,
            "Source/control changed while hashing")
    return {"sha256": digest.hexdigest(), "bytes": count}


def controls_map():
    result = {name: source_digest(CONTROL / name, 1_000_000) for name in CONTROL_NAMES}
    require(result["private_windows_api.py"]["sha256"] == HELPER_SHA, "Private helper hash differs")
    return result


def write_json(out, name, value):
    require(re.fullmatch(r"[a-z0-9][a-z0-9.-]*\.json", name), "Invalid receipt name")
    ordinary(out, directory=True)
    # No receipt is overwritten, even on failure/retry.
    with (out / name).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, indent=2, ensure_ascii=True) + "\n")


def new_output(run_id):
    require(re.fullmatch(r"[a-z][a-z0-9-]{0,95}", run_id), "Invalid create-only run ID")
    ordinary(CONTROL.parent, directory=True)
    try:
        RUNS.mkdir()
    except FileExistsError:
        pass
    ordinary(RUNS, directory=True)
    out = RUNS / run_id
    out.mkdir(exist_ok=False)
    ordinary(out, directory=True)
    return out


def load_windows_api():
    # Never import the concurrently edited working-tree host probe. Compile only
    # the reviewed, hash-pinned private helper bytes; do not create __pycache__.
    path = CONTROL / "private_windows_api.py"
    require(source_digest(path, 65_536)["sha256"] == HELPER_SHA, "Private ABI helper differs")
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == HELPER_SHA, "Private helper changed before loading")
    namespace = {"__name__": "private_reviewed_windows_api"}
    exec(compile(data, str(path), "exec"), namespace)
    result = namespace["windows_api"]()
    require(isinstance(result, tuple) and len(result) == 4 and c.sizeof(c.c_void_p) == 8,
            "Original four-item Windows ABI required")
    api, extended, _, _ = result
    for name, args, return_type in (
        ("OpenProcess", [c.c_ulong, c.c_int, c.c_ulong], c.c_void_p),
        ("IsProcessInJob", [c.c_void_p, c.c_void_p, c.POINTER(c.c_int)], c.c_int),
        ("QueryFullProcessImageNameW", [c.c_void_p, c.c_ulong, c.c_wchar_p, c.POINTER(c.c_ulong)], c.c_int),
        ("CreateFileW", [c.c_wchar_p, c.c_ulong, c.c_ulong, c.c_void_p, c.c_ulong, c.c_ulong, c.c_void_p], c.c_void_p),
        ("CreateMutexW", [c.c_void_p, c.c_int, c.c_wchar_p], c.c_void_p),
        ("ReleaseMutex", [c.c_void_p], c.c_int),
    ):
        function = getattr(api, name)
        function.argtypes, function.restype = args, return_type
    return api, extended


class ReadPin:
    """One existing ordinary file; deny writes/deletion until closed."""
    def __init__(self, api, path, maximum, image=False):
        import msvcrt

        self.path, self.maximum, self.stream = path, maximum, None
        if not image:
            require(path.suffix.lower() not in (".exe", ".pdb"), "Generic pin cannot read executable/PDB")
        before = ordinary(path)
        require((0 < before.st_size if image else 0 <= before.st_size) and before.st_size <= maximum,
                "Pinned file byte budget exceeded")
        handle = api.CreateFileW(str(path), 0x80000000, 1, None, 3, 0x00200000, None)
        require(handle not in (None, c.c_void_p(-1).value), "Write-denying read pin unavailable")
        try:
            fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
        except BaseException:
            api.CloseHandle(handle)
            raise
        self.stream = os.fdopen(fd, "rb")
        try:
            info = os.fstat(self.stream.fileno())
            require(identity(info) == identity(before) and info.st_nlink == 1,
                    "Pinned file identity differs")
            self.initial_identity = identity(info)
            self.initial_sha = self.digest()
        except BaseException:
            self.close()
            raise

    def digest(self):
        self.stream.seek(0)
        digest = hashlib.sha256()
        count = 0
        while data := self.stream.read(1_048_576):
            count += len(data)
            require(count <= self.maximum, "Pinned file grew beyond byte budget")
            digest.update(data)
        require(count == os.fstat(self.stream.fileno()).st_size, "Pinned file read incomplete")
        self.stream.seek(0)
        return digest.hexdigest()

    def bytes(self):
        self.stream.seek(0)
        result = self.stream.read(self.maximum + 1)
        require(len(result) <= self.maximum, "Pinned text receipt grew")
        return result

    def recheck(self):
        require(identity(ordinary(self.path)) == self.initial_identity
                and identity(os.fstat(self.stream.fileno())) == self.initial_identity,
                "Pinned file namespace/identity changed")
        require(self.digest() == self.initial_sha, "Pinned bytes changed")
        return self.record()

    def record(self):
        return {"path": str(self.path), "sha256": self.initial_sha,
                "fileIdentity": self.initial_identity[:2], "bytes": self.initial_identity[2],
                "mtimeNs": self.initial_identity[3], "links": self.initial_identity[4],
                "noReparseAncestors": True, "writersAndDeletionDeniedThroughRecheck": True}

    def close(self):
        if self.stream is not None:
            self.stream.close()
            self.stream = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        try:
            self.recheck()
        finally:
            self.close()


def run_owned(api, extended, out, label, argv, environment, seconds, cap=MAX_LOG,
              *, absolute_deadline_ns=None, job_name=None):
    """Every child (including read-only Git) is suspended and Job-assigned."""
    import _winapi
    import msvcrt

    require(re.fullmatch(r"[a-z0-9-]+", label), "Invalid command receipt label")
    require(Path(argv[0]).is_absolute(), "Absolute host-selected executable required")
    require(shutil.disk_usage("C:\\").free >= START_FREE, "1.2 GB start admission unavailable")
    row = {"command": argv, "deadlineSeconds": seconds, "logCapBytes": cap,
           "stdinClosed": False, "startedSuspended": False, "assignedBeforeResume": False,
           "completed": False, "treeExitedBeforeCleanup": False,
           "minimumFreeObserved": shutil.disk_usage("C:\\").free,
           "cleanupErrors": [], "streamEOF": [False, False], "readerErrors": [False, False]}
    job = process = thread = None
    assigned = False
    fds, readers, streams = [], [], []
    overflow = threading.Event()
    lock = threading.Lock()
    written = [0]
    started = time.monotonic()
    started_ns = time.monotonic_ns()
    require(type(seconds) is int and seconds > 0, "Positive fixed deadline required")
    if absolute_deadline_ns is None:
        absolute_deadline_ns = started_ns + seconds * 1_000_000_000
    require(type(absolute_deadline_ns) is int
            and started_ns < absolute_deadline_ns <= started_ns + seconds * 1_000_000_000,
            "Absolute deadline expired or refreshed")
    require(job_name is None or re.fullmatch(r"Local\\YokeCompilerLLD-[0-9a-f]{64}", job_name),
            "Closed compiler transaction Job name required")
    end = min(started + seconds, absolute_deadline_ns / 1_000_000_000)
    row.update(startedMonotonicNs=started_ns, absoluteDeadlineNs=absolute_deadline_ns,
               jobName=job_name, namedJobCreatedNew=False)

    def active():
        data = c.create_string_buffer(48)
        require(api.QueryInformationJobObject(job, 1, data, 48, None), "Owned Job accounting unavailable")
        return int.from_bytes(data.raw[40:44], "little")

    def members():
        data = c.create_string_buffer(8 + 8 * 2048)
        require(api.QueryInformationJobObject(job, 3, data, len(data), None), "Owned Job members unavailable")
        assigned_count = int.from_bytes(data.raw[0:4], "little")
        count = int.from_bytes(data.raw[4:8], "little")
        require(count <= 2048 and assigned_count == count, "Owned Job member list partial/over capacity")
        result = []
        for index in range(count):
            pid = int.from_bytes(data.raw[8 + 8 * index:16 + 8 * index], "little")
            item = {"pid": pid, "imageBytesRead": False, "imageIdentityKnown": False}
            handle = api.OpenProcess(0x101000, False, pid)
            if handle:
                try:
                    inside = c.c_int()
                    if api.IsProcessInJob(handle, job, c.byref(inside)) and inside.value:
                        item["membershipConfirmed"] = True
                        name = c.create_unicode_buffer(32768)
                        size = c.c_ulong(len(name))
                        if api.QueryFullProcessImageNameW(handle, 0, name, c.byref(size)):
                            item["imagePathMetadata"] = name.value
                            # A path query is deliberately not a file identity/byte observation.
                        else:
                            item["imageQueryError"] = c.get_last_error()
                    else:
                        item["membershipConfirmed"] = False
                        item["membershipQueryError"] = c.get_last_error()
                finally:
                    require(api.CloseHandle(handle), "Owned member metadata handle close failed")
            else:
                item["openError"] = c.get_last_error()
            result.append(item)
        return result

    def drain_stream(index, fd, stream):
        try:
            while True:
                data = os.read(fd, 8192)
                if not data:
                    row["streamEOF"][index] = True
                    break
                with lock:
                    available = max(0, cap - written[0])
                    accepted = data[:available]
                    if accepted:
                        require(stream.write(accepted) == len(accepted), "Partial capped log write")
                    written[0] += len(accepted)
                    if len(data) > available:
                        overflow.set()
        except BaseException:
            row["readerErrors"][index] = True
            overflow.set()
        finally:
            try:
                os.close(fd)
            except OSError:
                row["readerErrors"][index] = True

    try:
        c.set_last_error(0)
        job = api.CreateJobObjectW(None, job_name)
        create_error = c.get_last_error()
        require(job, "Private Job unavailable")
        if job_name is not None and create_error == 183:
            # A collision handle does not confer ownership. In particular the
            # finally block must never terminate or query that existing Job.
            occupied, job = job, None
            if not api.CloseHandle(occupied):
                row["cleanupErrors"].append("occupied-job-handle-close")
            raise RuntimeError("Named Job already occupied")
        row["namedJobCreatedNew"] = job_name is not None
        limits = extended()
        limits.basic.flags = 0x2000
        require(api.SetInformationJobObject(job, 9, c.byref(limits), c.sizeof(limits)),
                "Kill-on-close Job limits unavailable")
        for suffix in (".stdout", ".stderr"):
            streams.append((out / (label + suffix)).open("xb", buffering=0))
        stdin_read, stdin_write = os.pipe()
        fds.extend((stdin_read, stdin_write))
        stdout_read, stdout_write = os.pipe()
        fds.extend((stdout_read, stdout_write))
        stderr_read, stderr_write = os.pipe()
        fds.extend((stderr_read, stderr_write))
        child_handles = [msvcrt.get_osfhandle(fd) for fd in (stdin_read, stdout_write, stderr_write)]
        for handle in child_handles:
            os.set_handle_inheritable(handle, True)
        startup = subprocess.STARTUPINFO()
        startup.dwFlags = subprocess.STARTF_USESTDHANDLES
        startup.hStdInput, startup.hStdOutput, startup.hStdError = child_handles
        startup.lpAttributeList = {"handle_list": child_handles}
        require(time.monotonic_ns() < absolute_deadline_ns, "Absolute launch deadline expired")
        process, thread, pid, _ = _winapi.CreateProcess(
            str(argv[0]), subprocess.list2cmdline(argv), None, None, True,
            subprocess.CREATE_NO_WINDOW | 4, environment, str(ROOT), startup)
        row.update(pid=pid, startedSuspended=True)
        require(api.AssignProcessToJobObject(job, process), "Suspended Job assignment failed")
        assigned = True
        row["assignedBeforeResume"] = True
        for fd in (stdin_read, stdin_write, stdout_write, stderr_write):
            os.close(fd)
            fds.remove(fd)
        row["stdinClosed"] = True
        for index, fd in enumerate((stdout_read, stderr_read)):
            reader = threading.Thread(target=drain_stream, args=(index, fd, streams[index]), daemon=True)
            readers.append(reader)
            reader.start()
            fds.remove(fd)
        row["resumePreviousSuspendCount"] = api.ResumeThread(thread)
        require(row["resumePreviousSuspendCount"] == 1, "Primary suspended thread resume failed")
        previous = time.monotonic()
        while True:
            status = _winapi.WaitForSingleObject(process, 50)
            free = shutil.disk_usage("C:\\").free
            row["minimumFreeObserved"] = min(row["minimumFreeObserved"], free)
            if free < RUN_FREE:
                row["stopReason"] = "disk-reserve"
            elif time.monotonic() >= end:
                row["stopReason"] = "deadline"
            elif overflow.is_set():
                row["stopReason"] = "log-or-reader-budget"
            if status == 0:
                row["exitCode"] = _winapi.GetExitCodeProcess(process)
                break
            require(status == 258, "Owned root wait failed")
            if row.get("stopReason"):
                break
            if time.monotonic() - previous >= 30:
                emit({"owner": OWNER, "run": out.name, "command": label,
                      "freeBytes": free, "capturedLogBytes": written[0]})
                previous = time.monotonic()
        row["rootObservedMonotonicNs"] = time.monotonic_ns()
        row["membersAtRootObservation"] = members()
        row["rootExitedAtObservation"] = _winapi.WaitForSingleObject(process, 0) == 0
        row["activeAtRootObservation"] = active()
        drain_end = min(end, time.monotonic() + 1)
        row["originalDrainSeconds"] = 1
        row["activeBeforeCleanup"] = active()
        while row["activeBeforeCleanup"] and time.monotonic() < drain_end:
            time.sleep(.01)
            free = shutil.disk_usage("C:\\").free
            row["minimumFreeObserved"] = min(row["minimumFreeObserved"], free)
            if free < RUN_FREE:
                row["stopReason"] = "disk-reserve"
                break
            row["activeBeforeCleanup"] = active()
        row["membersAfterOriginalDrain"] = members()
        row["treeExitedBeforeCleanup"] = row["activeBeforeCleanup"] == 0
        row["treeObservedMonotonicNs"] = time.monotonic_ns()
        if row["treeObservedMonotonicNs"] >= absolute_deadline_ns:
            row["stopReason"] = "deadline"
    except BaseException as error:
        row["errorType"], row["error"] = type(error).__name__, str(error)
    finally:
        # Two seconds total, including accounting, root wait, and pipe EOF.
        cleanup_end = time.monotonic() + 2
        row["cleanupSeconds"] = 2
        if process is not None and not assigned:
            try:
                _winapi.TerminateProcess(process, 124)
            except OSError:
                row["cleanupErrors"].append("own-unassigned-root-termination")
        if job is not None:
            if not api.TerminateJobObject(job, 125):
                row["cleanupErrors"].append("own-job-termination")
            try:
                while active() and time.monotonic() < cleanup_end:
                    time.sleep(.01)
                row["activeAfterCleanup"] = active()
                if row["activeAfterCleanup"] != 0:
                    row["cleanupErrors"].append("job-still-active")
            except BaseException:
                row["activeAfterCleanup"] = None
                row["cleanupErrors"].append("job-accounting")
        else:
            row["activeAfterCleanup"] = None
        row["rootExitedAfterCleanup"] = process is None
        if process is not None:
            try:
                remaining_ms = max(0, int((cleanup_end - time.monotonic()) * 1000))
                row["rootExitedAfterCleanup"] = _winapi.WaitForSingleObject(process, remaining_ms) == 0
                if not row["rootExitedAfterCleanup"]:
                    row["cleanupErrors"].append("root-exit")
            except OSError:
                row["cleanupErrors"].append("root-wait")
        for reader in readers:
            try:
                reader.join(max(0, cleanup_end - time.monotonic()))
                if reader.is_alive():
                    row["cleanupErrors"].append("log-reader-still-active")
            except BaseException:
                row["cleanupErrors"].append("log-reader-join")
        for fd in fds:
            try:
                os.close(fd)
            except OSError:
                row["cleanupErrors"].append("pipe-close")
        for handle in (thread, process, job):
            if handle is not None and not api.CloseHandle(handle):
                row["cleanupErrors"].append("handle-close")
        for stream in streams:
            try:
                stream.close()
            except OSError:
                row["cleanupErrors"].append("log-close")
    row.update(elapsedSeconds=time.monotonic() - started, capturedLogBytes=written[0],
               outputExceeded=overflow.is_set())
    row["cleanupUnproven"] = bool(row["cleanupErrors"])
    row["completed"] = ("errorType" not in row and not row.get("stopReason")
                        and row.get("exitCode") == 0 and row["startedSuspended"]
                        and row["assignedBeforeResume"] and row["stdinClosed"]
                        and row.get("resumePreviousSuspendCount") == 1
                        and row["treeExitedBeforeCleanup"] and row.get("activeAfterCleanup") == 0
                        and row["rootExitedAfterCleanup"] and not row["cleanupUnproven"]
                        and all(row["streamEOF"]) and not any(row["readerErrors"])
                        and not row["outputExceeded"])
    write_json(out, label + ".job.json", row)
    return row


def environment_for(mode):
    environment = os.environ.copy()
    forbidden = []
    for key, value in environment.items():
        upper = key.upper()
        if (upper in {"RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS", "CARGO_ENCODED_RUSTDOCFLAGS",
                      "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "RUSTC", "RUSTDOC", "CARGO_BUILD_TARGET",
                      "CARGO_TARGET_DIR", "CARGO_BUILD_RUSTFLAGS", "CARGO_BUILD_RUSTC", "CARGO_BUILD_RUSTDOC",
                      "CARGO_BUILD_TARGET_DIR", "CARGO_BUILD_BUILD_DIR",
                      "CARGO_INCREMENTAL", "RUSTC_BOOTSTRAP",
                      "CARGO_BUILD_RUSTC_WRAPPER", "CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER",
                      "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_CONFIG_PARAMETERS", "GIT_CONFIG_COUNT"}
                or upper.startswith(("CARGO_PROFILE_", "CARGO_UNSTABLE_"))
                or upper.startswith("CARGO_TARGET_") and upper.endswith(("_RUSTFLAGS", "_RUNNER", "_LINKER"))):
            if value:
                forbidden.append(key)
    require(not forbidden, "Ambient compiler/target/runner/Git overrides refused: " + ", ".join(sorted(forbidden)))
    environment["PATH"] = str(CARGO.parent) + os.pathsep + environment.get("PATH", "")
    environment.update(GIT_TERMINAL_PROMPT="0", GIT_OPTIONAL_LOCKS="0")
    if mode == "test":
        for key in ("SSL_CERT_FILE", "SSL_CERT_DIR", "SSLKEYLOGFILE"):
            environment.pop(key, None)
    # Do not read global configuration contents or any credential file. Unknown
    # Cargo policy refuses rather than silently changing features/profiles/flags.
    cargo_home = Path(environment.get("CARGO_HOME", str(Path.home() / ".cargo")))
    require(cargo_home.is_absolute(), "Absolute Cargo home required")
    directories = [base / ".cargo" for base in (ROOT, *ROOT.parents)] + [cargo_home]
    for directory in set(directories):
        for name in ("config", "config.toml"):
            candidate = directory / name
            require(not os.path.lexists(candidate), "Existing Cargo configuration requires separate host review")
    return environment


def git_capture(api, extended, out, environment, label, arguments):
    git = shutil.which("git.exe", path=environment["PATH"])
    require(git and Path(git).is_absolute(), "Host Git unavailable")
    argv = [git, "--no-optional-locks", "-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false",
            *arguments]
    result = run_owned(api, extended, out, label, argv, environment, 30, cap=2_000_000)
    require(result["completed"], "Read-only Git observation incomplete: " + label)
    return (out / (label + ".stdout")).read_bytes()


def source_map(api, extended, out, environment, commit, phase):
    # Untracked Cargo configuration can alter a later compiler invocation while
    # remaining invisible to the tracked-only Git inventory below.
    require(environment_for("build") == environment, "Cargo environment/configuration changed")
    head = git_capture(api, extended, out, environment, "git-head-" + phase,
                       ["rev-parse", "--verify", "HEAD"]).decode("ascii").strip()
    require(head == commit, "HEAD differs from exact host-supplied source commit")
    status = git_capture(api, extended, out, environment, "git-status-" + phase,
                         ["status", "--porcelain=v1", "-z", "--untracked-files=no"])
    require(not status, "Tracked checkout is not clean")
    listing = git_capture(api, extended, out, environment, "git-files-" + phase,
                          ["ls-files", "-z"]).decode("utf-8", "strict")
    names = [name for name in listing.split("\0") if name]
    require(len(names) == len(set(names)) and len(names) <= 100_000, "Tracked inventory duplicate/over capacity")
    selected = sorted(name for name in names if name.startswith(("native/", "scripts/", ".cargo/"))
                      or Path(name).name in ("Cargo.toml", "Cargo.lock", "rust-toolchain", "rust-toolchain.toml")
                      or name == ".github/workflows/rust.yml")
    require({"Cargo.toml", "Cargo.lock", "native/Cargo.toml", "scripts/host_powershell_probe.py",
             "scripts/run_native_tests.py", "scripts/ci_windows_temp.py", "scripts/native_shards.py",
             ".github/workflows/rust.yml"}.issubset(selected), "Required tracked inputs missing")
    for name in selected:
        require(not Path(name).is_absolute() and ".." not in Path(name).parts and "\\" not in name
                and ":" not in name and all(ord(character) >= 32 for character in name)
                and all(part.rstrip(" .") == part for part in Path(name).parts),
                "Noncanonical tracked source path")
    result = hash_selected(selected)
    write_json(out, "source-" + phase + ".json", result)
    return result


def hash_selected(names):
    require(len(names) <= MAX_SOURCE_FILES, "Selected source file count budget exceeded")
    result, size = {}, 0
    end = time.monotonic() + 120
    for name in names:
        require(time.monotonic() < end, "Selected source hashing deadline exceeded")
        entry = source_digest(ROOT / name)
        size += entry["bytes"]
        require(size <= MAX_SOURCE_BYTES, "Selected source total byte budget exceeded")
        result[name] = entry
    return result


def unique_json(data):
    def pairs(values):
        result = {}
        for key, value in values:
            require(key not in result, "Duplicate JSON object key")
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=pairs)


def cargo_command(mode, target):
    if mode == "clippy":
        return [str(CARGO), "clippy", "--workspace", "--all-targets", "--locked", "--keep-going",
                "-j2", "--message-format=json", "--", "-D", "warnings"]
    selector = ["--lib"] if target == "lib" else ["--test", target]
    return [str(CARGO), "test", *selector, "--no-run", "--locked", "-j1", "--message-format=json"]


def cargo_summary(data, target=None):
    require(len(data) <= MAX_LOG, "Cargo log exceeds retained cap")
    finished, artifacts, selected = [], 0, []
    warnings = errors = 0
    for line in data.splitlines():
        if not line.strip():
            continue
        require(len(line) <= 2_000_000, "Cargo JSON line budget exceeded")
        item = unique_json(line)
        require(isinstance(item, dict), "Cargo stdout is not JSON objects")
        reason = item.get("reason")
        if reason == "build-finished":
            finished.append(item.get("success"))
        elif reason == "compiler-message":
            level = item.get("message", {}).get("level")
            warnings += level == "warning"
            errors += level in ("error", "ice")
        elif reason == "compiler-artifact":
            artifacts += 1
            if target is not None:
                name, kind, source, _ = TARGETS[target]
                description = item.get("target", {})
                if (description.get("name") == name and description.get("kind") == [kind]
                        and item.get("profile", {}).get("test") is True):
                    require(Path(description.get("src_path", "")) == ROOT / source, "Selected artifact source differs")
                    require(isinstance(item.get("package_id"), str) and "yoke-code-intelligence" in item["package_id"],
                            "Selected artifact package differs")
                    selected.append(item)
    require(finished == [True] and errors == 0, "Cargo build-finished success/diagnostics unavailable")
    summary = {"buildFinishedSuccess": True, "warningDiagnostics": warnings, "errorDiagnostics": errors,
               "compilerArtifactObservations": artifacts,
               "byproductImageBytesRead": False}
    if target is not None:
        require(len(selected) == 1 and selected[0].get("fresh") is False,
                "Exactly one fresh:false selected compiler artifact required; cached images refused")
        summary["selectedArtifact"] = selected[0]
    return summary


def image_path(artifact, target):
    text = artifact.get("executable")
    require(isinstance(text, str), "Selected compiler artifact has no executable")
    image = Path(text)
    name = TARGETS[target][0]
    require(image.is_absolute() and image.parent == ROOT / "target/debug/deps"
            and image.name.lower() not in PROTECTED
            and re.fullmatch(re.escape(name) + r"-[a-f0-9]{16}\.exe", image.name),
            "Image is not the exact selected hashed deps test image")
    ordinary(image)
    return image


def test_summary(data):
    matches = re.findall(rb"(?m)^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
                         rb"(\d+) measured; (\d+) filtered out;[^\r\n]*", data)
    require(matches, "Original parent libtest summary unavailable")
    status, passed, failed, ignored, measured, filtered = matches[-1]
    result = dict(zip(("passed", "failed", "ignored", "measured", "filteredOut"),
                      map(int, (passed, failed, ignored, measured, filtered))))
    require(status == b"ok" and result["failed"] == 0 and result["filteredOut"] == 0,
            "Whole-group default libtest result did not pass")
    result["existingIgnoredPromoted"] = False
    result["summaryLineCountIncludingNestedOutput"] = len(matches)
    return result


def producer_admission(stack, api, run_id, commit, target, sources, controls):
    require(re.fullmatch(r"[a-z][a-z0-9-]{0,95}", run_id), "Invalid producer run ID")
    producer = RUNS / run_id
    ordinary(producer, directory=True)
    names = ("request.json", "result.json", "source-before.json", "source-after.json", "source-final.json",
             "control-before.json", "control-after.json", "control-final.json", "command.job.json", "command.stdout",
             "command.stderr",
             "cargo-summary.json", "selected-image.json", "selected-image-after.json")
    pins = {name: stack.enter_context(ReadPin(api, producer / name, MAX_LOG)) for name in names}
    values = {name: unique_json(pin.bytes()) for name, pin in pins.items() if name.endswith(".json")}
    request, result, job = values["request.json"], values["result.json"], values["command.job.json"]
    require(request.get("owner") == result.get("owner") == OWNER
            and request.get("schema") == result.get("schema") == SCHEMA
            and request.get("sourceCommit") == result.get("sourceCommit") == commit
            and request.get("mode") == result.get("mode") == "build"
            and request.get("target") == result.get("target") == target
            and request.get("runId") == result.get("runId") == run_id and result.get("completed") is True
            and result.get("inputsUnchanged") is True, "Producer is not this controller's completed matching build")
    require(values["source-before.json"] == values["source-after.json"] == values["source-final.json"] == sources
            and values["control-before.json"] == values["control-after.json"] == values["control-final.json"] == controls,
            "Producer source/control byte maps differ")
    require(job.get("command") == result.get("command") == cargo_command("build", target)
            and job.get("completed") is True and job.get("startedSuspended") is True
            and job.get("assignedBeforeResume") is True and job.get("treeExitedBeforeCleanup") is True
            and job.get("activeAfterCleanup") == 0 and job.get("rootExitedAfterCleanup") is True
            and job.get("cleanupUnproven") is False, "Producer owner/command/cleanup incomplete")
    summary = cargo_summary(pins["command.stdout"].bytes(), target)
    require(summary == values["cargo-summary.json"], "Producer Cargo summary differs from raw evidence")
    artifact = summary["selectedArtifact"]
    image = image_path(artifact, target)
    record = values["selected-image.json"]
    require(record == values["selected-image-after.json"] == result.get("selectedImage") and record.get("path") == str(image)
            and result.get("selectedArtifact") == artifact, "Producer selected image binding differs")
    return image, record, pins, artifact


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("build", "test", "clippy"))
    parser.add_argument("--target", choices=tuple(TARGETS))
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--producer-run-id")
    args = parser.parse_args()
    require(os.name == "nt", "Controllers require Windows")
    require(re.fullmatch(r"[0-9a-f]{40}", args.source_commit), "Exact host-supplied source commit required")
    require((args.mode == "clippy") == (args.target is None), "Build/test requires one selected target; Clippy takes none")
    require((args.mode == "test") == (args.producer_run_id is not None), "Only tests require a producer run ID")
    require(args.run_id != args.producer_run_id, "Run and producer IDs must differ")
    ordinary(ROOT, directory=True)
    ordinary(CONTROL, directory=True)
    api, extended = load_windows_api()
    out = new_output(args.run_id)
    result = {"owner": OWNER, "schema": SCHEMA, "runId": args.run_id, "mode": args.mode,
              "target": args.target, "sourceCommit": args.source_commit, "completed": False,
              "inputsUnchanged": False, "nativeImageRead": False, "testExecutionRequested": args.mode == "test",
              "nativeImageReadAttempted": False,
              "metadataOnly": args.mode == "clippy", "qualification": QUALIFICATION}
    write_json(out, "request.json", {**result, "producerRunId": args.producer_run_id,
                                    "startAdmissionBytes": START_FREE, "runtimeReserveBytes": RUN_FREE})
    source_before = control_before = None
    environment = None
    mutex = None
    mutex_owned = False
    command_started = False
    try:
        # The local named mutex coordinates these controllers only. It does not
        # claim exclusive control of arbitrary external Cargo invocations.
        import _winapi

        mutex_name = "Local\\YokeValidation-" + hashlib.sha256(str(ROOT).encode("utf-8")).hexdigest()[:24]
        mutex = api.CreateMutexW(None, False, mutex_name)
        require(mutex, "Controller serial mutex unavailable")
        mutex_status = _winapi.WaitForSingleObject(mutex, 0)
        require(mutex_status in (0, 128), "Another validation controller is active")
        mutex_owned = True
        result["serialMutexAbandoned"] = mutex_status == 128
        environment = environment_for(args.mode)
        control_before = controls_map()
        write_json(out, "control-before.json", control_before)
        source_before = source_map(api, extended, out, environment, args.source_commit, "before")
        if args.target is not None:
            selected_source = TARGETS[args.target][2]
            result["selectedSource"] = {"path": selected_source, **source_before[selected_source]}
        with ExitStack() as stack:
            image_pin = None
            producer_pins = {}
            if args.mode == "test":
                image, producer_image, producer_pins, producer_artifact = producer_admission(
                    stack, api, args.producer_run_id, args.source_commit, args.target, source_before, control_before)
                result["selectedArtifact"] = producer_artifact
                require(shutil.disk_usage("C:\\").free >= START_FREE, "Native image admission unavailable")
                result.update(nativeImageRead=None, nativeImageReadAttempted=True)
                image_pin = stack.enter_context(ReadPin(api, image, 512_000_000, image=True))
                result["nativeImageRead"] = True
                require(image_pin.record() == producer_image, "Selected image differs from fresh producer pin")
                write_json(out, "selected-image.json", image_pin.record())
                write_json(out, "producer-before.json", {name: pin.record() for name, pin in producer_pins.items()})

                def recheck_pins_on_exit():
                    # Runs even when command/cleanup/input validation failed, while
                    # all evidence and image pins are still held.
                    write_json(out, "selected-image-after.json", image_pin.recheck())
                    write_json(out, "producer-after.json", {name: pin.recheck() for name, pin in producer_pins.items()})

                stack.callback(recheck_pins_on_exit)
                result["producerRunId"] = args.producer_run_id
                argv, seconds = [str(image), "--test-threads=1", "--nocapture"], TARGETS[args.target][3]
            else:
                argv = cargo_command(args.mode, args.target)
                seconds = CLIPPY_SECONDS if args.mode == "clippy" else BUILD_SECONDS
            result["command"] = argv
            command_started = True
            job = run_owned(api, extended, out, "command", argv, environment, seconds)
            result["commandOwnerCompleted"] = job["completed"]
            if args.mode == "test":
                result["testImageResumed"] = job.get("resumePreviousSuspendCount") == 1
            require(job.get("activeAfterCleanup") == 0 and job.get("rootExitedAfterCleanup") is True
                    and not job.get("cleanupUnproven"), "Cleanup unproven; no further commands admitted")
            # Recheck source and controls before selecting ANY built image.
            source_after = source_map(api, extended, out, environment, args.source_commit, "after")
            control_after = controls_map()
            write_json(out, "control-after.json", control_after)
            result["inputsUnchanged"] = source_before == source_after and control_before == control_after
            require(result["inputsUnchanged"], "Source/control inputs changed")
            result["sourceInputCount"] = len(source_before)
            require(job["completed"], "Owned command incomplete; no image adoption or acceptance")
            if args.mode == "test":
                result["selectedImage"] = image_pin.recheck()
                result["testSummary"] = test_summary((out / "command.stdout").read_bytes())
                result["wholeGroupNoNameFilter"] = True
            else:
                summary = cargo_summary((out / "command.stdout").read_bytes(),
                                        args.target if args.mode == "build" else None)
                write_json(out, "cargo-summary.json", summary)
                if args.mode == "clippy":
                    require(summary["warningDiagnostics"] == 0, "Clippy warning diagnostics remain")
                else:
                    artifact = summary["selectedArtifact"]
                    image = image_path(artifact, args.target)
                    require(shutil.disk_usage("C:\\").free >= START_FREE, "Native image admission unavailable")
                    result.update(nativeImageRead=None, nativeImageReadAttempted=True)
                    pin = stack.enter_context(ReadPin(api, image, 512_000_000, image=True))
                    result["nativeImageRead"] = True
                    result["selectedArtifact"] = artifact
                    result["selectedImage"] = pin.recheck()
                    write_json(out, "selected-image.json", result["selectedImage"])
                    stack.callback(lambda: write_json(out, "selected-image-after.json", pin.recheck()))
            final_sources = source_map(api, extended, out, environment, args.source_commit, "final")
            final_controls = controls_map()
            write_json(out, "control-final.json", final_controls)
            result["inputsUnchanged"] = final_sources == source_before and final_controls == control_before
            require(result["inputsUnchanged"], "Inputs changed during final image/receipt checks")
            result["completed"] = True
    except BaseException as error:
        result.update(completed=False, errorType=type(error).__name__, error=str(error))
    finally:
        if command_started and source_before is not None and not result["completed"]:
            # Byte-only recovery observation: do not start Git or another child
            # after any uncertain lifecycle. Preserve ordinary after maps too.
            try:
                failed_after = hash_selected(source_before)
                write_json(out, "source-after-failure.json", failed_after)
                failed_controls = controls_map()
                write_json(out, "control-after-failure.json", failed_controls)
                result["failureByteInputsUnchanged"] = failed_after == source_before and failed_controls == control_before
                if not result["failureByteInputsUnchanged"]:
                    result["inputsUnchanged"] = False
                result["failureByteRecheckIsNotCleanHeadProof"] = True
            except BaseException as error:
                result["failureInputRecheckErrorType"] = type(error).__name__
        if mutex_owned and not api.ReleaseMutex(mutex):
            result.update(completed=False, serialMutexReleaseUnproven=True)
        if mutex is not None and not api.CloseHandle(mutex):
            result.update(completed=False, serialMutexCloseUnproven=True)
        result["freeAfter"] = shutil.disk_usage("C:\\").free
        if result["freeAfter"] < RUN_FREE:
            result.update(completed=False, finalRuntimeReserveUnavailable=True)
        write_json(out, "result.json", result)
        emit(result)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    raise SystemExit("Library-only compiler transaction runtime")
