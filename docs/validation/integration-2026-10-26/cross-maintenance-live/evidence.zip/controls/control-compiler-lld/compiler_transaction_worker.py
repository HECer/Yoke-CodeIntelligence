"""Hash-pinned worker; an exact named outer Job is mandatory before Cargo."""
import hashlib
import os
from pathlib import Path
import stat
import sys


PROTOCOL_SHA = "eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a"


def main():
    if len(sys.argv) != 2 or os.name != "nt":
        return 1
    path = Path(__file__).absolute().parent / "transaction_protocol.py"
    try:
        before = path.lstat()
        if (not stat.S_ISREG(before.st_mode) or before.st_nlink != 1
                or getattr(before, "st_file_attributes", 0) & 0x400 or not 0 < before.st_size <= 1_000_000):
            return 1
        for ancestor in path.parents:
            info = ancestor.lstat()
            if not stat.S_ISDIR(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                return 1
        data = path.read_bytes()
        after = path.lstat()
        if ((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_nlink) !=
                (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_nlink)
                or hashlib.sha256(data).hexdigest() != PROTOCOL_SHA):
            return 1
        namespace = {"__name__": "reviewed_compiler_lld_protocol", "__file__": str(path)}
        exec(compile(data, str(path), "exec"), namespace)
        return namespace["worker_entry"](sys.argv[1])
    except BaseException:
        return 1


if __name__ == "__main__":
    # No implicit thread/process teardown or fresh cleanup interval. The
    # containing outer Job is the sole whole-tree abort authority.
    os._exit(main())
