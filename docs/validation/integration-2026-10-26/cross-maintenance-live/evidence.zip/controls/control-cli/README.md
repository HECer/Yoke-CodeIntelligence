# Private release CLI controller: pending review and execution

This preparation does not qualify a CLI, release, VSIX or platform. It leaves
the original platform-repair controller and its published receipts unchanged.

cli_controller.py loads an exact copy of that reviewed controller as
base_controller.py (SHA-256
a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7).
The four-item Windows API helper remains byte-exact, SHA-256
d9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500.
No existing Yoke image/PDB is read, hashed or adopted during preparation.

## Fixed scopes

The build invokes only cargo rustc --package yoke-code-intelligence --bin yoke
--release --locked --offline -j2 --message-format=json -- -o
<fresh-run-directory>/owned-release-cli.exe.
It preserves the release profile, 3600-second build ceiling, 4 GB release-start
floor and independent 500 MB running reserve. It does not qualify the whole
workspace. The source must already be committed and clean and remain unchanged.

The consumer accepts only --version on this controller's completed matching
producer, under the existing 30-second ceiling and 1.2 GB image admission. It
does not accept an arbitrary executable or arbitrary runtime arguments.
Functional CLI/Session/history fixtures require a later separately reviewed
consumer. A version result cannot establish those behaviors.

Both phases keep suspended creation/assignment before resume, one-second
original process drain, two-second total cleanup, finite capture, source/control
maps, producer receipt pins, single-link/non-reparse image identity and byte
rechecks through a write/delete-denying read handle. A Cargo exit code of zero
cannot substitute for an empty owned tree before cleanup.

The tiny owned output-path probe in ../cargo-output-path-probe/ emitted its
requested private file, but its producer remained incomplete because an owned
member survived the original drain. No probe image was read or adopted.
Cargo reported no filename and retained its default executable path in that
observation. Therefore this controller explicitly binds the fresh private output
role to the fixed host argument; it never claims that Cargo's executable field
attests that private file. Unexpected observations refuse.

Existing protected default paths are held with FILE_EXECUTE and
FILE_READ_ATTRIBUTES, without FILE_READ_DATA. This establishes sharing denial
while allowing metadata queries. Write denial applies to the file; deletion
denial applies to each held pathname. The fixed list holds known aliases
separately and does not claim to lock every possible alias namespace. A later
link-count or identity change refuses. Opening a file handle does not launch or
load its image; it is not inherited. Those handles cannot read executable/PDB
bytes. Unknown occupants or changed metadata refuse. No protected process is
opened by this mechanism. Retained own-text failures show why attribute-only
write denial and deletion denial through an unheld alias are not assumed.

## Parent execution

After independent source review, sufficient storage and completed source
integration, run serially with the real final commit:

    $finalSourceCommit = '<40-hex-commit>'
    python validation/integration-20261025/platform-repairs/control-cli/cli_controller.py build --source-commit $finalSourceCommit --run-id release-cli-reviewed
    if ($LASTEXITCODE -ne 0) { throw 'Incomplete release producer: no adoption' }
    python validation/integration-20261025/platform-repairs/control-cli/cli_controller.py version --source-commit $finalSourceCommit --run-id release-version-reviewed --producer-run-id release-cli-reviewed
    if ($LASTEXITCODE -ne 0) { throw 'Version qualification failed' }

Do not execute while other Cargo producers or source writers are active. The
shared local mutex coordinates these controllers, not arbitrary host processes.
External dependencies, tools, caches, environment and the entire host are not
frozen; the receipts are scoped observations, not sandbox or supply-chain proof.
Do not execute or salvage an image from an incomplete producer.

The protected-role route now records all lexical ancestor identities before opening any leaf and rechecks them throughout, including absent leaves. Junction/reparse ancestors and unavailable identities refuse. Five own-text tests pass for ordinary and hard-linked files, present/absent leaves under a real junction, replaced ancestors and unavailable identities. These checks do not execute a Yoke image or qualify the release producer. The initial unavailable-identity test mock dropped Windows attributes and failed; the corrected mock preserves them.
