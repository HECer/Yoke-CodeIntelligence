"""Own-text filesystem checks; never reads or executes native images."""
import os
from pathlib import Path
import runpy
import tempfile
import unittest
from types import SimpleNamespace
from unittest import mock


CONTROL = Path(__file__).parent
SOURCE = CONTROL / "cli_controller.py"
NAMESPACE = runpy.run_path(str(SOURCE), run_name="metadata_pin_test_source")
MetadataPin = NAMESPACE["MetadataPin"]
GLOBALS = MetadataPin.__init__.__globals__


class MetadataPinTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.api, _ = NAMESPACE["load_base"]()["load_windows_api"]()

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="yoke-metadata-pin-")
        self.root = Path(self.temporary.name).resolve()
        self.patch = mock.patch.dict(GLOBALS, ROOT=self.root)
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.temporary.cleanup()

    def test_ordinary_and_hard_linked_text_keep_sharing_denial(self):
        target = self.root / "owned.txt"
        alias = self.root / "alias.txt"
        target.write_bytes(b"owned metadata fixture")
        os.link(target, alias)
        original = target.read_bytes()
        with MetadataPin(self.api, "owned.txt") as pin:
            observation = pin.recheck()
            self.assertEqual(observation["metadata"]["links"], 2)
            self.assertTrue(observation["fileWritesDenied"])
            self.assertFalse(observation["imageBytesRead"])
            with self.assertRaises(OSError):
                target.write_bytes(b"must refuse")
        self.assertEqual(target.read_bytes(), original)
        self.assertEqual(alias.read_bytes(), original)

    def test_absent_leaf_has_ordinary_ancestor_receipt(self):
        with MetadataPin(self.api, "missing.txt") as pin:
            observation = pin.recheck()
            self.assertFalse(observation["metadata"]["exists"])
            self.assertTrue(observation["ancestors"])
            self.assertFalse(observation["fileWritesDenied"])

    def test_present_and_absent_leaves_below_junction_refuse_before_open(self):
        import _winapi
        destination = self.root / "destination"
        destination.mkdir()
        foreign = destination / "foreign.txt"
        original = b"foreign text must stay exact"
        foreign.write_bytes(original)
        junction = self.root / "junction"
        _winapi.CreateJunction(str(destination), str(junction))
        try:
            for leaf in ("foreign.txt", "absent.txt"):
                with self.subTest(leaf=leaf):
                    with mock.patch.object(self.api, "CreateFileW", side_effect=AssertionError("must not open leaf")):
                        with self.assertRaisesRegex(RuntimeError, "ancestor"):
                            MetadataPin(self.api, "junction/" + leaf)
            self.assertEqual(foreign.read_bytes(), original)
            self.assertFalse((destination / "absent.txt").exists())
        finally:
            os.rmdir(junction)

    def test_replaced_ancestor_refuses_even_for_absent_leaf(self):
        parent = self.root / "parent"
        parent.mkdir()
        with MetadataPin(self.api, "parent/missing.txt") as pin:
            parent.rename(self.root / "retained-parent")
            parent.mkdir()
            with self.assertRaisesRegex(RuntimeError, "ancestor identities changed"):
                pin.recheck()
            # Restore the original route before the context's final recheck.
            parent.rmdir()
            (self.root / "retained-parent").rename(parent)

    def test_missing_ancestor_identity_refuses(self):
        original = Path.lstat

        def unavailable(path):
            info = original(path)
            if path == self.root:
                return SimpleNamespace(st_mode=info.st_mode,
                                       st_file_attributes=info.st_file_attributes,
                                       st_dev=info.st_dev, st_ino=0)
            return info

        with mock.patch.object(Path, "lstat", unavailable):
            with self.assertRaisesRegex(RuntimeError, "identity unavailable"):
                MetadataPin(self.api, "missing.txt")


if __name__ == "__main__":
    unittest.main()
