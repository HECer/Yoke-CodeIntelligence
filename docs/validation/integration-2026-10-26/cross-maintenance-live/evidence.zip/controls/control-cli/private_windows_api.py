import ctypes as c
import ctypes.wintypes as w


def windows_api():
    from ctypes import wintypes as w

    class Basic(c.Structure):
        _fields_ = [("process", c.c_int64), ("job", c.c_int64), ("flags", w.DWORD),
                    ("minimum", c.c_size_t), ("maximum", c.c_size_t), ("active", w.DWORD),
                    ("affinity", c.c_size_t), ("priority", w.DWORD), ("scheduling", w.DWORD)]

    class Extended(c.Structure):
        _fields_ = [("basic", Basic), ("io", c.c_uint64 * 6), ("process", c.c_size_t),
                    ("job", c.c_size_t), ("peak_process", c.c_size_t), ("peak_job", c.c_size_t)]

    class Thread(c.Structure):
        _fields_ = [("size", w.DWORD), ("usage", w.DWORD), ("id", w.DWORD),
                    ("owner", w.DWORD), ("base", w.LONG), ("delta", w.LONG), ("flags", w.DWORD)]

    class Association(c.Structure):
        _fields_ = [("key", c.c_void_p), ("port", c.c_void_p)]

    if c.sizeof(Extended) != 144 or c.sizeof(Thread) != 28:
        raise RuntimeError("Unsupported Windows diagnostic layout")
    api = c.WinDLL("kernel32", use_last_error=True)
    for name, args, result in [
        ("CreateJobObjectW", [c.c_void_p, c.c_wchar_p], c.c_void_p),
        ("SetInformationJobObject", [c.c_void_p, c.c_int, c.c_void_p, w.DWORD], w.BOOL),
        ("QueryInformationJobObject", [c.c_void_p, c.c_int, c.c_void_p, w.DWORD, c.c_void_p], w.BOOL),
        ("AssignProcessToJobObject", [c.c_void_p, c.c_void_p], w.BOOL),
        ("TerminateJobObject", [c.c_void_p, w.UINT], w.BOOL),
        ("ResumeThread", [c.c_void_p], w.DWORD),
        ("CloseHandle", [c.c_void_p], w.BOOL),
        ("CreateIoCompletionPort", [c.c_void_p, c.c_void_p, c.c_size_t, w.DWORD], c.c_void_p),
        ("CreateToolhelp32Snapshot", [w.DWORD, w.DWORD], c.c_void_p),
        ("Thread32First", [c.c_void_p, c.POINTER(Thread)], w.BOOL),
        ("Thread32Next", [c.c_void_p, c.POINTER(Thread)], w.BOOL),
        ("OpenThread", [w.DWORD, w.BOOL, w.DWORD], c.c_void_p),
    ]:
        function = getattr(api, name)
        function.argtypes, function.restype = args, result
    return api, Extended, Thread, Association
