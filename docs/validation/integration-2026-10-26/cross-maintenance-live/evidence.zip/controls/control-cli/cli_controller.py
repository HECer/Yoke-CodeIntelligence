"""Fixed private release producer and version-only consumer; source review first."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys

ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
CONTROL = ROOT / "validation/integration-20261025/platform-repairs/control-cli"
RUNS = CONTROL.parent / "runs-cli"
BASE_SHA = "a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7"
HELPER_SHA = "d9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500"
OWNER = "integration-20261025-private-release-cli-v1"
RELEASE_START_FREE = 4_000_000_000
IMAGE_START_FREE = 1_200_000_000
RUN_FREE = 500_000_000
BUILD_SECONDS = 3600
VERSION_SECONDS = 30
IMAGE_NAME = "owned-release-cli.exe"
CONTROL_NAMES = ("cli_controller.py", "base_controller.py", "private_windows_api.py",
                 "review-manifest.json", "README.md", ".gitattributes",
                 "test_metadata_pin.py")
PROTECTED_RELATIVE = (
    "target/debug/deps/capture_options-784339a4da3fe379.exe",
    "target/debug/deps/capture_options-784339a4da3fe379.pdb",
    "target/debug/deps/session_fixed_tools-0671ac4d8f474009.exe",
    "target/debug/deps/session_fixed_tools-0671ac4d8f474009.pdb",
    "target/debug/deps/yoke.exe", "target/debug/deps/yoke.pdb",
    "target/debug/yoke.exe", "target/debug/yoke.pdb",
    "target/release/yoke.exe", "target/release/yoke.pdb")


def require(value, message):
    if not value:
        raise RuntimeError(message)


def load_base():
    """Execute only the exact previously reviewed source blob, never a worker."""
    path = CONTROL / "base_controller.py"
    for parent in (path.parent, *path.parents):
        info = parent.lstat()
        require(stat.S_ISDIR(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400,
                "Base controller ancestor is not an ordinary directory")
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
            and not getattr(before, "st_file_attributes", 0) & 0x400
            and before.st_size <= 1_000_000, "Base controller is not bounded ordinary source")
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == BASE_SHA, "Reviewed base source differs")
    namespace = {"__name__": "reviewed_release_cli_base", "__file__": str(path)}
    exec(compile(data, str(path), "exec"), namespace)
    namespace.update(CONTROL=CONTROL, RUNS=RUNS, OWNER=OWNER, CONTROL_NAMES=CONTROL_NAMES)
    require(namespace["HELPER_SHA"] == HELPER_SHA, "Base helper pin differs")
    return namespace


def selected_image(out):
    # No user-supplied image path, Cargo-reported default path, or generic image scan.
    return out / IMAGE_NAME


def protected_ancestors(path):
    """Observe each lexical ancestor without following a reparse directory."""
    observed = []
    for parent in reversed(path.parents):
        try:
            info = parent.lstat()
        except FileNotFoundError:
            observed.append({"path": str(parent), "exists": False})
            continue
        require(stat.S_ISDIR(info.st_mode)
                and not getattr(info, "st_file_attributes", 0) & 0x400,
                "Protected role ancestor is not an ordinary directory")
        require(info.st_ino > 0 and info.st_dev >= 0,
                "Protected ancestor identity unavailable")
        observed.append({"path": str(parent), "exists": True,
                         "device": info.st_dev, "inode": info.st_ino,
                         "mode": info.st_mode,
                         "attributes": getattr(info, "st_file_attributes", 0)})
    return observed


class MetadataPin:
    """Attribute/execute-right handle; no data-read right and no execution."""
    def __init__(self, api, relative):
        import msvcrt
        self.path, self.api, self.fd = ROOT / relative, api, None
        # Check the complete lexical route even if the protected leaf is absent.
        # An absent leaf under a junction cannot be treated as an empty role.
        self.ancestors = protected_ancestors(self.path)
        try:
            before = self.path.lstat()
        except FileNotFoundError:
            self.initial = {"exists": False}
            return
        require(stat.S_ISREG(before.st_mode)
                and not getattr(before, "st_file_attributes", 0) & 0x400
                and before.st_ino > 0 and before.st_dev >= 0,
                "Protected role is not a regular non-reparse file")
        # Attribute-only handles do not establish share denial. FILE_EXECUTE
        # participates in read sharing without FILE_READ_DATA. Merely opening
        # this handle never loads/launches the image; it is not inherited.
        handle = api.CreateFileW(str(self.path), 0xA0, 1, None, 3, 0x00200000, None)
        require(handle not in (None, -1, (1 << 64) - 1), "Protected metadata pin unavailable")
        try:
            self.fd = msvcrt.open_osfhandle(handle, os.O_RDONLY | os.O_BINARY)
        except BaseException:
            api.CloseHandle(handle)
            raise
        try:
            self.initial = self.observation(before)
            require(self.observation(os.fstat(self.fd)) == self.initial,
                    "Protected metadata handle differs")
        except BaseException:
            os.close(self.fd)
            self.fd = None
            raise

    @staticmethod
    def observation(info):
        return {"exists": True, "device": info.st_dev, "inode": info.st_ino,
                "bytes": info.st_size, "mtimeNs": info.st_mtime_ns,
                "links": info.st_nlink, "mode": info.st_mode,
                "attributes": getattr(info, "st_file_attributes", 0)}

    def recheck(self):
        require(protected_ancestors(self.path) == self.ancestors,
                "Protected ancestor identities changed")
        try:
            current = self.observation(self.path.lstat())
        except FileNotFoundError:
            current = {"exists": False}
        require(current == self.initial, "Protected image metadata changed")
        if self.fd is not None:
            require(self.observation(os.fstat(self.fd)) == self.initial,
                    "Protected metadata handle changed")
        return {"path": str(self.path), "metadata": self.initial,
                "ancestors": self.ancestors,
                "imageBytesRead": False, "imageExecuted": False,
                "desiredAccess": "FILE_EXECUTE|FILE_READ_ATTRIBUTES (no FILE_READ_DATA)",
                "fileWritesDenied": self.fd is not None,
                "heldPathDeletionDenied": self.fd is not None,
                "allAliasNamespaceDenialClaimed": False}

    def __enter__(self):
        return self

    def __exit__(self, *_):
        try:
            self.recheck()
        finally:
            if self.fd is not None:
                os.close(self.fd)
                self.fd = None


def build_command(g, out):
    return [str(g["CARGO"]), "rustc", "--package", "yoke-code-intelligence",
            "--bin", "yoke", "--release", "--locked", "--offline", "-j2",
            "--message-format=json", "--", "-o", str(selected_image(out))]


def cargo_summary(g, data):
    require(len(data) <= g["MAX_LOG"], "Cargo log over bound")
    finished, selected, observations, errors, warnings = [], [], 0, 0, 0
    for line in data.splitlines():
        if not line.strip():
            continue
        require(len(line) <= 2_000_000, "Cargo line over bound")
        row = g["unique_json"](line)
        require(isinstance(row, dict), "Cargo output is not objects")
        if row.get("reason") == "build-finished":
            finished.append(row.get("success"))
        elif row.get("reason") == "compiler-message":
            level = row.get("message", {}).get("level")
            errors += level in ("error", "ice")
            warnings += level == "warning"
        elif row.get("reason") == "compiler-artifact":
            observations += 1
            target = row.get("target", {})
            if target.get("name") == "yoke" and target.get("kind") == ["bin"]:
                require(Path(target.get("src_path", "")) == ROOT / "native/src/main.rs",
                        "CLI artifact source differs")
                require(row.get("package_id") ==
                        "path+" + (ROOT / "native").as_uri() + "#yoke-code-intelligence@0.5.0",
                        "CLI package identity differs")
                require(row.get("fresh") is False and row.get("profile", {}).get("test") is False
                        and row.get("profile", {}).get("opt_level") == "3",
                        "A new non-test release CLI compilation is required")
                # Cargo's -o observation does NOT identify the requested private file.
                # The controlled command and fresh output role are separate evidence.
                require(row.get("filenames") == []
                        and Path(row.get("executable", "")) == ROOT / "target/release/yoke.exe",
                        "Unexpected Cargo custom-output observation")
                selected.append(row)
    require(finished == [True] and errors == 0 and len(selected) == 1,
            "Exactly one completed fresh CLI compilation required")
    return {"buildFinishedSuccess": True, "warningDiagnostics": warnings,
            "errorDiagnostics": errors, "compilerArtifactObservations": observations,
            "selectedArtifact": selected[0],
            "imageBinding": "fixed-host-output-argument-and-fresh-output-role",
            "cargoExecutableFieldIsNotSelectedImage": True, "byproductImageBytesRead": False}


def checked_job(job, expected):
    require(job.get("command") == expected and job.get("completed") is True
            and job.get("startedSuspended") is True and job.get("assignedBeforeResume") is True
            and job.get("stdinClosed") is True and job.get("resumePreviousSuspendCount") == 1
            and job.get("rootExitedAtObservation") is True
            and job.get("treeExitedBeforeCleanup") is True and job.get("activeBeforeCleanup") == 0
            and job.get("activeAfterCleanup") == 0 and job.get("rootExitedAfterCleanup") is True
            and job.get("cleanupUnproven") is False and job.get("cleanupErrors") == []
            and job.get("streamEOF") == [True, True] and job.get("readerErrors") == [False, False]
            and job.get("exitCode") == 0 and job.get("outputExceeded") is False,
            "Owned lifecycle is incomplete")


def checked_protected(before, after):
    require(isinstance(before, dict) and before == after
            and set(before) == set(PROTECTED_RELATIVE), "Protected role metadata differs")
    for name, row in before.items():
        require(isinstance(row, dict) and row.get("path") == str(ROOT / name)
                and row.get("imageBytesRead") is False and row.get("imageExecuted") is False
                and row.get("allAliasNamespaceDenialClaimed") is False
                and row.get("desiredAccess") ==
                "FILE_EXECUTE|FILE_READ_ATTRIBUTES (no FILE_READ_DATA)",
                "Protected role observation differs")
        exists = row.get("metadata", {}).get("exists")
        require(type(exists) is bool and row.get("fileWritesDenied") is exists
                and row.get("heldPathDeletionDenied") is exists,
                "Protected role pin proof differs")


def producer_admission(g, stack, api, run_id, commit, sources, controls):
    require(re.fullmatch(r"[a-z][a-z0-9-]{0,95}", run_id), "Invalid producer run ID")
    producer = RUNS / run_id
    g["ordinary"](producer, directory=True)
    names = ("request.json", "result.json", "source-before.json", "source-after.json",
             "source-final.json", "control-before.json", "control-after.json", "control-final.json",
             "command.job.json", "command.stdout", "command.stderr", "cargo-summary.json",
             "selected-image.json", "selected-image-after.json",
             "protected-before.json", "protected-after.json")
    pins = {name: stack.enter_context(g["ReadPin"](api, producer / name, g["MAX_LOG"]))
            for name in names}
    values = {name: g["unique_json"](pin.bytes()) for name, pin in pins.items()
              if name.endswith(".json")}
    request, result = values["request.json"], values["result.json"]
    require(request.get("owner") == result.get("owner") == OWNER
            and request.get("schema") == result.get("schema") == 1
            and request.get("runId") == result.get("runId") == run_id
            and request.get("mode") == result.get("mode") == "build"
            and request.get("sourceCommit") == result.get("sourceCommit") == commit
            and request.get("selectedImageAbsentBeforeCommand") is True
            and result.get("freshPrivateOutputRole") is True
            and result.get("protectedMetadataUnchanged") is True
            and result.get("completed") is True and result.get("inputsUnchanged") is True,
            "Matching completed fresh private producer required")
    expected = build_command(g, producer)
    require(result.get("command") == request.get("command") == expected,
            "Producer host output arguments differ")
    checked_job(values["command.job.json"], expected)
    checked_protected(values["protected-before.json"], values["protected-after.json"])
    require(values["command.job.json"].get("deadlineSeconds") == BUILD_SECONDS
            and request.get("startAdmissionBytes") == RELEASE_START_FREE
            and request.get("runtimeReserveBytes") == RUN_FREE,
            "Original release budgets differ")
    require(values["source-before.json"] == values["source-after.json"] ==
            values["source-final.json"] == sources
            and values["control-before.json"] == values["control-after.json"] ==
            values["control-final.json"] == controls, "Producer source/control maps differ")
    summary = cargo_summary(g, pins["command.stdout"].bytes())
    require(summary == values["cargo-summary.json"]
            and summary["selectedArtifact"] == result.get("selectedArtifact"),
            "Producer Cargo evidence differs")
    image = selected_image(producer)
    record = values["selected-image.json"]
    require(record == values["selected-image-after.json"] == result.get("selectedImage")
            and record.get("path") == str(image), "Producer image role differs")
    return image, record, pins, summary["selectedArtifact"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("build", "version"))
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--producer-run-id")
    args = parser.parse_args()
    require(os.name == "nt", "Windows only")
    require(re.fullmatch(r"[0-9a-f]{40}", args.source_commit), "Exact source commit required")
    require((args.mode == "version") == (args.producer_run_id is not None),
            "Only version consumes a producer")
    require(args.run_id != args.producer_run_id, "Run IDs must differ")
    start_floor = RELEASE_START_FREE if args.mode == "build" else IMAGE_START_FREE
    # Refuse before loading Windows helpers, launching Git/Cargo or reading an image.
    require(shutil.disk_usage("C:\\").free >= start_floor, "Original disk admission unavailable")
    g = load_base()
    g["ordinary"](ROOT, directory=True)
    g["ordinary"](CONTROL, directory=True)
    api, extended = g["load_windows_api"]()
    out = g["new_output"](args.run_id)
    image = selected_image(out)
    require(not os.path.lexists(image), "Private output already occupied")
    command = build_command(g, out) if args.mode == "build" else None
    result = {"owner": OWNER, "schema": 1, "sourceCommit": args.source_commit,
              "runId": args.run_id, "mode": args.mode, "completed": False,
              "inputsUnchanged": False, "nativeImageReadAttempted": False,
              "nativeImageRead": False, "command": command,
              "protectedMetadataUnchanged": False,
              "freshPrivateOutputRole": args.mode == "build",
              "releaseQualification": False, "vsixQualification": False,
              "qualification": g["QUALIFICATION"]}
    g["write_json"](out, "request.json",
                    {**result, "producerRunId": args.producer_run_id,
                     "selectedImageAbsentBeforeCommand": not os.path.lexists(image),
                     "startAdmissionBytes": start_floor, "runtimeReserveBytes": RUN_FREE})
    mutex, mutex_owned, command_started = None, False, False
    sources = controls = None
    try:
        import _winapi
        mutex_name = "Local\\YokeValidation-" + hashlib.sha256(str(ROOT).encode("utf-8")).hexdigest()[:24]
        mutex = api.CreateMutexW(None, False, mutex_name)
        require(mutex, "Serial mutex unavailable")
        status = _winapi.WaitForSingleObject(mutex, 0)
        require(status in (0, 128), "Another validation controller is active")
        mutex_owned = True
        result["serialMutexAbandoned"] = status == 128
        environment = g["environment_for"]("build")
        controls = g["controls_map"]()
        require(controls["base_controller.py"]["sha256"] == BASE_SHA, "Base source pin changed")
        g["write_json"](out, "control-before.json", controls)
        sources = g["source_map"](api, extended, out, environment, args.source_commit, "before")
        with ExitStack() as stack:
            protected = {name: stack.enter_context(MetadataPin(api, name))
                         for name in PROTECTED_RELATIVE}
            protected_before = {name: pin.recheck() for name, pin in protected.items()}
            g["write_json"](out, "protected-before.json", protected_before)

            def recheck_protected():
                after = {name: pin.recheck() for name, pin in protected.items()}
                g["write_json"](out, "protected-after.json", after)
                checked_protected(protected_before, after)
                result["protectedMetadataUnchanged"] = True
            stack.callback(recheck_protected)
            image_pin, producer_pins = None, {}
            if args.mode == "version":
                image, record, producer_pins, artifact = producer_admission(
                    g, stack, api, args.producer_run_id, args.source_commit, sources, controls)
                require(shutil.disk_usage("C:\\").free >= IMAGE_START_FREE,
                        "Native image admission unavailable")
                result["nativeImageReadAttempted"] = True
                image_pin = stack.enter_context(g["ReadPin"](api, image, 512_000_000, image=True))
                result["nativeImageRead"] = True
                require(image_pin.record() == record, "Fresh producer image changed")
                result.update(producerRunId=args.producer_run_id, selectedArtifact=artifact)
                g["write_json"](out, "selected-image.json", image_pin.record())
                g["write_json"](out, "producer-before.json",
                                {name: pin.record() for name, pin in producer_pins.items()})

                def recheck_consumer_pins():
                    g["write_json"](out, "selected-image-after.json", image_pin.recheck())
                    g["write_json"](out, "producer-after.json",
                                    {name: pin.recheck() for name, pin in producer_pins.items()})
                stack.callback(recheck_consumer_pins)
                command = [str(image), "--version"]
            else:
                require(shutil.disk_usage("C:\\").free >= RELEASE_START_FREE,
                        "4 GB release start admission unavailable")
                require(not os.path.lexists(image), "Fresh private output role occupied")
            result["command"] = command
            command_started = True
            job = g["run_owned"](api, extended, out, "command", command, environment,
                                 BUILD_SECONDS if args.mode == "build" else VERSION_SECONDS)
            result["commandOwnerCompleted"] = job["completed"]
            require(job.get("activeAfterCleanup") == 0 and job.get("rootExitedAfterCleanup") is True
                    and job.get("cleanupUnproven") is False, "Cleanup unproven")
            source_after = g["source_map"](api, extended, out, environment, args.source_commit, "after")
            control_after = g["controls_map"]()
            g["write_json"](out, "control-after.json", control_after)
            result["inputsUnchanged"] = sources == source_after and controls == control_after
            require(result["inputsUnchanged"], "Selected inputs changed")
            checked_job(job, command)
            result["sourceInputCount"] = len(sources)
            if args.mode == "build":
                summary = cargo_summary(g, (out / "command.stdout").read_bytes())
                g["write_json"](out, "cargo-summary.json", summary)
                g["ordinary"](image)
                require(image.name == IMAGE_NAME and image.parent == out
                        and image.name.lower() not in g["PROTECTED"], "Image role differs")
                require(shutil.disk_usage("C:\\").free >= IMAGE_START_FREE,
                        "Native image admission unavailable")
                result["nativeImageReadAttempted"] = True
                image_pin = stack.enter_context(g["ReadPin"](api, image, 512_000_000, image=True))
                result["nativeImageRead"] = True
                result["selectedArtifact"] = summary["selectedArtifact"]
                result["selectedImage"] = image_pin.recheck()
                g["write_json"](out, "selected-image.json", result["selectedImage"])
                stack.callback(lambda: g["write_json"](
                    out, "selected-image-after.json", image_pin.recheck()))
            else:
                version = (out / "command.stdout").read_bytes()
                require(version.strip() == b"yoke 0.5.0", "Unexpected CLI version")
                result["observedVersion"] = "yoke 0.5.0"
                result["selectedImage"] = image_pin.recheck()
            source_final = g["source_map"](api, extended, out, environment, args.source_commit, "final")
            control_final = g["controls_map"]()
            g["write_json"](out, "control-final.json", control_final)
            result["inputsUnchanged"] = sources == source_final and controls == control_final
            require(result["inputsUnchanged"], "Final selected inputs changed")
            result["completed"] = True
    except BaseException as error:
        result.update(completed=False, errorType=type(error).__name__, error=str(error))
    finally:
        if command_started and sources is not None and not result["completed"]:
            # Never start a new child after an uncertain lifecycle.
            try:
                after = g["hash_selected"](sources)
                g["write_json"](out, "source-after-failure.json", after)
                control_after = g["controls_map"]()
                g["write_json"](out, "control-after-failure.json", control_after)
                result["failureByteInputsUnchanged"] = after == sources and control_after == controls
                result["failureByteRecheckIsNotCleanHeadProof"] = True
            except BaseException as error:
                result["failureInputRecheckErrorType"] = type(error).__name__
        if mutex_owned and not api.ReleaseMutex(mutex):
            result.update(completed=False, serialMutexReleaseUnproven=True)
        if mutex is not None and not api.CloseHandle(mutex):
            result.update(completed=False, serialMutexCloseUnproven=True)
        result["freeAfter"] = shutil.disk_usage("C:\\").free
        if result["freeAfter"] < RUN_FREE:
            result.update(completed=False, finalRuntimeReserveUnavailable=True)
        g["write_json"](out, "result.json", result)
        g["emit"](result)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    sys.exit(main())
