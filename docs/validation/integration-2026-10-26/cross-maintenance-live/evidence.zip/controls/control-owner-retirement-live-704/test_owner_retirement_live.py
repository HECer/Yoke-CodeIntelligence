"""Inert worker contract tests; these do not qualify native execution."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock


SPEC = importlib.util.spec_from_file_location("owned_retirement_recipe", Path(__file__).with_name("owner_retirement_live.py"))
W = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(W)

EXPECTED_TRUE = frozenset("""complete singleOriginalSelection missingWritePermissionRefused
secondSelectionRefused ownedMarkerPresenceBlocked markerRemovalRestoredUnblockedView
terminalRetirementCommitted terminalInspectionComplete terminalOwnerSchema3
configurationBytesExact configurationIdentityExact originalJournalBytesExact
ownerPhysicalIdentityExact independentReadBytesExact cachedProposalRefused newProposalRefused
ordinaryRecoveryRefused sessionConfigurationUnchanged analyzedSourceUnchanged repeatApplyRefused
owningSessionExitedBeforeJobCleanup""".split())
EXPECTED_FALSE = frozenset("""actualInterruptedRetirementQualified retirementRecoveryQualified
olderBinaryQualified browserQualified physicalOwnerDeletionQualified allHostsReleased
releaseQualification""".split())


def encode(value):
    return (json.dumps(value, ensure_ascii=False) + "\n").encode("utf-8")


def golden_summary(label="native"):
    value = {name: True for name in EXPECTED_TRUE}
    value.update({name: False for name in EXPECTED_FALSE})
    value.update(variant=label, protocol=label, markerEvidenceKind="owned-foreign-marker-presence-only",
                 originalJournalRecords=2, cliCases=8,
                 owningExit={"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True})
    return value


class SummaryAdmission(unittest.TestCase):
    def test_worker_cannot_silently_remove_an_acceptance_or_scope_field(self):
        self.assertEqual(set(W.TRUE_FIELDS), EXPECTED_TRUE)
        self.assertEqual(set(W.FALSE_FIELDS), EXPECTED_FALSE)
        self.assertEqual(len(W.TRUE_FIELDS), len(EXPECTED_TRUE))
        self.assertEqual(len(W.FALSE_FIELDS), len(EXPECTED_FALSE))

    def test_exact_native_and_serena_summaries(self):
        for label in ("native", "serena"):
            self.assertIs(W.validate_summary(golden_summary(label), label)["complete"], True)

    def test_every_required_claim_refuses_false_integer_and_missing(self):
        for name in W.TRUE_FIELDS:
            for replacement in (False, 1, None):
                value = golden_summary()
                value[name] = replacement
                with self.subTest(name=name, replacement=replacement), self.assertRaises(RuntimeError):
                    W.validate_summary(value, "native")
            value = golden_summary()
            del value[name]
            with self.subTest(missing=name), self.assertRaises(RuntimeError):
                W.validate_summary(value, "native")

    def test_every_unqualified_claim_refuses_promotion_or_integer_false(self):
        for name in W.FALSE_FIELDS:
            for replacement in (True, 0, None):
                value = golden_summary()
                value[name] = replacement
                with self.subTest(name=name, replacement=replacement), self.assertRaises(RuntimeError):
                    W.validate_summary(value)

    def test_marker_presence_cannot_become_interrupted_transaction_evidence(self):
        for field, replacement in (("markerEvidenceKind", "actual-retirement-interruption"),
                                   ("actualInterruptedRetirementQualified", True),
                                   ("retirementRecoveryQualified", True)):
            value = golden_summary()
            value[field] = replacement
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                W.validate_summary(value)

    def test_closed_keys_and_exact_variant_membership(self):
        for changes in ({"unexpected": True}, {"variant": "python"}, {"protocol": "serena"}):
            value = golden_summary()
            value.update(changes)
            with self.subTest(changes=changes), self.assertRaises(RuntimeError):
                W.validate_summary(value)
        with self.assertRaises(RuntimeError):
            W.validate_summary(golden_summary(), "serena")

    def test_record_and_case_counts_refuse_boolean_float_and_bounds(self):
        for field, values in (("originalJournalRecords", (True, 2.0, 0, 1, 1025)),
                              ("cliCases", (True, 8.0, 0, 7, 9))):
            for replacement in values:
                value = golden_summary()
                value[field] = replacement
                with self.subTest(field=field, replacement=replacement), self.assertRaises(RuntimeError):
                    W.validate_summary(value)

    def test_natural_exit_proof_cannot_accept_forced_exit_or_coercions(self):
        for replacement in ({"nativeExitCode": False, "stdinWasStillOpen": True, "beforeJobCleanup": True},
                            {"nativeExitCode": 0, "stdinWasStillOpen": False, "beforeJobCleanup": True},
                            {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": False},
                            {"nativeExitCode": 1, "stdinWasStillOpen": True, "beforeJobCleanup": True},
                            {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True, "forced": True}):
            value = golden_summary()
            value["owningExit"] = replacement
            with self.subTest(replacement=replacement), self.assertRaises(RuntimeError):
                W.validate_summary(value)


class FixedCommandsAndPrivateOutput(unittest.TestCase):
    def paths(self):
        root = Path(tempfile.gettempdir()).resolve()
        return root / "owned-native.exe", root / "from.json", root / "review.stdout"

    def test_accepted_recipe_has_only_original_selection_and_fixed_deadline(self):
        native, selection, plan = self.paths()
        argv = W.cli_argv(native, selection, "owner-retirement-apply", plan, True)
        self.assertEqual(argv, [str(native), "--timeout", "30000", "--max-bytes", "1000000", "host-documents",
                               "--from-selection", str(selection), "owner-retirement-apply", "--plan", str(plan),
                               "--allow-host-writes"])
        self.assertNotIn("--to-selection", argv)
        self.assertEqual(W.CLI_SECONDS, 40)

    def test_deliberate_second_selection_and_missing_permission_cases_remain_distinct(self):
        native, selection, plan = self.paths()
        argv = W.cli_argv(native, selection, "owner-retirement-plan", second_selection=True)
        self.assertEqual(argv.count("--from-selection"), 1)
        self.assertEqual(argv.count("--to-selection"), 1)
        self.assertNotIn("--allow-host-writes", W.cli_argv(native, selection, "owner-retirement-apply", plan))

    def test_unknown_operations_roles_grants_and_relative_inputs_refuse(self):
        native, selection, plan = self.paths()
        for args in ((native, selection, "history-purge-apply", plan),
                     (native, selection, "owner-retirement-plan", plan),
                     (native, selection, "owner-retirement-apply"),
                     (native, selection, "owner-retirement-inspect", plan, True),
                     (native, selection, "owner-retirement-apply", plan, 1),
                     (Path("foreign.exe"), selection, "owner-retirement-plan")):
            with self.subTest(args=args), self.assertRaises(RuntimeError):
                W.cli_argv(*args)

    def test_run_cli_retains_exact_stdout_and_requires_expected_exit(self):
        native, selection, _ = self.paths()
        raw = b'{ "id" : "owned-review" }\r\n'
        harness = types.SimpleNamespace(read_json=lambda path, maximum: json.loads(path.read_bytes()),
                                        write_json=lambda path, value: path.write_bytes(encode(value)))
        with tempfile.TemporaryDirectory(prefix="owned-retirement-cli-") as directory:
            out = Path(directory)
            def run(argv, **kwargs):
                self.assertEqual(kwargs["timeout"], 40)
                self.assertEqual(kwargs["creationflags"], 0x08000000)
                kwargs["stdout"].write(raw)
                return types.SimpleNamespace(returncode=0)
            with mock.patch.object(W.subprocess, "run", side_effect=run), \
                 mock.patch.object(W.subprocess, "CREATE_NO_WINDOW", 0x08000000, create=True):
                self.assertEqual(W.run_cli(harness, native, out, selection, out, "retirement-plan",
                                          "owner-retirement-plan"), {"id": "owned-review"})
            self.assertEqual((out / "retirement-plan.stdout").read_bytes(), raw)

    def test_refusal_requires_no_successful_stdout_and_exact_exit_one(self):
        native, selection, plan = self.paths()
        harness = types.SimpleNamespace(write_json=lambda path, value: path.write_bytes(encode(value)))
        for code, raw in ((0, b""), (2, b""), (101, b""), (1, b'{"complete":true}')):
            with tempfile.TemporaryDirectory(prefix="owned-retirement-refusal-") as directory:
                out = Path(directory)
                def run(argv, **kwargs):
                    kwargs["stdout"].write(raw)
                    return types.SimpleNamespace(returncode=code)
                with mock.patch.object(W.subprocess, "run", side_effect=run), \
                     mock.patch.object(W.subprocess, "CREATE_NO_WINDOW", 0x08000000, create=True), \
                     self.assertRaises(RuntimeError):
                    W.run_cli(harness, native, out, selection, out, "missing-write-permission",
                              "owner-retirement-apply", plan, success=False)

    def test_expected_refusal_requires_its_private_causal_marker(self):
        native, selection, plan = self.paths()
        harness = types.SimpleNamespace(write_json=lambda path, value: path.write_bytes(encode(value)))
        expected = b"Host owner retirement requires --allow-host-writes"
        for error, accepted in ((b"", False), (b"unrelated native error", False),
                                (b"yoke: " + expected + b"\r\n", True)):
            with tempfile.TemporaryDirectory(prefix="owned-retirement-cause-") as directory:
                out = Path(directory)
                def run(argv, **kwargs):
                    kwargs["stderr"].write(error)
                    return types.SimpleNamespace(returncode=1)
                with mock.patch.object(W.subprocess, "run", side_effect=run), \
                     mock.patch.object(W.subprocess, "CREATE_NO_WINDOW", 0x08000000, create=True):
                    if accepted:
                        self.assertIsNone(W.run_cli(harness, native, out, selection, out,
                            "missing-write-permission", "owner-retirement-apply", plan, success=False))
                    else:
                        with self.assertRaises(RuntimeError):
                            W.run_cli(harness, native, out, selection, out,
                                "missing-write-permission", "owner-retirement-apply", plan, success=False)

    def test_oversized_cli_output_refuses_before_json_admission(self):
        native, selection, _ = self.paths()
        harness = types.SimpleNamespace(read_json=mock.Mock(side_effect=AssertionError("Must not parse")))
        with tempfile.TemporaryDirectory(prefix="owned-retirement-bound-") as directory:
            out = Path(directory)
            def run(argv, **kwargs):
                kwargs["stdout"].write(b"x" * 33)
                return types.SimpleNamespace(returncode=0)
            with mock.patch.object(W, "MAX_JSON", 32), mock.patch.object(W.subprocess, "run", side_effect=run), \
                 mock.patch.object(W.subprocess, "CREATE_NO_WINDOW", 0x08000000, create=True), \
                 self.assertRaises(RuntimeError):
                W.run_cli(harness, native, out, selection, out, "retirement-plan", "owner-retirement-plan")
            harness.read_json.assert_not_called()


class IndependentEvidence(unittest.TestCase):
    def test_read_requires_exact_unicode_bom_crlf_hash_and_length(self):
        raw = "\ufeffπ e\u0301 🦀\r\n".encode("utf-8")
        good = {"documentId": "owned", "content": raw.decode(), "byteLength": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest()}
        actor = types.SimpleNamespace(document=lambda request: {"document": good})
        self.assertEqual(W.assert_read(actor, raw), good)
        for name, replacement in (("content", raw.decode().replace("\r\n", "\n")),
                                  ("byteLength", True), ("sha256", "0" * 64), ("documentId", "foreign")):
            changed = dict(good)
            changed[name] = replacement
            actor = types.SimpleNamespace(document=lambda request, changed=changed: {"document": changed})
            with self.subTest(name=name), self.assertRaises(RuntimeError):
                W.assert_read(actor, raw)

    def test_empty_journals_never_imply_complete_blocker_or_missing_authority(self):
        good = {"blockedByOwnerRetirement": True, "complete": False, "journals": [],
                "fileChanged": False, "metadataChanged": False, "sourceWritten": False}
        W.assert_blocked(types.SimpleNamespace(document=lambda request: good))
        for name, replacement in (("blockedByOwnerRetirement", False), ("complete", True),
                                  ("complete", 0), ("journals", [{}]), ("fileChanged", 0)):
            changed = dict(good)
            changed[name] = replacement
            with self.subTest(name=name), self.assertRaises(RuntimeError):
                W.assert_blocked(types.SimpleNamespace(document=lambda request, changed=changed: changed))

    def journal(self):
        plan = {"id": "1" * 64, "accessBinding": "2" * 64, "documentId": "owned"}
        stem = "yoke-doc-" + plan["accessBinding"] + "-" + plan["id"]
        first = {"sequence": 0, "id": "3" * 64}
        last = {"sequence": 1, "id": "4" * 64, "previous": first["id"],
                "planId": plan["id"], "accessBinding": plan["accessBinding"], "phase": "committed"}
        records = {stem + ".plan.json": encode({"schemaVersion": 1, "plan": plan, "initial": first}),
                   stem + ".e0001.json": encode(last), ".owned-lock": b""}
        return plan, stem, records

    def test_closed_event_is_derived_from_original_records_not_cached_proposal(self):
        plan, _, records = self.journal()
        harness = types.SimpleNamespace(decode=json.loads)
        self.assertEqual(W.closed_journal_event(harness, records, plan), ("4" * 64, 2))

    def test_missing_forged_unclosed_and_gapped_journal_evidence_refuses(self):
        plan, stem, records = self.journal()
        harness = types.SimpleNamespace(decode=json.loads)
        for field, value in (("previous", "5" * 64), ("phase", "prepared"),
                             ("sequence", True), ("planId", "6" * 64)):
            changed = dict(records)
            event = json.loads(changed[stem + ".e0001.json"])
            event[field] = value
            changed[stem + ".e0001.json"] = encode(event)
            with self.subTest(field=field), self.assertRaises(RuntimeError):
                W.closed_journal_event(harness, changed, plan)
        for changed in ({stem + ".plan.json": records[stem + ".plan.json"]},
                        {stem + ".plan.json": records[stem + ".plan.json"],
                         stem + ".e0002.json": records[stem + ".e0001.json"]}):
            with self.assertRaises(RuntimeError):
                W.closed_journal_event(harness, changed, plan)


class WholeRecipe(unittest.TestCase):
    def test_invalid_variant_and_occupied_fixture_refuse_before_actor(self):
        actor = mock.Mock(side_effect=AssertionError("Must not launch"))
        harness = types.SimpleNamespace(Actor=actor)
        root = Path(tempfile.gettempdir()).resolve()
        with self.assertRaises(RuntimeError):
            W.exercise(harness, root / "native.exe", root, root / "unused", "native", "serena")
        with self.assertRaises(RuntimeError):
            W.exercise(harness, root / "native.exe", root, root / "unused", "native", "native")
        actor.assert_not_called()

    def test_actor_is_closed_when_first_poststartup_assertion_fails(self):
        actor = mock.Mock()
        actor.plan.return_value = {"id": "1" * 64}
        actor.apply.return_value = {"receipt": {"journalId": "wrong", "outcome": "committed", "fileChanged": True}}
        harness = types.SimpleNamespace(Actor=mock.Mock(return_value=actor),
                                        write_json=lambda path, value: path.write_bytes(encode(value)))
        with tempfile.TemporaryDirectory(prefix="owned-retirement-finally-") as directory:
            root = Path(directory)
            with self.assertRaises(RuntimeError):
                W.exercise(harness, root / "native.exe", root / "fixture", root / "out", "native", "native")
        actor.close.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
