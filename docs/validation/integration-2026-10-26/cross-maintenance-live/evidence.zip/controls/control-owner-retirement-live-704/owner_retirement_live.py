"""Closed owned-fixture retirement exercise; no executable admission or entrypoint.

The parent admits the native image and hash-pinned original history harness,
creates the owned Job, and supplies that harness here. All output is private
until the parent's independent closed-summary admission. No pending interruption,
older binary, browser, physical owner deletion or all-host release is qualified.
"""
import hashlib
from pathlib import Path
import re
import stat
import subprocess


MAX_JSON = 1_000_000
MAX_PLAN = 32_000
MAX_TREE_BYTES = 32_000_000
MAX_TREE_ENTRIES = 1024
CLI_SECONDS = 40
HEX = re.compile(r"[0-9a-f]{64}")
OPERATIONS = frozenset(("owner-retirement-plan", "owner-retirement-apply", "owner-retirement-inspect"))
CLI_NAMES = frozenset(("retirement-plan", "missing-write-permission", "second-selection-plan",
                       "second-selection-apply", "marker-apply", "retirement-apply",
                       "retirement-inspect", "repeat-apply"))
REFUSAL_MARKERS = {
    "missing-write-permission": b"Host owner retirement requires --allow-host-writes",
    "second-selection-plan": b"Standalone owner retirement accepts only the original --from-selection",
    "second-selection-apply": b"Standalone owner retirement accepts only the original --from-selection",
    "marker-apply": b"Host document owner retirement is pending; use explicit host retirement recovery",
    "repeat-apply": None,
}
TRUE_FIELDS = (
    "complete", "singleOriginalSelection", "missingWritePermissionRefused",
    "secondSelectionRefused", "ownedMarkerPresenceBlocked", "markerRemovalRestoredUnblockedView",
    "terminalRetirementCommitted", "terminalInspectionComplete", "terminalOwnerSchema3",
    "configurationBytesExact", "configurationIdentityExact", "originalJournalBytesExact",
    "ownerPhysicalIdentityExact", "independentReadBytesExact", "cachedProposalRefused",
    "newProposalRefused", "ordinaryRecoveryRefused", "sessionConfigurationUnchanged",
    "analyzedSourceUnchanged", "repeatApplyRefused", "owningSessionExitedBeforeJobCleanup",
)
FALSE_FIELDS = ("actualInterruptedRetirementQualified", "retirementRecoveryQualified",
                "olderBinaryQualified", "browserQualified", "physicalOwnerDeletionQualified",
                "allHostsReleased", "releaseQualification")


def require(value, message):
    if not value:
        raise RuntimeError(message)


def valid_hex(value):
    return type(value) is str and HEX.fullmatch(value) is not None


def closed(value, names):
    require(type(value) is dict and set(value) == set(names), "Closed retirement result differs")


def validate_summary(value, label=None):
    closed(value, (*TRUE_FIELDS, *FALSE_FIELDS, "variant", "protocol", "markerEvidenceKind",
                   "originalJournalRecords", "cliCases", "owningExit"))
    require(type(value["variant"]) is str and type(value["protocol"]) is str
            and value["variant"] in ("native", "serena") and value["protocol"] == value["variant"],
            "Closed retirement variant differs")
    require(label is None or (type(label) is str and value["variant"] == label),
            "Caller-selected retirement variant differs")
    require(all(value[name] is True for name in TRUE_FIELDS)
            and all(value[name] is False for name in FALSE_FIELDS), "Retirement claims differ")
    require(type(value["markerEvidenceKind"]) is str
            and value["markerEvidenceKind"] == "owned-foreign-marker-presence-only",
            "Marker evidence cannot certify an interruption")
    require(type(value["originalJournalRecords"]) is int
            and 2 <= value["originalJournalRecords"] <= MAX_TREE_ENTRIES,
            "Original journal count differs")
    require(type(value["cliCases"]) is int and value["cliCases"] == len(CLI_NAMES),
            "Closed CLI case count differs")
    exit_proof = value["owningExit"]
    closed(exit_proof, ("nativeExitCode", "stdinWasStillOpen", "beforeJobCleanup"))
    require(type(exit_proof["nativeExitCode"]) is int and exit_proof["nativeExitCode"] == 0
            and exit_proof["stdinWasStillOpen"] is True and exit_proof["beforeJobCleanup"] is True,
            "Natural owning Session exit not proved")
    return value


def file_identity(path):
    info = Path(path).lstat()
    require(stat.S_ISREG(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400
            and info.st_nlink == 1, "Owned regular single-link fixture required")
    return info.st_dev, info.st_ino


def tree_bytes(root):
    """Read only the explicitly owned, flat journal fixture, with original caps."""
    result = {}
    total = 0
    for path in sorted(Path(root).iterdir()):
        require(len(result) < MAX_TREE_ENTRIES, "Owned journal entry capacity exceeded")
        file_identity(path)
        first = path.lstat()
        require(first.st_size <= MAX_JSON, "Owned journal file capacity exceeded")
        total += first.st_size
        require(total <= MAX_TREE_BYTES, "Owned journal byte capacity exceeded")
        raw = path.read_bytes()
        last = path.lstat()
        require((first.st_dev, first.st_ino, first.st_size, first.st_mtime_ns) ==
                (last.st_dev, last.st_ino, last.st_size, last.st_mtime_ns)
                and len(raw) == first.st_size, "Owned journal observation changed")
        result[path.name] = raw
    return result


def cli_argv(native, selection, operation, plan=None, allow=False, second_selection=False):
    require(type(operation) is str and operation in OPERATIONS and type(allow) is bool
            and type(second_selection) is bool, "Closed CLI operation required")
    require(Path(native).is_absolute() and Path(selection).is_absolute(), "Absolute host inputs required")
    require((operation == "owner-retirement-plan") == (plan is None), "Exact CLI plan role required")
    require(not allow or operation == "owner-retirement-apply", "Unexpected host-write grant")
    argv = [str(native), "--timeout", "30000", "--max-bytes", "1000000", "host-documents",
            "--from-selection", str(selection)]
    if second_selection:
        # A deliberate invalid second selection; never part of the accepted command.
        argv += ["--to-selection", str(selection)]
    argv += [operation]
    argv += ["--document", "owned"] if plan is None else ["--plan", str(plan)]
    if allow:
        argv += ["--allow-host-writes"]
    return argv


def run_cli(harness, native, source, selection, output, name, operation, plan=None,
            allow=False, second_selection=False, success=True):
    require(name in CLI_NAMES and type(success) is bool, "Closed CLI case required")
    argv = cli_argv(native, selection, operation, plan, allow, second_selection)
    stdout, stderr = output / (name + ".stdout"), output / (name + ".stderr")
    with stdout.open("xb") as out_file, stderr.open("xb") as err_file:
        result = subprocess.run(argv, cwd=source, stdout=out_file, stderr=err_file,
                                timeout=CLI_SECONDS, creationflags=subprocess.CREATE_NO_WINDOW)
    require(stdout.stat().st_size <= MAX_JSON and stderr.stat().st_size <= MAX_JSON,
            "CLI output capacity exceeded")
    require(type(result.returncode) is int and result.returncode == (0 if success else 1),
            "Unexpected owned retirement CLI outcome: " + name)
    harness.write_json(output / (name + ".result.json"),
                       {"case": name, "exitCode": result.returncode, "expectedSuccess": success})
    if not success:
        require(stdout.read_bytes() == b"", "Refused CLI published successful output")
        require(name in REFUSAL_MARKERS, "Expected refusal case differs")
        error = stderr.read_bytes()
        marker = REFUSAL_MARKERS[name]
        require(bool(error) and (marker is None or marker in error),
                "Expected private retirement refusal cause differs")
        return None
    return harness.read_json(stdout, MAX_PLAN if operation == "owner-retirement-plan" else MAX_JSON)


def assert_read(actor, expected):
    snapshot = actor.document({"kind": "read", "documentId": "owned"})["document"]
    require(snapshot["documentId"] == "owned" and type(snapshot["content"]) is str
            and snapshot["content"].encode("utf-8") == expected
            and type(snapshot["byteLength"]) is int and snapshot["byteLength"] == len(expected)
            and snapshot["sha256"] == hashlib.sha256(expected).hexdigest(),
            "Independent owning HTTP read differs")
    return snapshot


def assert_blocked(actor):
    value = actor.document({"kind": "pending", "documentId": "owned"})
    require(value.get("blockedByOwnerRetirement") is True and value.get("complete") is False
            and type(value.get("journals")) is list and value["journals"] == []
            and value.get("fileChanged") is False and value.get("metadataChanged") is False
            and value.get("sourceWritten") is False, "Incomplete retirement blocker differs")


def closed_journal_event(harness, records, plan):
    require(valid_hex(plan.get("id")) and valid_hex(plan.get("accessBinding")), "Saved plan differs")
    stem = "yoke-doc-" + plan["accessBinding"] + "-" + plan["id"]
    header = harness.decode(records[stem + ".plan.json"])
    require(type(header["schemaVersion"]) is int and header["schemaVersion"] == 1 and header["plan"] == plan,
            "Actual original journal header differs")
    event = header["initial"]
    require(type(event["sequence"]) is int and event["sequence"] == 0
            and valid_hex(event["id"]), "Initial journal event differs")
    pattern = re.compile(re.escape(stem) + r"\.e([0-9]{4})\.json")
    events = sorted((int(match.group(1)), name) for name in records
                    if (match := pattern.fullmatch(name)))
    require(bool(events), "Closed original journal has no event")
    for sequence, name in events:
        following = harness.decode(records[name])
        require(type(following["sequence"]) is int
                and sequence == event["sequence"] + 1 == following["sequence"]
                and following["previous"] == event["id"] and valid_hex(following["id"])
                and following["planId"] == plan["id"]
                and following["accessBinding"] == plan["accessBinding"], "Original event chain differs")
        event = following
    require(event["phase"] == "committed", "Original journal was not closed by the native save")
    return event["id"], len(events) + 1


def assert_refused_writes(actor, cached, saved, event):
    actor.apply("owned", cached, 422)
    read = assert_read(actor, saved)
    actor.document({"kind": "plan", "documentId": "owned", "expectedRevision": read["revision"],
                    "content": "# refused new proposal π\r\n"}, 422)
    actor.document({"kind": "recover", "documentId": "owned", "journalId": event[0],
                    "expectedEvent": event[1], "direction": "resume"}, 422)


def exercise(harness, native, fixture, output, label, protocol):
    """Run one native or Serena owning Session in the parent's already owned Job."""
    require(label in ("native", "serena") and protocol == label, "Closed retirement variant required")
    native, fixture, output = Path(native), Path(fixture), Path(output)
    require(all(path.is_absolute() for path in (native, fixture, output))
            and not fixture.exists() and not output.exists(), "Fresh absolute fixture/output required")
    fixture.mkdir()
    output.mkdir()
    source, journal, host = (fixture / name for name in ("source-İ-e\u0301", "journal-π", "host-🦀"))
    for path in (source, journal, host):
        path.mkdir()
    source_file = source / "main.rs"
    source_bytes = "// owned inert e\u0301 🦀\r\nfn untouched() {}\r\n".encode("utf-8")
    source_file.write_bytes(source_bytes)
    source_identity = file_identity(source_file)
    target = host / "settings-π.yaml"
    original = "\ufeff# owned configuration π e\u0301 🦀\r\nvalue: preserved\r\n".encode("utf-8")
    target.write_bytes(original)
    config = {"documents": [{"id": "owned", "label": "Owned retirement settings", "path": str(target),
                             "scope": {"kind": "global"}, "writable": True}],
              "journalRoot": str(journal), "maxDocumentBytes": 64000}
    selection = fixture / "from.json"
    harness.write_json(selection, {"documents": config, "projects": [{"name": "default", "root": str(source)}]})
    profile = fixture / "host-profile.json"
    harness.write_json(profile, {"context": "desktop-app", "modes": ["editing"], "steering": {},
        "dashboard": {"management": {"sessionControls": False, "memories": False,
                        "documents": config, "shutdown": True, "operationTimeoutMs": 3000},
                      "lifetimeMs": 600000}})
    actor = None
    try:
        actor = harness.Actor(native, source, profile, output, label, protocol)
        saved = original + "# actual owning HTTP save π\r\n".encode("utf-8")
        saved_plan = actor.plan("owned", saved.decode("utf-8"))
        applied = actor.apply("owned", saved_plan)["receipt"]
        require(applied["journalId"] == saved_plan["id"] and applied["outcome"] == "committed"
                and applied["fileChanged"] is True and target.read_bytes() == saved,
                "Actual owning save did not create the expected closed journal")
        assert_read(actor, saved)
        cached = actor.plan("owned", "# cached proposal must never revive π\r\n")
        old_journal = tree_bytes(journal)
        event, original_record_count = closed_journal_event(harness, old_journal, saved_plan)
        target_identity = file_identity(target)

        def cli(name, operation, plan=None, allow=False, second=False, success=True):
            return run_cli(harness, native, source, selection, output, name, operation,
                           plan, allow, second, success)

        retirement = cli("retirement-plan", "owner-retirement-plan")
        require(type(retirement["schemaVersion"]) is int and retirement["schemaVersion"] == 1
                and retirement["documentId"] == "owned"
                and valid_hex(retirement["id"]) and valid_hex(retirement["target"])
                and retirement["sourceHash"] == hashlib.sha256(saved).hexdigest()
                and retirement["accessBinding"] == saved_plan["accessBinding"], "Reviewed retirement plan differs")
        plan_path = output / "retirement-plan.stdout"  # exact native stdout, not reconstructed JSON
        owner = host / (".yoke-doc-owner-" + retirement["target"] + ".json")
        owner_before = owner.read_bytes()
        owner_identity = file_identity(owner)
        require(harness.decode(owner_before) == retirement["beforeOwner"], "Original owner bytes differ")

        def unchanged():
            require(target.read_bytes() == saved and file_identity(target) == target_identity
                    and source_file.read_bytes() == source_bytes and file_identity(source_file) == source_identity
                    and owner.read_bytes() == owner_before and file_identity(owner) == owner_identity
                    and tree_bytes(journal) == old_journal, "Refused operation mutated owned evidence")

        unchanged()
        cli("missing-write-permission", "owner-retirement-apply", plan_path, success=False)
        unchanged()
        cli("second-selection-plan", "owner-retirement-plan", second=True, success=False)
        unchanged()
        cli("second-selection-apply", "owner-retirement-apply", plan_path, allow=True, second=True, success=False)
        unchanged()
        marker = host / (".yoke-doc-owner-retirement-" + retirement["target"] + ".pending.json")
        sentinel = b"owned foreign pending-marker presence only; not a retirement transaction\n"
        with marker.open("xb") as stream:
            stream.write(sentinel)
        marker_identity = file_identity(marker)
        assert_blocked(actor)
        assert_refused_writes(actor, cached, saved, (saved_plan["id"], event))
        cli("marker-apply", "owner-retirement-apply", plan_path, allow=True, success=False)
        unchanged()
        require(marker.read_bytes() == sentinel and file_identity(marker) == marker_identity,
                "Foreign marker was not preserved")
        # Remove only this exact single-link sentinel in this private owned fixture.
        marker.unlink()
        normal = actor.document({"kind": "pending", "documentId": "owned"})
        require(normal.get("blockedByOwnerRetirement") is not True and normal.get("journals") == [],
                "Removing owned sentinel did not restore the unblocked view")
        unchanged()
        receipt = cli("retirement-apply", "owner-retirement-apply", plan_path, allow=True)
        require(receipt["planId"] == retirement["id"] and valid_hex(receipt["eventId"])
                and receipt["outcome"] == "committed" and receipt["metadataChanged"] is True
                and receipt["fileChanged"] is False and receipt["sourceWritten"] is False,
                "Actual retirement receipt differs")
        review = cli("retirement-inspect", "owner-retirement-inspect", plan_path)
        require(review["planId"] == retirement["id"] and review["eventId"] == receipt["eventId"]
                and review["phase"] == "committed" and review["ownerState"] == "retired"
                and review["markerPresent"] is False and review["terminalEvidencePresent"] is True
                and review["complete"] is True and review["fileChanged"] is False
                and review["sourceWritten"] is False, "Durable terminal inspection differs")
        after_owner = harness.decode(owner.read_bytes())
        require(after_owner == retirement["afterOwner"] and after_owner["schemaVersion"] == 3
                and after_owner["originalOwnerId"] == retirement["beforeOwner"]["id"]
                and file_identity(owner) == owner_identity, "Retired fixed owner identity or bytes differ")
        complete_marker = host / (".yoke-doc-owner-retirement-" + retirement["id"] + ".complete.json")
        require(not marker.exists() and complete_marker.is_file(), "Terminal retirement marker absent")
        terminal_journal = tree_bytes(journal)
        require(all(terminal_journal.get(name) == raw for name, raw in old_journal.items()),
                "Original journal evidence changed during retirement")
        terminal_owner = owner.read_bytes()
        terminal_marker = complete_marker.read_bytes()
        assert_blocked(actor)
        assert_refused_writes(actor, cached, saved, (saved_plan["id"], event))
        cli("repeat-apply", "owner-retirement-apply", plan_path, allow=True, success=False)
        require(target.read_bytes() == saved and file_identity(target) == target_identity
                and owner.read_bytes() == terminal_owner and file_identity(owner) == owner_identity
                and tree_bytes(journal) == terminal_journal and complete_marker.read_bytes() == terminal_marker,
                "Retired write/refusal changed terminal evidence")
        require(actor.state()["view"]["management"]["sessionStateSha256"] == actor.fingerprint,
                "Existing owning Session configuration reloaded")
        assert_read(actor, saved)
        exit_proof = actor.shutdown()
        require(source_file.read_bytes() == source_bytes and file_identity(source_file) == source_identity,
                "Analyzed source changed")
        summary = {name: True for name in TRUE_FIELDS}
        summary.update({name: False for name in FALSE_FIELDS})
        summary.update(variant=label, protocol=protocol,
                       markerEvidenceKind="owned-foreign-marker-presence-only",
                       originalJournalRecords=original_record_count, cliCases=len(CLI_NAMES), owningExit=exit_proof)
        validate_summary(summary)
        harness.write_json(output / "variant-result.json", summary)
        return summary
    finally:
        if actor is not None:
            actor.close()
