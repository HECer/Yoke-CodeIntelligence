"""Authored protocol/owned-inert tests; no real native image or producer required."""
from contextlib import ExitStack, nullcontext
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

SPEC = importlib.util.spec_from_file_location(
    "owned_local_history_controller", Path(__file__).with_name("local_history_controller.py"))
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)


def valid_job():
    return {"startedSuspended": True, "assignedBeforeResume": True, "complete": True,
            "pid": 123, "exitCode": 0, "activeAtParentExit": 1, "activeBeforeCleanup": 0,
            "treeExitedBeforeCleanup": True, "activeAfterCleanup": 0}


def valid_live():
    variants = []
    for label in C.VARIANTS:
        variants.append({
            "variant": label, "complete": True, "packages": 2, "originalRecords": 33,
            "allOriginalsReadBack": True, "oldAndCurrentAuthorityRefusedDuringPending": True,
            "configurationAndOwnerExactDuringArchival": True,
            "freshSameHostSaveAfterArchival": True, "actualJournalCurrentGeneration": True,
            "bothArchiveFramesRemainExact": True, "persistent45Retained": label == "persistent-python",
            "runtimeExitBeforeJobCleanup": label == "persistent-python",
            "currentExit": {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True},
            "oldExit": {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True},
            "analyzedSourceUnchanged": True})
    return {"product": "Code Intelligence", "version": "0.5.0", "complete": True,
            "nativeSha256": "a" * 64, "variants": variants,
            "workerJobAdmission": {"specificJobMembershipConfirmed": True,
                                  "queryHandleClosedBeforeNativeRead": True},
            "modelCalls": 0, "analyzedSourceExecuted": False,
            "existingCredentialsSelected": False, "nativeBrowserAcceptanceClaimed": False}


def archive_fixture():
    result = {}
    for label in C.VARIANTS:
        for tag, numbers in (("first", range(32)), ("second", range(32, 33))):
            records = []
            for index, number in enumerate(numbers):
                name = "yoke-doc-" + "b" * 64 + "-" + format(number, "064x") + ".plan.json"
                data = ("\ufeffowned π 🦀 e\u0301 " + str(number) + "\r\n").encode("utf8")
                digest = hashlib.sha256(data).hexdigest()
                record = {"name": name, "bytes": len(data), "sha256": digest}
                records.append(record)
                result[label + "/" + tag + "-read-" + str(index) + ".stdout"] = {
                    "planId": ("c" if tag == "first" else "d") * 64,
                    "recordName": name, "originalIdentity": "owned-original-identity",
                    "originalSecuritySha256": "e" * 64, "sha256": digest,
                    "byteLength": len(data), "bytesBase64": C.base64.b64encode(data).decode("ascii"),
                    "immutableRecordEvidenceOnly": True, "fileChanged": False, "sourceWritten": False}
            result[label + "/" + tag + "-frame-proof.json"] = {
                "sha256": ("f" if tag == "first" else "1") * 64, "records": records}
    return result


class ClosedProtocolTests(unittest.TestCase):
    def test_arguments_accept_only_three_fixed_fields_and_bounded_ids(self):
        args = ["--source-commit", C.SOURCE_COMMIT, "--run-id", "history-reviewed",
                "--producer-run-id", "release-reviewed"]
        self.assertEqual(C.options(args).run_id, "history-reviewed")
        for changed in [
                args + ["--native", "foreign.exe"], args[:-2], [],
                ["--source-commit", "b" * 40, "--run-id", "one", "--producer-run-id", "two"],
                ["--source-commit", C.SOURCE_COMMIT, "--run-id", "../escape", "--producer-run-id", "two"],
                ["--source-commit", C.SOURCE_COMMIT, "--run-id", "same", "--producer-run-id", "same"],
                ["--source-commit", C.SOURCE_COMMIT, "--run-id", "a" * 97, "--producer-run-id", "two"]]:
            with self.subTest(changed=changed), self.assertRaises(C.Refusal):
                C.options(changed)

    def test_duplicate_json_and_exact_byte_limits_refuse(self):
        self.assertEqual(C.unique_json(b'{"value":1}', 11), {"value": 1})
        for data, cap in [(b'{"x":1,"x":2}', 100), (b'{"x":{"a":1,"a":2}}', 100),
                          (b'{"ok":true}trailing', 100), (b" " * 101, 100), (b"\xff", 100)]:
            with self.subTest(data=data), self.assertRaises(C.Refusal):
                C.unique_json(data, cap)

    def test_manifest_pins_self_source_separately_from_original_seven(self):
        controls = {name: {"bytes": 1, "sha256": "a" * 64} for name in C.CONTROL_NAMES}
        value = {"schema": 1, "owner": C.OWNER, "scope": "original-archive-only",
                 "sourceCommit": C.SOURCE_COMMIT,
                 "consumerSources": {n: "a" * 64 for n in C.CONTROL_NAMES if n != "review-manifest.json"},
                 "producerSources": dict(C.PRODUCER_PINS), "historySource": C.HISTORY_SHA,
                 "budgets": dict(C.BUDGETS)}
        C.validate_manifest(value, controls, C.SOURCE_COMMIT)
        for mutate in (
                lambda x: x.update(extra=True),
                lambda x: x.update(schema=True),
                lambda x: x.update(sourceCommit="b" * 40),
                lambda x: x["consumerSources"].update({"unknown.py": "a" * 64}),
                lambda x: x["consumerSources"].update({"local_history_controller.py": "b" * 64}),
                lambda x: x["producerSources"].update({"local_history_controller.py": "a" * 64}),
                lambda x: x["producerSources"].update({"cli_controller.py": "b" * 64}),
                lambda x: x["budgets"].update(workerSeconds=181),
                lambda x: x["budgets"].update(workerDrainSeconds=True)):
            changed = copy.deepcopy(value)
            mutate(changed)
            with self.subTest(changed=changed), self.assertRaises(C.Refusal):
                C.validate_manifest(changed, controls, C.SOURCE_COMMIT)

    def test_cleanup_cannot_turn_surviving_tree_into_success(self):
        C.validate_job(valid_job())
        for key, value in [("complete", False), ("treeExitedBeforeCleanup", False),
                           ("activeBeforeCleanup", 1), ("activeAfterCleanup", 1),
                           ("assignedBeforeResume", False), ("startedSuspended", False),
                           ("exitCode", 1), ("exitCode", False), ("pid", True),
                           ("activeAtParentExit", -1), ("activeBeforeCleanup", False)]:
            row = valid_job()
            row[key] = value
            with self.subTest(key=key, value=value), self.assertRaises(C.Refusal):
                C.validate_job(row)
        row = valid_job()
        row["cleanupSucceeded"] = True
        with self.assertRaises(C.Refusal):
            C.validate_job(row)

    def test_variants_are_exact_ordered_complete_and_preserve_runtime_exit(self):
        value = valid_live()
        C.validate_live(value, "a" * 64)
        mutations = [
            lambda x: x.update(nativeSha256="b" * 64),
            lambda x: x.update(complete=False),
            lambda x: x.update(modelCalls=False),
            lambda x: x.update(existingCredentialsSelected=True),
            lambda x: x.update(nativeBrowserAcceptanceClaimed=True),
            lambda x: x["workerJobAdmission"].update(queryHandleClosedBeforeNativeRead=False),
            lambda x: x["variants"].reverse(),
            lambda x: x["variants"].pop(),
            lambda x: x["variants"].append(copy.deepcopy(x["variants"][0])),
            lambda x: x["variants"][1].update(variant="native"),
            lambda x: x["variants"][0].update(originalRecords=32),
            lambda x: x["variants"][0].update(originalRecords=65),
            lambda x: x["variants"][0].update(packages=True),
            lambda x: x["variants"][0].update(allOriginalsReadBack=False),
            lambda x: x["variants"][0].update(sourceAuthority=True),
            lambda x: x["variants"][2].update(persistent45Retained=False),
            lambda x: x["variants"][2].update(runtimeExitBeforeJobCleanup=False),
            lambda x: x["variants"][0]["currentExit"].update(beforeJobCleanup=False),
            lambda x: x["variants"][1]["oldExit"].update(nativeExitCode=False),
        ]
        for mutate in mutations:
            changed = copy.deepcopy(value)
            mutate(changed)
            with self.subTest(changed=changed), self.assertRaises(C.Refusal):
                C.validate_live(changed, "a" * 64)

    def test_every_readback_reconstructs_exact_unicode_bytes(self):
        data = archive_fixture()
        result = C.validate_archives(valid_live(), data.__getitem__)
        self.assertEqual([v["originalRecordsReadBack"] for v in result], [33, 33, 33])
        self.assertEqual([v["variant"] for v in result], list(C.VARIANTS))
        self.assertTrue(all(v["bothSessionExitsBeforeCleanup"] for v in result))

    def test_frame_and_readback_mutations_refuse_without_partial_success(self):
        for mutate in (
                lambda d: d["native/first-frame-proof.json"].update(extra=True),
                lambda d: d["native/first-frame-proof.json"]["records"].append(
                    copy.deepcopy(d["native/first-frame-proof.json"]["records"][0])),
                lambda d: d["native/second-frame-proof.json"]["records"][0].update(name="../foreign"),
                lambda d: d["native/first-read-0.stdout"].update(bytesBase64="not-base64"),
                lambda d: d["native/first-read-0.stdout"].update(
                    bytesBase64=C.base64.b64encode(
                        b"X" * d["native/first-read-0.stdout"]["byteLength"]).decode("ascii")),
                lambda d: d["native/first-read-0.stdout"].update(
                    bytesBase64=d["native/first-read-0.stdout"]["bytesBase64"] + "="),
                lambda d: d["native/first-read-0.stdout"].update(byteLength=True),
                lambda d: d["native/first-read-0.stdout"].update(originalSecuritySha256="bad"),
                lambda d: d["native/first-read-0.stdout"].update(originalIdentity="bad\nidentity"),
                lambda d: d["native/first-read-0.stdout"].update(immutableRecordEvidenceOnly=False),
                lambda d: d["native/first-read-0.stdout"].update(fileChanged=True),
                lambda d: d["native/first-read-0.stdout"].update(sourceWritten=True),
                lambda d: d["native/first-read-0.stdout"].update(unknown=True),
                lambda d: d["native/first-read-1.stdout"].update(planId="f" * 64),
                lambda d: d["native/first-read-0.stdout"].update(sha256="f" * 64)):
            data = archive_fixture()
            mutate(data)
            with self.subTest(mutate=mutate), self.assertRaises(C.Refusal):
                C.validate_archives(valid_live(), data.__getitem__)
        data = archive_fixture()
        del data["serena/second-read-0.stdout"]
        with self.assertRaises(KeyError):
            C.validate_archives(valid_live(), data.__getitem__)


class AdmissionTests(unittest.TestCase):
    def image_record(self, producer="owned-producer"):
        image = C.BASE / "runs-cli" / producer / "owned-release-cli.exe"
        return image, {"path": str(image), "sha256": "a" * 64, "fileIdentity": [1, 2],
                       "bytes": 100, "mtimeNs": 3, "links": 1, "noReparseAncestors": True,
                       "writersAndDeletionDeniedThroughRecheck": True}

    def test_only_fixed_private_image_role_and_complete_identity_are_admitted(self):
        image, record = self.image_record()
        C.validate_image_role(image, record, "owned-producer")
        for mutate in (
                lambda r: r.update(path=str(C.ROOT / "target/release/yoke.exe")),
                lambda r: r.update(path=str(image.with_name("renamed.exe"))),
                lambda r: r.update(links=2),
                lambda r: r.update(links=True),
                lambda r: r.update(bytes=C.BUDGETS["imageBytes"] + 1),
                lambda r: r.update(fileIdentity=[1, 0]),
                lambda r: r.update(noReparseAncestors=False),
                lambda r: r.update(writersAndDeletionDeniedThroughRecheck=False),
                lambda r: r.update(extra="unknown")):
            changed = copy.deepcopy(record)
            mutate(changed)
            with self.subTest(changed=changed), self.assertRaises(C.Refusal):
                C.validate_image_role(image, changed, "owned-producer")
        with self.assertRaises(C.Refusal):
            C.validate_image_role(image, record, "../foreign")

    def test_incomplete_producer_refuses_before_image_pin(self):
        cli = SimpleNamespace(producer_admission=mock.Mock(
            side_effect=RuntimeError("private capability must never be printed")))
        read_pin = mock.Mock(side_effect=AssertionError("Native must remain unread"))
        result = {"nativeImageReadAttempted": False, "nativeImageRead": False}
        opt = SimpleNamespace(producer_run_id="owned-producer", source_commit=C.SOURCE_COMMIT)
        with ExitStack() as stack, self.assertRaises(RuntimeError):
            C.admit_image(cli, {"ReadPin": read_pin}, stack, None, opt, {}, {}, result)
        read_pin.assert_not_called()
        self.assertFalse(result["nativeImageReadAttempted"])

    def test_default_or_foreign_image_refuses_before_metadata_or_native_read(self):
        image, record = self.image_record()
        record["path"] = str(C.ROOT / "target/release/yoke.exe")
        cli = SimpleNamespace(producer_admission=mock.Mock(return_value=(image, record, {}, {})),
                              MetadataPin=mock.Mock(side_effect=AssertionError("Too late")))
        read_pin = mock.Mock(side_effect=AssertionError("Native must remain unread"))
        opt = SimpleNamespace(producer_run_id="owned-producer", source_commit=C.SOURCE_COMMIT)
        with ExitStack() as stack, self.assertRaises(C.Refusal):
            C.admit_image(cli, {"ReadPin": read_pin}, stack, None, opt, {}, {}, {})
        cli.MetadataPin.assert_not_called()
        read_pin.assert_not_called()

    def test_closed_spec_uses_named_job_and_disjoint_owned_paths(self):
        image, record = self.image_record()
        fixture, evidence = C.PRIVATE / "one" / "fixture", C.PRIVATE / "one" / "worker-evidence"
        name = "Local\\YokeHistoryCI-" + "a" * 64
        spec = {"native": str(image), "nativeSha256": record["sha256"], "fixture": str(fixture),
                "output": str(evidence), "workerJobName": name}
        C.validate_spec(spec, image, record["sha256"], fixture, evidence, name)
        for mutate in (
                lambda s: s.update(native=str(C.ROOT / "target/release/yoke.exe")),
                lambda s: s.update(extra=True),
                lambda s: s.update(workerJobName="Global\\YokeHistoryCI-" + "a" * 64),
                lambda s: s.update(nativeSha256="b" * 64)):
            changed = copy.deepcopy(spec)
            mutate(changed)
            with self.subTest(changed=changed), self.assertRaises(C.Refusal):
                C.validate_spec(changed, image, record["sha256"], fixture, evidence, name)
        changed = dict(spec, output=str(fixture))
        with self.assertRaises(C.Refusal):
            C.validate_spec(changed, image, record["sha256"], fixture, fixture, name)

    def test_lower_disk_refuses_before_loading_helpers_or_producer(self):
        fake_os = SimpleNamespace(name="nt")
        opt = SimpleNamespace(source_commit=C.SOURCE_COMMIT, run_id="one", producer_run_id="two")
        with mock.patch.object(C, "os", fake_os), \
             mock.patch.object(C.shutil, "disk_usage",
                               return_value=SimpleNamespace(free=C.BUDGETS["imageAdmissionBytes"] - 1)), \
             mock.patch.object(C, "load_runtime", side_effect=AssertionError("Must not load")):
            value = C.execute(opt)
        self.assertFalse(value["completed"])
        self.assertEqual(value["failureCode"], "disk")
        self.assertFalse(value["nativeImageReadAttempted"])
        self.assertFalse(value["nativeExecutionRequested"])

    def test_external_errors_never_expose_fixture_messages(self):
        opt = SimpleNamespace(source_commit=C.SOURCE_COMMIT, run_id="one", producer_run_id="two")
        with mock.patch.object(C, "os", SimpleNamespace(name="nt")), \
             mock.patch.object(C.shutil, "disk_usage",
                               return_value=SimpleNamespace(free=C.BUDGETS["imageAdmissionBytes"])), \
             mock.patch.object(C, "control_map", side_effect=RuntimeError("private bearer capability")):
            value = C.execute(opt)
        self.assertFalse(value["completed"])
        self.assertEqual(value["failureCode"], "external-failure")
        self.assertNotIn("bearer", json.dumps(value))
        output = io.StringIO()
        with mock.patch.object(C, "execute", return_value=value), mock.patch("sys.stdout", output):
            self.assertEqual(C.main(["--source-commit", C.SOURCE_COMMIT, "--run-id", "one",
                                     "--producer-run-id", "two"]), 1)
        self.assertNotIn("bearer", output.getvalue())
        self.assertNotIn("fixture", output.getvalue())


class SourceAndPathTests(unittest.TestCase):
    def fake_g(self, listing):
        return {"git_capture": mock.Mock(return_value=listing),
                "source_digest": mock.Mock(return_value={"bytes": 1, "sha256": "a" * 64})}

    def test_history_selector_is_broader_and_separate_from_producer_map(self):
        g = self.fake_g(b"Cargo.toml\0src/owned.ts\0")
        value = C.history_source_map(g, None, None, None, {}, "before")
        self.assertEqual(set(value), {"Cargo.toml", "src/owned.ts"})
        self.assertEqual(g["git_capture"].call_args.args[-1],
                         ["ls-files", "-z", "--", *C.HISTORY_SELECTOR])
        self.assertIn("src", C.HISTORY_SELECTOR)
        self.assertIn("python", C.HISTORY_SELECTOR)

    def test_history_inventory_path_cardinality_and_duplicates_refuse_before_read(self):
        for listing in [b"", b"../foreign\0", b"C:/foreign\0", b"src\\foreign\0",
                        b"src/./foreign\0", b"src/line\nname\0", b"src/trailing. \0",
                        b"src/a\0src/a\0", b"src/a", b"a\0" * 2049]:
            g = self.fake_g(listing)
            with self.subTest(listing=listing[:30]), self.assertRaises(C.Refusal):
                C.history_source_map(g, None, None, None, {}, "before")
            g["source_digest"].assert_not_called()

    def test_history_source_bytes_and_deadline_are_bounded(self):
        g = self.fake_g(b"one\0")
        g["source_digest"].return_value = {"bytes": 16_000_001, "sha256": "a" * 64}
        with self.assertRaises(C.Refusal):
            C.history_source_map(g, None, None, None, {}, "before")
        g = self.fake_g(b"one\0two\0")
        with mock.patch.object(C.time, "monotonic", side_effect=[0, 0, 121]):
            with self.assertRaises(C.Refusal):
                C.history_source_map(g, None, None, None, {}, "after")
        self.assertEqual(g["source_digest"].call_count, 1)
        g = self.fake_g(b"only\0")
        with mock.patch.object(C.time, "monotonic", side_effect=[0, 0, 121]):
            with self.assertRaises(C.Refusal):
                C.history_source_map(g, None, None, None, {}, "before")

    def test_fixture_environment_never_inherits_tokens_or_forges_ci(self):
        with tempfile.TemporaryDirectory(prefix="owned-history-env-") as directory:
            root = Path(directory).resolve()
            with mock.patch.dict(C.os.environ, {"PATH": "owned-tool-path", "SystemRoot": "C:\\Windows",
                                               "TOKEN": "must-not-propagate", "GITHUB_ACTIONS": "true",
                                               "GITHUB_SHA": "a" * 40}, clear=True):
                environment = C.fixture_environment(root)
            self.assertNotIn("TOKEN", environment)
            self.assertNotIn("GITHUB_ACTIONS", environment)
            self.assertNotIn("GITHUB_SHA", environment)
            self.assertEqual(environment["PYTHONUTF8"], "1")
            self.assertTrue(all(Path(environment[n]).is_relative_to(root) for n in
                                ("HOME", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP")))

    def test_owned_unicode_text_limit_precedes_open_and_linked_text_refuses(self):
        with tempfile.TemporaryDirectory(prefix="owned-history-text-") as directory:
            path = Path(directory).resolve() / "owned ' π ; text.json"
            path.write_bytes(b"owned")
            self.assertEqual(C.text_bytes(path, 5), b"owned")
            with mock.patch.object(Path, "open", side_effect=AssertionError("Must not open")):
                with self.assertRaises(C.Refusal):
                    C.text_bytes(path, 4)
            with mock.patch.object(C, "ordinary", side_effect=C.Refusal("path")), \
                 mock.patch.object(Path, "open", side_effect=AssertionError("Must not open")):
                with self.assertRaises(C.Refusal):
                    C.text_bytes(path)

    def test_occupied_role_and_traversal_never_replace_own_text(self):
        with tempfile.TemporaryDirectory(prefix="owned-history-namespace-") as directory:
            parent = Path(directory).resolve()
            occupied = parent / "taken"
            occupied.mkdir()
            (occupied / "foreign.txt").write_bytes(b"preserved")
            with self.assertRaises(C.Refusal):
                C.fresh_directory(parent, "taken")
            with self.assertRaises(C.Refusal):
                C.fresh_directory(parent, "../escape")
            self.assertEqual((occupied / "foreign.txt").read_bytes(), b"preserved")

    def test_result_publication_does_not_replace_an_occupied_file(self):
        with tempfile.TemporaryDirectory(prefix="owned-history-result-") as directory:
            path = Path(directory).resolve() / "result.json"
            path.write_bytes(b"owned foreign result")
            with self.assertRaises(FileExistsError):
                C.write_json(path, {"completed": True})
            self.assertEqual(path.read_bytes(), b"owned foreign result")


class ScopedCompletionTests(unittest.TestCase):
    def mock_consumer(self, late_pin_failure):
        # All dependency and native observations are mocks. Only inert JSON is
        # written; no executable file exists and no process/API is launched.
        with tempfile.TemporaryDirectory(prefix="owned-history-flow-") as directory:
            root = Path(directory).resolve()
            base = root / "validation"
            base.mkdir()
            control, original, harness = root / "control", root / "control-cli", root / "history.py"
            controls = {name: {"bytes": 1, "sha256": "a" * 64} for name in C.CONTROL_NAMES}
            producer_controls = {name: {"bytes": 1, "sha256": digest}
                                 for name, digest in C.PRODUCER_PINS.items()}
            image = base / "runs-cli/owned-producer/owned-release-cli.exe"
            record = {"path": str(image), "sha256": "a" * 64, "fileIdentity": [1, 2],
                      "bytes": 100, "mtimeNs": 3, "links": 1, "noReparseAncestors": True,
                      "writersAndDeletionDeniedThroughRecheck": True}

            class Pin:
                def __init__(self, api, path, maximum, image=False):
                    self.path = path

                def __enter__(self):
                    return self

                def __exit__(self, *_):
                    if late_pin_failure and self.path == control / "local_history_controller.py":
                        raise RuntimeError("private fixture capability must not be published")

                def bytes(self):
                    return self.path.read_bytes()

                def record(self):
                    if self.path == harness:
                        return {"sha256": C.HISTORY_SHA}
                    if self.path.parent == original:
                        return {"sha256": C.PRODUCER_PINS[self.path.name]}
                    if self.path.parent == control:
                        return {"sha256": controls[self.path.name]["sha256"]}
                    return {"sha256": hashlib.sha256(self.bytes()).hexdigest()}

                def recheck(self):
                    return self.record()

            class ImagePin:
                def __enter__(self):
                    return self

                def __exit__(self, *_):
                    return None

                def record(self):
                    return record

                def recheck(self):
                    return record

            def admit(cli, g, stack, api, opt, sources, before, result):
                result.update(nativeImageReadAttempted=True, nativeImageRead=True)
                image_pin = stack.enter_context(ImagePin())
                producer_pins = {"owned-proof.json": SimpleNamespace(recheck=lambda: None)}
                return image, record, producer_pins, {}, {}, image_pin

            def worker(spec, fixture, output, environment, job):
                self.assertNotIn("GITHUB_ACTIONS", environment)
                self.assertNotIn("GITHUB_SHA", environment)
                C.write_json(output / "job.json", valid_job())
                C.write_json(output / "live-result.json", valid_live())
                for name, value in archive_fixture().items():
                    path = output / name
                    path.parent.mkdir(exist_ok=True)
                    C.write_json(path, value)

            live = SimpleNamespace(bounded_worker=mock.Mock(side_effect=worker),
                                   output_size=mock.Mock(return_value=0))
            g = {"ReadPin": Pin, "environment_for": lambda mode: {},
                 "source_map": lambda *args: {"native/owned.rs": {"bytes": 1, "sha256": "a" * 64}}}
            cli = SimpleNamespace(checked_protected=mock.Mock())
            fake_os = SimpleNamespace(name="nt", path=os.path, environ={}, urandom=lambda n: b"a" * n)
            opt = SimpleNamespace(source_commit=C.SOURCE_COMMIT, run_id="owned-history",
                                  producer_run_id="owned-producer")
            with mock.patch.multiple(C, ROOT=root, BASE=base, CONTROL=control, CLI_CONTROL=original,
                                     RUNS=base / "runs-history", PRIVATE=base / "private-history",
                                     HISTORY_PATH=harness, os=fake_os), \
                 mock.patch.object(C.shutil, "disk_usage",
                                   return_value=SimpleNamespace(free=2_000_000_000)), \
                 mock.patch.object(C, "control_map", return_value=controls), \
                 mock.patch.object(C, "text_bytes", return_value=b"{}"), \
                 mock.patch.object(C, "validate_manifest"), \
                 mock.patch.object(C, "load_runtime", return_value=(cli, g, None, None)), \
                 mock.patch.object(C, "Mutex", return_value=nullcontext()), \
                 mock.patch.object(C, "original_controls", return_value=producer_controls), \
                 mock.patch.object(C, "load_source", return_value=live), \
                 mock.patch.object(C, "history_source_map", return_value={"src/owned.ts": "b" * 64}), \
                 mock.patch.object(C, "admit_image", side_effect=admit):
                result = C.execute(opt)
            live.bounded_worker.assert_called_once()
            self.assertFalse(image.exists())
            self.assertNotIn("capability", json.dumps(result))
            published = json.loads((base / "runs-history/owned-history/result.json").read_text())
            self.assertEqual(published["completed"], result["completed"])
            return result

    def test_mocked_complete_flow_requires_all_frames_and_natural_exits(self):
        result = self.mock_consumer(False)
        self.assertTrue(result["completed"])
        self.assertTrue(result["allOriginalRecordsIndependentlyReadBack"])
        self.assertEqual(result["consumerControlCount"], 5)
        self.assertEqual(result["producerControlCount"], 7)
        self.assertFalse(result["archivePurgeQualification"])
        self.assertFalse(result["ownerRetirementQualification"])

    def test_late_pin_failure_cannot_publish_success_or_private_message(self):
        result = self.mock_consumer(True)
        self.assertFalse(result["completed"])
        self.assertEqual(result["phase"], "final-recheck")
        self.assertEqual(result["failureCode"], "external-failure")


if __name__ == "__main__":
    unittest.main()
