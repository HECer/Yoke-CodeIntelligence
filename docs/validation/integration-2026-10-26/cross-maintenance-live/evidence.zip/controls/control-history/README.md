# Separate local original-history consumer

Source-only implementation. Parent review, authored unit tests, a completed
matching producer, actual consumer execution and evidence review remain unrun
by this implementation agent. This is not release, VSIX or platform acceptance.

The original seven control-cli files and tracked history harness are unchanged.
This directory is outside the producer's source/control maps. It has its own
five-file map and a manifest pinning the other four files; the manifest itself
is included in the before/after consumer map. There is no self-referential hash.

## Fixed invocation and native admission

After the parent reviews this source and runs its tests, the only supported
consumer arguments are:

~~~powershell
python -B validation/integration-20261025/platform-repairs/control-history/local_history_controller.py --source-commit f8b02d4eb0145de95f108e12df51786d368b6ef3 --run-id history-reviewed --producer-run-id future-completed-producer
~~~

The placeholder is not an arbitrary image selector. The original unchanged
producer_admission derives the private image from a matching source commit,
producer run and fresh fixed host output role, and validates all original
receipt, lifecycle, Cargo, source, control and protected-role requirements.
Incomplete producers refuse before consumer image reads or execution. In
particular, release-cli-isolated-f8-r2 is invalid and must not be consumed or
salvaged. A version result alone does not qualify history.

The parent must use the script installed in its prepared isolated checkout.
ROOT derives from the script's own file location. The CLI/base roots must agree
with it. Original producer source pins, selected image and private receipt pins
stay held during the consumer. No default yoke.exe, caller executable, arbitrary
native arguments, environment-based image selector or fake CI environment is
accepted. The producer remains a trusted host observation, not a sandbox or
proof against another equally privileged process.

The existing per-root validation mutex is shared with the original controller.
The parent must additionally serialize Cargo/consumers across the entire host.
No compiler or producer runs as part of this consumer.

## Unchanged archive worker and separate budgets

The wrapper loads the hash-pinned history script under a non-main module name,
then calls its unchanged bounded_worker. That function starts exactly:

~~~text
<current Python> -I <tracked scripts/host_history_live.py> --worker <private spec>
~~~

The worker is created suspended, assigned to a new named Job, and resumed.
Its existing internal entry checks membership in that exact named Job before
native reads. Local use does not set GITHUB_ACTIONS or GITHUB_SHA and does not
invoke the CI-only main route. The legacy Local\YokeHistoryCI name is a required
Job namespace, not a claim that this run occurred on a CI runner.

The closed specification has only native, nativeSha256, fixture, output and
workerJobName. Every path comes from the fixed completed producer or newly
created private directories. The spec and history source stay read-pinned.

Original budgets remain separate:

- Producer: release profile, 3,600 seconds, 4-GB start floor, 500-MB running
  reserve, one-second drain and two-second cleanup.
- Consumer image admission: 1.2 GB free and a 512-MB image cap.
- History worker: 180 seconds, one-second drain within that deadline and its
  existing ten-second cleanup. This is not a two-second history cleanup.
- History fixture/evidence trees: each 32 MB and 1,024 entries; 500-MB disk
  reserve; 1-MB JSON/CLI streams; 16-MB frames; 64-KB spec; 40-second CLI,
  ten-second RPC and six-second HTTP operation limits.

The broader history source selector is reproduced through the reviewed bounded
Git capture, using the unchanged selector and listing/count/byte limits, plus
ordinary-file checks. That avoids introducing an unbounded local Git subprocess.
It is compared before/after separately from the producer's selected native,
script, Cargo and workflow map. Neither is relabelled as the 1,135-file
preparation inventory. Tools, dependencies, caches and all host state are not
frozen by those maps.

## Proof and publication

Success requires the complete ordered native, serena and persistent-python
variants, all original archive assertions, both owning Session exits and the
selected Python runtime exit before Job cleanup. The worker Job must report
root exit 0 and an empty tree before force. Later forced cleanup cannot turn a
surviving child or incomplete worker into a pass.

The consumer independently parses all six frame proofs and each original
record's CLI readback. Closed schemas, exact record names/lengths, canonical
Base64, SHA256 and nonmutation/immutable-evidence flags must agree. The unchanged
worker separately compares every frame and readback to its original fixture
bytes, checks pending refusals under both authorities, recovers the reviewed
event and proves a fresh same-host save.

All raw worker/CLI output, fixture data and stderr stay under the separate
private-history namespace, outside runs-history. Fixture stderr may carry
management capabilities. Never publish private-history, a whole checkout or
arbitrary producer output. Public consumer results contain closed reason codes,
booleans, counts and hashes; exception messages and raw worker output are never
printed or copied into public results. Selected maps retain their stated scope.

Success is set only after final image/source/control/protected-role checks and
all read-pin/mutex exits succeed. Result publication failure is also failure.
There is no fallback to an earlier binary, retry, journal repair, data purge or
automatic cleanup of another run.

This scope qualifies only the original archive workflow. It does not qualify
standalone owner retirement, physical archive purge, a browser, bundled-runtime
VSIX, main integration, all providers or the full project.

## Authored tests and remaining gates

test_local_history_controller.py contains mocked protocol/admission/lifecycle
checks and owned inert text/JSON fixtures. No actual native artifact is needed.
It includes incomplete producer/image-role refusal, metadata/schema/variant
mutations, exact Unicode readback, path/budget/environment restrictions and a
mocked whole consumer whose late pin failure cannot publish success.

No test, controller/helper function, build, worker or native image was executed
by the implementation agent. Only AST/source/hash/whitespace checks may be
reported for this handoff. Parent gates remain independent source review, those
tests, a new valid producer, version qualification, actual local archive
acceptance and retained evidence review. The unchanged history tests' real inert
Job membership/tree cases should also be run by the parent under its approved
test runner.
