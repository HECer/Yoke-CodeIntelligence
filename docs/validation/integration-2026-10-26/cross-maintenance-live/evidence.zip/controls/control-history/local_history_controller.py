"""Separate local archive acceptance; never accepts an arbitrary executable."""
import argparse
import base64
import binascii
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import time
import types

ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
BASE = ROOT / "validation/integration-20261025/platform-repairs"
CONTROL = BASE / "control-history"
CLI_CONTROL = BASE / "control-cli"
RUNS = BASE / "runs-history"
PRIVATE = BASE / "private-history"
OWNER = "local-original-archive-history-consumer-v1"
SOURCE_COMMIT = "f8b02d4eb0145de95f108e12df51786d368b6ef3"
CONTROL_NAMES = ("local_history_controller.py", "test_local_history_controller.py",
                 "README.md", "review-manifest.json", ".gitattributes")
PRODUCER_PINS = {
    "cli_controller.py": "d6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582",
    "base_controller.py": "a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7",
    "private_windows_api.py": "d9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500",
    "test_metadata_pin.py": "6f555a7b29a85f17c404cba57474c682ae84adf28915ac8b1f10db73b9041aca",
    "README.md": "1bbe94b3ac00dff9d1116ab8ccc8aadce545b14dd536888644d1cb92eac3cea6",
    "review-manifest.json": "8dd48b1595220464fc638d458a6f8dd7b19f55454c35c0bda7eb7cea255b94f8",
    ".gitattributes": "a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9",
}
HISTORY_PATH = ROOT / "scripts/host_history_live.py"
HISTORY_SHA = "3a3f5de28756ddcc383c3c92821f15fd5db24a72c324ef6a20d1ed6a24f819b2"
HISTORY_SELECTOR = ("Cargo.toml", "Cargo.lock", "package.json", "package-lock.json",
                    "native", "src", "python", "scripts", ".github/workflows/rust.yml")
VARIANTS = ("native", "serena", "persistent-python")
RUN_PATTERN = re.compile(r"[a-z][a-z0-9-]{0,95}")
HEX_PATTERN = re.compile(r"[0-9a-f]{64}")
RECORD_PATTERN = re.compile(r"yoke-doc-[0-9a-f]{64}-[0-9a-f]{64}\.(?:plan|e[0-9]{4})\.json")
EVIDENCE_PATTERN = re.compile(
    r"(?:native|serena|persistent-python)/(?:first|second)-(?:frame-proof\.json|read-[0-9]{1,2}\.stdout)")
BUDGETS = {
    "imageAdmissionBytes": 1_200_000_000, "reserveBytes": 500_000_000,
    "imageBytes": 512_000_000, "jsonBytes": 1_000_000, "specBytes": 64_000,
    "frameBytes": 16_000_000, "outputBytesPerTree": 32_000_000,
    "entriesPerTree": 1024, "workerSeconds": 180, "workerDrainSeconds": 1,
    "workerCleanupSeconds": 10, "producerCleanupSeconds": 2,
    "cliSeconds": 40, "rpcSeconds": 10, "httpSeconds": 6,
    "historyListingBytes": 1_000_000, "historySourceFiles": 2048,
    "historySourceBytes": 96_000_000, "historySourceFileBytes": 16_000_000,
    "historySourceObservationSeconds": 120,
}
CODES = {
    "arguments", "platform", "disk", "path", "occupied", "source", "manifest",
    "control", "mutex", "producer", "image", "spec", "json", "evidence",
    "job", "variants", "record", "budget", "drift", "external-failure",
}


class Refusal(RuntimeError):
    def __init__(self, code):
        self.code = code if code in CODES else "external-failure"
        super().__init__(self.code)


def require(value, code):
    if not value:
        raise Refusal(code)


def exact_keys(value, keys, code):
    require(type(value) is dict and set(value) == set(keys), code)


def hexadecimal(value):
    return type(value) is str and HEX_PATTERN.fullmatch(value) is not None


def integer(value, minimum=0, maximum=None):
    return type(value) is int and value >= minimum and (maximum is None or value <= maximum)


def unique_json(data, maximum=1_000_000):
    require(type(data) is bytes and len(data) <= maximum, "json")

    def pairs(items):
        result = {}
        for name, value in items:
            require(name not in result, "json")
            result[name] = value
        return result
    try:
        return json.loads(data, object_pairs_hook=pairs)
    except (ValueError, UnicodeError):
        raise Refusal("json") from None


class Arguments(argparse.ArgumentParser):
    def error(self, message):
        raise Refusal("arguments")


def options(arguments):
    parser = Arguments(description=__doc__, add_help=False)
    parser.add_argument("--source-commit", required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--producer-run-id", required=True)
    value = parser.parse_args(arguments)
    require(value.source_commit == SOURCE_COMMIT
            and RUN_PATTERN.fullmatch(value.run_id)
            and RUN_PATTERN.fullmatch(value.producer_run_id)
            and value.run_id != value.producer_run_id, "arguments")
    return value


def ordinary(path, directory=False):
    path = Path(path)
    require(path.is_absolute() and os.path.normpath(str(path)) == str(path), "path")
    for parent in reversed(path.parents):
        info = parent.lstat()
        require(stat.S_ISDIR(info.st_mode)
                and not getattr(info, "st_file_attributes", 0) & 0x400, "path")
    info = path.lstat()
    require(not getattr(info, "st_file_attributes", 0) & 0x400
            and (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)), "path")
    if not directory:
        require(info.st_nlink == 1 and info.st_ino > 0, "path")
    return info


def text_bytes(path, maximum=1_000_000):
    require(path.suffix.lower() not in (".exe", ".pdb", ".dll", ".lib", ".obj", ".o"), "path")
    info = ordinary(path)
    require(info.st_size <= maximum, "budget")
    with path.open("rb") as stream:
        data = stream.read(maximum + 1)
    after = ordinary(path)
    require(len(data) == info.st_size <= maximum
            and (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns) ==
                (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns), "drift")
    return data


def control_map():
    return {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for name in CONTROL_NAMES for data in (text_bytes(CONTROL / name),)}


def validate_manifest(value, controls, commit):
    exact_keys(value, ("schema", "owner", "scope", "sourceCommit", "consumerSources",
                       "producerSources", "historySource", "budgets"), "manifest")
    require(type(value["schema"]) is int and value["schema"] == 1
            and value["owner"] == OWNER and value["scope"] == "original-archive-only"
            and value["sourceCommit"] == commit == SOURCE_COMMIT, "manifest")
    expected_names = set(CONTROL_NAMES) - {"review-manifest.json"}
    exact_keys(value["consumerSources"], expected_names, "manifest")
    require(set(controls) == set(CONTROL_NAMES)
            and all(hexadecimal(digest) and controls[name]["sha256"] == digest
                    for name, digest in value["consumerSources"].items())
            and value["producerSources"] == PRODUCER_PINS
            and value["historySource"] == HISTORY_SHA, "manifest")
    exact_keys(value["budgets"], BUDGETS, "manifest")
    require(all(type(number) is int for number in value["budgets"].values())
            and value["budgets"] == BUDGETS, "manifest")


def load_source(path, digest, name):
    data = text_bytes(path)
    require(hashlib.sha256(data).hexdigest() == digest, "control")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(data, str(path), "exec"), module.__dict__)
    return module


def load_runtime():
    cli = load_source(CLI_CONTROL / "cli_controller.py", PRODUCER_PINS["cli_controller.py"],
                      "reviewed_local_history_cli")
    g = cli.load_base()
    require(cli.ROOT == ROOT and cli.CONTROL == CLI_CONTROL
            and cli.RUNS == BASE / "runs-cli" and g["ROOT"] == ROOT, "control")
    api, extended = g["load_windows_api"]()
    return cli, g, api, extended


def original_controls(g):
    controls = g["controls_map"]()
    require(set(controls) == set(PRODUCER_PINS)
            and all(row.get("sha256") == PRODUCER_PINS[name]
                    for name, row in controls.items()), "control")
    return controls


def fresh_directory(parent, name):
    require(type(name) is str and RUN_PATTERN.fullmatch(name), "path")
    ordinary(parent, directory=True)
    path = parent / name
    require(not os.path.lexists(path), "occupied")
    path.mkdir(mode=0o700)
    ordinary(path, directory=True)
    return path


def fixed_parent(path):
    ordinary(path.parent, directory=True)
    if not os.path.lexists(path):
        path.mkdir(mode=0o700)
    ordinary(path, directory=True)
    return path


class Mutex:
    def __init__(self, api):
        self.api = api
        self.handle = None
        self.held = False

    def __enter__(self):
        import _winapi
        name = "Local\\YokeValidation-" + hashlib.sha256(str(ROOT).encode("utf8")).hexdigest()[:24]
        self.handle = self.api.CreateMutexW(None, False, name)
        require(bool(self.handle), "mutex")
        try:
            result = _winapi.WaitForSingleObject(self.handle, 0)
        except BaseException:
            closed = self.api.CloseHandle(self.handle)
            self.handle = None
            require(bool(closed), "mutex")
            raise
        self.held = result in (0, 128)
        if not self.held:
            closed = self.api.CloseHandle(self.handle)
            self.handle = None
            require(bool(closed), "mutex")
            raise Refusal("mutex")
        return self

    def __exit__(self, *_):
        released = False
        try:
            released = not self.held or bool(self.api.ReleaseMutex(self.handle))
        finally:
            try:
                closed = self.handle is None or bool(self.api.CloseHandle(self.handle))
            finally:
                self.handle = None
                self.held = False
        require(released and closed, "mutex")


def history_source_map(g, api, extended, out, environment, phase):
    require(phase in ("before", "after"), "source")
    listing = g["git_capture"](api, extended, out, environment, "history-files-" + phase,
                               ["ls-files", "-z", "--", *HISTORY_SELECTOR])
    require(len(listing) <= BUDGETS["historyListingBytes"], "budget")
    try:
        names = listing.decode("utf8", "strict").split("\0")
    except UnicodeError:
        raise Refusal("source") from None
    require(names[-1] == "" and 0 < len(names) - 1 <= BUDGETS["historySourceFiles"], "source")
    names.pop()
    require(len(names) == len(set(names)), "source")
    result, total = {}, 0
    deadline = time.monotonic() + BUDGETS["historySourceObservationSeconds"]
    for name in names:
        require(time.monotonic() < deadline, "budget")
        path = Path(name)
        require(name and not path.is_absolute() and ":" not in name and "\\" not in name
                and all(ord(c) >= 32 and ord(c) != 127 for c in name)
                and all(part not in ("", ".", "..") and part.rstrip(" .") == part
                        for part in name.split("/")), "source")
        row = g["source_digest"](ROOT / name, BUDGETS["historySourceFileBytes"])
        require(time.monotonic() < deadline, "budget")
        require(integer(row.get("bytes"), 0, BUDGETS["historySourceFileBytes"])
                and hexadecimal(row.get("sha256")), "source")
        total += row["bytes"]
        require(total <= BUDGETS["historySourceBytes"], "budget")
        result[name] = row["sha256"]
    return result


def fixture_environment(fixture):
    environment = {name: os.environ[name] for name in
                   ("PATH", "SystemRoot", "SystemDrive", "WINDIR") if name in os.environ}
    for name in ("home", "roaming", "local", "tmp"):
        (fixture / name).mkdir(mode=0o700)
    for key, name in (("HOME", "home"), ("USERPROFILE", "home"), ("APPDATA", "roaming"),
                      ("LOCALAPPDATA", "local"), ("TEMP", "tmp"), ("TMP", "tmp")):
        environment[key] = str(fixture / name)
    environment.update(PYTHONUTF8="1", PYTHONDONTWRITEBYTECODE="1", DO_NOT_TRACK="1")
    return environment


def validate_spec(spec, image, digest, fixture, output, job_name):
    exact_keys(spec, ("native", "nativeSha256", "fixture", "output", "workerJobName"), "spec")
    require(hexadecimal(digest) and spec == {
        "native": str(image), "nativeSha256": digest, "fixture": str(fixture),
        "output": str(output), "workerJobName": job_name}, "spec")
    require(type(job_name) is str and re.fullmatch(r"Local\\YokeHistoryCI-[0-9a-f]{64}", job_name),
            "spec")
    require(image.name == "owned-release-cli.exe" and image.is_absolute()
            and fixture.is_absolute() and output.is_absolute()
            and fixture != output and image.parent != fixture and image.parent != output, "spec")
    require(not fixture.is_relative_to(output) and not output.is_relative_to(fixture)
            and not image.is_relative_to(fixture) and not image.is_relative_to(output)
            and not fixture.is_relative_to(image.parent)
            and not output.is_relative_to(image.parent), "spec")


def validate_image_role(image, record, producer_run_id):
    require(type(producer_run_id) is str and RUN_PATTERN.fullmatch(producer_run_id), "image")
    expected = BASE / "runs-cli" / producer_run_id / "owned-release-cli.exe"
    exact_keys(record, ("path", "sha256", "fileIdentity", "bytes", "mtimeNs", "links",
                        "noReparseAncestors", "writersAndDeletionDeniedThroughRecheck"), "image")
    require(image == expected and record["path"] == str(expected)
            and hexadecimal(record["sha256"]) and integer(record["bytes"], 1, BUDGETS["imageBytes"])
            and integer(record["mtimeNs"]) and type(record["links"]) is int and record["links"] == 1
            and type(record["fileIdentity"]) is list and len(record["fileIdentity"]) == 2
            and integer(record["fileIdentity"][0]) and integer(record["fileIdentity"][1], 1)
            and record["noReparseAncestors"] is True
            and record["writersAndDeletionDeniedThroughRecheck"] is True, "image")


def admit_image(cli, g, stack, api, opt, sources, producer_controls, result):
    image, record, pins, _ = cli.producer_admission(
        g, stack, api, opt.producer_run_id, opt.source_commit, sources, producer_controls)
    validate_image_role(image, record, opt.producer_run_id)
    protected = {name: stack.enter_context(cli.MetadataPin(api, name))
                 for name in cli.PROTECTED_RELATIVE}
    before = {name: pin.recheck() for name, pin in protected.items()}
    cli.checked_protected(before, before)
    require(before == g["unique_json"](pins["protected-after.json"].bytes()), "producer")
    require(shutil.disk_usage(ROOT).free >= BUDGETS["imageAdmissionBytes"], "disk")
    result["nativeImageReadAttempted"] = True
    image_pin = stack.enter_context(g["ReadPin"](api, image, BUDGETS["imageBytes"], image=True))
    result["nativeImageRead"] = True
    require(image_pin.record() == record, "image")
    return image, record, pins, protected, before, image_pin


def validate_job(job):
    exact_keys(job, ("startedSuspended", "assignedBeforeResume", "complete", "pid", "exitCode",
                     "activeAtParentExit", "activeBeforeCleanup", "treeExitedBeforeCleanup",
                     "activeAfterCleanup"), "job")
    require(all(job[key] is True for key in
                ("startedSuspended", "assignedBeforeResume", "complete", "treeExitedBeforeCleanup"))
            and integer(job["pid"], 1)
            and integer(job["exitCode"]) and job["exitCode"] == 0
            and integer(job["activeAtParentExit"])
            and type(job["activeBeforeCleanup"]) is int and job["activeBeforeCleanup"] == 0
            and type(job["activeAfterCleanup"]) is int and job["activeAfterCleanup"] == 0, "job")


def validate_exit(value):
    exact_keys(value, ("nativeExitCode", "stdinWasStillOpen", "beforeJobCleanup"), "variants")
    require(type(value["nativeExitCode"]) is int and value["nativeExitCode"] == 0
            and value["stdinWasStillOpen"] is True and value["beforeJobCleanup"] is True, "variants")


def validate_live(value, digest):
    exact_keys(value, ("product", "version", "complete", "nativeSha256", "variants",
                      "workerJobAdmission", "modelCalls", "analyzedSourceExecuted",
                      "existingCredentialsSelected", "nativeBrowserAcceptanceClaimed"), "variants")
    require(value["product"] == "Code Intelligence" and value["version"] == "0.5.0"
            and value["complete"] is True and value["nativeSha256"] == digest
            and type(value["modelCalls"]) is int and value["modelCalls"] == 0
            and all(value[key] is False for key in ("analyzedSourceExecuted",
                    "existingCredentialsSelected", "nativeBrowserAcceptanceClaimed")), "variants")
    exact_keys(value["workerJobAdmission"], ("specificJobMembershipConfirmed",
                                            "queryHandleClosedBeforeNativeRead"), "variants")
    require(all(item is True for item in value["workerJobAdmission"].values())
            and type(value["variants"]) is list and len(value["variants"]) == 3, "variants")
    keys = ("variant", "complete", "packages", "originalRecords", "allOriginalsReadBack",
            "oldAndCurrentAuthorityRefusedDuringPending", "configurationAndOwnerExactDuringArchival",
            "freshSameHostSaveAfterArchival", "actualJournalCurrentGeneration",
            "bothArchiveFramesRemainExact", "persistent45Retained", "runtimeExitBeforeJobCleanup",
            "currentExit", "oldExit", "analyzedSourceUnchanged")
    truth = ("complete", "allOriginalsReadBack", "oldAndCurrentAuthorityRefusedDuringPending",
             "configurationAndOwnerExactDuringArchival", "freshSameHostSaveAfterArchival",
             "actualJournalCurrentGeneration", "bothArchiveFramesRemainExact", "analyzedSourceUnchanged")
    for expected, variant in zip(VARIANTS, value["variants"]):
        exact_keys(variant, keys, "variants")
        require(variant["variant"] == expected and all(variant[key] is True for key in truth)
                and type(variant["packages"]) is int and variant["packages"] == 2
                and integer(variant["originalRecords"], 33, 64)
                and variant["persistent45Retained"] is (expected == "persistent-python")
                and variant["runtimeExitBeforeJobCleanup"] is (expected == "persistent-python"), "variants")
        validate_exit(variant["currentExit"])
        validate_exit(variant["oldExit"])


def validate_readback(value, record, plan_id):
    exact_keys(value, ("planId", "recordName", "originalIdentity", "originalSecuritySha256",
                      "sha256", "byteLength", "bytesBase64", "immutableRecordEvidenceOnly",
                      "fileChanged", "sourceWritten"), "record")
    require(hexadecimal(value["planId"]) and value["planId"] == plan_id
            and value["recordName"] == record["name"] and value["sha256"] == record["sha256"]
            and type(value["originalIdentity"]) is str
            and 0 < len(value["originalIdentity"]) <= 1024
            and not any(c in value["originalIdentity"] for c in "\0\r\n")
            and hexadecimal(value["originalSecuritySha256"])
            and type(value["byteLength"]) is int and value["byteLength"] == record["bytes"]
            and type(value["bytesBase64"]) is str
            and len(value["bytesBase64"]) <= 700_000
            and value["immutableRecordEvidenceOnly"] is True
            and value["fileChanged"] is False and value["sourceWritten"] is False, "record")
    try:
        data = base64.b64decode(value["bytesBase64"], validate=True)
    except (ValueError, binascii.Error):
        raise Refusal("record") from None
    require(len(data) == record["bytes"]
            and base64.b64encode(data).decode("ascii") == value["bytesBase64"]
            and hashlib.sha256(data).hexdigest() == record["sha256"], "record")


def validate_archives(value, read):
    summaries = []
    for variant in value["variants"]:
        label, seen, plans, packages = variant["variant"], set(), [], []
        for tag in ("first", "second"):
            frame = read(label + "/" + tag + "-frame-proof.json")
            exact_keys(frame, ("sha256", "records"), "record")
            require(hexadecimal(frame["sha256"]) and type(frame["records"]) is list
                    and 0 < len(frame["records"]) <= 32, "record")
            plan_id = None
            for index, record in enumerate(frame["records"]):
                exact_keys(record, ("name", "bytes", "sha256"), "record")
                require(type(record["name"]) is str and RECORD_PATTERN.fullmatch(record["name"])
                        and record["name"] not in seen and integer(record["bytes"], 1, 512_000)
                        and hexadecimal(record["sha256"]), "record")
                seen.add(record["name"])
                readback = read(label + "/" + tag + "-read-" + str(index) + ".stdout")
                if plan_id is None:
                    require(type(readback) is dict and hexadecimal(readback.get("planId")), "record")
                    plan_id = readback["planId"]
                validate_readback(readback, record, plan_id)
            require(plan_id not in plans, "record")
            plans.append(plan_id)
            packages.append({"frameSha256": frame["sha256"], "records": len(frame["records"])})
        require(len(seen) == variant["originalRecords"], "record")
        summaries.append({"variant": label, "packages": packages,
                          "originalRecordsReadBack": len(seen), "bothSessionExitsBeforeCleanup": True,
                          "persistentRuntimeExitBeforeCleanup": label == "persistent-python"})
    return summaries


def write_json(path, value):
    data = json.dumps(value, ensure_ascii=True, indent=2).encode("utf8") + b"\n"
    require(len(data) <= BUDGETS["jsonBytes"], "budget")
    with path.open("xb") as stream:
        stream.write(data)


def execute(opt):
    result = {"owner": OWNER, "schema": 1, "sourceCommit": opt.source_commit,
              "runId": opt.run_id, "producerRunId": opt.producer_run_id,
              "completed": False, "nativeImageReadAttempted": False, "nativeImageRead": False,
              "nativeExecutionRequested": False, "localAcceptanceOnly": True,
              "ownerRetirementQualification": False, "archivePurgeQualification": False,
              "nativeBrowserAcceptanceClaimed": False, "releaseQualification": False,
              "vsixQualification": False, "failureCode": None, "phase": "preflight"}
    out = None
    try:
        require(os.name == "nt", "platform")
        require(shutil.disk_usage(ROOT).free >= BUDGETS["imageAdmissionBytes"], "disk")
        controls = control_map()
        manifest = unique_json(text_bytes(CONTROL / "review-manifest.json", 64_000), 64_000)
        validate_manifest(manifest, controls, opt.source_commit)
        cli, g, api, extended = load_runtime()
        with Mutex(api), ExitStack() as stack:
            fixed_parent(RUNS)
            fixed_parent(PRIVATE)
            out = fresh_directory(RUNS, opt.run_id)
            private = fresh_directory(PRIVATE, opt.run_id)
            fixture, evidence = private / "fixture", private / "worker-evidence"
            fixture.mkdir(mode=0o700)
            evidence.mkdir(mode=0o700)
            write_json(out / "request.json", {**result, "budgets": BUDGETS})
            for name in CONTROL_NAMES:
                pin = stack.enter_context(g["ReadPin"](api, CONTROL / name, 1_000_000))
                require(pin.record()["sha256"] == controls[name]["sha256"], "control")
            producer_controls = original_controls(g)
            for name in PRODUCER_PINS:
                pin = stack.enter_context(g["ReadPin"](api, CLI_CONTROL / name, 1_000_000))
                require(pin.record()["sha256"] == PRODUCER_PINS[name], "control")
            history_pin = stack.enter_context(g["ReadPin"](api, HISTORY_PATH, 1_000_000))
            require(history_pin.record()["sha256"] == HISTORY_SHA, "control")
            live = load_source(HISTORY_PATH, HISTORY_SHA, "reviewed_local_history_worker")
            environment = g["environment_for"]("test")
            result["phase"] = "producer-admission"
            sources = g["source_map"](api, extended, out, environment, opt.source_commit, "before")
            image, record, producer_pins, protected, protected_before, image_pin = admit_image(
                cli, g, stack, api, opt, sources, producer_controls, result)
            history_before = history_source_map(g, api, extended, out, environment, "before")
            write_json(out / "producer-sources-before.json", sources)
            write_json(out / "history-sources-before.json", history_before)
            write_json(out / "consumer-controls-before.json", controls)
            write_json(out / "producer-controls-before.json", producer_controls)
            job_name = "Local\\YokeHistoryCI-" + os.urandom(32).hex()
            spec = {"native": str(image), "nativeSha256": record["sha256"], "fixture": str(fixture),
                    "output": str(evidence), "workerJobName": job_name}
            validate_spec(spec, image, record["sha256"], fixture, evidence, job_name)
            spec_path = private / "spec.json"
            spec_data = json.dumps(spec, ensure_ascii=True).encode("utf8") + b"\n"
            require(len(spec_data) <= BUDGETS["specBytes"], "budget")
            with spec_path.open("xb") as stream:
                stream.write(spec_data)
            spec_pin = stack.enter_context(g["ReadPin"](api, spec_path, BUDGETS["specBytes"]))
            require(unique_json(spec_pin.bytes(), BUDGETS["specBytes"]) == spec, "spec")
            fixture_env = fixture_environment(fixture)
            require(not any(name in fixture_env for name in ("GITHUB_ACTIONS", "GITHUB_SHA")), "spec")
            result["phase"] = "owned-history-worker"
            result["nativeExecutionRequested"] = True
            live.bounded_worker(spec_path, fixture, evidence, fixture_env, job_name)
            result["phase"] = "evidence-admission"

            def private_json(relative, maximum=1_000_000):
                require(relative in ("job.json", "live-result.json")
                        or EVIDENCE_PATTERN.fullmatch(relative), "evidence")
                pin = stack.enter_context(g["ReadPin"](api, evidence / relative, maximum))
                return unique_json(pin.bytes(), maximum)
            job, live_result = private_json("job.json"), private_json("live-result.json")
            validate_job(job)
            validate_live(live_result, record["sha256"])
            summaries = validate_archives(live_result, private_json)
            live.output_size(fixture)
            live.output_size(evidence)
            result["phase"] = "final-recheck"
            require(image_pin.recheck() == record and spec_pin.recheck()["sha256"] ==
                    hashlib.sha256(spec_data).hexdigest(), "drift")
            source_after = g["source_map"](api, extended, out, environment, opt.source_commit, "after")
            history_after = history_source_map(g, api, extended, out, environment, "after")
            controls_after, producer_after = control_map(), original_controls(g)
            require(sources == source_after and history_before == history_after
                    and controls == controls_after and producer_controls == producer_after, "drift")
            protected_after = {name: pin.recheck() for name, pin in protected.items()}
            cli.checked_protected(protected_before, protected_after)
            for pin in producer_pins.values():
                pin.recheck()
            require(shutil.disk_usage(ROOT).free >= BUDGETS["reserveBytes"], "disk")
            write_json(out / "producer-sources-after.json", source_after)
            write_json(out / "history-sources-after.json", history_after)
            write_json(out / "consumer-controls-after.json", controls_after)
            write_json(out / "producer-controls-after.json", producer_after)
            result.update(nativeSha256=record["sha256"], variants=summaries,
                          sourceInputsUnchanged=True, producerSourceInputCount=len(sources),
                          historySourceInputCount=len(history_before), consumerControlCount=len(controls),
                          producerControlCount=len(producer_controls), protectedMetadataUnchanged=True,
                          allOriginalRecordsIndependentlyReadBack=True, treeExitedBeforeCleanup=True)
        # Read-pin and mutex exits may still refuse; success is set only afterward.
        require(shutil.disk_usage(ROOT).free >= BUDGETS["reserveBytes"], "disk")
        result.update(completed=True, phase="complete")
    except BaseException as error:
        result.update(completed=False,
                      failureCode=error.code if isinstance(error, Refusal) else "external-failure")
    finally:
        if out is not None:
            try:
                write_json(out / "result.json", result)
            except BaseException:
                result.update(completed=False, failureCode="external-failure", phase="result-publication")
    return result


def main(arguments=None):
    try:
        opt = options(arguments)
        result = execute(opt)
    except BaseException:
        result = {"owner": OWNER, "completed": False, "phase": "arguments", "failureCode": "arguments"}
    # Never print exception messages, worker output or private fixture paths.
    print(json.dumps({"owner": OWNER, "completed": result["completed"], "phase": result["phase"],
                      "failureCode": result["failureCode"]}), flush=True)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    sys.exit(main())
