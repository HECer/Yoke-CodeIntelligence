# Separate purge, migrated-owner retirement and retained-read consumer

Owner `local-cross-maintenance-lld-consumer-v1`, schema 3. Actual native source is
`704b647d625dcc5f359386b20834d329ffb6cdf4`. This new finite consumer preserves the
existing release producer, archive worker and terminal-retirement consumer. It
does not relabel that executable as a current-head build.

Before first selected-image access, the original 27 producer receipts and actual
held `BuildInputsGuard` must match current observations. Before execution, all 22
matching version receipts and exact selected image/artifact must agree. Original
controls, source/protected metadata and all new/frozen helper controls stay held
through final checks and successful context/mutex closure. No failed/default image,
fake CI environment, arbitrary native selector or redirected module global exists.

## Fixed owned-fixture workflow

Native and Serena owning Sessions run separate create-only Unicode/BOM/CRLF
fixtures. Six real HTTP saves establish 42 original journal records. A reviewed
binding migration produces an active generated destination owner; two completed
archive packages preserve 28 and 14 records, each independently read back exactly.

The first purge review becomes stale after an explicit destination save. Its
refusal must leave both frames and durable maintenance roles untouched. A fresh
review tests missing host-write grant, missing separate state-deletion grant and
wrong valid confirmation before actual purge. Required confirmation arguments stay
present in permission tests so a parser error cannot masquerade as permission
refusal. Raw exit 1, empty stdout and the expected private causal errors are
required where established.

The actual purge removes only the first reviewed owned frame. Apply/inspect must
report committed completion, the exact confirmed removed content length, zero
unverified removal, unavailable record evidence, no measured filesystem-space or
secure-erasure claim, and no authored-source/configuration change. The sibling
package remains exact and all its records remain readable.

Only after all intentional saves and first purge is the second package reviewed
for purge and a fresh HTTP write proposal cached. The migrated owner is then
retired through the complete destination selection as the sole `--from-selection`.
Both before/after owner generations retain the migration nonce. The fixed owner
identity, exact configuration and original evidence remain; schema-3 tombstone and
terminal retirement inspection must agree.

Applying the cached second purge plan must refuse. A CLI caches a reviewed plan,
not the library's opaque approval; each apply reconstructs current approval. The
remaining package's records must still read exactly after retirement; the purged
package must remain explicitly unavailable for exact-record reads. Historical
archive/purge inspection must continue using retained evidence without obtaining
fresh deletion authority from a retired owner. The owning dashboard retains exact
reads, explicit incomplete retirement blocking and write/recovery refusal.

Both owning Sessions acknowledge shutdown and actually exit while stdin remains
open. The entire parent-owned Job must be empty before forced cleanup. Private
plans, configuration, protocols, capabilities and native stderr are not public
evidence. Only closed scalar/boolean summaries and bounded causal proofs qualify.

## Original bounds and source-only preparation

Worker lifetime remains 180 seconds, natural drain one second, cleanup ten seconds;
CLI wait 40 seconds, Session request lifetime 30 seconds, RPC ten seconds and HTTP
six seconds remain. Image admission stays 1.2 GB, continuous disk reserve 500 MB,
image ceiling 512 MB, JSON 1 MB and spec 64 KB. Each fixture/evidence tree retains
1,024 entries and 32 MB. Original source observation and output bounds remain.
Force cannot repair incomplete natural termination.

This prepared source and manifest do not claim tests or native execution. Fresh
guard/live receipts and independent reviews are required. Actual interrupted purge
or retirement, cancellation/recovery, unverified unlink attribution, older binaries,
browser/mobile, physical owner unlink/reactivation, all-host release, current
release/VSIX and full-project acceptance remain separate. Retention age and an
external archive-consumer registry are not inferred. All deletion is confined to
explicitly owned temporary fixtures; no real user-data maintenance is authorized.
