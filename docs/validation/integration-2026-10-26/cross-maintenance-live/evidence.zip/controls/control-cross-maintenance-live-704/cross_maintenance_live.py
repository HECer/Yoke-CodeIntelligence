"""Owned CLI/Session cross-maintenance recipe; no image admission or entrypoint.

The parent retains matching source/producer/version/image authority and its named
Job. This module receives the pinned original history harness as inert code,
without modifying its globals or archive exercise. Fixture/protocol bodies stay
private. Only closed boolean/scalar summaries may be published.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

MAX_JSON = 1_000_000
MAX_FRAME = 16_000_000
MAX_TREE = 32_000_000
MAX_ENTRIES = 1024
CLI_SECONDS = 40
HEX = re.compile(r"[0-9a-f]{64}")
RECORD = re.compile(r"yoke-doc-[0-9a-f]{64}-[0-9a-f]{64}\.(?:plan|e[0-9]{4})\.json")
FIXED_CASES = (
    "migration-plan", "migration-apply", "first-archive-plan", "first-archive-apply",
    "second-archive-plan", "second-archive-apply", "first-purge-stale-plan",
    "purge-no-host-grant", "purge-no-deletion-grant", "purge-wrong-confirmation",
    "purge-stale-review", "first-purge-plan", "first-purge-apply", "first-purge-inspect",
    "first-archive-purged-inspect", "purged-read-before-retirement", "second-purge-plan",
    "generated-retirement-plan", "generated-retirement-apply", "generated-retirement-inspect",
    "cached-purge-after-retirement", "first-purge-inspect-after-retirement",
    "first-archive-inspect-after-retirement", "purged-read-after-retirement",
    "second-archive-inspect-after-retirement",
)
READ_CASES = {
    "initial-first-read": ("first", 28),
    "initial-second-read": ("second", 14),
    "sibling-after-purge-read": ("second", 14),
    "sibling-after-retirement-read": ("second", 14),
}
PRIVATE_REFUSAL_CAUSES = {
    "purge-no-host-grant": b"Host history purge requires --allow-host-writes",
    "purge-no-deletion-grant": b"Host history purge requires separate --allow-state-deletion",
    "purge-wrong-confirmation": b"Exact reviewed purge plan confirmation differs",
    "purge-stale-review": b"Source, owner, generation, dependency or retained archive evidence changed since purge review",
    "cached-purge-after-retirement": None,
    "purged-read-before-retirement": b"Exact archived record evidence unavailable after recorded physical purge; retained receipts do not contain record bytes",
    "purged-read-after-retirement": b"Exact archived record evidence unavailable after recorded physical purge; retained receipts do not contain record bytes",
}
TRUE_FIELDS = (
    "complete", "allOriginalRecordsReadBackBeforePurge", "bothFramesOriginallyAdmitted",
    "separatePurgeHostWritePermissionChecked", "separateStateDeletionPermissionChecked",
    "exactPurgePlanConfirmationChecked", "stalePurgeReviewRefused", "freshPurgeReviewApplied",
    "firstFrameActuallyPurged", "purgeInspectionComplete", "purgedReadsExplicitlyUnavailable",
    "confirmedAndUnverifiedRemovalDistinct", "siblingFrameExactAfterPurge",
    "siblingRecordsExactAfterPurge", "generatedOwnerRetirementCommitted",
    "retirementGenerationRetained", "fixedOwnerIdentityPreserved", "terminalRetirementInspected",
    "cachedPurgePlanRefusedAfterRetirement", "siblingFrameExactAfterRetirement",
    "siblingRecordsExactAfterRetirement", "purgeReceiptReadableAfterRetirement",
    "archiveReceiptsReadableAfterRetirement", "independentHttpReadExactAfterRetirement",
    "incompleteRetirementBlocker", "cachedAndNewWritesRefused", "ordinaryRecoveryRefused",
    "configurationPreservedAcrossPurgeAndRetirement", "originalStatePreservedByRefusals",
    "sessionConfigurationsUnchanged", "analyzedSourceUnchanged", "bothSessionsExitedBeforeJobCleanup",
)
FALSE_FIELDS = (
    "actualInterruptedPurgeQualified", "purgeRecoveryQualified", "actualInterruptedRetirementQualified",
    "retirementRecoveryQualified", "olderBinaryQualified", "browserQualified",
    "physicalOwnerDeletionQualified", "allHostsReleased", "secureErasureClaimed", "releaseQualification",
)


def require(value, message):
    if not value:
        raise RuntimeError(message)


def closed(value, names):
    require(type(value) is dict and set(value) == set(names), "Closed cross-maintenance result differs")


def valid_hex(value):
    return type(value) is str and HEX.fullmatch(value) is not None


def expected_cases():
    return set(FIXED_CASES) | {prefix + "-" + str(index)
        for prefix, (_, count) in READ_CASES.items() for index in range(count)}


def validate_summary(value, label=None):
    closed(value, (*TRUE_FIELDS, *FALSE_FIELDS, "variant", "protocol", "originalRecords",
        "purgedRecords", "retainedRecords", "recordReadCases", "cliCases", "confirmedRemovedContentBytes",
        "unverifiedRemovalBytes", "measuredFilesystemSpaceBytes", "oldExit", "currentExit"))
    require(type(value["variant"]) is str and value["variant"] in ("native", "serena")
            and value["protocol"] == value["variant"]
            and (label is None or (type(label) is str and value["variant"] == label)), "Fixed variant differs")
    require(all(value[name] is True for name in TRUE_FIELDS)
            and all(value[name] is False for name in FALSE_FIELDS), "Cross-maintenance claims differ")
    for name, count in (("originalRecords", 42), ("purgedRecords", 28), ("retainedRecords", 14),
                        ("recordReadCases", 70), ("cliCases", 95), ("unverifiedRemovalBytes", 0)):
        require(type(value[name]) is int and value[name] == count, "Exact case/count evidence differs")
    require(type(value["confirmedRemovedContentBytes"]) is int
            and 0 < value["confirmedRemovedContentBytes"] <= MAX_FRAME
            and value["measuredFilesystemSpaceBytes"] is None, "Removal accounting differs")
    for name in ("oldExit", "currentExit"):
        proof = value[name]
        closed(proof, ("nativeExitCode", "stdinWasStillOpen", "beforeJobCleanup"))
        require(type(proof["nativeExitCode"]) is int and proof["nativeExitCode"] == 0
                and proof["stdinWasStillOpen"] is True and proof["beforeJobCleanup"] is True,
                "Natural owning Session exit not proved")
    return value


def file_identity(path):
    info = Path(path).lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1
            and not getattr(info, "st_file_attributes", 0) & 0x400, "Owned single-link regular file required")
    return info.st_dev, info.st_ino


def bounded_bytes(path, maximum):
    path = Path(path)
    identity = file_identity(path)
    before = path.lstat()
    require(before.st_size <= maximum, "Owned fixture file budget exceeded")
    raw = path.read_bytes()
    after = path.lstat()
    require(file_identity(path) == identity and before.st_size == after.st_size == len(raw)
            and before.st_mtime_ns == after.st_mtime_ns, "Owned fixture file changed")
    return raw


def tree_snapshot(*roots):
    result = {}
    for root in roots:
        count = total = 0
        for path in sorted(Path(root).iterdir()):
            count += 1
            require(count <= MAX_ENTRIES, "Owned tree entry budget exceeded")
            raw = bounded_bytes(path, min(MAX_FRAME, MAX_TREE - total))
            total += len(raw)
            require(total <= MAX_TREE, "Owned tree byte budget exceeded")
            result[str(path)] = (file_identity(path), raw)
    return result


def assert_read(actor, document, expected):
    value = actor.document({"kind": "read", "documentId": document})["document"]
    require(value["documentId"] == document and type(value["content"]) is str
            and value["content"].encode("utf-8") == expected
            and type(value["byteLength"]) is int and value["byteLength"] == len(expected)
            and value["sha256"] == hashlib.sha256(expected).hexdigest(), "Independent HTTP bytes differ")
    return value


def closed_journal_event(harness, root, plan):
    require(valid_hex(plan.get("id")) and valid_hex(plan.get("accessBinding")), "Saved journal plan differs")
    stem = "yoke-doc-" + plan["accessBinding"] + "-" + plan["id"]
    records = {p.name: bounded_bytes(p, MAX_JSON) for p in root.iterdir()
               if p.name.startswith(stem + ".")}
    header = harness.decode(records[stem + ".plan.json"])
    require(header["schemaVersion"] == 1 and header["plan"] == plan, "Saved journal header differs")
    event = header["initial"]
    require(type(event["sequence"]) is int and event["sequence"] == 0 and valid_hex(event["id"]),
            "Initial event differs")
    pattern = re.compile(re.escape(stem) + r"\.e([0-9]{4})\.json")
    following = sorted((int(match.group(1)), name) for name in records if (match := pattern.fullmatch(name)))
    require(bool(following), "Saved journal lacks terminal evidence")
    for sequence, name in following:
        next_event = harness.decode(records[name])
        require(type(next_event["sequence"]) is int and next_event["sequence"] == sequence == event["sequence"] + 1
                and next_event["previous"] == event["id"] and valid_hex(next_event["id"])
                and next_event["planId"] == plan["id"]
                and next_event["accessBinding"] == plan["accessBinding"], "Saved event chain differs")
        event = next_event
    require(event["phase"] == "committed", "Ordinary journal is not closed")
    return event["id"]


def _record_case(case, record, plans):
    for prefix, (role, count) in READ_CASES.items():
        if case.startswith(prefix + "-"):
            suffix = case[len(prefix) + 1:]
            require(suffix.isascii() and suffix.isdecimal() and str(int(suffix)) == suffix
                    and 0 <= int(suffix) < count, "Fixed read-case index differs")
            require(type(record) is str and RECORD.fullmatch(record)
                    and plans[role]["records"][int(suffix)]["name"] == record,
                    "Read must select the exact admitted original record")
            return role
    return None


def cli_argv(native, paths, plans, case, record=None):
    require(type(case) is str and case in expected_cases(), "Closed CLI case required")
    native = Path(native)
    require(native.is_absolute() and all(Path(path).is_absolute() for path in paths.values()),
            "Absolute owned host roles required")
    retirement = case.startswith("generated-retirement-")
    command = [str(native), "--timeout", "30000", "--max-bytes", "1000000", "host-documents",
               "--from-selection", str(paths["to"] if retirement else paths["from"])]
    if not retirement:
        command += ["--to-selection", str(paths["to"]), "--history-record-budget", "32"]
    role = _record_case(case, record, plans)
    if role:
        return command + ["history-read", "--plan", str(paths[role]), "--archive-root", str(paths["archive"]),
                          "--record", record]
    require(record is None, "Unexpected record selector")
    if case == "migration-plan":
        arguments = ["binding-plan", "--from-document", "old", "--to-document", "new"]
    elif case == "migration-apply":
        arguments = ["binding-apply", "--plan", str(paths["migration"]), "--allow-host-writes"]
    elif case in ("first-archive-plan", "second-archive-plan"):
        arguments = ["history-plan", "--migration", str(paths["migration"]), "--archive-root", str(paths["archive"])]
    elif case in ("first-archive-apply", "second-archive-apply"):
        role = "first" if case.startswith("first-") else "second"
        arguments = ["history-apply", "--plan", str(paths[role]), "--archive-root", str(paths["archive"]), "--allow-host-writes"]
    elif case in ("first-purge-stale-plan", "first-purge-plan", "second-purge-plan"):
        role = "second" if case == "second-purge-plan" else "first"
        arguments = ["history-purge-plan", "--archive-plan", str(paths[role]), "--archive-root", str(paths["archive"])]
    elif case in ("purge-no-host-grant", "purge-no-deletion-grant", "purge-wrong-confirmation", "purge-stale-review",
                  "first-purge-apply", "cached-purge-after-retirement"):
        role = "first_purge" if case == "first-purge-apply" else ("second_purge" if case == "cached-purge-after-retirement" else "stale_purge")
        identifier = plans[role]["id"]
        require(valid_hex(identifier), "Exact reviewed purge ID required")
        if case == "purge-wrong-confirmation":
            identifier = "0" * 64 if identifier != "0" * 64 else "f" * 64
        arguments = ["history-purge-apply", "--plan", str(paths[role]), "--archive-root", str(paths["archive"]),
                     "--confirmed-plan", identifier]
        if case != "purge-no-host-grant":
            arguments += ["--allow-host-writes"]
        if case != "purge-no-deletion-grant":
            arguments += ["--allow-state-deletion"]
    elif case in ("first-purge-inspect", "first-purge-inspect-after-retirement"):
        arguments = ["history-purge-inspect", "--plan", str(paths["first_purge"]), "--archive-root", str(paths["archive"])]
    elif case in ("first-archive-purged-inspect", "first-archive-inspect-after-retirement", "second-archive-inspect-after-retirement"):
        role = "second" if case.startswith("second-") else "first"
        arguments = ["history-inspect", "--plan", str(paths[role]), "--archive-root", str(paths["archive"])]
    elif case in ("purged-read-before-retirement", "purged-read-after-retirement"):
        record = plans["first"]["records"][0]["name"]
        require(type(record) is str and RECORD.fullmatch(record), "Exact purged original record required")
        arguments = ["history-read", "--plan", str(paths["first"]), "--archive-root", str(paths["archive"]), "--record", record]
    elif case == "generated-retirement-plan":
        arguments = ["owner-retirement-plan", "--document", "new"]
    elif case in ("generated-retirement-apply", "generated-retirement-inspect"):
        operation = "owner-retirement-apply" if case.endswith("apply") else "owner-retirement-inspect"
        arguments = [operation, "--plan", str(paths["retirement"])]
        if case.endswith("apply"):
            arguments += ["--allow-host-writes"]
    else:
        raise RuntimeError("Unimplemented closed CLI case")
    return command + arguments


def run_cli(harness, native, source, output, paths, plans, seen, case, record=None):
    require(case not in seen, "CLI case cannot be duplicated")
    argv = cli_argv(native, paths, plans, case, record)
    success = case not in PRIVATE_REFUSAL_CAUSES
    stdout, stderr = output / (case + ".stdout"), output / (case + ".stderr")
    with stdout.open("xb") as out_file, stderr.open("xb") as err_file:
        result = subprocess.run(argv, cwd=source, stdout=out_file, stderr=err_file,
                                timeout=CLI_SECONDS, creationflags=subprocess.CREATE_NO_WINDOW)
    require(type(result.returncode) is int and result.returncode == (0 if success else 1),
            "Expected exact cross-maintenance CLI exit differs")
    out, error = bounded_bytes(stdout, MAX_JSON), bounded_bytes(stderr, MAX_JSON)
    harness.write_json(output / (case + ".result.json"),
                       {"case": case, "exitCode": result.returncode, "expectedSuccess": success})
    if not success:
        cause = PRIVATE_REFUSAL_CAUSES[case]
        require(out == b"" and bool(error) and (cause is None or cause in error),
                "Expected private cross-maintenance refusal cause differs")
        value = None
    else:
        value = harness.decode(out)
    seen.add(case)
    return value


def require_exact_receipt(value, expected):
    require(type(value) is dict and type(expected) is dict, "Closed retained receipt required")
    try:
        same = json.dumps(value, sort_keys=True, allow_nan=False) == json.dumps(expected, sort_keys=True, allow_nan=False)
    except (TypeError, ValueError):
        raise RuntimeError("Invalid retained receipt JSON") from None
    require(same, "Retained receipt changed or its JSON types differ")
    return value


def check_purge_review(value, plan):
    closed(value, ("planId", "archivePlanId", "eventId", "phase", "framePresent", "frameVerified",
        "evidenceUnavailable", "markerPresent", "complete", "confirmedRemovedContentBytes",
        "unverifiedRemovalBytes", "measuredFilesystemSpaceBytes", "secureErasureClaimed", "fileChanged", "sourceWritten"))
    require(value["planId"] == plan["id"] and value["archivePlanId"] == plan["archive"]["id"]
            and valid_hex(value["eventId"]) and value["phase"] == "committed"
            and value["framePresent"] is False and value["frameVerified"] is False
            and value["evidenceUnavailable"] is True and value["markerPresent"] is False
            and value["complete"] is True and type(value["confirmedRemovedContentBytes"]) is int
            and value["confirmedRemovedContentBytes"] == plan["frame"]["byteLength"]
            and type(value["unverifiedRemovalBytes"]) is int and value["unverifiedRemovalBytes"] == 0
            and value["measuredFilesystemSpaceBytes"] is None and value["secureErasureClaimed"] is False
            and value["fileChanged"] is False and value["sourceWritten"] is False,
            "Confirmed purge inspection differs")


def check_purged_archive(value, archive, purge):
    closed(value, ("planId", "eventId", "phase", "originalRecords", "presentOriginalRecords", "absentOriginalRecords",
        "immutableArchiveVerified", "archivedRecordEvidenceAvailable", "purge", "markerPresent", "complete",
        "unselectedClosedJournalsAtReview", "allClosedJournalsSelectedAtReview",
        "originalAbsenceProvesThisProcessDeletedIt", "fileChanged", "sourceWritten"))
    require(value["planId"] == archive["id"] and value["phase"] == "committed"
            and valid_hex(value["eventId"])
            and value["complete"] is True and value["markerPresent"] is False
            and value["immutableArchiveVerified"] is False and value["archivedRecordEvidenceAvailable"] is False
            and type(value["originalRecords"]) is int and value["originalRecords"] == len(archive["records"])
            and type(value["presentOriginalRecords"]) is int and value["presentOriginalRecords"] == 0
            and type(value["absentOriginalRecords"]) is int and value["absentOriginalRecords"] == len(archive["records"])
            and type(value["unselectedClosedJournalsAtReview"]) is int
            and value["unselectedClosedJournalsAtReview"] == archive["unselectedClosedJournalsAtReview"]
            and value["allClosedJournalsSelectedAtReview"] is (archive["unselectedClosedJournalsAtReview"] == 0)
            and value["originalAbsenceProvesThisProcessDeletedIt"] is False
            and value["fileChanged"] is False and value["sourceWritten"] is False
            and json.dumps(value["purge"], sort_keys=True, allow_nan=False) == json.dumps(purge, sort_keys=True, allow_nan=False),
            "Purged archive receipt differs")


def exercise(harness, native, fixture, output, label, protocol):
    """Source-adapted original archive recipe plus separately reviewed purge/retirement."""
    require(type(label) is str and label in ("native", "serena") and protocol == label,
            "Closed cross-maintenance variant required")
    native, fixture, output = Path(native), Path(fixture), Path(output)
    require(all(path.is_absolute() for path in (native, fixture, output))
            and not fixture.exists() and not output.exists(), "Fresh absolute fixture/output required")
    fixture.mkdir()
    output.mkdir()
    source, old, new, archive, host = [fixture / name for name in ("source-İ", "old", "new", "archive-π", "host-🦀")]
    for path in (source, old, new, archive, host):
        path.mkdir()
    source_file = source / "main.rs"
    source_bytes = "// owned inert e\u0301 🦀\r\nfn untouched() {}\r\n".encode("utf-8")
    source_file.write_bytes(source_bytes)
    source_identity = file_identity(source_file)
    target = host / "settings-π.yaml"
    original = "\ufeff# owned configuration π e\u0301 🦀\r\nvalue: preserved\r\n".encode("utf-8")
    target.write_bytes(original)
    config = {"documents": [{"id": "old", "label": "Owned old settings", "path": str(target),
                             "scope": {"kind": "global"}, "writable": True}],
              "journalRoot": str(old), "maxDocumentBytes": 64000}
    destination = harness.decode(json.dumps(config).encode("utf-8"))
    destination["documents"][0].update(id="new", label="Owned destination settings")
    destination["journalRoot"] = str(new)
    roots = [{"name": "default", "root": str(source)}]
    paths = {"from": fixture / "from.json", "to": fixture / "to.json", "archive": archive,
             "migration": output / "migration-plan.stdout", "first": output / "first-archive-plan.stdout",
             "second": output / "second-archive-plan.stdout", "stale_purge": output / "first-purge-stale-plan.stdout",
             "first_purge": output / "first-purge-plan.stdout", "second_purge": output / "second-purge-plan.stdout",
             "retirement": output / "generated-retirement-plan.stdout"}
    harness.write_json(paths["from"], {"documents": config, "projects": roots})
    harness.write_json(paths["to"], {"documents": destination, "projects": roots})
    profiles = []
    for name, documents in (("old", config), ("new", destination)):
        path = fixture / (name + "-host.json")
        harness.write_json(path, {"context": "desktop-app", "modes": ["editing"], "steering": {},
            "dashboard": {"management": {"sessionControls": False, "memories": False,
                "documents": documents, "shutdown": True, "operationTimeoutMs": 3000}, "lifetimeMs": 600000}})
        profiles.append(path)
    plans, seen, actors = {}, set(), []
    def cli(case, record=None):
        return run_cli(harness, native, source, output, paths, plans, seen, case, record)
    def unchanged(snapshot):
        require(tree_snapshot(old, new, archive, host) == snapshot
                and bounded_bytes(source_file, MAX_JSON) == source_bytes
                and file_identity(source_file) == source_identity, "Refusal changed original owned evidence")
    try:
        previous = harness.Actor(native, source, profiles[0], output, label + "-old", protocol)
        actors.append(previous)
        for saved in range(6):
            content = original.decode("utf-8") + "# explicit saved history " + str(saved) + " 🦀\r\n"
            p = previous.plan("old", content)
            previous.apply("old", p)
            require(bounded_bytes(target, 64000) == content.encode("utf-8"), "Original save bytes differ")
        pre_migration = bounded_bytes(target, 64000)
        plans["migration"] = cli("migration-plan")
        migration = plans["migration"]
        require(valid_hex(migration["nonce"]) and valid_hex(migration["target"]), "Migration plan differs")
        receipt = cli("migration-apply")
        require(receipt["outcome"] == "committed" and receipt["fileChanged"] is False
                and bounded_bytes(target, 64000) == pre_migration, "Migration changed configuration")
        owner = host / (".yoke-doc-owner-" + migration["target"] + ".json")
        owner_before = bounded_bytes(owner, 2048)
        owner_identity = file_identity(owner)
        require(harness.decode(owner_before)["generation"] == migration["nonce"], "Migrated owner generation differs")
        current = harness.Actor(native, source, profiles[1], output, label + "-current", protocol)
        actors.append(current)
        originals = {p.name: bounded_bytes(p, MAX_JSON) for p in old.iterdir()
                     if p.name.startswith("yoke-doc-" + migration["fromAccess"] + "-")}
        require(len(originals) == 42, "Original six-save journal count differs")
        plans["first"] = cli("first-archive-plan")
        first = plans["first"]
        require(first["recordBudget"] == 32 and len(first["records"]) == 28
                and first["unselectedClosedJournalsAtReview"] == 2, "First whole-journal package differs")
        first_done = cli("first-archive-apply")
        require(first_done["complete"] is True and first_done["markerPresent"] is False,
                "First archive did not complete")
        plans["second"] = cli("second-archive-plan")
        second = plans["second"]
        require(second["id"] != first["id"] and len(second["records"]) == 14
                and second["unselectedClosedJournalsAtReview"] == 0, "Separate remainder review differs")
        require(cli("second-archive-apply")["complete"] is True, "Second archive did not complete")
        require({r["name"] for plan in (first, second) for r in plan["records"]} == set(originals),
                "Original package membership differs")
        frames = {}
        for role, plan in (("first", first), ("second", second)):
            frame = archive / ("yoke-doc-history-" + plan["id"] + ".bin")
            data = bounded_bytes(frame, MAX_FRAME)
            rows = harness.admitted_frame(data, plan, originals)
            frames[role] = (frame, data, file_identity(frame))
            harness.write_json(output / (role + "-frame-proof.json"),
                               {"sha256": hashlib.sha256(data).hexdigest(), "records": rows})
            for index, record in enumerate(plan["records"]):
                value = cli("initial-" + role + "-read-" + str(index), record["name"])
                _check_record_bytes(value, record, originals, plan["id"])
        require(not any((old / name).exists() for name in originals)
                and bounded_bytes(target, 64000) == pre_migration
                and bounded_bytes(owner, 2048) == owner_before, "Archival changed unrelated evidence")
        first_text = original + "# first fresh destination save π\r\n".encode("utf-8")
        current.apply("new", current.plan("new", first_text.decode("utf-8")))
        require(bounded_bytes(target, 64000) == first_text, "First destination save differs")
        plans["stale_purge"] = cli("first-purge-stale-plan")
        _check_purge_plan(plans["stale_purge"], first, frames["first"])
        baseline = tree_snapshot(old, new, archive, host)
        for case in ("purge-no-host-grant", "purge-no-deletion-grant", "purge-wrong-confirmation"):
            cli(case)
            unchanged(baseline)
        final_text = original + "# final fresh destination save e\u0301 🦀\r\n".encode("utf-8")
        final_save = current.plan("new", final_text.decode("utf-8"))
        current.apply("new", final_save)
        require(bounded_bytes(target, 64000) == final_text, "Final destination save differs")
        configuration_identity = file_identity(target)
        stale_baseline = tree_snapshot(old, new, archive, host)
        cli("purge-stale-review")
        unchanged(stale_baseline)
        plans["first_purge"] = cli("first-purge-plan")
        purge = plans["first_purge"]
        _check_purge_plan(purge, first, frames["first"])
        require(purge["id"] != plans["stale_purge"]["id"], "Stale purge review was reused")
        committed = cli("first-purge-apply")
        check_purge_review(committed, purge)
        inspected = cli("first-purge-inspect")
        check_purge_review(inspected, purge)
        require(committed == inspected and not frames["first"][0].exists(), "Purge completion/frame absence differs")
        purged_archive = cli("first-archive-purged-inspect")
        check_purged_archive(purged_archive, first, inspected)
        cli("purged-read-before-retirement")
        _same_frame(frames["second"])
        for index, record in enumerate(second["records"]):
            _check_record_bytes(cli("sibling-after-purge-read-" + str(index), record["name"]), record, originals, second["id"])
        require(bounded_bytes(target, 64000) == final_text and file_identity(target) == configuration_identity
                and bounded_bytes(owner, 2048) == owner_before and file_identity(owner) == owner_identity,
                "Purge changed configuration or owner")
        # This fresh proposal has the final source revision; it is not the old
        # archive setup proposal that the intentional saves already invalidated.
        cached = current.plan("new", "# cached only before retirement π\r\n")
        require(cached["beforeHash"] == hashlib.sha256(final_text).hexdigest()
                and cached["ownerGeneration"] == migration["nonce"], "Cached proposal is not current before retirement")
        ordinary_event = closed_journal_event(harness, new, final_save)
        plans["second_purge"] = cli("second-purge-plan")
        _check_purge_plan(plans["second_purge"], second, frames["second"])
        require(plans["second_purge"]["source"]["sha256"] == hashlib.sha256(final_text).hexdigest(),
                "Second purge review does not bind the final source")
        plans["retirement"] = cli("generated-retirement-plan")
        retirement = plans["retirement"]
        require(retirement["documentId"] == "new" and retirement["sourceHash"] == hashlib.sha256(final_text).hexdigest()
                and retirement["beforeOwner"] == harness.decode(owner_before)
                and retirement["beforeOwner"]["generation"] == migration["nonce"]
                and retirement["afterOwner"]["generation"] == migration["nonce"], "Generated retirement review differs")
        retired = cli("generated-retirement-apply")
        require(retired["planId"] == retirement["id"] and valid_hex(retired["eventId"])
                and retired["outcome"] == "committed" and retired["metadataChanged"] is True
                and retired["fileChanged"] is False and retired["sourceWritten"] is False,
                "Generated retirement receipt differs")
        review = cli("generated-retirement-inspect")
        require(review["planId"] == retirement["id"] and review["eventId"] == retired["eventId"]
                and review["phase"] == "committed" and review["ownerState"] == "retired"
                and review["markerPresent"] is False and review["terminalEvidencePresent"] is True
                and review["complete"] is True and review["fileChanged"] is False and review["sourceWritten"] is False,
                "Generated retirement inspection differs")
        retired_bytes = bounded_bytes(owner, 2048)
        after_owner = harness.decode(retired_bytes)
        require(after_owner == retirement["afterOwner"] and after_owner["schemaVersion"] == 3
                and after_owner["generation"] == migration["nonce"]
                and after_owner["originalOwnerId"] == retirement["beforeOwner"]["id"]
                and file_identity(owner) == owner_identity, "Generated owner tombstone differs")
        terminal = tree_snapshot(old, new, archive, host)
        cli("cached-purge-after-retirement")
        unchanged(terminal)
        late_purge = cli("first-purge-inspect-after-retirement")
        check_purge_review(late_purge, purge)
        require_exact_receipt(late_purge, inspected)
        late_archive = cli("first-archive-inspect-after-retirement")
        check_purged_archive(late_archive, first, late_purge)
        require_exact_receipt(late_archive, purged_archive)
        cli("purged-read-after-retirement")
        sibling_review = cli("second-archive-inspect-after-retirement")
        require(sibling_review["planId"] == second["id"] and sibling_review["phase"] == "committed"
                and sibling_review["complete"] is True and sibling_review["immutableArchiveVerified"] is True
                and sibling_review["archivedRecordEvidenceAvailable"] is True,
                "Retained sibling archive is not independently readable")
        _same_frame(frames["second"])
        for index, record in enumerate(second["records"]):
            _check_record_bytes(cli("sibling-after-retirement-read-" + str(index), record["name"]), record, originals, second["id"])
        assert_read(current, "new", final_text)
        blocked = current.document({"kind": "pending", "documentId": "new"})
        require(blocked.get("blockedByOwnerRetirement") is True and blocked.get("complete") is False
                and blocked.get("journals") == [] and blocked.get("fileChanged") is False
                and blocked.get("metadataChanged") is False and blocked.get("sourceWritten") is False,
                "Generated retirement HTTP blocker differs")
        current.apply("new", cached, 422)
        snapshot = assert_read(current, "new", final_text)
        current.document({"kind": "plan", "documentId": "new", "expectedRevision": snapshot["revision"],
                          "content": "# refused post-retirement write\r\n"}, 422)
        current.document({"kind": "recover", "documentId": "new", "journalId": final_save["id"],
                          "expectedEvent": ordinary_event, "direction": "resume"}, 422)
        unchanged(terminal)
        require(bounded_bytes(target, 64000) == final_text and file_identity(target) == configuration_identity
                and bounded_bytes(owner, 2048) == retired_bytes, "Retired configuration/owner changed")
        for actor in actors:
            require(actor.state()["view"]["management"]["sessionStateSha256"] == actor.fingerprint,
                    "Owning Session configuration changed")
        require(seen == expected_cases(), "Incomplete or unexpected actual CLI case coverage")
        current_exit = current.shutdown()
        require(previous.state()["view"]["management"]["sessionStateSha256"] == previous.fingerprint,
                "Ending destination ended the original Session")
        old_exit = previous.shutdown()
        require(bounded_bytes(source_file, MAX_JSON) == source_bytes and file_identity(source_file) == source_identity,
                "Analyzed source changed")
        summary = {name: True for name in TRUE_FIELDS}
        summary.update({name: False for name in FALSE_FIELDS})
        summary.update(variant=label, protocol=protocol, originalRecords=42, purgedRecords=28, retainedRecords=14,
            recordReadCases=70, cliCases=len(seen), confirmedRemovedContentBytes=purge["frame"]["byteLength"],
            unverifiedRemovalBytes=0, measuredFilesystemSpaceBytes=None, oldExit=old_exit, currentExit=current_exit)
        validate_summary(summary, label)
        harness.write_json(output / "variant-result.json", summary)
        return summary
    finally:
        for actor in reversed(actors):
            actor.close()


def _check_purge_plan(plan, archive, frame):
    require(plan["schemaVersion"] == 1 and valid_hex(plan["id"])
            and json.dumps(plan["archive"], sort_keys=True, allow_nan=False) == json.dumps(archive, sort_keys=True, allow_nan=False)
            and valid_hex(plan["archiveEventId"]) and type(plan["frame"]["byteLength"]) is int
            and plan["frame"]["byteLength"] == len(frame[1]) > 0
            and plan["frame"]["sha256"] == hashlib.sha256(frame[1]).hexdigest(), "Purge frame review differs")


def _same_frame(frame):
    require(file_identity(frame[0]) == frame[2] and bounded_bytes(frame[0], MAX_FRAME) == frame[1],
            "Retained sibling frame changed")


def _check_record_bytes(value, record, originals, archive_id):
    closed(value, ("planId", "recordName", "originalIdentity", "originalSecuritySha256", "sha256", "byteLength",
                   "bytesBase64", "immutableRecordEvidenceOnly", "fileChanged", "sourceWritten"))
    require(value["planId"] == archive_id and value["recordName"] == record["name"]
            and value["originalIdentity"] == record["identity"]
            and value["originalSecuritySha256"] == record["securityHash"]
            and base64.b64decode(value["bytesBase64"], validate=True) == originals[record["name"]]
            and type(value["byteLength"]) is int and value["byteLength"] == len(originals[record["name"]])
            and value["sha256"] == record["hash"] and value["immutableRecordEvidenceOnly"] is True
            and value["fileChanged"] is False and value["sourceWritten"] is False,
            "Exact immutable original record read differs")
