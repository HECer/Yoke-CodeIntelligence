"""Owned inert fixtures and mocks only; importing defines no native execution."""
import base64
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock

SPEC = importlib.util.spec_from_file_location("owned_cross_maintenance_recipe", Path(__file__).with_name("cross_maintenance_live.py"))
W = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(W)

EXPECTED_TRUE = (
    "complete", "allOriginalRecordsReadBackBeforePurge", "bothFramesOriginallyAdmitted",
    "separatePurgeHostWritePermissionChecked", "separateStateDeletionPermissionChecked",
    "exactPurgePlanConfirmationChecked", "stalePurgeReviewRefused", "freshPurgeReviewApplied",
    "firstFrameActuallyPurged", "purgeInspectionComplete", "purgedReadsExplicitlyUnavailable",
    "confirmedAndUnverifiedRemovalDistinct", "siblingFrameExactAfterPurge", "siblingRecordsExactAfterPurge",
    "generatedOwnerRetirementCommitted", "retirementGenerationRetained", "fixedOwnerIdentityPreserved",
    "terminalRetirementInspected", "cachedPurgePlanRefusedAfterRetirement", "siblingFrameExactAfterRetirement",
    "siblingRecordsExactAfterRetirement", "purgeReceiptReadableAfterRetirement",
    "archiveReceiptsReadableAfterRetirement", "independentHttpReadExactAfterRetirement",
    "incompleteRetirementBlocker", "cachedAndNewWritesRefused", "ordinaryRecoveryRefused",
    "configurationPreservedAcrossPurgeAndRetirement", "originalStatePreservedByRefusals",
    "sessionConfigurationsUnchanged", "analyzedSourceUnchanged", "bothSessionsExitedBeforeJobCleanup",
)
EXPECTED_FALSE = (
    "actualInterruptedPurgeQualified", "purgeRecoveryQualified", "actualInterruptedRetirementQualified",
    "retirementRecoveryQualified", "olderBinaryQualified", "browserQualified", "physicalOwnerDeletionQualified",
    "allHostsReleased", "secureErasureClaimed", "releaseQualification",
)


def encode(value):
    return json.dumps(value, ensure_ascii=False).encode("utf-8")


def golden_summary(label):
    return {**{name: True for name in EXPECTED_TRUE}, **{name: False for name in EXPECTED_FALSE},
        "variant": label, "protocol": label, "originalRecords": 42, "purgedRecords": 28, "retainedRecords": 14,
        "recordReadCases": 70, "cliCases": 95, "confirmedRemovedContentBytes": 4096,
        "unverifiedRemovalBytes": 0, "measuredFilesystemSpaceBytes": None,
        "oldExit": {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True},
        "currentExit": {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True}}


def context(root):
    paths = {name: root / (name + ".json") for name in ("from", "to", "migration", "first", "second",
                                                       "stale_purge", "first_purge", "second_purge", "retirement")}
    paths["archive"] = root / "archive"
    plans = {"stale_purge": {"id": "c" * 64}, "first_purge": {"id": "d" * 64}, "second_purge": {"id": "e" * 64},
        "first": {"id": "a" * 64, "unselectedClosedJournalsAtReview": 2,
                  "records": [{"name": "yoke-doc-" + "a" * 64 + "-" + format(i, "064x") + ".plan.json"} for i in range(28)]},
        "second": {"id": "b" * 64, "unselectedClosedJournalsAtReview": 0,
                   "records": [{"name": "yoke-doc-" + "b" * 64 + "-" + format(i, "064x") + ".plan.json"} for i in range(14)]}}
    return paths, plans


def purge_fixture():
    archive = {"id": "a" * 64, "records": [None] * 28, "unselectedClosedJournalsAtReview": 2}
    plan = {"id": "c" * 64, "archive": archive, "frame": {"byteLength": 4096}}
    review = {"planId": plan["id"], "archivePlanId": archive["id"], "eventId": "d" * 64,
        "phase": "committed", "framePresent": False, "frameVerified": False, "evidenceUnavailable": True,
        "markerPresent": False, "complete": True, "confirmedRemovedContentBytes": 4096,
        "unverifiedRemovalBytes": 0, "measuredFilesystemSpaceBytes": None, "secureErasureClaimed": False,
        "fileChanged": False, "sourceWritten": False}
    archived = {"planId": archive["id"], "eventId": "e" * 64, "phase": "committed", "originalRecords": 28,
        "presentOriginalRecords": 0, "absentOriginalRecords": 28, "immutableArchiveVerified": False,
        "archivedRecordEvidenceAvailable": False, "purge": copy.deepcopy(review), "markerPresent": False,
        "complete": True, "unselectedClosedJournalsAtReview": 2, "allClosedJournalsSelectedAtReview": False,
        "originalAbsenceProvesThisProcessDeletedIt": False, "fileChanged": False, "sourceWritten": False}
    return plan, review, archived


class SummaryAdmission(unittest.TestCase):
    def test_declared_contract_cannot_remove_an_acceptance_or_false_qualification(self):
        self.assertEqual(set(W.TRUE_FIELDS), set(EXPECTED_TRUE))
        self.assertEqual(set(W.FALSE_FIELDS), set(EXPECTED_FALSE))

    def test_both_exact_owning_variants_admit(self):
        for label in ("native", "serena"):
            self.assertEqual(W.validate_summary(golden_summary(label), label), golden_summary(label))

    def test_every_positive_claim_requires_exact_true(self):
        for name in EXPECTED_TRUE:
            for bad in (False, 1, None):
                value = golden_summary("native"); value[name] = bad
                with self.subTest(name=name, bad=bad), self.assertRaises(RuntimeError):
                    W.validate_summary(value)

    def test_unqualified_interruption_recovery_and_other_scopes_cannot_be_promoted(self):
        for name in EXPECTED_FALSE:
            for bad in (True, 0, None):
                value = golden_summary("native"); value[name] = bad
                with self.subTest(name=name, bad=bad), self.assertRaises(RuntimeError):
                    W.validate_summary(value)

    def test_summary_keys_and_variant_order_are_closed(self):
        for mutate in (lambda x: x.update(foreign=True), lambda x: x.pop("oldExit"),
                       lambda x: x.update(protocol="native", variant="serena"),
                       lambda x: x.update(variant="persistent-python", protocol="persistent-python")):
            value = golden_summary("native"); mutate(value)
            with self.assertRaises(RuntimeError): W.validate_summary(value)
        with self.assertRaises(RuntimeError): W.validate_summary(golden_summary("native"), "serena")

    def test_fixed_record_and_cli_counts_refuse_filters_coercions_or_missing_cases(self):
        for name in ("originalRecords", "purgedRecords", "retainedRecords", "recordReadCases", "cliCases", "unverifiedRemovalBytes"):
            for bad in (False, 0.0, -1, 1_000_001):
                value = golden_summary("native"); value[name] = bad
                with self.subTest(name=name, bad=bad), self.assertRaises(RuntimeError): W.validate_summary(value)

    def test_content_removal_never_becomes_space_measurement_or_secure_erasure(self):
        for name, bad in (("confirmedRemovedContentBytes", True), ("confirmedRemovedContentBytes", 0),
                          ("confirmedRemovedContentBytes", W.MAX_FRAME + 1),
                          ("measuredFilesystemSpaceBytes", 4096), ("secureErasureClaimed", True),
                          ("unverifiedRemovalBytes", 4096)):
            value = golden_summary("native"); value[name] = bad
            with self.subTest(name=name, bad=bad), self.assertRaises(RuntimeError): W.validate_summary(value)

    def test_each_owning_session_requires_real_natural_exit_proof(self):
        for name in ("oldExit", "currentExit"):
            for bad in ({"nativeExitCode": False, "stdinWasStillOpen": True, "beforeJobCleanup": True},
                        {"nativeExitCode": 0, "stdinWasStillOpen": False, "beforeJobCleanup": True},
                        {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": False},
                        {"nativeExitCode": 0, "stdinWasStillOpen": True, "beforeJobCleanup": True, "extra": True}):
                value = golden_summary("native"); value[name] = bad
                with self.subTest(name=name, bad=bad), self.assertRaises(RuntimeError): W.validate_summary(value)


class FixedCommands(unittest.TestCase):
    def roles(self):
        root = Path(tempfile.gettempdir()).resolve()
        paths, plans = context(root)
        return root / "inert-never-read.exe", paths, plans

    def test_exact_recipe_has_25_static_and_70_selected_read_cases(self):
        self.assertEqual(len(W.FIXED_CASES), 25)
        self.assertEqual(len(set(W.FIXED_CASES)), 25)
        self.assertEqual(len(W.expected_cases()), 95)
        self.assertIn("cached-purge-after-retirement", W.expected_cases())
        self.assertIn("generated-retirement-inspect", W.expected_cases())
        self.assertIn("sibling-after-retirement-read-13", W.expected_cases())
        self.assertNotIn("sibling-after-retirement-read-14", W.expected_cases())

    def test_generated_retirement_uses_only_original_destination_as_single_selection(self):
        native, paths, plans = self.roles()
        for name in ("generated-retirement-plan", "generated-retirement-apply", "generated-retirement-inspect"):
            argv = W.cli_argv(native, paths, plans, name)
            self.assertEqual(argv[:8], [str(native), "--timeout", "30000", "--max-bytes", "1000000",
                "host-documents", "--from-selection", str(paths["to"])])
            self.assertNotIn("--to-selection", argv)
            self.assertNotIn("--allow-state-deletion", argv)

    def test_purge_permissions_remain_independent_and_confirmation_is_always_syntactically_valid(self):
        native, paths, plans = self.roles()
        for name, host, delete in (("purge-no-host-grant", False, True),
                ("purge-no-deletion-grant", True, False), ("first-purge-apply", True, True)):
            argv = W.cli_argv(native, paths, plans, name)
            self.assertEqual("--allow-host-writes" in argv, host)
            self.assertEqual("--allow-state-deletion" in argv, delete)
            self.assertEqual(argv[argv.index("--history-record-budget") + 1], "32")
            self.assertTrue(W.valid_hex(argv[argv.index("--confirmed-plan") + 1]))

    def test_wrong_confirmation_and_cached_review_cannot_select_another_plan(self):
        native, paths, plans = self.roles()
        wrong = W.cli_argv(native, paths, plans, "purge-wrong-confirmation")
        self.assertNotEqual(wrong[wrong.index("--confirmed-plan") + 1], plans["stale_purge"]["id"])
        cached = W.cli_argv(native, paths, plans, "cached-purge-after-retirement")
        self.assertEqual(cached[cached.index("--plan") + 1], str(paths["second_purge"]))
        self.assertEqual(cached[cached.index("--confirmed-plan") + 1], plans["second_purge"]["id"])

    def test_each_bounded_read_binds_exact_plan_membership(self):
        native, paths, plans = self.roles()
        for prefix, (role, count) in W.READ_CASES.items():
            for index in range(count):
                record = plans[role]["records"][index]["name"]
                argv = W.cli_argv(native, paths, plans, prefix + "-" + str(index), record)
                self.assertEqual(argv[-1], record)
                self.assertEqual(argv[argv.index("--plan") + 1], str(paths[role]))
            with self.assertRaises(RuntimeError): W.cli_argv(native, paths, plans, prefix + "-0", "../foreign")
            with self.assertRaises(RuntimeError): W.cli_argv(native, paths, plans, prefix + "-00", plans[role]["records"][0]["name"])

    def test_unknown_operations_relative_roles_and_unselected_records_refuse(self):
        native, paths, plans = self.roles()
        for name in ("--help", "arbitrary-native", "history-purge-recover", "initial-first-read-28"):
            with self.subTest(name=name), self.assertRaises(RuntimeError): W.cli_argv(native, paths, plans, name)
        with self.assertRaises(RuntimeError): W.cli_argv(Path("foreign.exe"), paths, plans, "migration-plan")
        with self.assertRaises(RuntimeError): W.cli_argv(native, paths, plans, "migration-plan", "foreign")
        plans["second_purge"]["id"] = True
        with self.assertRaises(RuntimeError): W.cli_argv(native, paths, plans, "cached-purge-after-retirement")

    def test_run_cli_retains_exact_plan_stdout_without_reserializing(self):
        native, paths, plans = self.roles()
        raw = b'{ "schemaVersion" : 1 }\r\n'
        harness = types.SimpleNamespace(decode=json.loads, write_json=lambda path, value: path.write_bytes(encode(value)))
        with tempfile.TemporaryDirectory(prefix="owned-cross-cli-") as directory:
            out = Path(directory); seen = set()
            def run(argv, **kwargs):
                self.assertEqual(kwargs["timeout"], 40)
                self.assertEqual(kwargs["creationflags"], 0x08000000)
                kwargs["stdout"].write(raw)
                return types.SimpleNamespace(returncode=0)
            with mock.patch.object(W.subprocess, "run", side_effect=run), \
                 mock.patch.object(W.subprocess, "CREATE_NO_WINDOW", 0x08000000, create=True):
                self.assertEqual(W.run_cli(harness, native, out, out, paths, plans, seen, "migration-plan"), {"schemaVersion": 1})
            self.assertEqual((out / "migration-plan.stdout").read_bytes(), raw)
            self.assertEqual(seen, {"migration-plan"})

    def test_negative_cases_reject_parser_panic_success_or_wrong_cause(self):
        native, paths, plans = self.roles()
        harness = types.SimpleNamespace(write_json=lambda path, value: path.write_bytes(encode(value)))
        cause = b"Host history purge requires --allow-host-writes"
        for code, stdout, stderr, accept in ((2, b"", cause, False), (101, b"", cause, False),
                (0, b"", cause, False), (1, b'{"complete":true}', cause, False),
                (1, b"", b"unrelated error", False), (1, b"", b"", False), (1, b"", b"yoke: " + cause, True)):
            with tempfile.TemporaryDirectory(prefix="owned-cross-refusal-") as directory:
                out = Path(directory); seen = set()
                def run(argv, **kwargs):
                    kwargs["stdout"].write(stdout); kwargs["stderr"].write(stderr)
                    return types.SimpleNamespace(returncode=code)
                with mock.patch.object(W.subprocess, "run", side_effect=run), \
                     mock.patch.object(W.subprocess, "CREATE_NO_WINDOW", 0x08000000, create=True):
                    if accept:
                        self.assertIsNone(W.run_cli(harness, native, out, out, paths, plans, seen, "purge-no-host-grant"))
                    else:
                        with self.assertRaises(RuntimeError): W.run_cli(harness, native, out, out, paths, plans, seen, "purge-no-host-grant")
                        self.assertEqual(seen, set())

    def test_duplicate_case_or_oversized_capture_never_counts_as_acceptance(self):
        native, paths, plans = self.roles()
        harness = types.SimpleNamespace(decode=mock.Mock(side_effect=AssertionError("Must not parse")))
        with mock.patch.object(W.subprocess, "run") as run:
            with self.assertRaises(RuntimeError): W.run_cli(harness, native, paths["from"], paths["from"], paths, plans, {"migration-plan"}, "migration-plan")
            run.assert_not_called()
        with tempfile.TemporaryDirectory(prefix="owned-cross-size-") as directory:
            out = Path(directory)
            def run(argv, **kwargs):
                kwargs["stdout"].write(b"x" * 33)
                return types.SimpleNamespace(returncode=0)
            with mock.patch.object(W, "MAX_JSON", 32), mock.patch.object(W.subprocess, "run", side_effect=run), \
                 mock.patch.object(W.subprocess, "CREATE_NO_WINDOW", 0x08000000, create=True):
                with self.assertRaises(RuntimeError): W.run_cli(harness, native, out, out, paths, plans, set(), "migration-plan")
            harness.decode.assert_not_called()


class IndependentEvidence(unittest.TestCase):
    def test_late_retained_receipts_reject_numeric_boolean_aliases_and_invalid_json(self):
        expected = {"complete": True, "removed": 4096, "nested": {"unverified": 0, "written": False}}
        reordered = {"nested": {"written": False, "unverified": 0}, "removed": 4096, "complete": True}
        self.assertEqual(W.require_exact_receipt(reordered, expected), reordered)
        for mutate in (lambda x: x.update(complete=1), lambda x: x.update(removed=4096.0),
                       lambda x: x["nested"].update(unverified=False),
                       lambda x: x["nested"].update(written=0), lambda x: x.update(extra=None),
                       lambda x: x.update(removed=float("nan"))):
            value = copy.deepcopy(expected)
            mutate(value)
            with self.subTest(mutate=mutate), self.assertRaises(RuntimeError):
                W.require_exact_receipt(value, expected)
        with self.assertRaises(RuntimeError):
            W.require_exact_receipt([], expected)

    def test_committed_purge_has_exact_content_accounting_without_space_or_erasure_claim(self):
        plan, review, _ = purge_fixture()
        W.check_purge_review(review, plan)
        for name, bad in (("phase", "removed"), ("framePresent", True), ("complete", 1),
                ("confirmedRemovedContentBytes", 4095), ("unverifiedRemovalBytes", False),
                ("unverifiedRemovalBytes", 4096), ("measuredFilesystemSpaceBytes", 4096), ("secureErasureClaimed", True)):
            value = copy.deepcopy(review); value[name] = bad
            with self.subTest(name=name, bad=bad), self.assertRaises(RuntimeError): W.check_purge_review(value, plan)

    def test_purge_review_refuses_unrelated_ids_and_extra_protocol_fields(self):
        plan, review, _ = purge_fixture()
        for mutate in (lambda x: x.update(planId="e" * 64), lambda x: x.update(archivePlanId="f" * 64),
                       lambda x: x.update(eventId=False), lambda x: x.update(unknown=True)):
            value = copy.deepcopy(review); mutate(value)
            with self.assertRaises(RuntimeError): W.check_purge_review(value, plan)

    def test_purged_archive_cannot_disguise_missing_evidence_as_empty_complete_source(self):
        plan, review, archived = purge_fixture()
        W.check_purged_archive(archived, plan["archive"], review)
        for name, bad in (("archivedRecordEvidenceAvailable", True), ("immutableArchiveVerified", True),
                          ("presentOriginalRecords", False), ("absentOriginalRecords", 27),
                          ("originalAbsenceProvesThisProcessDeletedIt", True), ("allClosedJournalsSelectedAtReview", True)):
            value = copy.deepcopy(archived); value[name] = bad
            with self.subTest(name=name, bad=bad), self.assertRaises(RuntimeError): W.check_purged_archive(value, plan["archive"], review)
        value = copy.deepcopy(archived); value["purge"]["unverifiedRemovalBytes"] = False
        with self.assertRaises(RuntimeError): W.check_purged_archive(value, plan["archive"], review)

    def test_original_record_read_preserves_unicode_bom_crlf_bytes_and_historical_identity(self):
        body = "\ufeffπ e\u0301 🦀\r\n".encode("utf-8")
        record = {"name": "owned.plan.json", "identity": "owned-history-identity", "securityHash": "b" * 64,
                  "hash": hashlib.sha256(body).hexdigest()}
        value = {"planId": "a" * 64, "recordName": record["name"], "originalIdentity": record["identity"],
                 "originalSecuritySha256": record["securityHash"], "sha256": record["hash"], "byteLength": len(body),
                 "bytesBase64": base64.b64encode(body).decode(), "immutableRecordEvidenceOnly": True,
                 "fileChanged": False, "sourceWritten": False}
        W._check_record_bytes(value, record, {record["name"]: body}, "a" * 64)
        for name, bad in (("planId", "f" * 64), ("originalIdentity", "live-substitute"), ("recordName", "foreign"),
                          ("byteLength", False), ("bytesBase64", base64.b64encode(body.replace(b"\r\n", b"\n")).decode()),
                          ("sourceWritten", True), ("immutableRecordEvidenceOnly", 1)):
            changed = copy.deepcopy(value); changed[name] = bad
            with self.subTest(name=name), self.assertRaises(RuntimeError):
                W._check_record_bytes(changed, record, {record["name"]: body}, "a" * 64)

    def test_independent_http_read_needs_exact_selected_bytes_hash_and_length(self):
        raw = "\ufeffπ\r\n".encode()
        value = {"documentId": "new", "content": raw.decode(), "byteLength": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        actor = types.SimpleNamespace(document=lambda request: {"document": value})
        W.assert_read(actor, "new", raw)
        for name, bad in (("documentId", "old"), ("content", raw.decode().replace("\r\n", "\n")),
                          ("byteLength", False), ("sha256", "0" * 64)):
            original = value[name]; value[name] = bad
            with self.assertRaises(RuntimeError): W.assert_read(actor, "new", raw)
            value[name] = original

    def test_owned_frame_identity_and_bytes_both_survive_readback(self):
        with tempfile.TemporaryDirectory(prefix="owned-cross-frame-") as directory:
            path = Path(directory) / "frame.bin"; path.write_bytes(b"owned inert archive")
            frame = (path, path.read_bytes(), W.file_identity(path))
            W._same_frame(frame)
            path.write_bytes(b"foreign changed archive")
            with self.assertRaises(RuntimeError): W._same_frame(frame)

    def test_owned_tree_enforces_entry_and_byte_caps_before_unbounded_read(self):
        with tempfile.TemporaryDirectory(prefix="owned-cross-tree-") as directory:
            root = Path(directory); (root / "one.json").write_bytes(b"owned")
            baseline = W.tree_snapshot(root)
            self.assertEqual(len(baseline), 1)
            with mock.patch.object(W, "MAX_ENTRIES", 0), self.assertRaises(RuntimeError): W.tree_snapshot(root)
            with mock.patch.object(W, "MAX_TREE", 4), self.assertRaises(RuntimeError): W.tree_snapshot(root)
            with self.assertRaises(RuntimeError): W.bounded_bytes(root / "one.json", 4)


class WholeRecipeOwnership(unittest.TestCase):
    def test_invalid_variant_or_occupied_fixture_refuses_before_actor_creation(self):
        actor = mock.Mock(side_effect=AssertionError("Must not start a native process"))
        harness = types.SimpleNamespace(Actor=actor)
        with tempfile.TemporaryDirectory(prefix="owned-cross-selector-") as directory:
            root = Path(directory)
            with self.assertRaises(RuntimeError): W.exercise(harness, root / "never.exe", root / "fresh", root / "out", "foreign", "foreign")
            with self.assertRaises(RuntimeError): W.exercise(harness, root / "never.exe", root, root / "out", "native", "native")
        actor.assert_not_called()

    def test_actor_is_closed_when_first_poststartup_native_save_assertion_fails(self):
        closed = []
        actor = types.SimpleNamespace(plan=lambda *args: {"id": "a" * 64}, apply=lambda *args: None,
                                      close=lambda: closed.append(True))
        harness = types.SimpleNamespace(Actor=lambda *args: actor, decode=json.loads,
            write_json=lambda path, value: path.write_bytes(encode(value)))
        with tempfile.TemporaryDirectory(prefix="owned-cross-close-") as directory:
            root = Path(directory)
            with self.assertRaises(RuntimeError):
                W.exercise(harness, root / "never-read.exe", root / "fixture", root / "output", "native", "native")
        self.assertEqual(closed, [True])


if __name__ == "__main__":
    unittest.main()
