"""Pinned compiler-transaction build and version receipts precede local archive acceptance."""
import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import types


ROOT = Path(os.path.abspath(Path(__file__).parents[4]))
BASE = ROOT / "validation/integration-20261025/platform-repairs"
CONTROL = BASE / "control-history-lld-704"
LEGACY = BASE / "control-history"
TRANSACTION = BASE / "control-compiler-lld"
ORIGINAL = BASE / "control-cli"
RUNS = BASE / "runs-history-lld-704"
PRIVATE = BASE / "private-history-lld-704"
OWNER = "local-original-archive-history-lld-consumer-v1"
SOURCE_COMMIT = "704b647d625dcc5f359386b20834d329ffb6cdf4"
TRANSACTION_OWNER = "integration-20261026-compiler-lld-v1"
CONTROL_NAMES = ("history_transaction_controller.py", "test_history_transaction_controller.py",
                 "README.md", "review-manifest.json", ".gitattributes")
LEGACY_PINS = {
    "local_history_controller.py": "8d37fd4ca9c4f9d7b3320da6d628ff1b5537d880b4090289347d9df7f205d142",
    "test_local_history_controller.py": "7ec89b7aa5e810d44d466c7150d1b0f7615defa78cc310617d8b4d5a239427f7",
    "README.md": "628651bd06b1a37a90b03af8d85926991d0bc7f3029e9559a60c92db1c08bf5f",
    "review-manifest.json": "84e19772b5c90d6313cfb4902bc7d671f82eaa753d6279b8b9f787f422c055c9",
    ".gitattributes": "a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9",
}
TRANSACTION_PINS = {
    "compiler_transaction_controller.py": "d6ab4fe93432a74a769e9abcdddcef40e87ef274e98fea498a219d95c2c9f29d",
    "compiler_transaction_worker.py": "cf24492dafb4c30ce057a0885c5021339fc76fa3dba1e1efdddaf111fa1285fb",
    "transaction_protocol.py": "eda51ab9efef48ae9675bef75ecd57ad4b3bea3319f132f6614c2e813de0b45a",
    "transaction_runtime.py": "1608c69131ab3374812496ee9ff855e2c906ac172d31f9899331aa33f2e98de8",
    "private_windows_api.py": "d9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500",
    "test_compiler_transaction.py": "da422d730d3db84b4967fe422d8b8106ed5bb2faac05fa95b012ec5c5ee4bed9",
    "review-manifest.json": "141943606a7c38d4b33f2291b211eabee008d3469da8c45b12bfc4f3b6edaea9",
    "README.md": "a09c68653255a64ad2f0cca79ecb8a3ba8690416cdbf11cb4ed35c497aaa7ba0",
    ".gitattributes": "a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9",
    "runtime-fork.patch": "93bb522cb253643e9ac69e05efd26e9964d6d7cc05dc6ce31699d141f9314ad6",
    "v2-fork.patch": "006f58884051c894305b88ab3b3b46796b8eb0a6c3111df816bf6ac4765bdee5"
}
ORIGINAL_PINS = {
    "cli_controller.py": "d6e306cabbeffaf47b51904758dd0d7c0c4c0ed4dd65f077f1ef07a01ec47582",
    "base_controller.py": "a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7",
    "private_windows_api.py": "d9ff76538ec359bb6095898b83c21390aec57c2252073190eeb6e317d9091500",
    "test_metadata_pin.py": "6f555a7b29a85f17c404cba57474c682ae84adf28915ac8b1f10db73b9041aca",
    "README.md": "1bbe94b3ac00dff9d1116ab8ccc8aadce545b14dd536888644d1cb92eac3cea6",
    "review-manifest.json": "8dd48b1595220464fc638d458a6f8dd7b19f55454c35c0bda7eb7cea255b94f8",
    ".gitattributes": "a79691a93b46e49ce460c26ef22afcc03d6eca1e63bf2edbc20e96159510f6c9",
}
HARNESS_PINS = {
    "scripts/host_history_live.py": "3a3f5de28756ddcc383c3c92821f15fd5db24a72c324ef6a20d1ed6a24f819b2",
    "scripts/tests/test_host_history_live.py": "f37e7b419be242337d066678c3a8454156f3062bbb7578b33d14d001500b73db",
}
BUDGETS = {
    "imageAdmissionBytes": 1_200_000_000, "reserveBytes": 500_000_000,
    "imageBytes": 512_000_000, "jsonBytes": 1_000_000, "specBytes": 64_000,
    "frameBytes": 16_000_000, "outputBytesPerTree": 32_000_000,
    "entriesPerTree": 1024, "workerSeconds": 180, "workerDrainSeconds": 1,
    "workerCleanupSeconds": 10, "producerCleanupSeconds": 2,
    "cliSeconds": 40, "rpcSeconds": 10, "httpSeconds": 6,
    "historyListingBytes": 1_000_000, "historySourceFiles": 2048,
    "historySourceBytes": 96_000_000, "historySourceFileBytes": 16_000_000,
    "historySourceObservationSeconds": 120,
}
MAX_FIXTURE_UTF16_UNITS = 70
VERSION_FILES = (
    "request.json", "result.json", "outer.job.json", "outer.stdout", "outer.stderr",
    "source-before.json", "source-after.json", "source-final.json",
    "original-control-before.json", "original-control-after.json", "original-control-final.json",
    "transaction-control-before.json", "transaction-control-after.json", "transaction-control-final.json",
    "protected-before.json", "protected-after.json", "protected-final.json",
    "selected-image.json", "selected-image-after.json",
    "build-inputs-before.json", "build-inputs-after.json", "build-inputs-final.json",
)
RUN_PATTERN = re.compile(r"[a-z][a-z0-9-]{0,95}")
HEX_PATTERN = re.compile(r"[0-9a-f]{64}")
CODES = {"arguments", "platform", "disk", "path", "occupied", "source", "manifest",
         "control", "mutex", "producer", "version", "image", "spec", "json", "evidence",
         "job", "variants", "record", "budget", "drift", "external-failure"}


class Refusal(RuntimeError):
    def __init__(self, code):
        self.code = code if code in CODES else "external-failure"
        super().__init__(self.code)


def require(value, code):
    if not value:
        raise Refusal(code)


def closed(value, keys, code):
    require(type(value) is dict and set(value) == set(keys), code)


def integer(value, minimum=0, maximum=(1 << 63) - 1):
    return type(value) is int and minimum <= value <= maximum


def unique_json(data, maximum=1_000_000):
    require(type(data) is bytes and len(data) <= maximum, "json")

    def pairs(items):
        result = {}
        for name, value in items:
            require(name not in result, "json")
            result[name] = value
        return result

    def constant(_):
        raise Refusal("json")
    try:
        return json.loads(data, object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, UnicodeError):
        raise Refusal("json") from None


class Arguments(argparse.ArgumentParser):
    def error(self, message):
        raise Refusal("arguments")


def options(arguments):
    arguments = sys.argv[1:] if arguments is None else list(arguments)
    names = ("--source-commit", "--run-id", "--producer-run-id", "--version-run-id")
    require(len(arguments) == 8 and set(arguments[::2]) == set(names), "arguments")
    parser = Arguments(description=__doc__, add_help=False, allow_abbrev=False)
    for name in names:
        parser.add_argument(name, required=True)
    value = parser.parse_args(arguments)
    ids = (value.run_id, value.producer_run_id, value.version_run_id)
    require(value.source_commit == SOURCE_COMMIT and len(set(ids)) == 3
            and all(RUN_PATTERN.fullmatch(name) for name in ids), "arguments")
    return value


def ordinary(path, directory=False):
    path = Path(path)
    require(path.is_absolute() and os.path.normpath(str(path)) == str(path), "path")
    for parent in reversed(path.parents):
        info = parent.lstat()
        require(stat.S_ISDIR(info.st_mode)
                and not getattr(info, "st_file_attributes", 0) & 0x400, "path")
    info = path.lstat()
    require(not getattr(info, "st_file_attributes", 0) & 0x400
            and (stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)), "path")
    if not directory:
        require(info.st_nlink == 1 and info.st_ino > 0, "path")
    return info


def text_bytes(path, maximum=1_000_000):
    require(path.suffix.lower() not in (".exe", ".pdb", ".dll", ".lib", ".obj", ".o"), "path")
    before = ordinary(path)
    require(before.st_size <= maximum, "budget")
    with path.open("rb") as stream:
        data = stream.read(maximum + 1)
    after = ordinary(path)
    require(len(data) == before.st_size <= maximum
            and (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
                (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), "drift")
    return data


def source_map(folder, names):
    return {name: {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            for name in names for data in (text_bytes(folder / name),)}


def checked_map(folder, pins):
    result = source_map(folder, pins)
    require(all(result[name]["sha256"] == digest for name, digest in pins.items()), "control")
    return result


def validate_manifest(value, own):
    closed(value, ("owner", "schema", "scope", "sourceCommit", "consumerSources", "legacySources",
                   "transactionSources", "originalSources", "harnessSources", "budgets"), "manifest")
    require(value["owner"] == OWNER and type(value["schema"]) is int and value["schema"] == 1
            and value["scope"] == "original-archive-only" and value["sourceCommit"] == SOURCE_COMMIT,
            "manifest")
    expected = set(CONTROL_NAMES) - {"review-manifest.json"}
    closed(value["consumerSources"], expected, "manifest")
    require(set(own) == set(CONTROL_NAMES)
            and all(type(sha) is str and HEX_PATTERN.fullmatch(sha)
                    and own[name]["sha256"] == sha for name, sha in value["consumerSources"].items())
            and value["legacySources"] == LEGACY_PINS and value["transactionSources"] == TRANSACTION_PINS
            and value["originalSources"] == ORIGINAL_PINS and value["harnessSources"] == HARNESS_PINS,
            "manifest")
    closed(value["budgets"], BUDGETS, "manifest")
    require(value["budgets"] == BUDGETS
            and all(type(number) is int for number in value["budgets"].values()), "manifest")


def load_source(path, expected, name):
    data = text_bytes(path)
    require(hashlib.sha256(data).hexdigest() == expected, "control")
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(data, str(path), "exec"), module.__dict__)
    return module


def load_dependencies():
    # Non-main source loading only. Never call legacy execute/admit_image/load_runtime.
    compiler = load_source(TRANSACTION / "compiler_transaction_controller.py",
                           TRANSACTION_PINS["compiler_transaction_controller.py"], "history_compiler_adapter")
    p = compiler.protocol()
    require(p.ROOT == ROOT and p.CONTROL == TRANSACTION and p.RUNS == BASE / "runs-compiler-lld"
            and p.OWNER == TRANSACTION_OWNER and type(p.SCHEMA) is int and p.SCHEMA == 3
            and p.ORIGINAL_PINS == ORIGINAL_PINS, "control")
    g, original = p.load_runtime(), p.load_original()
    legacy = load_source(LEGACY / "local_history_controller.py", LEGACY_PINS["local_history_controller.py"],
                         "immutable_history_validators")
    require(legacy.ROOT == ROOT and legacy.CONTROL == LEGACY and legacy.BUDGETS == BUDGETS
            and legacy.PRODUCER_PINS == ORIGINAL_PINS
            and legacy.HISTORY_SHA == HARNESS_PINS["scripts/host_history_live.py"]
            and g["ROOT"] == ROOT and g["CONTROL"] == TRANSACTION
            and set(g["CONTROL_NAMES"]) == set(TRANSACTION_PINS)
            and type(original) is dict and original["ROOT"] == ROOT, "control")
    api, extended = g["load_windows_api"]()
    return compiler, p, g, original, legacy, api, extended


class Mutex:
    def __init__(self, compiler, p, api):
        self.compiler, self.p, self.api, self.handle = compiler, p, api, None

    def __enter__(self):
        self.handle = self.compiler.acquire_mutex(self.p, self.api)
        return self

    def __exit__(self, *_):
        handle, self.handle = self.handle, None
        self.compiler.release_mutex(self.p, self.api, handle)


def pin_sources(g, api, stack, groups):
    pins = {}
    for prefix, folder, values in groups:
        for name, expected in values.items():
            pin = stack.enter_context(g["ReadPin"](api, folder / name, 1_000_000))
            require(pin.record()["sha256"] == expected["sha256"], "control")
            pins[prefix + "/" + name] = pin
    return pins


def pin_snapshot(pins):
    return {name: pin.recheck() for name, pin in pins.items()}


def recheck_snapshot(pins, expected):
    require(pin_snapshot(pins) == expected, "drift")


def held_build_inputs(p, admitted):
    # This recheck-only context is deliberately retained alongside the 27
    # producer file pins. A file-only adapter must not discard its authority.
    pins = admitted["receiptPins"]
    require(type(pins) is dict and set(pins) == set(p.PRODUCER_FILES) | {"held-build-inputs"}, "producer")
    guard = pins["held-build-inputs"]
    require(isinstance(guard, p.BuildInputsGuard) and callable(getattr(guard, "recheck", None)), "producer")
    return guard


def validate_admitted(p, admitted, producer_run_id):
    closed(admitted, ("image", "imagePin", "receiptPins", "record", "protectedPins", "protectedBefore",
                      "artifact"), "producer")
    require(admitted["image"] == p.image_path(producer_run_id)
            and admitted["image"].parent == BASE / "runs-compiler-lld" / producer_run_id,
            "image")
    held_build_inputs(p, admitted)
    p.image_record(admitted["record"], producer_run_id)
    require(admitted["imagePin"].recheck() == admitted["record"], "image")


def validate_version(p, opt, sources, originals, transactions, admitted, values, stdout, stderr):
    closed(values, (name for name in VERSION_FILES if name.endswith(".json")), "version")
    expected = p.request_record("version", opt.version_run_id, opt.source_commit,
                                opt.producer_run_id, sources, originals, transactions)
    p.validate_request(values["request.json"], expected)
    row = values["result.json"]
    closed(row, p.RESULT_KEYS, "version")
    require(row["owner"] == TRANSACTION_OWNER and type(row["schema"]) is int and row["schema"] == 3
            and row["mode"] == "version" and row["runId"] == opt.version_run_id
            and row["sourceCommit"] == opt.source_commit and row["errorCode"] is None
            and row["qualification"] == "compiler-transaction/version-only"
            and row["releaseQualification"] is False and row["vsixQualification"] is False
            and row["observedVersion"] == "yoke 0.5.0" and integer(row["freeAfter"], p.RUN_FREE)
            and all(row[key] is True for key in ("completed", "inputsUnchanged", "protectedMetadataUnchanged",
                                                "nativeImageReadAttempted", "nativeImageRead")), "version")
    p.image_record(row["selectedImage"], opt.producer_run_id)
    for name in ("selected-image.json", "selected-image-after.json"):
        p.image_record(values[name], opt.producer_run_id)
    require(row["selectedImage"] == values["selected-image.json"] == values["selected-image-after.json"]
            == admitted["record"] and row["selectedArtifact"] == admitted["artifact"]
            and p.digest(row["selectedArtifact"]) == p.digest(admitted["artifact"]), "version")
    p.validate_outer(values["outer.job.json"], None, expected["command"], p.VERSION_SECONDS)
    require(type(stdout) is bytes and type(stderr) is bytes
            and len(stdout) + len(stderr) <= p.MAX_LOG
            and len(stdout) + len(stderr) == values["outer.job.json"]["capturedLogBytes"]
            and stdout.strip() == b"yoke 0.5.0" and stderr == b"", "version")
    for stem, mapping in (("source", sources), ("original-control", originals),
                           ("transaction-control", transactions), ("protected", admitted["protectedBefore"])):
        require(all(values[stem + "-" + phase + ".json"] == mapping
                    and p.digest(values[stem + "-" + phase + ".json"]) == p.digest(mapping)
                    for phase in ("before", "after", "final")), "version")
    current_inputs = p.validate_build_inputs(held_build_inputs(p, admitted).recheck(), sources)
    for phase in ("before", "after", "final"):
        observed = p.validate_build_inputs(values["build-inputs-" + phase + ".json"], sources)
        require(observed == current_inputs and p.digest(observed) == p.digest(current_inputs), "version")


def version_admission(p, g, api, stack, opt, sources, originals, transactions, admitted):
    # Public reuse must validate selectors before any receipt namespace lookup.
    p.run_name(opt.version_run_id)
    p.run_name(opt.producer_run_id)
    require(opt.source_commit == SOURCE_COMMIT and opt.version_run_id != opt.producer_run_id, "arguments")
    out = p.RUNS / opt.version_run_id
    ordinary(out, directory=True)
    sizes = {name: ordinary(out / name).st_size for name in VERSION_FILES}
    require(sum(sizes.values()) <= 64_000_000, "budget")
    pins = {name: stack.enter_context(g["ReadPin"](
        api, out / name, p.MAX_LOG if name in ("outer.stdout", "outer.stderr") else BUDGETS["jsonBytes"]))
        for name in VERSION_FILES}
    values = {name: unique_json(pin.bytes()) for name, pin in pins.items() if name.endswith(".json")}
    validate_version(p, opt, sources, originals, transactions, admitted, values,
                     pins["outer.stdout"].bytes(), pins["outer.stderr"].bytes())
    return pins, pin_snapshot(pins)


def recheck_pair(p, original, admitted, version_pins, version_before):
    held_build_inputs(p, admitted)
    p.recheck_admission(original, admitted)
    recheck_snapshot(version_pins, version_before)


def admit_pair(p, g, api, original, stack, opt, sources, originals, transactions, result):
    require(opt.source_commit == SOURCE_COMMIT, "arguments")
    p.run_name(opt.version_run_id)
    p.run_name(opt.producer_run_id)
    require(opt.version_run_id != opt.producer_run_id, "arguments")
    admitted = p.producer_admission(
        g, api, original, stack, opt.producer_run_id, opt.source_commit, sources, originals, transactions,
        on_image_attempt=lambda: result.update(nativeImageReadAttempted=True))
    result["nativeImageRead"] = True
    validate_admitted(p, admitted, opt.producer_run_id)
    version_pins, version_before = version_admission(
        p, g, api, stack, opt, sources, originals, transactions, admitted)
    recheck_pair(p, original, admitted, version_pins, version_before)
    return admitted, version_pins, version_before


def history_source_map(legacy, g, api, extended, out, environment, phase):
    require(phase in ("before", "after", "final"), "source")
    if phase != "final":
        return legacy.history_source_map(g, api, extended, out, environment, phase)

    def capture(a, e, o, env, label, arguments):
        require(label == "history-files-after", "source")
        return g["git_capture"](a, e, o, env, "history-files-final", arguments)
    final_g = dict(g, git_capture=capture)
    return legacy.history_source_map(final_g, api, extended, out, environment, "after")


def fixed_parent(path):
    ordinary(path.parent, directory=True)
    if not os.path.lexists(path):
        path.mkdir(mode=0o700)
    ordinary(path, directory=True)
    return path


def fresh_directory(parent, name):
    require(type(name) is str and RUN_PATTERN.fullmatch(name), "path")
    ordinary(parent, directory=True)
    path = parent / name
    require(not os.path.lexists(path), "occupied")
    path.mkdir(mode=0o700)
    ordinary(path, directory=True)
    return path


def fresh_fixture():
    # Long journal basenames need a short root even when the checkout is deep.
    # Admit the host-selected existing local TEMP route before creating anything.
    value = os.environ.get("TEMP")
    require(type(value) is str and bool(value), "path")
    parent = Path(value)
    require(parent.is_absolute() and parent.drive.lower() == ROOT.drive.lower(), "path")
    name = "yh-" + os.urandom(8).hex()
    candidate = parent / name
    require(len(str(candidate).encode("utf-16-le")) // 2 <= MAX_FIXTURE_UTF16_UNITS, "path")
    ordinary(parent, directory=True)
    return fresh_directory(parent, name)


def write_json(path, value):
    data = json.dumps(value, ensure_ascii=True, indent=2, allow_nan=False).encode("utf8") + b"\n"
    require(len(data) <= BUDGETS["jsonBytes"], "budget")
    with path.open("xb") as stream:
        stream.write(data)


def initial_result(opt):
    return {"owner": OWNER, "schema": 1, "sourceCommit": opt.source_commit, "runId": opt.run_id,
            "producerRunId": opt.producer_run_id, "versionRunId": opt.version_run_id,
            "completed": False, "nativeImageReadAttempted": False, "nativeImageRead": False,
            "nativeExecutionRequested": False, "localAcceptanceOnly": True,
            "ownerRetirementQualification": False, "archivePurgeQualification": False,
            "nativeBrowserAcceptanceClaimed": False, "releaseQualification": False, "vsixQualification": False,
            "sourceInputsUnchanged": False, "protectedMetadataUnchanged": False,
            "allOriginalRecordsIndependentlyReadBack": False, "treeExitedBeforeCleanup": False,
            "matchingVersionReceiptAdmitted": False, "failureCode": None, "phase": "preflight"}


def current_maps(p, g):
    originals = p.original_map(g)
    transactions = g["controls_map"]()
    legacy = checked_map(LEGACY, LEGACY_PINS)
    harness = checked_map(ROOT, HARNESS_PINS)
    own = source_map(CONTROL, CONTROL_NAMES)
    require(originals == checked_map(ORIGINAL, ORIGINAL_PINS)
            and transactions == checked_map(TRANSACTION, TRANSACTION_PINS), "control")
    validate_manifest(unique_json(text_bytes(CONTROL / "review-manifest.json", 64_000), 64_000), own)
    return {"original": originals, "transaction": transactions, "legacy-history": legacy,
            "harness": harness, "consumer": own}


def write_maps(out, maps, phase):
    require(phase in ("before", "after", "final"), "source")
    for stem, value in maps.items():
        write_json(out / (stem + "-controls-" + phase + ".json"), value)


def execute(opt):
    result = initial_result(opt)
    out = None
    try:
        require(os.name == "nt", "platform")
        require(shutil.disk_usage(ROOT).free >= BUDGETS["imageAdmissionBytes"], "disk")
        # All bootstrap source checks precede any non-main source loading.
        own = source_map(CONTROL, CONTROL_NAMES)
        validate_manifest(unique_json(text_bytes(CONTROL / "review-manifest.json", 64_000), 64_000), own)
        for folder, expected in ((LEGACY, LEGACY_PINS), (TRANSACTION, TRANSACTION_PINS),
                                  (ORIGINAL, ORIGINAL_PINS), (ROOT, HARNESS_PINS)):
            checked_map(folder, expected)
        compiler, p, g, original, legacy, api, extended = load_dependencies()
        with Mutex(compiler, p, api), ExitStack() as stack:
            fixed_parent(RUNS)
            fixed_parent(PRIVATE)
            out = fresh_directory(RUNS, opt.run_id)
            private = fresh_directory(PRIVATE, opt.run_id)
            fixture, evidence = fresh_fixture(), private / "worker-evidence"
            evidence.mkdir(mode=0o700)
            write_json(out / "request.json", {**result, "scope": "original-archive-only", "budgets": BUDGETS})
            before = current_maps(p, g)
            require(before["consumer"] == own, "drift")
            controls = p.pin_control_files(g, api, stack)
            controls.update(pin_sources(g, api, stack, (
                ("consumer", CONTROL, before["consumer"]), ("legacy-history", LEGACY, before["legacy-history"]),
                ("harness", ROOT, before["harness"]))))
            control_records = pin_snapshot(controls)
            require(current_maps(p, g) == before, "drift")
            live = load_source(ROOT / "scripts/host_history_live.py", HARNESS_PINS["scripts/host_history_live.py"],
                               "unchanged_history_transaction_worker")
            environment = g["environment_for"]("build")
            result["phase"] = "producer-and-version-admission"
            sources = g["source_map"](api, extended, out, environment, opt.source_commit, "before")
            admitted, version_pins, version_before = admit_pair(
                p, g, api, original, stack, opt, sources, before["original"], before["transaction"], result)
            result["matchingVersionReceiptAdmitted"] = True
            broader_before = history_source_map(legacy, g, api, extended, out, environment, "before")
            write_json(out / "history-sources-before.json", broader_before)
            write_maps(out, before, "before")
            image, record = admitted["image"], admitted["record"]
            job_name = "Local\\YokeHistoryCI-" + os.urandom(32).hex()
            spec = {"native": str(image), "nativeSha256": record["sha256"], "fixture": str(fixture),
                    "output": str(evidence), "workerJobName": job_name}
            legacy.validate_spec(spec, image, record["sha256"], fixture, evidence, job_name)
            spec_path = private / "spec.json"
            spec_data = json.dumps(spec, ensure_ascii=True).encode("utf8") + b"\n"
            require(len(spec_data) <= BUDGETS["specBytes"], "budget")
            with spec_path.open("xb") as stream:
                stream.write(spec_data)
            spec_pin = stack.enter_context(g["ReadPin"](api, spec_path, BUDGETS["specBytes"]))
            spec_before = spec_pin.recheck()
            require(unique_json(spec_pin.bytes(), BUDGETS["specBytes"]) == spec, "spec")
            fixture_env = legacy.fixture_environment(fixture)
            require(not any(name.upper() in ("GITHUB_ACTIONS", "GITHUB_SHA") for name in fixture_env), "spec")
            recheck_pair(p, original, admitted, version_pins, version_before)
            recheck_snapshot(controls, control_records)
            result["phase"] = "owned-history-worker"
            result["nativeExecutionRequested"] = True
            # This exact harness alone creates the named history Job. No generic
            # runner, direct worker call, fake CI or caller-supplied command exists.
            live.bounded_worker(spec_path, fixture, evidence, fixture_env, job_name)
            result["phase"] = "evidence-admission"
            evidence_pins = {}

            def private_json(relative, maximum=1_000_000):
                require(relative in ("job.json", "live-result.json")
                        or legacy.EVIDENCE_PATTERN.fullmatch(relative), "evidence")
                require(relative not in evidence_pins, "evidence")
                pin = stack.enter_context(g["ReadPin"](api, evidence / relative, maximum))
                evidence_pins[relative] = pin
                return unique_json(pin.bytes(), maximum)
            job, live_result = private_json("job.json"), private_json("live-result.json")
            legacy.validate_job(job)
            legacy.validate_live(live_result, record["sha256"])
            summaries = legacy.validate_archives(live_result, private_json)
            evidence_before = pin_snapshot(evidence_pins)
            live.output_size(fixture)
            live.output_size(evidence)
            result["phase"] = "final-recheck"
            require(spec_pin.recheck() == spec_before, "drift")
            for phase in ("after", "final"):
                after = g["source_map"](api, extended, out, environment, opt.source_commit, phase)
                broader = history_source_map(legacy, g, api, extended, out, environment, phase)
                maps = current_maps(p, g)
                require(after == sources and broader == broader_before and maps == before, "drift")
                write_json(out / ("history-sources-" + phase + ".json"), broader)
                write_maps(out, maps, phase)
                recheck_pair(p, original, admitted, version_pins, version_before)
                recheck_snapshot(controls, control_records)
                recheck_snapshot(evidence_pins, evidence_before)
                require(spec_pin.recheck() == spec_before, "drift")
                require(shutil.disk_usage(ROOT).free >= BUDGETS["reserveBytes"], "disk")
            result.update(nativeSha256=record["sha256"], variants=summaries,
                          producerSourceInputCount=len(sources), historySourceInputCount=len(broader_before),
                          originalControlCount=len(before["original"]), transactionControlCount=len(before["transaction"]),
                          legacyHistoryControlCount=len(before["legacy-history"]), consumerControlCount=len(before["consumer"]),
                          harnessSourceCount=len(before["harness"]), sourceInputsUnchanged=True,
                          protectedMetadataUnchanged=True, allOriginalRecordsIndependentlyReadBack=True,
                          treeExitedBeforeCleanup=True)
        # Every pin recheck/close and mutex release must succeed first.
        require(shutil.disk_usage(ROOT).free >= BUDGETS["reserveBytes"], "disk")
        result.update(completed=True, phase="complete")
    except BaseException as error:
        code = getattr(error, "code", None)
        result.update(completed=False, sourceInputsUnchanged=False, protectedMetadataUnchanged=False,
                      allOriginalRecordsIndependentlyReadBack=False, treeExitedBeforeCleanup=False,
                      failureCode=code if type(code) is str and code in CODES else "external-failure")
    finally:
        if out is not None:
            try:
                write_json(out / "result.json", result)
            except BaseException:
                result.update(completed=False, failureCode="external-failure", phase="result-publication")
    return result


def main(arguments=None):
    try:
        result = execute(options(arguments))
    except BaseException:
        result = {"owner": OWNER, "completed": False, "phase": "arguments", "failureCode": "arguments"}
    # Never expose exception messages, raw fixture stderr, capability URLs or paths.
    print(json.dumps({"owner": OWNER, "completed": result["completed"], "phase": result["phase"],
                      "failureCode": result["failureCode"]}), flush=True)
    return 0 if result["completed"] else 1


if __name__ == "__main__":
    sys.exit(main())
