"""Prepare inert test source for the new closed cross-maintenance consumer."""
import ast
from pathlib import Path

ROOT = Path.cwd()
BASE = ROOT / 'validation/integration-20261025/platform-repairs'
OLD = Path(r'C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-b1973677') / BASE.relative_to(ROOT) / 'control-owner-retirement-live-704'
NEW = BASE / 'control-cross-maintenance-live-704'


def replace(source, before, after):
    assert source.count(before) == 1, before[:90]
    return source.replace(before, after)


def main():
    source = (OLD / 'test_retirement_transaction_controller.py').read_text(encoding='utf-8')
    for before, after in (
        ('retirement_transaction_controller.py', 'cross_transaction_controller.py'),
        ('owner_retirement_live.py', 'cross_maintenance_live.py'),
        ('retirement_worker_entry.py', 'cross_worker_entry.py'),
        ('single-selection-owner-retirement-live', 'cross-maintenance-purge-generated-retirement-live'),
        ('validate_retirement_live', 'validate_cross_live'),
    ):
        source = source.replace(before, after)
    source = replace(source, '"archive-consumer": {name: {"bytes": 1, "sha256": sha} for name, sha in C.ARCHIVE_CONSUMER_PINS.items()}}',
                     '"archive-consumer": {name: {"bytes": 1, "sha256": sha} for name, sha in C.ARCHIVE_CONSUMER_PINS.items()},\n'
                     '            "retirement-consumer": {name: {"bytes": 1, "sha256": sha} for name, sha in C.RETIREMENT_CONSUMER_PINS.items()}}')
    source = replace(source, '"schema": 2, "scope": "cross-maintenance-purge-generated-retirement-live"',
                     '"schema": 3, "scope": "cross-maintenance-purge-generated-retirement-live"')
    source = replace(source, '"archiveConsumerSources": C.ARCHIVE_CONSUMER_PINS, "budgets": C.BUDGETS}',
                     '"archiveConsumerSources": C.ARCHIVE_CONSUMER_PINS,\n'
                     '                    "retirementConsumerSources": C.RETIREMENT_CONSUMER_PINS, "budgets": C.BUDGETS}')
    tree = ast.parse(source)
    golden = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'golden_summary')
    segment = ast.get_source_segment(source, golden)
    source = replace(source, segment, '''G_SPEC = importlib.util.spec_from_file_location("inert_cross_goldens", Path(__file__).with_name("test_cross_maintenance_live.py"))
G = importlib.util.module_from_spec(G_SPEC)
G_SPEC.loader.exec_module(G)


def golden_summary(label):
    return G.golden_summary(label)''')
    source = replace(source, '"nativeBrowserAcceptanceClaimed": False, "actualInterruptedRetirementQualification": False}',
                     '"nativeBrowserAcceptanceClaimed": False, "actualInterruptedRetirementQualification": False,\n'
                     '            "actualInterruptedPurgeQualification": False}')
    source = replace(source, 'self.assertTrue(all(v["independentReadBytesExact"] for v in value["variants"]))',
                     'self.assertTrue(all(v["complete"] for v in value["variants"]))\n'
                     '        self.assertTrue(value["retainedArchiveReadsAfterRetirementQualification"])\n'
                     '        self.assertTrue(value["generatedOwnerQualification"])')
    source = replace(source, 'self.assertFalse(value["archivePurgeQualification"])',
                     'self.assertTrue(value["archivePurgeQualification"])\n'
                     '        self.assertFalse(value["actualInterruptedPurgeQualification"])\n'
                     '        self.assertFalse(value["purgeRecoveryQualification"])')
    source = source.replace('x["variants"][0]["owningExit"].update', 'x["variants"][0]["currentExit"].update')
    source = replace(source, 'lambda x: x["live-result.json"]["variants"][1].update(markerEvidenceKind="actual-native-interruption")',
                     'lambda x: x["live-result.json"].update(actualInterruptedPurgeQualification=True)')
    # Existing unknown-key refusal test remains; the new field is never manufactured.
    source = source.replace('class RetirementScopeTests', 'class CrossMaintenanceScopeTests')
    ast.parse(source)
    output = NEW / 'test_cross_transaction_controller.py'
    assert not output.exists()
    output.write_bytes(source.encode('utf-8'))
    print('Prepared inert cross-maintenance controller test source only')


if __name__ == '__main__':
    main()
