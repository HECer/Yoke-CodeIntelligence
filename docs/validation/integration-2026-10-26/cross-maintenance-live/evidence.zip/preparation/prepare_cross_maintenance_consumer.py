"""Prepare a new immutable-admission consumer; source only, never execute controls."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
REL = Path('validation/integration-20261025/platform-repairs')
BASE = ROOT / REL
OLD_ROOT = Path(r'C:\Users\Lomi\.t3\worktrees\Yoke-CodeIntelligence\t3-b1973677')
OLD = OLD_ROOT / REL / 'control-owner-retirement-live-704'
NEW = BASE / 'control-cross-maintenance-live-704'


def replace(source, before, after):
    assert source.count(before) == 1, before[:90]
    return source.replace(before, after)


def write(name, value):
    target = NEW / name
    assert not target.exists()
    if name.endswith('.py'):
        ast.parse(value)
    target.write_bytes(value.encode('utf-8'))


def main():
    NEW.mkdir(exist_ok=True)
    source = (OLD / 'retirement_transaction_controller.py').read_text(encoding='utf-8')
    pins = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in OLD.iterdir()
            if path.is_file() and path.suffix in ('.py', '.md', '.json') or path.name == '.gitattributes'}
    assert len(pins) == 8
    for old, new in (
        ('control-owner-retirement-live-704', 'control-cross-maintenance-live-704'),
        ('runs-owner-retirement-live-704', 'runs-cross-maintenance-live-704'),
        ('private-owner-retirement-live-704', 'private-cross-maintenance-live-704'),
        ('local-owner-retirement-lld-consumer-v1', 'local-cross-maintenance-lld-consumer-v1'),
        ('retirement_transaction_controller.py', 'cross_transaction_controller.py'),
        ('test_retirement_transaction_controller.py', 'test_cross_transaction_controller.py'),
        ('owner_retirement_live.py', 'cross_maintenance_live.py'),
        ('test_owner_retirement_live.py', 'test_cross_maintenance_live.py'),
        ('retirement_worker_entry.py', 'cross_worker_entry.py'),
        ('single-selection-owner-retirement-live', 'cross-maintenance-purge-generated-retirement-live'),
        ('validate_retirement_live', 'validate_cross_live'),
    ):
        source = source.replace(old, new)
    source = replace(source, '"archiveConsumerSources", "budgets"), "manifest")',
                     '"archiveConsumerSources", "retirementConsumerSources", "budgets"), "manifest")')
    source = replace(source, 'value["schema"] == 2', 'value["schema"] == 3')
    source = replace(source, '"owner": OWNER, "schema": 2,', '"owner": OWNER, "schema": 3,')
    source = replace(source, 'and value["archiveConsumerSources"] == ARCHIVE_CONSUMER_PINS,',
                     'and value["archiveConsumerSources"] == ARCHIVE_CONSUMER_PINS\n'
                     '            and value["retirementConsumerSources"] == RETIREMENT_CONSUMER_PINS,')
    source = replace(source, 'ARCHIVE_CONSUMER = BASE / "control-history-lld-704"',
                     'ARCHIVE_CONSUMER = BASE / "control-history-lld-704"\n'
                     'RETIREMENT_CONSUMER = BASE / "control-owner-retirement-live-704"\n'
                     'RETIREMENT_CONSUMER_PINS = ' + repr(pins))
    source = replace(source, '"archive-consumer": checked_map(ARCHIVE_CONSUMER, ARCHIVE_CONSUMER_PINS)}',
                     '"archive-consumer": checked_map(ARCHIVE_CONSUMER, ARCHIVE_CONSUMER_PINS),\n'
                     '            "retirement-consumer": checked_map(RETIREMENT_CONSUMER, RETIREMENT_CONSUMER_PINS)}')
    source = replace(source, '(ARCHIVE_CONSUMER, ARCHIVE_CONSUMER_PINS)):',
                     '(ARCHIVE_CONSUMER, ARCHIVE_CONSUMER_PINS),\n'
                     '                                  (RETIREMENT_CONSUMER, RETIREMENT_CONSUMER_PINS)):')
    source = replace(source, '("archive-consumer", ARCHIVE_CONSUMER, before["archive-consumer"]))))',
                     '("archive-consumer", ARCHIVE_CONSUMER, before["archive-consumer"]),\n'
                     '                ("retirement-consumer", RETIREMENT_CONSUMER, before["retirement-consumer"]))))')
    source = replace(source, '"actualInterruptedRetirementQualification": False, "olderBinaryQualification": False,',
                     '"actualInterruptedRetirementQualification": False, "olderBinaryQualification": False,\n'
                     '            "actualInterruptedPurgeQualification": False, "purgeRecoveryQualification": False,\n'
                     '            "retainedArchiveReadsAfterRetirementQualification": False, "generatedOwnerQualification": False,')
    source = replace(source, 'ownerRetirementQualification=True,\n                          treeExitedBeforeCleanup=True)',
                     'ownerRetirementQualification=True, archivePurgeQualification=True,\n'
                     '                          retainedArchiveReadsAfterRetirementQualification=True, generatedOwnerQualification=True,\n'
                     '                          treeExitedBeforeCleanup=True)')
    source = replace(source, 'independentDocumentReadsExact=False, ownerRetirementQualification=False,',
                     'independentDocumentReadsExact=False, ownerRetirementQualification=False, archivePurgeQualification=False,\n'
                     '                      retainedArchiveReadsAfterRetirementQualification=False, generatedOwnerQualification=False,')
    source = source.replace('"nativeBrowserAcceptanceClaimed", "actualInterruptedRetirementQualification")',
                            '"nativeBrowserAcceptanceClaimed", "actualInterruptedRetirementQualification", "actualInterruptedPurgeQualification")')
    # The two occurrences above are the closed key set and the exact false list.
    assert source.count('"actualInterruptedPurgeQualification")') == 2
    write('cross_transaction_controller.py', source)
    entry = (OLD / 'retirement_worker_entry.py').read_text(encoding='utf-8')
    tree = ast.parse(entry)
    assignment = next(n for n in tree.body if isinstance(n, ast.Assign)
                      and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'WORKER_SHA')
    entry = replace(entry, ast.get_source_segment(entry, assignment), 'WORKER_SHA = "PARENT_SEAL_REQUIRED"')
    entry = entry.replace('owner_retirement_live.py', 'cross_maintenance_live.py')
    entry = entry.replace('single-selection-owner-retirement-live', 'cross-maintenance-purge-generated-retirement-live')
    entry = replace(entry, '"actualInterruptedRetirementQualification": False})',
                    '"actualInterruptedRetirementQualification": False, "actualInterruptedPurgeQualification": False})')
    write('cross_worker_entry.py', entry)
    write('.gitattributes', '*.py -text\n*.json -text\n*.md text eol=lf\n.gitattributes text eol=lf\n')
    print(json.dumps({'sourceOnly': True, 'preparedFiles': 3, 'retirementConsumerSourcesPinned': len(pins)}))


if __name__ == '__main__':
    main()
