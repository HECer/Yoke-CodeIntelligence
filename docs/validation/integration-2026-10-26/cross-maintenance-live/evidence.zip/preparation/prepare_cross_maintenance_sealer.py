"""Derive a source-only sealer for the new cross-maintenance bundle."""
import ast
from pathlib import Path

BASE = Path.cwd() / 'validation/integration-20261025/platform-repairs'
source = (BASE / 'seal_retirement_consumer.py').read_text(encoding='utf-8')
for before, after in (
    ('control-owner-retirement-live-704', 'control-cross-maintenance-live-704'),
    ('retirement_transaction_controller.py', 'cross_transaction_controller.py'),
    ('test_retirement_transaction_controller.py', 'test_cross_transaction_controller.py'),
    ('owner_retirement_live.py', 'cross_maintenance_live.py'),
    ('test_owner_retirement_live.py', 'test_cross_maintenance_live.py'),
    ('retirement_worker_entry.py', 'cross_worker_entry.py'),
    ('local-owner-retirement-lld-consumer-v1', 'local-cross-maintenance-lld-consumer-v1'),
    ('single-selection-owner-retirement-live', 'cross-maintenance-purge-generated-retirement-live'),
    ('runs-retirement-704-guard-tests', 'runs-cross-maintenance-704-guard-tests'),
    ('retirement-lld-source-guard-tests-v1', 'cross-maintenance-lld-source-guard-tests-v1'),
    ('retirement-704-guard-tests-r1', 'cross-maintenance-704-guard-tests-r1'),
    ('run_retirement_704_guard_tests_r1.py', 'run_cross_maintenance_704_guard_tests_r1.py'),
    ('owner-retirement-consumer-preparation-r1.json', 'cross-maintenance-consumer-preparation-r1.json'),
    ('actualRetirementAcceptance', 'actualCrossMaintenanceAcceptance'),
):
    source = source.replace(before, after)
assert source.count("'schema': 2") == 1
source = source.replace("'schema': 2", "'schema': 3")
before = "'archiveConsumerSources': constant(source, 'ARCHIVE_CONSUMER_PINS'),"
assert source.count(before) == 1
source = source.replace(before, before + "\n                'retirementConsumerSources': constant(source, 'RETIREMENT_CONSUMER_PINS'),")
before = "dependencies[str(OLD / name)] = digest"
assert source.count(before) == 1
source = source.replace(before, before + "\n    for name, digest in manifest['retirementConsumerSources'].items():\n        dependencies[str(WORKTREE / REL / 'control-owner-retirement-live-704' / name)] = digest")
source = source.replace("print(json.dumps({'sourceOnly': True", "print(json.dumps({'sourceOnly': True")
ast.parse(source)
output = BASE / 'seal_cross_maintenance_consumer.py'
assert not output.exists()
output.write_bytes(source.encode('utf-8'))
print('Prepared sealer source only; no controls installed or executed')
