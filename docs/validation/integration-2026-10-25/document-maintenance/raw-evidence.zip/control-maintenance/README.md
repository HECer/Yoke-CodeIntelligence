# Scoped maintenance validation controller

Derived from the reviewed platform controller a226a064. All function and class ASTs are identical. Only owner, private control/output directories and the finite target descriptor change. The extra whole target is session_dashboard_management with300seconds, a new conservative scope rather than an inherited platform budget. Existing lib/process/REPL/discovery/ingress limits, profiles, 1.2GB start/500MB running floors, 1second drain, 2second cleanup, fresh matching producer and protected-image refusals are unchanged.

Use build then test with an exact clean committed source and unique run IDs. The source, controls and source-bound fresh image must match throughout. No old Yoke image is adopted. Actual execution remains unqualified until receipts prove completion.
