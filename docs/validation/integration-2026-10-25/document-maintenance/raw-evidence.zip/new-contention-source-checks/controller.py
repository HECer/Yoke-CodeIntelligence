"""Run text/Node checks through the unchanged reviewed owned-Job controller."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import sys

ROOT = Path(__file__).resolve().parents[3]
CONTROL = ROOT / 'validation/integration-20261025/platform-repairs/control'
EXPECTED = 'a226a064b769585a9f3a107042ed5b26cbbdede4816106ae1db6d62b4dfa1af7'
data = (CONTROL / 'validation_controller.py').read_bytes()
assert hashlib.sha256(data).hexdigest() == EXPECTED
scope = {'__name__': 'reviewed_source_checks', '__file__': str(CONTROL / 'validation_controller.py')}
exec(compile(data, scope['__file__'], 'exec'), scope)
out = scope['new_output']('source-contention-r1')
api, extended = scope['load_windows_api']()
environment = scope['environment_for']('test')
git = lambda label, args: scope['git_capture'](api, extended, out, environment, label, args)
head = git('git-head', ['rev-parse', 'HEAD']).decode('ascii').strip()
status = git('git-status', ['status', '--porcelain=v1', '-z', '--untracked-files=no'])
names = git('git-files', ['ls-files', '-z']).decode('utf8').split('\0')
selected = sorted(name for name in names if name and (
    name.startswith(('native/', 'scripts/', '.cargo/', 'src/', 'test/', 'tests/', 'bin/', 'extension/'))
    or name == '.github/workflows/rust.yml'
    or Path(name).suffix in ('.json', '.jsonc', '.ts', '.js', '.mjs', '.cjs') and '/' not in name
    or Path(name).name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain', 'rust-toolchain.toml')))
before = scope['hash_selected'](selected)
scope['write_json'](out, 'source-before.json', before)
scope['write_json'](out, 'base-and-worktree.json', {
    'baseCommit': head, 'trackedStatusSha256': hashlib.sha256(status).hexdigest(),
    'cleanHeadClaimed': False, 'trackedStatus': status.decode('utf8').split('\0')})
commands = [
    ('typecheck', [str(Path(os.environ['SystemRoot']) / 'System32/cmd.exe'), '/d', '/c', 'npm run typecheck']),
    ('npm-test', [str(Path(os.environ['SystemRoot']) / 'System32/cmd.exe'), '/d', '/c', 'npm test']),
    ('native-format', [sys.executable, '-B', 'scripts/native_fmt.py', '--check']),
]
result = {'baseCommit': head, 'cleanHeadClaimed': False, 'sourceInputs': len(selected),
          'inputsUnchanged': False, 'nativeCompileOrTestClaimed': False, 'phases': {}}
try:
    for name, command in commands:
        row = scope['run_owned'](api, extended, out, name, command, environment, 1200)
        result['phases'][name] = row
        scope['write_json'](out, name + '-phase.json', row)
        scope['require'](row['completed'], 'Owned source check incomplete: ' + name)
    after = scope['hash_selected'](selected)
    scope['write_json'](out, 'source-after.json', after)
    result['inputsUnchanged'] = before == after
    scope['require'](result['inputsUnchanged'], 'Selected source bytes changed during checks')
finally:
    scope['write_json'](out, 'result.json', result)
print(json.dumps({'run': out.name, 'inputs': len(selected), 'inputsUnchanged': result['inputsUnchanged'],
                  'phases': {name: {'completed': row['completed'], 'exitCode': row.get('exitCode'),
                            'treeExitedBeforeCleanup': row['treeExitedBeforeCleanup']}
                             for name, row in result['phases'].items()}}))
