pub type MacId = u32;
pub fn observed_cast(pid: u32) -> MacId { pid as MacId }
