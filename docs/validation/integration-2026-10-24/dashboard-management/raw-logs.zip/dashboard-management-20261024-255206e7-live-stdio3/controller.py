from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-management-20261024-255206e7-live-stdio3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')



q=w/'validation/integration-20261018/dashboard-management-20261024-255206e7-split-green1';inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());built=json.loads((q/'built-cli.json').read_bytes());assert built['buildPassed'];native=w/'target/debug/yoke.exe';assert sha(native)==built['sha256'];worker=Path(r'C:\Users\Lomi\AppData\Local\Temp\dashboard-management-stdio-worker-20261024.py');shutil.copyfile(worker,out/'stdio-worker.py');complete=False;accepted=[]
try:
 for variant in ['serena','persistent-python','native-session']:
  selected=out/variant;selected.mkdir();source=jobroot/('source-'+variant);source.mkdir();(source/'main.rs').write_bytes('// owned \U0001f980 e\u0301\r\nfn original() {}\r\n'.encode());other=jobroot/('other-'+variant);other.mkdir();(other/'secondary.rs').write_bytes(b'fn second() {}\r\n');profile=jobroot/(variant+'-host.json');profile.write_text(json.dumps({'context':'desktop-app','modes':['editing'],'steering':{},'notesPolicy':{'writable':True},'dashboard':{'management':{'operationTimeoutMs':3000},'lifetimeMs':60000},'projects':[{'name':'secondary','root':str(other),'readOnly':True}]}));spec={'out':str(selected),'native':str(native),'root':str(source),'hostProfilePath':str(profile),'cliSha256':built['sha256']}
  if variant=='persistent-python':spec['python']=r'C:\Python314\python.exe'
  if variant=='native-session':
   spec['protocolProfile']='native';host=json.loads(profile.read_bytes());host['steering']={'modes':{'hide-find':{'instructions':'Owned catalog selection fixture','excludedTools':['ci_find']}}};profile.write_text(json.dumps(host))
  path=jobroot/(variant+'-spec.json');path.write_text(json.dumps(spec));run('actual-stdio-'+variant,[r'C:\Python314\python.exe','-I',worker,path],timeout=120);result=json.loads((selected/'stdio-live-result.json').read_bytes());assert result['complete'] and result['readerJoined'];accepted.append({'variant':variant,'result':result})
 complete=True
finally:
 result={'complete':complete,'variants':accepted,'currentCliSha256':sha(native),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'existingCredentialsAccessed':False,'systemSettingsChanged':False,'modelCalls':0,'analyzedSourceExecuted':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'complete':complete,'variants':len(accepted),'allJobsEmpty':result['allJobsEmpty']}),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
