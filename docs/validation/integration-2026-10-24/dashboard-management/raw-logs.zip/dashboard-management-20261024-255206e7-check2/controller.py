from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-management-20261024-255206e7-check2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')



previous=w/'validation/integration-20261018/dashboard-management-20261024-255206e7-test1/source-before.json';names=set(json.loads(previous.read_bytes()));names.add('native/src/protocol_managed_stdio.rs');inputs={n:sha(w/n) for n in sorted(names)};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');assert shutil.disk_usage(w).free>550_000_000
complete=False
try:
 run('check-all-targets',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','check','--workspace','--all-targets','--locked','--offline','-j','1'],timeout=600)
 run('typescript-typecheck',[r'C:\Program Files\nodejs\node.exe',r'C:\Program Files\nodejs\node_modules\npm\bin\npm-cli.js','run','typecheck'],timeout=300)
 run('typescript-tests',[r'C:\Program Files\nodejs\node.exe',r'C:\Program Files\nodejs\node_modules\npm\bin\npm-cli.js','test'],timeout=300)
 complete=True
finally:
 result={'complete':complete,'sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'freeBytes':shutil.disk_usage(w).free};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
