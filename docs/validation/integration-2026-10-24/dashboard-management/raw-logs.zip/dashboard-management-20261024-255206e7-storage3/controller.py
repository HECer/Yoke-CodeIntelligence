from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-management-20261024-255206e7-storage3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')






phase=w/'validation/integration-20261018/dashboard-management-20261024-255206e7-lib1';proof=json.loads((phase/'result.json').read_bytes());assert proof['complete'] and proof['sourceInputsUnchanged'] and proof['allJobsEmpty'];artifacts=[]
for line in (phase/'whole-library.stdout').read_bytes().splitlines():
 try:m=json.loads(line)
 except ValueError:continue
 if m.get('reason')=='compiler-artifact' and Path(m['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and m['target']['name']=='yoke' and m['target']['kind']==['lib'] and m['profile']['test']:artifacts.append(m)
assert len(artifacts)==1;artifact=artifacts[0];exe=Path(artifact['executable']);exe_hash=sha(exe);files=[Path(n) for n in artifact['filenames']];assert len(files)==2 and all(p.suffix in ('.exe','.pdb') for p in files)
done=[];initial=shutil.disk_usage(w).free;complete=False;compact=os.environ['SystemRoot']+'\\System32\\compact.exe'
try:
 for path in files:
  assert path.parent.resolve()==(w/'target/debug/deps').resolve() and not path.name.startswith(('capture_options-','session_fixed_tools-')) and not path.is_symlink()
  size=path.stat().st_size;expected=sha(path);assert shutil.disk_usage(w).free>500_000_000+size+64_000_000 and sha(exe)==exe_hash
  if path.stat().st_file_attributes&0x800:
   run('decompress-passed-'+path.name,[compact,'/U','/F','/I','/Q',path],timeout=90);assert path.stat().st_size==size and sha(path)==expected
  run('lzx-passed-'+path.name,[compact,'/C','/F','/EXE:LZX','/I','/Q',path],timeout=90);assert path.stat().st_size==size and sha(path)==expected and sha(exe)==exe_hash
  done.append({'path':str(path),'bytes':size,'sha256':expected,'positiveWholeHarness':str(phase.relative_to(w)),'associatedPassedExecutableSha256':exe_hash,'logicalBytesAndSha256Exact':True});(out/'compression.json').write_text(json.dumps(done,indent=2)+'\n')
 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'files':len(done),'initialFreeBytes':initial,'freeBytes':shutil.disk_usage(w).free,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'deletions':False},indent=2)+'\n');assert _scratch_api.CloseHandle(scratch_guard)
