import hashlib,http.client,json,os,queue,subprocess,sys,threading,time,urllib.parse
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_bytes());out=Path(spec['out']);native=Path(spec['native']);source=Path(spec['root']);profile=Path(spec['hostProfilePath']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(native)==spec['cliSha256'];source_before=sha(source/'main.rs');events=[];notifications=[];pending=queue.Queue();process=None;reader=None;complete=False;stderr=None;dashboard=None;capability=None;outcome={}

def reader_main():
 try:
  while True:
   line=process.stdout.readline(16_000_001)
   if not line:break
   assert len(line)<=16_000_000
   pending.put(json.loads(line))
 except BaseException:pending.put({'ownedReaderError':True})
 finally:pending.put({'ownedReaderEof':True})
def next_frame(timeout=8):
 item=pending.get(timeout=timeout);assert not item.get('ownedReaderError') and not item.get('ownedReaderEof'),'Owned native stdio ended unexpectedly';return item
def rpc(identifier,method,params=None):
 message={'jsonrpc':'2.0','id':identifier,'method':method,'params':params or {}};process.stdin.write(json.dumps(message,ensure_ascii=False).encode()+b'\n');process.stdin.flush();until=time.monotonic()+10
 while time.monotonic()<until:
  item=next_frame(min(8,max(.01,until-time.monotonic())))
  if item.get('method')=='notifications/tools/list_changed':notifications.append(item);continue
  assert item.get('id')==identifier and 'error' not in item,'Unexpected native protocol response';return item
 raise TimeoutError('Owned native protocol response deadline')
def tool(identifier,name,args=None):
 if spec.get('protocolProfile')=='native' and name in ('open_dashboard','get_current_config'):
  args={'operation':{'open_dashboard':'openDashboard','get_current_config':'configuration'}[name],'args':args or {}};name='ci_session'
 reply=rpc(identifier,'tools/call',{'name':name,'arguments':args or {}});assert reply['result']['isError'] is False,'Owned native tool refused';value=reply['result'].get('structuredContent')
 if value is None:value=json.loads(reply['result']['content'][0]['text'])
 assert value['status']=='ok','Owned native tool response is not complete';return value['data']
def dashboard_request(method,path,body=None):
 connection=http.client.HTTPConnection(dashboard.hostname,dashboard.port,timeout=6);headers={'Authorization':'Bearer '+capability,'Origin':f'http://{dashboard.hostname}:{dashboard.port}'}
 if body is not None:headers['Content-Type']='application/json'
 connection.request(method,path,body=None if body is None else json.dumps(body,ensure_ascii=False).encode(),headers=headers);response=connection.getresponse();status=response.status;raw=response.read(4_000_001);connection.close();assert len(raw)<=4_000_000;return status,json.loads(raw)
def state():
 status,value=dashboard_request('GET','/api/state');assert status==200;return value
def manage(action,selected=None):
 selected=selected or state();body={'id':os.urandom(32).hex(),'sessionStateSha256':selected['view']['management']['sessionStateSha256'],'project':selected['view']['activeProject'],'action':action};status,value=dashboard_request('POST','/api/manage',body);events.append({'kind':action['kind'],'status':status,'notApplied':value.get('notApplied')});return status,value
try:
 argv=[str(native),'--root',str(source),'--timeout','30000','--max-bytes','4000000','serve-session','--profile',spec.get('protocolProfile','serena'),'--id','dashboard-stdio-owned','--host-profile',str(profile)]
 if spec.get('python'):argv.extend(['--python',spec['python'],'--trust-python'])
 stderr=(out/'native-stdio.stderr').open('wb');process=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,creationflags=0x08000000);reader=threading.Thread(target=reader_main);reader.start()
 initial=rpc(1,'initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'owned-dashboard-live-acceptance','version':'0.5.0'}});assert initial['result']['serverInfo']['version']=='0.5.0'
 catalog=rpc(2,'tools/list')['result']['tools']
 if spec.get('protocolProfile')=='native':assert 'ci_find' in [t['name'] for t in catalog]
 else:
  description=next(t['description'] for t in catalog if t['name']=='open_dashboard');assert 'management' in description and 'Configuration files' in description
 opened=tool(3,'open_dashboard');dashboard=urllib.parse.urlparse(opened['url']);capability=dashboard.fragment;assert dashboard.scheme=='http' and dashboard.hostname=='127.0.0.1' and len(capability)==64 and opened['browserOpened'] is False
 assert opened['capabilities']['memoryEditing'] is True and opened['capabilities']['mcpShutdown'] is False;original=state();assert original['view']['management']['enabled'] is True
 if spec.get('python'):
  runtime_session=tool(30,'get_current_config')['sessionId'];cell=tool(31,'serena_repl',{'session_id':runtime_session,'code':'owned_marker = 41\nprint(owned_marker)'});assert cell['stdout']=='41\n'
 status,created=manage({'kind':'createMemory','name':'owned/\u03c0','content':'first\r\n<script>inert</script>\r\n\U0001f980 e\u0301'});assert status==200;first=created['data']['note']['id'];status,read=manage({'kind':'readMemory','name':'owned/\u03c0'});assert status==200 and read['data']['note']['content']=='first\r\n<script>inert</script>\r\n\U0001f980 e\u0301'
 status,written=manage({'kind':'writeMemory','name':'owned/\u03c0','content':'second\r\n','expectedRevision':first});assert status==200;second=written['data']['note']['id'];status,stale=manage({'kind':'writeMemory','name':'owned/\u03c0','content':'must not overwrite','expectedRevision':first});assert status==409 and stale['notApplied'] is True
 before_mode=state();selected_modes=['editing','no-memories']+(['hide-find'] if spec.get('protocolProfile')=='native' else []);status,changed=manage({'kind':'switchModes','modes':selected_modes});assert status==200
 # No further stdio request is sent until the asynchronous notification arrives.
 notice=next_frame();assert notice.get('method')=='notifications/tools/list_changed';notifications.append(notice);outcome['catalogNotificationWhileStdioInputIdle']=True
 config=tool(4,'get_current_config');assert 'no-memories' in config['modes'];catalog=rpc(5,'tools/list')['result']['tools'];assert ('ci_find' if spec.get('protocolProfile')=='native' else 'write_memory') not in [v['name'] for v in catalog]
 status,denied=manage({'kind':'createMemory','name':'denied','content':'not allowed'});assert status!=200
 status,stale_session=manage({'kind':'createMemory','name':'stale-session','content':'must not apply'},before_mode);assert status==409 and stale_session['notApplied'] is True
 status,restored=manage({'kind':'switchModes','modes':['editing']});assert status==200;notice=next_frame();assert notice.get('method')=='notifications/tools/list_changed';notifications.append(notice)
 status,renamed=manage({'kind':'renameMemory','oldName':'owned/\u03c0','newName':'owned/renamed','expectedRevision':second});assert status==200;current=renamed['data']['note']['id'];status,deleted=manage({'kind':'deleteMemory','name':'owned/renamed','expectedRevision':current});assert status==200
 status,listed=manage({'kind':'listMemories'});assert status==200 and listed['data']['items']==[]
 if spec.get('python'):
  cell=tool(32,'serena_repl',{'session_id':runtime_session,'code':'owned_marker += 1\nprint(owned_marker)'});assert cell['stdout']=='42\n';outcome['persistentRuntimeStateKeptAcrossDashboardCalls']=True
 process.stdin.close();process.wait(timeout=8);reader.join(timeout=3);assert process.returncode==0 and not reader.is_alive(),'Owned native stdio did not stop on EOF'
 try:dashboard_request('GET','/api/state')
 except (ConnectionError,OSError,http.client.HTTPException):outcome['dashboardListenerClosedOnStdioEof']=True
 else:raise AssertionError('Owned dashboard survived transport EOF')
 assert sha(source/'main.rs')==source_before and sha(native)==spec['cliSha256'];complete=True
finally:
 if process is not None and process.poll() is None:process.kill();process.wait(timeout=8)
 if process is not None:
  if process.stdin and not process.stdin.closed:process.stdin.close()
  if process.stdout:process.stdout.close()
 if reader is not None:reader.join(timeout=3)
 if stderr is not None:stderr.close()
 capability=None;dashboard=None
 result={'complete':complete,'nativeExitCode':None if process is None else process.returncode,'readerJoined':reader is None or not reader.is_alive(),'managementEvents':events,'notificationCount':len(notifications),'sameOwningSessionModesAndCatalog':complete,'noteCasAndSourceBytesExact':complete,'capabilitiesExcludedFromLogs':True,'modelCalls':0,'analyzedSourceExecuted':False,**outcome};(out/'stdio-live-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
