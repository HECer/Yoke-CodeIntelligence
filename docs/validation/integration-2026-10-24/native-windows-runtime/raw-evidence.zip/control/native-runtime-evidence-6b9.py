"""Package completed local run receipts without including native image bytes."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path.cwd()
BASE = ROOT / 'validation/integration-20261018'
OUT = ROOT / 'docs/validation/integration-2026-10-24/native-windows-runtime'
OUT.mkdir(exist_ok=False)
members = {}
runs = {}
inputs = None
def sha(data):
    return hashlib.sha256(data).hexdigest()
def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf8', newline='\n')

builds = [('process-build', 'native-process-build-6b9-r1', 'build-process-6b9.py'),
          ('agent-repl-build', 'native-agent-repl-build-6b9-r1', 'build-agent-repl-6b9.py'),
          ('inline-body-build', 'native-inline-body-build-6b9-r1', 'build-inline-body-6b9.py'),
          ('library-build', 'native-library-build-6b9-r2', 'build-library-6b9-r2.py')]
tests = [('process', 'native-process-tests-6b9-r1', 'test-process-6b9.py', 7, 0),
         ('agent-repl', 'native-agent-repl-tests-6b9-r1', 'test-agent-repl-6b9.py', 22, 0)]
for label in ['namespace-bindings','namespace-refusals','assignment-bindings','assignment-refusals']:
    tests.append((label, f'native-inline-body-{label}-6b9-r1', f'test-inline-body-{label}-6b9.py', 1, 24))
tests.append(('library', 'native-library-tests-6b9-r2', 'test-library-6b9-r2.py', 703, 0))

for label, folder, control in builds + [row[:3] for row in tests]:
    path = BASE/folder
    receipt = json.loads((path/'result.json').read_text(encoding='utf8'))
    before = json.loads((path/'source-before.json').read_text(encoding='utf8'))
    after = json.loads((path/'source-after.json').read_text(encoding='utf8'))
    assert before == after and receipt['inputCount'] == 1003 and receipt['inputsUnchanged']
    if inputs is None:
        inputs = before
    assert before == inputs
    assert receipt['completed'] and receipt['treeExitedBeforeCleanup']
    assert receipt['activeAfterCleanup'] == 0 and receipt['rootExitedAfterCleanup']
    assert receipt['exitCode'] == 0 and receipt['assignedBeforeResume'] and receipt['startedSuspended']
    run = {'ownerReceipt': receipt}
    if (path/'selected-image.json').exists():
        run['selectedImage'] = json.loads((path/'selected-image.json').read_text(encoding='utf8'))
        assert run['selectedImage']['links'] == 1 and run['selectedImage']['noReparse']
        assert run['selectedImage']['producerCompleted'] and not run['selectedImage']['producerArtifactFresh']
        text = (path/'cargo.stdout').read_text(encoding='utf8')
        matches = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)
        assert len(matches) == 1 and matches[0][0] == 'ok'
        _, passed, failed, ignored, measured, filtered = matches[0]
        expected = next(row for row in tests if row[0] == label)
        assert int(failed) == int(measured) == 0 and int(filtered) == expected[4]
        assert int(ignored) == (7 if label == 'library' else 0)
        if expected[3] is not None:
            assert int(passed) == expected[3]
        else:
            assert int(passed) > 0
        run['actualLibtestSummary'] = {'passed':int(passed),'failed':0,'ignored':int(ignored),'measured':0,'filteredOut':int(filtered),
            'wholeGroup': int(filtered)==0}
        if label == 'library':
            run['unchangedDefaultIgnoredTests'] = [line for line in text.splitlines() if ' ... ignored' in line]
            assert len(run['unchangedDefaultIgnoredTests']) == 7
    else:
        cargo = []
        for line in (path/'cargo.stdout').read_text(encoding='utf8').splitlines():
            try:
                cargo.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        assert [row for row in cargo if row.get('reason')=='build-finished'] == [{'reason':'build-finished','success':True}]
        assert not [row for row in cargo if row.get('reason')=='compiler-message' and row['message']['level'] in ('warning','error')]
        artifacts = [row for row in cargo if row.get('reason')=='compiler-artifact' and Path(row['manifest_path']).resolve()==ROOT/'native/Cargo.toml']
        run['cargoNativeArtifactMetadata'] = [{'target':a['target']['name'],'kind':a['target']['kind'],
            'testProfile':a['profile']['test'],'fresh':a['fresh'],'executable':a['executable'],'files':a['filenames']} for a in artifacts]
        run['unselectedExecutableByproductsAdoptedOrExecuted'] = False
    for filename in ['cargo.stdout','cargo.stderr','source-before.json','source-after.json','job.json','result.json','selected-image.json']:
        if (path/filename).exists():
            members[f'{label}/{filename}'] = (path/filename).read_bytes()
    members[f'control/{control}'] = (BASE/control).read_bytes()
    runs[label] = run

invalidation = json.loads((BASE/'library-invalidation-6b9.json').read_text(encoding='utf8'))
assert invalidation['sourceSha256Before'] == invalidation['sourceSha256After']
assert invalidation['mtimeRestored'] and invalidation['fileIdentityUnchanged'] and invalidation['bytesUnchanged']
members['library-invalidation.json'] = (BASE/'library-invalidation-6b9.json').read_bytes()
members['inline-dependency-observation.json'] = (BASE/'inline-dependency-observation-6b9.json').read_bytes()
members['control/rebuild-library-6b9.py'] = (BASE/'rebuild-library-6b9.py').read_bytes()
members['control/native-runtime-evidence-6b9.py'] = Path(__file__).read_bytes()
write('source-inputs.json', inputs)
write('runs.json', runs)
write('checkpoint.json', {'codeRevision':'6b9a60dda07d546ce09108cf40018a4fe29e3099',
    'platform':'x86_64-pc-windows-msvc','rustVersion':'1.94.1','sourceInputCount':1003,
    'wholeGroupTests': {label: runs[label]['actualLibtestSummary'] for label in ['process','agent-repl','library']},
    'selectedInlineBodyRegressions':4, 'completeInlineBodyGroupClaimed':False,
    'all11OwnedRunsNaturallyEmptyBeforeCleanup':True,
    'originalD80LibraryIncompleteReceiptReclassified':False,
    'hostedFailureCauseEstablished':False,'fullNativeSuiteClaimed':False,
    'stillOpen':['hosted PowerShell/root-cause acceptance','remaining native integration/default target groups',
                 'all current platform/live/history/browser/VSIX','full STATUS/main/release']})
archive = OUT/'raw-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as package:
    for name,data in members.items():
        package.writestr(name,data)
index = {name:{'bytes':len(data),'sha256':sha(data)} for name,data in members.items()}
with zipfile.ZipFile(archive) as package:
    assert set(package.namelist()) == set(index)
    for name,expected in index.items():
        data=package.read(name)
        assert len(data)==expected['bytes'] and sha(data)==expected['sha256']
write('raw-index.json',{'members':index,'zipBytes':archive.stat().st_size,'zipSha256':sha(archive.read_bytes()),
    'everyMemberReopenedAndVerified':True,'nativeImageOrPdbBytesIncluded':False})
print(json.dumps({'wholeGroups':{label:runs[label]['actualLibtestSummary'] for label in ['process','agent-repl','library']},
    'selectedRegressions':4,'ownedRuns':len(runs),'zipBytes':archive.stat().st_size}))
