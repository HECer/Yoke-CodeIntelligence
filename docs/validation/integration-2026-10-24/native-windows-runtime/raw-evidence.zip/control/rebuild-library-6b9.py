"""Request a fresh default library build without changing source bytes/flags."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import stat
import time

root = Path.cwd().resolve()
base = root / 'validation/integration-20261018'
source = root / 'native/src/lib.rs'
receipt_path = base / 'library-invalidation-6b9.json'
assert not receipt_path.exists()
assert shutil.disk_usage(root).free >= 1_200_000_000
before = source.stat(follow_symlinks=False)
assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
assert not before.st_file_attributes & (0x400 | 1)
for parent in source.parents:
    assert not parent.stat(follow_symlinks=False).st_file_attributes & 0x400
digest = hashlib.sha256(source.read_bytes()).hexdigest()
now = time.time_ns()
assert before.st_mtime_ns < now
row = {'path': 'native/src/lib.rs', 'sourceSha256Before': digest,
       'mtimeBeforeNs': before.st_mtime_ns, 'mtimeForCargoNs': now,
       'fileIdentity': [before.st_dev, before.st_ino],
       'reason': 'Force a fresh producer after prior incomplete library owner receipt; no source byte, profile or compiler flag change'}
try:
    os.utime(source, ns=(before.st_atime_ns, now))
    row['mtimeInvalidationObserved'] = source.stat().st_mtime_ns == now
    assert row['mtimeInvalidationObserved']
    runpy.run_path(str(base / 'build-library-6b9-r2.py'), run_name='__main__')
finally:
    current = source.stat(follow_symlinks=False)
    assert (current.st_dev, current.st_ino) == (before.st_dev, before.st_ino)
    assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
    os.utime(source, ns=(before.st_atime_ns, before.st_mtime_ns))
    after = source.stat(follow_symlinks=False)
    row.update(sourceSha256After=hashlib.sha256(source.read_bytes()).hexdigest(),
               mtimeAfterNs=after.st_mtime_ns, mtimeRestored=after.st_mtime_ns == before.st_mtime_ns,
               bytesUnchanged=True, fileIdentityUnchanged=(after.st_dev, after.st_ino) == (before.st_dev, before.st_ino))
    receipt_path.write_text(json.dumps(row, indent=2) + '\n', encoding='utf8')
