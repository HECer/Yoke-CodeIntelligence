"""One-off equivalence/gating check; never executes repository commands."""
import copy
import hashlib
import itertools
import json
from pathlib import Path
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'validation/integration-20261018'
sys.path.insert(0, str(BASE / 'workflow-yaml-tools'))
import yaml

OUT = ROOT / 'docs/validation/integration-2026-10-24/platform-ci-dependencies'
OUT.mkdir(exist_ok=True)
PRIVATE = BASE / 'platform-ci-dependencies'
PRIVATE.mkdir(exist_ok=True)
REVISION = 'd80c6c784f462d5ad60c0f553986b2b4895108d4'
old_bytes = subprocess.run(['git', 'show', REVISION + ':.github/workflows/rust.yml'],
    cwd=ROOT, check=True, capture_output=True).stdout
new_bytes = (ROOT / '.github/workflows/rust.yml').read_bytes()
old = yaml.safe_load(old_bytes)
new = yaml.safe_load(new_bytes)
PLATFORMS = {'linux': 'ubuntu-latest', 'windows': 'windows-latest', 'macos': 'macos-latest'}

def check(document):
    assert {k: v for k, v in document.items() if k != 'jobs'} == {
        k: v for k, v in old.items() if k != 'jobs'}
    jobs = document['jobs']
    assert set(jobs) == {f'{kind}-{platform}' for kind in ('native-shards', 'native-rust') for platform in PLATFORMS}
    labels = set()
    for platform, os in PLATFORMS.items():
        for kind in ('native-shards', 'native-rust'):
            job = jobs[f'{kind}-{platform}']
            baseline = old['jobs'][kind]
            matrix = job['strategy']['matrix']
            assert matrix == ({'os': [os], 'shard': list(range(8))} if kind == 'native-shards' else {'os': [os]})
            assert {k: v for k, v in job['strategy'].items() if k != 'matrix'} == {
                k: v for k, v in baseline['strategy'].items() if k != 'matrix'}
            expected_name = 'native-shards (${{ matrix.os }}, ${{ matrix.shard }})' if kind == 'native-shards' else 'native-rust (${{ matrix.os }})'
            assert job['name'] == expected_name
            assert {k: v for k, v in job.items() if k not in ('name', 'needs', 'strategy')} == {
                k: v for k, v in baseline.items() if k not in ('needs', 'strategy')}
            if kind == 'native-rust':
                assert job.get('needs') == f'native-shards-{platform}'
            else:
                assert 'needs' not in job
            for shard in range(8) if kind == 'native-shards' else [None]:
                label = job['name'].replace('${{ matrix.os }}', os).replace('${{ matrix.shard }}', str(shard))
                assert label not in labels
                labels.add(label)
    expected_labels = {f'native-shards ({os}, {shard})' for os in PLATFORMS.values() for shard in range(8)} | {
        f'native-rust ({os})' for os in PLATFORMS.values()}
    assert labels == expected_labels
    return sorted(labels)

labels = check(new)
mutations = []
def refuse(name, change):
    document = copy.deepcopy(new)
    # Dealias in-memory step lists so a negative edit tests one platform only.
    for job in document['jobs'].values():
        job['steps'] = copy.deepcopy(job['steps'])
    change(document)
    try:
        check(document)
    except AssertionError:
        mutations.append({'name': name, 'refused': True})
    else:
        raise AssertionError('Invalid workflow accepted: ' + name)

refuse('missing platform', lambda d: d['jobs'].pop('native-rust-macos'))
refuse('missing shard', lambda d: d['jobs']['native-shards-windows']['strategy']['matrix']['shard'].pop())
refuse('duplicate shard', lambda d: d['jobs']['native-shards-windows']['strategy']['matrix']['shard'].append(0))
refuse('wrong runner', lambda d: d['jobs']['native-rust-windows'].update({'runs-on': 'ubuntu-latest'}))
refuse('cross-platform dependency', lambda d: d['jobs']['native-rust-windows'].update({'needs': 'native-shards-linux'}))
refuse('all-platform barrier restored', lambda d: d['jobs']['native-rust-windows'].update({'needs': list(d['jobs'])[:3]}))
refuse('missing own dependency', lambda d: d['jobs']['native-rust-windows'].pop('needs'))
refuse('changed final check name', lambda d: d['jobs']['native-rust-windows'].update({'name': 'windows-only'}))
refuse('fail-fast enabled', lambda d: d['jobs']['native-shards-windows']['strategy'].update({'fail-fast': True}))
refuse('timeout changed', lambda d: d['jobs']['native-rust-windows'].update({'timeout-minutes': 46}))
refuse('failure evidence skipped', lambda d: d['jobs']['native-rust-windows'].update({'if': 'success()'}))
refuse('wider permissions', lambda d: d.update({'permissions': {'contents': 'write'}}))
for text in ['native_shards.py check', 'actual_rust_analyzer', 'cargo build --workspace --release', 'host_history_live.py']:
    refuse('removed ' + text, lambda d, text=text: d['jobs']['native-rust-windows']['steps'].__delitem__(next(
        i for i, step in enumerate(d['jobs']['native-rust-windows']['steps']) if text in step.get('run', ''))))
refuse('changed native test command', lambda d: next(step for step in d['jobs']['native-shards-windows']['steps']
    if step.get('id') == 'native_tests').update({'run': 'echo skipped'}))
refuse('dropped release upload', lambda d: d['jobs']['native-rust-windows']['steps'].__delitem__(next(
    i for i, step in enumerate(d['jobs']['native-rust-windows']['steps']) if step.get('with', {}).get('name') == 'yoke-${{ matrix.os }}')))

# Only a dependency-readiness model, not hosted execution or GitHub scheduling.
modeled = 0
for platform in PLATFORMS:
    parent = new['jobs'][f'native-rust-{platform}']['needs']
    assert parent == f'native-shards-{platform}'
    for own_mask, other_terminal, cancelled in itertools.product(range(256), itertools.product((False, True), repeat=2), (False, True)):
        own_terminal = all(own_mask & (1 << shard) for shard in range(8))
        states = {parent: own_terminal}
        states.update(zip((f'native-shards-{p}' for p in PLATFORMS if p != platform), other_terminal))
        ready = states[parent] and not cancelled
        assert ready == (own_mask == 255 and not cancelled)
        if ready:
            assert states[parent]
        modeled += 1

# Pinned official tool, no shellcheck/pyflakes or repository command execution.
release = json.loads(subprocess.run(['gh', 'api', 'repos/rhysd/actionlint/releases/tags/v1.7.12'],
    check=True, capture_output=True, timeout=30).stdout)
asset = next(a for a in release['assets'] if a['name'] == 'actionlint_1.7.12_windows_amd64.zip')
archive = PRIVATE / asset['name']
if not archive.exists():
    with urllib.request.urlopen(asset['browser_download_url'], timeout=30) as response:
        data = response.read(4_000_001)
    assert len(data) == asset['size'] and len(data) <= 4_000_000
    assert 'sha256:' + hashlib.sha256(data).hexdigest() == asset['digest']
    with archive.open('xb') as output:
        output.write(data)
data = archive.read_bytes()
assert len(data) == asset['size'] and 'sha256:' + hashlib.sha256(data).hexdigest() == asset['digest']
exe = PRIVATE / 'actionlint.exe'
with zipfile.ZipFile(archive) as package:
    executable = package.read('actionlint.exe')
if not exe.exists():
    with exe.open('xb') as output:
        output.write(executable)
assert exe.read_bytes() == executable
command = [str(exe), '-shellcheck=', '-pyflakes=', '.github/workflows/rust.yml']
lint = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=30)
(OUT / 'actionlint.stdout').write_bytes(lint.stdout)
(OUT / 'actionlint.stderr').write_bytes(lint.stderr)
assert lint.returncode == 0, lint.stdout.decode() + lint.stderr.decode()
for filename, data in [('before.yml', old_bytes), ('after.yml', new_bytes), ('check.py', Path(__file__).read_bytes())]:
    (OUT / filename).write_bytes(data)
proof = {'baselineRevision': REVISION, 'yamlParser': {'name': 'PyYAML', 'version': yaml.__version__},
    'oldWorkflowSha256': hashlib.sha256(old_bytes).hexdigest(), 'newWorkflowSha256': hashlib.sha256(new_bytes).hexdigest(),
    'oldWorkflowSource': 'exact Git blob; before.yml', 'newWorkflowSource': 'working-copy bytes; after.yml',
    'shards': 24, 'platformAcceptanceJobs': 3, 'unchangedExpandedCheckNames': labels,
    'allOriginalParsedStepsAndOtherJobPoliciesExact': True, 'negativeCases': mutations,
    'dependencyReadinessModelCases': modeled, 'modelIsHostedExecution': False,
    'nativeYokeImagesReadOrExecuted': False, 'hostedNativeAcceptance': False,
    'actionlint': {'version': release['tag_name'], 'asset': asset['name'], 'size': asset['size'],
        'officialAssetDigest': asset['digest'], 'localAssetSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
        'executableSha256': hashlib.sha256(executable).hexdigest(), 'exitCode': lint.returncode,
        'shellcheckAndPyflakesDisabled': True}}
(OUT / 'checks.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps({'expandedJobs': len(labels), 'negativeCases': len(mutations), 'readinessModelCases': modeled,
    'actionlint': lint.returncode, 'nativeExecution': False}))
