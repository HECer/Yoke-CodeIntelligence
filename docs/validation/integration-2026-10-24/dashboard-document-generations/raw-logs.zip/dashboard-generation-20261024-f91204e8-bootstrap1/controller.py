from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-generation-20261024-f91204e8-bootstrap1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-dashboard-generation-bootstrap1-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')







q=w/'validation/integration-20261018/dashboard-generation-20261024-f91204e8-qualified1';old=json.loads((q/'result.json').read_bytes());assert not old['complete'] and old['allJobsEmpty'];assert b'678 passed; 0 failed; 7 ignored' in (q/'whole-library.stdout').read_bytes();inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');artifacts=[]
for line in (q/'build-session_dashboard_management.stdout').read_bytes().splitlines():
 try:v=json.loads(line)
 except ValueError:continue
 if v.get('reason')=='compiler-artifact' and Path(v['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and v['target']['kind']==['lib'] and not v['profile']['test']:artifacts.append(v)
assert len(artifacts)==1;complete=False;metadata=[]
try:
 for path in [Path(n) for n in artifacts[0]['filenames'] if n.endswith('.rmeta')]:
  assert path.parent.resolve()==(w/'target/debug/deps').resolve() and path.name.startswith('libyoke-') and path.stat().st_nlink==1;size=path.stat().st_size;digest=sha(path);assert shutil.disk_usage(w).free>500_000_000+size+64_000_000
  if path.stat().st_file_attributes&0x800:run('decompress-checked-current-metadata',[os.environ['SystemRoot']+'\\System32\\compact.exe','/U','/F','/I','/Q',path],timeout=90);assert sha(path)==digest
  run('lzx-checked-current-metadata',[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',path],timeout=90);assert sha(path)==digest and path.stat().st_size==size;metadata.append({'path':str(path),'sha256':digest,'bytes':size,'positiveProof':'completed own-package compiler artifact on exact678-pass whole-library source; metadata only, no failed executable or PDB touched'})
 assert shutil.disk_usage(w).free>580_000_000
 build=run('current-cli-only-build',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','build','--manifest-path','native/Cargo.toml','--bin','yoke','--locked','--offline','-j','1','--message-format=json'],timeout=600);exe_artifacts=[]
 for line in build.splitlines():
  try:v=json.loads(line)
  except ValueError:continue
  if v.get('reason')=='compiler-artifact' and Path(v['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and v['target']['kind']==['bin'] and not v['profile']['test']:exe_artifacts.append(v)
 assert len(exe_artifacts)==1;artifact=exe_artifacts[0];cli=Path(artifact['executable']);assert cli.resolve()==(w/'target/debug/yoke.exe').resolve();expected=sha(cli);assert expected!='03ef5e39ce72e21269bd447d9bf814ca2479f486221fe9bfc40674f267df7bcf';assert b'0.5.0' in run('built-cli-version',[cli,'--version'],timeout=30);assert b'host-documents' in run('built-cli-help',[cli,'--help'],timeout=30);(out/'built-cli.json').write_text(json.dumps({'sha256':expected,'buildPassed':True,'versionAndHelpPassed':True,'artifact':artifact,'bootstrapOnlyFullIntegrationPending':True},indent=2)+'\n');complete=True
finally:
 result={'complete':complete,'bootstrapOnlyFullIntegrationPending':True,'metadata':metadata,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'freeBytes':shutil.disk_usage(w).free,'hardStopBytes':500_000_000};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
