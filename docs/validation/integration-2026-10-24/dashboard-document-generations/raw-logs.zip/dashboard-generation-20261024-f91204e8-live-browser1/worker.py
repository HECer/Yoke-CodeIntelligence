import hashlib,http.client,json,os,queue,subprocess,sys,threading,time,urllib.parse
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_bytes());out=Path(spec['out']);native=Path(spec['native']);source=Path(spec['root']);profile=Path(spec['hostProfilePath']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(native)==spec['cliSha256'];source_before=sha(source/'main.rs');events=[];notifications=[];pending=queue.Queue();process=None;reader=None;complete=False;stderr=None;dashboard=None;capability=None;outcome={};runtime_handle=None;runtime_api=None

def reader_main():
 try:
  while True:
   line=process.stdout.readline(16_000_001)
   if not line:break
   assert len(line)<=16_000_000
   pending.put(json.loads(line))
 except BaseException:pending.put({'ownedReaderError':True})
 finally:pending.put({'ownedReaderEof':True})
def next_frame(timeout=8):
 item=pending.get(timeout=timeout);assert not item.get('ownedReaderError') and not item.get('ownedReaderEof'),'Owned native stdio ended unexpectedly';return item
def rpc(identifier,method,params=None):
 message={'jsonrpc':'2.0','id':identifier,'method':method,'params':params or {}};process.stdin.write(json.dumps(message,ensure_ascii=False).encode()+b'\n');process.stdin.flush();until=time.monotonic()+10
 while time.monotonic()<until:
  item=next_frame(min(8,max(.01,until-time.monotonic())))
  if item.get('method')=='notifications/tools/list_changed':notifications.append(item);continue
  assert item.get('id')==identifier and 'error' not in item,'Unexpected native protocol response';return item
 raise TimeoutError('Owned native protocol response deadline')
def tool(identifier,name,args=None):
 if spec.get('protocolProfile')=='native' and name in ('open_dashboard','get_current_config'):
  args={'operation':{'open_dashboard':'openDashboard','get_current_config':'configuration'}[name],'args':args or {}};name='ci_session'
 reply=rpc(identifier,'tools/call',{'name':name,'arguments':args or {}});assert reply['result']['isError'] is False,'Owned native tool refused';value=reply['result'].get('structuredContent')
 if value is None:value=json.loads(reply['result']['content'][0]['text'])
 assert value['status']=='ok','Owned native tool response is not complete';return value['data']
def dashboard_request(method,path,body=None):
 connection=http.client.HTTPConnection(dashboard.hostname,dashboard.port,timeout=6);headers={'Authorization':'Bearer '+capability,'Origin':f'http://{dashboard.hostname}:{dashboard.port}'}
 if body is not None:headers['Content-Type']='application/json'
 connection.request(method,path,body=None if body is None else json.dumps(body,ensure_ascii=False).encode(),headers=headers);response=connection.getresponse();status=response.status;raw=response.read(4_000_001);connection.close();assert len(raw)<=4_000_000
 try:value=json.loads(raw)
 except json.JSONDecodeError:
  assert status>=400,'Successful native response must be JSON';value={'httpErrorBodyWasPlainText':True}
 return status,value
def state():
 status,value=dashboard_request('GET','/api/state');assert status==200;return value
def manage(action,selected=None):
 selected=selected or state();body={'id':os.urandom(32).hex(),'sessionStateSha256':selected['view']['management']['sessionStateSha256'],'project':selected['view']['activeProject'],'action':action};status,value=dashboard_request('POST','/api/manage',body);events.append({'kind':action['kind'],'status':status,'notApplied':value.get('notApplied')});return status,value


def selected_document(action):return manage({'kind':'document','request':action})
def require_ok(reply):
 status,value=reply;assert status==200,(status,value.get('outcome'));return value['data']
def review(content):
 loaded=require_ok(selected_document({'kind':'read','documentId':'settings'}))['document']
 return require_ok(selected_document({'kind':'plan','documentId':'settings','expectedRevision':loaded['revision'],'content':content}))['plan']
def journals():
 rows={}
 for label,root in [('old',Path(spec['oldJournal'])),('new',Path(spec['newJournal']))]:
  for path in sorted(root.iterdir()):
   assert path.is_file() and not path.is_symlink() and not path.is_junction();rows[label+'/'+path.name]=sha(path)
 return rows
def migration(label,reverse=False):
 a,b=(spec['toSelection'],spec['fromSelection']) if reverse else (spec['fromSelection'],spec['toSelection'])
 old_id,new_id=('settings-next','settings') if reverse else ('settings','settings-next')
 prefix=[str(native),'--timeout','30000','--max-bytes','1000000','host-documents','--from-selection',a,'--to-selection',b]
 def call(suffix,args):
  reply=subprocess.run(prefix+args,cwd=source,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40,creationflags=0x08000000);assert len(reply.stdout)<=2_000_000 and len(reply.stderr)<=2_000_000
  (out/(label+'-'+suffix+'.stdout')).write_bytes(reply.stdout);(out/(label+'-'+suffix+'.stderr')).write_bytes(reply.stderr);assert reply.returncode==0,(label,suffix,reply.returncode);return json.loads(reply.stdout),reply.stdout
 plan,raw=call('plan',['binding-plan','--from-document',old_id,'--to-document',new_id]);path=out/(label+'-plan.json');path.write_bytes(raw);receipt,_=call('apply',['binding-apply','--plan',str(path),'--allow-host-writes']);assert receipt['outcome']=='committed' and receipt['fileChanged'] is False and receipt['sourceWritten'] is False
 return plan
try:
 argv=[str(native),'--root',str(source),'--timeout','30000','--max-bytes','4000000','serve-session','--profile',spec.get('protocolProfile','native'),'--id','generation-owned','--host-profile',str(profile)]
 if spec.get('python'):argv.extend(['--python',spec['python'],'--trust-python'])
 stderr=(out/'native-stdio.stderr').open('wb');process=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,creationflags=0x08000000);reader=threading.Thread(target=reader_main);reader.start();initialized=rpc(1,'initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'owned-generation-acceptance','version':'0.5.0'}});assert initialized['result']['serverInfo']['version']=='0.5.0'
 opened=tool(2,'open_dashboard');dashboard=urllib.parse.urlparse(opened['url']);capability=dashboard.fragment;assert dashboard.hostname=='127.0.0.1' and len(capability)==64 and opened['browserOpened'] is False;initial_state=state()['view']['management']['sessionStateSha256'];global_config=Path(spec['globalConfig']);original=global_config.read_bytes();seed=original+b'# create the first global write binding\r\n';plan=review(seed.decode());require_ok(selected_document({'kind':'apply','documentId':'settings','planId':plan['id']}));assert global_config.read_bytes()==seed

 deadline=time.monotonic()+300
 def wait_flag(name):
  path=out/name
  while time.monotonic()<deadline:
   if path.exists():return path
   assert process.poll() is None,'Owned Session ended before browser acceptance';time.sleep(.05)
  raise TimeoutError('Owned browser acceptance deadline')
 (out/'private-dashboard.json').write_text(json.dumps({'url':dashboard.geturl(),'cliSha256':spec['cliSha256'],'product':'Code Intelligence','version':'0.5.0'}))
 reviewed=json.loads(wait_flag('.ui-reviewed').read_bytes());plan_id=reviewed['planId'];assert len(plan_id)==64 and all(c in '0123456789abcdef' for c in plan_id);before=global_config.read_bytes();outbound=migration('ui-out');returned=migration('ui-back',True);assert global_config.read_bytes()==before and outbound['fromAccess']==returned['toAccess'];owner=global_config.parent/('.yoke-doc-owner-'+returned['target']+'.json');owner_hash=sha(owner);before_journals=journals();(out/'ui-migrated.json').write_text(json.dumps({'complete':True,'configurationSha256':sha(global_config),'oldPlanId':plan_id,'ownerGeneration':returned['nonce'],'configurationBytesUnchanged':True},indent=2)+'\n')
 wait_flag('.ui-save-refused');assert global_config.read_bytes()==before and sha(owner)==owner_hash and journals()==before_journals;(out/'ui-refusal-proved.json').write_text(json.dumps({'complete':True,'configurationBytesUnchanged':True,'ownerBytesUnchanged':True,'journalBytesUnchanged':True,'oldPlanId':plan_id},indent=2)+'\n')
 saved=json.loads(wait_flag('.ui-fresh-saved').read_bytes());assert len(saved['planId'])==64 and len(saved['afterHash'])==64 and sha(global_config)==saved['afterHash'];root=Path(spec['oldJournal']);header=json.loads((root/('yoke-doc-'+returned['toAccess']+'-'+saved['planId']+'.plan.json')).read_bytes());assert header['plan']['ownerGeneration']==returned['nonce'] and header['plan']['afterHash']==saved['afterHash'];assert sha(owner)==owner_hash;(out/'ui-fresh-proved.json').write_text(json.dumps({'complete':True,'freshPlanId':saved['planId'],'configurationSha256':sha(global_config),'currentOwnerGenerationBound':True,'ownerBytesUnchanged':True},indent=2)+'\n')
 while time.monotonic()<deadline and process.poll() is None:time.sleep(.05)
 assert process.poll()==0 and (out/'.ui-complete').exists() and not process.stdin.closed;reader.join(timeout=3);assert not reader.is_alive();assert sha(source/'main.rs')==source_before and sha(native)==spec['cliSha256'];(out/'native-process-exited.json').write_text(json.dumps({'nativeExitCode':0,'stdinWasStillOpen':True,'beforeJobCleanup':True})+'\n');outcome={'actualBrowserOldDraftRefusedAfterRoundTrip':True,'actualFreshBrowserSaveBindsCurrentOwnerGeneration':True,'sameOwningSession':True,'configurationAndJournalsExactOnRefusal':True,'ownShutdownBeforeStdinEof':True,'sourceFileUnchanged':True};process.stdin.close();complete=True

finally:
 if process is not None and process.poll() is None:process.kill();process.wait(timeout=8)
 if process is not None:
  if process.stdin and not process.stdin.closed:process.stdin.close()
  if process.stdout:process.stdout.close()
 if reader:reader.join(timeout=3)
 if stderr:stderr.close()
 if runtime_handle:assert runtime_api.CloseHandle(runtime_handle)
 capability=None;dashboard=None;result={'complete':complete,'readerJoined':reader is None or not reader.is_alive(),'events':events,'cliSha256':spec['cliSha256'],'modelCalls':0,'analyzedSourceExecuted':False,**outcome};(out/'live-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'complete':complete,'expectedRefusal':spec['expectRefusal']}),flush=True)
