from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-generation-20261024-f91204e8-live-browser1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-dashboard-generation-live-browser1-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')







expect_refusal=True

q=w/('validation/integration-20261018/dashboard-generation-20261024-f91204e8-'+('bootstrap1' if expect_refusal else 'gates1'));proof=json.loads((q/'result.json').read_bytes());assert proof['complete'] and proof['allJobsEmpty'];inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
if expect_refusal:
 built=json.loads((q/'built-cli.json').read_bytes());native=w/'target/debug/yoke.exe';expected=built['sha256']
else:
 old=json.loads((w/'validation/integration-20261018/dashboard-generation-20261024-f91204e8-baseline1/result.json').read_bytes());assert old['complete'];native=Path(old['path']);expected=old['sha256']
assert sha(native)==expected;worker=Path(r'C:\Users\Lomi\AppData\Local\Temp\dashboard-generation-live-browser-worker-20261024.py');shutil.copyfile(worker,out/'worker.py');complete=False;accepted=[]
try:
 for variant in (['native-session'] if expect_refusal else ['native-session']):
  selected=out/variant;selected.mkdir();source=jobroot/('source-'+variant);source.mkdir();(source/'main.rs').write_bytes('// owned inert \u03c0 \U0001f980 e\u0301\r\nfn unchanged() {}\r\n'.encode());global_config=jobroot/('settings-\u03c0-'+variant+'.yaml');global_config.write_bytes('\ufeff# owned configuration \u03c0\r\nvalue: preserved\r\n'.encode());old_journal=jobroot/('old-'+variant);new_journal=jobroot/('new-'+variant);old_journal.mkdir();new_journal.mkdir()
  documents={'documents':[{'id':'settings','label':'Owned settings','path':str(global_config),'scope':{'kind':'global'},'writable':True}],'journalRoot':str(old_journal),'maxDocumentBytes':64000};changed=json.loads(json.dumps(documents));changed['journalRoot']=str(new_journal);changed['documents'][0]['id']='settings-next';changed['documents'][0]['label']='Owned migrated settings';roots=[{'name':'default','root':str(source)}];from_selection=jobroot/(variant+'-from.json');to_selection=jobroot/(variant+'-to.json');from_selection.write_text(json.dumps({'documents':documents,'projects':roots}));to_selection.write_text(json.dumps({'documents':changed,'projects':roots}));profile=jobroot/(variant+'-host.json');profile.write_text(json.dumps({'context':'desktop-app','modes':['editing'],'steering':{},'dashboard':{'management':{'sessionControls':False,'memories':False,'documents':documents,'shutdown':True,'operationTimeoutMs':3000},'lifetimeMs':600000}}));spec={'out':str(selected),'native':str(native),'cliSha256':expected,'root':str(source),'hostProfilePath':str(profile),'protocolProfile':'native' if variant=='native-session' else 'serena','globalConfig':str(global_config),'oldJournal':str(old_journal),'newJournal':str(new_journal),'fromSelection':str(from_selection),'toSelection':str(to_selection),'expectRefusal':expect_refusal}
  if variant=='persistent-python':spec['python']=r'C:\Python314\python.exe'
  path=jobroot/(variant+'-spec.json');path.write_text(json.dumps(spec));run('actual-'+variant,[r'C:\Python314\python.exe','-I',worker,path],timeout=340);result=json.loads((selected/'live-result.json').read_bytes());assert result['complete'] and result['readerJoined'];accepted.append({'variant':variant,'result':result})
 complete=True
finally:
 result={'complete':complete,'expectedRefusal':expect_refusal,'variants':accepted,'cliSha256':expected,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'existingCredentialsAccessed':False,'modelCalls':0,'analyzedSourceExecuted':False,'systemSettingsChanged':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'complete':complete,'variants':len(accepted),'expectedRefusal':expect_refusal,'allJobsEmpty':result['allJobsEmpty']}),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
