from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-generation-20261024-f91204e8-resources2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-dashboard-generation-resources2-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')







stageproof=json.loads((w/'validation/integration-20261018/ci-vsix-20261024-f91204e8-stage1/result.json').read_bytes());assert stageproof['complete'];stage=Path(stageproof['sourceRoot']);assert stage.parent==Path(tempfile.gettempdir()) and stage.name.startswith('yoke-current-vsix-source-') and not stage.is_symlink() and not stage.is_junction();selected=[]
for row in stageproof['files']:
 path=stage/row['path'];assert path.resolve().is_relative_to(stage.resolve()) and not path.is_symlink() and not path.is_junction() and path.stat().st_nlink==1;assert sha(path)==row['sha256'];selected.append({'path':str(path),'sha256':row['sha256'],'bytes':row['bytes'],'positiveIndex':'ci-vsix-20261024-f91204e8-stage1/result.json'})
for phase in ['dashboard-history-20261024-f91204e8-focused1','dashboard-generation-20261024-f91204e8-red1','dashboard-generation-20261024-f91204e8-green1','dashboard-keyboard-20261024-cce9714b-checks1','dashboard-keyboard-20261024-cce9714b-checks2']:
 root=w/'validation/integration-20261018'/phase;result=json.loads((root/'result.json').read_bytes());assert result['complete'] and result['allJobsEmpty']
 for path in sorted(root.iterdir()):
  if not path.is_file() or path.suffix not in ['.json','.py','.stdout','.stderr']:continue
  assert not path.is_symlink() and not path.is_junction() and path.stat().st_nlink==1;selected.append({'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'positiveIndex':phase+'/result.json'})
assert len(selected)<=3000 and len({r['path'] for r in selected})==len(selected);(out/'selected-before.json').write_text(json.dumps(selected,indent=2)+'\n');complete=False;compact=os.environ['SystemRoot']+'\\System32\\compact.exe';before_free=shutil.disk_usage(w).free
try:
 for offset in range(0,len(selected),48):
  batch=selected[offset:offset+48];assert shutil.disk_usage(w).free>500_000_000+max(r['bytes'] for r in batch)+64_000_000;paths=[Path(r['path']) for r in batch]
  for path,row in zip(paths,batch):assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes']
  compressed=[p for p in paths if p.stat().st_file_attributes&0x800]
  if compressed:run('decompress-owned-indexed-source-'+str(offset),[compact,'/U','/F','/I','/Q',*compressed],timeout=90)
  run('lzx-owned-indexed-source-'+str(offset),[compact,'/C','/F','/EXE:LZX','/I','/Q',*paths],timeout=90)
  for path,row in zip(paths,batch):assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes']
 complete=True
finally:
 result={'complete':complete,'indexedFiles':len(selected),'beforeFreeBytes':before_free,'freeBytes':shutil.disk_usage(w).free,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'allSelectedBytesExact':all(sha(Path(r['path']))==r['sha256'] for r in selected),'protectedOrUnrelatedArtifactsAccessed':False,'hardStopBytes':500_000_000};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
