"""Pinned, byte-preserving NTFS compression of closed own text evidence only."""
import ctypes as c
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import shutil
import stat
import time

ROOT=Path.cwd().resolve()
OUT=ROOT/'validation/integration-20261018/text-compression-d80-r2'
TARGET_FREE=1_300_000_000
def selected_name(name):
    return (name.endswith('.json') and any(part in name for part in ('source','freeze','inputs'))) or name.endswith(('.log','.stdout','.stderr'))
api=c.WinDLL('kernel32',use_last_error=True)
for name,args,result in [
 ('CreateFileW',[c.c_wchar_p,c.c_uint32,c.c_uint32,c.c_void_p,c.c_uint32,c.c_uint32,c.c_void_p],c.c_void_p),
 ('GetFileInformationByHandleEx',[c.c_void_p,c.c_int,c.c_void_p,c.c_uint32],c.c_int),
 ('DeviceIoControl',[c.c_void_p,c.c_uint32,c.c_void_p,c.c_uint32,c.c_void_p,c.c_uint32,c.c_void_p,c.c_void_p],c.c_int),
 ('CloseHandle',[c.c_void_p],c.c_int),
]:
    fn=getattr(api,name);fn.argtypes=args;fn.restype=result

class Compression(c.Structure):
    _fields_=[('bytes',c.c_int64),('format',c.c_uint16),('unit',c.c_ubyte),
              ('chunk',c.c_ubyte),('cluster',c.c_ubyte),('reserved',c.c_ubyte*3)]

class Attributes(c.Structure):
    _fields_=[('attributes',c.c_uint32),('reparse',c.c_uint32)]

def query(handle,kind,cls):
    value=cls()
    if not api.GetFileInformationByHandleEx(handle,kind,c.byref(value),c.sizeof(value)):
        raise OSError(c.get_last_error(),'Owned file metadata query failed')
    return value

def digest(stream):
    stream.seek(0); value=hashlib.sha256()
    while data:=stream.read(1024*1024):value.update(data)
    return value.hexdigest()

def admissible(path):
    assert path.is_absolute() and path.is_relative_to(ROOT)
    for item in [path,*path.parents]:
        if item==ROOT:break
        if item.stat(follow_symlinks=False).st_file_attributes&0x400:
            raise RuntimeError('Linked evidence path refused')
    info=path.stat(follow_symlinks=False)
    assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
    assert not info.st_file_attributes&(0x400|0x800|1)
    assert info.st_mtime<time.time()-3600 and info.st_size>=128000
    relative=path.relative_to(ROOT)
    special=relative in [Path('docs/validation/parity-windows-2026-10-15-wave2/wave2-integration-first.log'),
                         Path('docs/validation/parity-windows-2026-10-15-wave2/wave2-retention-accounting-red.log')]
    assert special or (selected_name(path.name) and (path.is_relative_to(ROOT/'validation/integration-20261018') or path.is_relative_to(ROOT/'docs/validation')))
    return info

def candidates():
    values=[]
    selected=[]
    for base in [ROOT/'validation/integration-20261018',ROOT/'docs/validation']:
        for directory,dirs,files in os.walk(base,followlinks=False):
            dirs[:]=[n for n in dirs if n not in ('target','node_modules','.git') and not(Path(directory,n).stat(follow_symlinks=False).st_file_attributes&0x400)]
            for name in files:
                if not selected_name(name):continue
                path=Path(directory,name)
                try:info=admissible(path)
                except (AssertionError,RuntimeError):continue
                selected.append((info.st_size,path))
    values += [path for _,path in sorted(selected,key=lambda x:x[0],reverse=True)[:600]]
    return values

def compress(path,index):
    before=admissible(path)
    # Share-read only: no other writer/delete can change the held file while
    # both hashes and the synchronous FSCTL refer to this exact own handle.
    raw=api.CreateFileW(str(path),0xc0000000,1,None,3,0x00200000|0x08000000,None)
    if raw in (None,c.c_void_p(-1).value):raise OSError(c.get_last_error(),'Own evidence open failed')
    try:
        fd=msvcrt.open_osfhandle(raw,os.O_RDWR|os.O_BINARY)
    except BaseException:
        api.CloseHandle(raw);raise
    with os.fdopen(fd,'r+b',buffering=0) as stream:
        held=os.fstat(stream.fileno())
        assert (held.st_dev,held.st_ino,held.st_size,held.st_nlink)==(before.st_dev,before.st_ino,before.st_size,1)
        attrs=query(raw,9,Attributes)
        assert not attrs.attributes&(0x400|0x800|1) and attrs.reparse==0
        allocation=query(raw,8,Compression)
        original=digest(stream)
        row={'path':str(path.relative_to(ROOT)),'bytes':held.st_size,'sha256Before':original,
             'allocatedBefore':allocation.bytes,'formatBefore':allocation.format,
             'identity':[held.st_dev,held.st_ino],'links':held.st_nlink,'state':'prepared'}
        journal=OUT/f'{index:04}.json'
        journal.write_text(json.dumps(row,indent=2)+'\n',encoding='utf8')
        requested=c.c_uint16(1)  # DEFAULT = ordinary NTFS LZNT1; no WOF backing.
        returned=c.c_uint32()
        result=api.DeviceIoControl(raw,0x0009c040,c.byref(requested),2,None,0,c.byref(returned),None)
        error=c.get_last_error() if not result else None
        after=os.fstat(stream.fileno())
        final=digest(stream)
        compressed=query(raw,8,Compression)
        attributes=query(raw,9,Attributes)
        assert (after.st_dev,after.st_ino,after.st_size,after.st_nlink)==(held.st_dev,held.st_ino,held.st_size,1)
        assert final==original and not attributes.attributes&0x400 and attributes.reparse==0
        row.update(state='verified',sha256After=final,bytesExact=True,fsctlSucceeded=bool(result),
                   fsctlError=error,allocatedAfter=compressed.bytes,formatAfter=compressed.format,
                   noReparsePoint=True,mtimeBeforeNs=before.st_mtime_ns,mtimeAfterNs=after.st_mtime_ns)
        journal.write_text(json.dumps(row,indent=2)+'\n',encoding='utf8')
        if not result:raise RuntimeError('Compression API refusal; byte proof retained')
        assert compressed.format!=0
    return row

assert c.sizeof(Compression)==16 and c.sizeof(Attributes)==8
selected=candidates()
OUT.mkdir(exist_ok=False)
free_before=shutil.disk_usage(ROOT).free
(OUT/'selection.json').write_text(json.dumps({'targetFree':TARGET_FREE,'freeBefore':free_before,
    'paths':[str(p.relative_to(ROOT)) for p in selected]},indent=2)+'\n',encoding='utf8')
results=[]
for index,path in enumerate(selected):
    if shutil.disk_usage(ROOT).free>=TARGET_FREE:break
    row=compress(path,index)
    results.append(row)
    if index<2 or (index+1)%50==0:
        print(json.dumps({'filesVerified':len(results),'fileAllocatedBytesSaved':sum(r['allocatedBefore']-r['allocatedAfter'] for r in results),'freeNow':shutil.disk_usage(ROOT).free}),flush=True)
report={'schema':1,'sourceRevision':'d80c6c784f462d5ad60c0f553986b2b4895108d4',
        'filesVerified':len(results),'allBytesExact':all(r['bytesExact'] for r in results),
        'fileAllocatedBytesSaved':sum(r['allocatedBefore']-r['allocatedAfter'] for r in results),
        'freeBefore':free_before,'freeAfter':shutil.disk_usage(ROOT).free,
        'targetFree':TARGET_FREE,'nativeImagesReadOrModified':False,'filesDeleted':0,
        'directoriesCompressed':0,'allSingleLinkNoReparse':True,
        'sizeMetric':'FILE_COMPRESSION_INFO.CompressedFileSize reductions, not an independent extent-allocation measurement',
        'results':results}
(OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='results'}),flush=True)
