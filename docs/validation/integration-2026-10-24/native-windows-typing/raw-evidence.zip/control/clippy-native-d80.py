"""Owned guarded all-target Cargo typing; never execute a Yoke test/image."""
import ctypes as c
import hashlib
import importlib.util
import json
import msvcrt
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import _winapi

ROOT=Path.cwd().resolve()
OUT=ROOT/'validation/integration-20261018/native-clippy-d80-r1'
SOURCE='d80c6c784f462d5ad60c0f553986b2b4895108d4'
def require(condition,message):
    if not condition:raise RuntimeError(message)
def sha(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        while data:=stream.read(1024*1024):value.update(data)
    return value.hexdigest()
def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf8')

require(shutil.disk_usage(ROOT).free>=1_200_000_000,'Native check admission unavailable')
require(subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()==SOURCE,'Source head differs')
require(not subprocess.check_output(['git','status','--porcelain']),'Tracked worktree differs')
cargo=Path(r'C:\Users\Lomi\.cargo\bin\cargo.exe')
environment=os.environ.copy()
environment['PATH']=str(cargo.parent)+';'+environment['PATH']
metadata=subprocess.run([str(cargo),'metadata','--locked','--no-deps','--format-version','1'],cwd=ROOT,env=environment,capture_output=True,timeout=30,check=True)
metadata=json.loads(metadata.stdout)
require(Path(metadata['workspace_root']).resolve()==ROOT,'Cargo workspace differs')
require(Path(metadata['target_directory']).resolve()==ROOT/'target','Shared target location differs')
OUT.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-files','-z','--','Cargo.toml','Cargo.lock','native','.github/workflows/rust.yml'],cwd=ROOT).decode('utf8').split('\0')
paths=[name for name in paths if name]
before={name:sha(ROOT/name) for name in paths}
write('source-before.json',before)
versions={name:subprocess.check_output([str(cargo.parent/(name+'.exe')),*args],env=environment,cwd=ROOT).decode().strip()
          for name,args in [('cargo',['--version']),('rustc',['-vV'])]}
argv=[str(cargo),'clippy','--workspace','--all-targets','--locked','--keep-going','-j','1','--message-format=json','--','-D','warnings']
spec=importlib.util.spec_from_file_location('owned_api',ROOT/'scripts/host_powershell_probe.py')
owned=importlib.util.module_from_spec(spec);spec.loader.exec_module(owned)
api,Extended,_,_=owned.windows_api()
job=api.CreateJobObjectW(None,None);require(job,'Owned build Job unavailable')
limits=Extended();limits.basic.flags=0x2000
require(api.SetInformationJobObject(job,9,c.byref(limits),c.sizeof(limits)),'Owned build Job limits failed')
process=thread=None;assigned=False
row={'schema':1,'sourceRevision':SOURCE,'command':argv,'versions':versions,'startedSuspended':False,
     'assignedBeforeResume':False,'nativeYokeImageReadOrExecuted':False,'testExecution':False,
     'minimumFreeObserved':shutil.disk_usage(ROOT).free,'completed':False,'metadataOnly':True}
def active():
    data=c.create_string_buffer(48)
    require(api.QueryInformationJobObject(job,1,data,48,None),'Owned build accounting unavailable')
    return int.from_bytes(data.raw[40:44],'little')
try:
    with open(os.devnull,'rb') as stdin,(OUT/'cargo.stdout').open('xb') as stdout,(OUT/'cargo.stderr').open('xb') as stderr:
        handles=[msvcrt.get_osfhandle(f.fileno()) for f in [stdin,stdout,stderr]]
        for handle in handles:os.set_handle_inheritable(handle,True)
        startup=subprocess.STARTUPINFO();startup.dwFlags=subprocess.STARTF_USESTDHANDLES
        startup.hStdInput,startup.hStdOutput,startup.hStdError=handles
        startup.lpAttributeList={'handle_list':handles}
        process,thread,pid,_=_winapi.CreateProcess(None,subprocess.list2cmdline(argv),None,None,True,
            subprocess.CREATE_NO_WINDOW|4,environment,str(ROOT),startup)
        row.update(pid=pid,startedSuspended=True)
        require(api.AssignProcessToJobObject(job,process),'Suspended build Job assignment failed')
        assigned=True;row['assignedBeforeResume']=True
        require(api.ResumeThread(thread)!=0xffffffff,'Owned build resume failed')
        end=time.monotonic()+1200
        previous=time.monotonic()
        while _winapi.WaitForSingleObject(process,100)==258:
            free=shutil.disk_usage(ROOT).free
            row['minimumFreeObserved']=min(row['minimumFreeObserved'],free)
            if free<500_000_000:
                row['stopReason']='disk-reserve';break
            if time.monotonic()>=end:
                row['stopReason']='build-budget';break
            if stdout.tell()+stderr.tell()>16_000_000:
                row['stopReason']='log-budget';break
            if time.monotonic()-previous>=30:
                write('live.json',row)
                print(json.dumps({'ownedCargoLive':True,'freeBytes':free,'logBytes':stdout.tell()+stderr.tell()}),flush=True)
                previous=time.monotonic()
        else:
            row['exitCode']=_winapi.GetExitCodeProcess(process)
        row['activeBeforeCleanup']=active()
        drain=min(end,time.monotonic()+1)
        while row['activeBeforeCleanup'] and time.monotonic()<drain:
            time.sleep(.01);row['activeBeforeCleanup']=active()
        row['treeExitedBeforeCleanup']=row['activeBeforeCleanup']==0
finally:
    if process is not None and not assigned:_winapi.TerminateProcess(process,124)
    require(api.TerminateJobObject(job,125),'Owned build termination failed')
    cleanup=time.monotonic()+2
    while active() and time.monotonic()<cleanup:time.sleep(.01)
    row['activeAfterCleanup']=active()
    row['rootExitedAfterCleanup']=process is None or _winapi.WaitForSingleObject(process,max(0,int((cleanup-time.monotonic())*1000)))==0
    for handle in [thread,process,job]:
        if handle is not None:require(api.CloseHandle(handle),'Owned build handle close failed')
    write('job.json',row)
require(row['activeAfterCleanup']==0 and row['rootExitedAfterCleanup'],'Build cleanup unproven')
after={name:sha(ROOT/name) for name in paths}
write('source-after.json',after)
require(after==before,'Native check inputs changed')
row.update(inputsUnchanged=True,inputCount=len(before),freeAfter=shutil.disk_usage(ROOT).free,
           completed=row.get('exitCode')==0 and row.get('treeExitedBeforeCleanup') and not row.get('stopReason'))
write('result.json',row)
print(json.dumps(row,indent=2),flush=True)
sys.exit(0 if row['completed'] else 1)
