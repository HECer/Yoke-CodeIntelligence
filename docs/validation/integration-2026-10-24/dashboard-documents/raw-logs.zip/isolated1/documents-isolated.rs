pub use yoke::{capture,model,paths};
mod project_session { use anyhow::{Result,ensure};
pub(crate) fn label(s: &str) -> Result<()> {
    ensure!(
        !s.is_empty()
            && s.len() <= 100
            && s.chars()
                .all(|c| c.is_ascii_alphanumeric() || matches!(c, '_' | '-' | '.')),
        "Invalid session or project label"
    );
    Ok(())
}
}
mod host_install { use std::path::{Path,PathBuf};use yoke::model::valid_id;
#[cfg_attr(not(windows), allow(dead_code))]
pub(super) struct DurableOutputRegistration {
    plan_id: String,
    journal_id: String,
    root_index: usize,
    attempt: u8,
    path: PathBuf,
    identity: String,
    after_hash: String,
    security_hash: String,
}
impl DurableOutputRegistration {
    #[cfg(windows)]
    pub(super) fn after_hash(&self) -> &str {
        &self.after_hash
    }
    #[cfg(windows)]
    pub(super) fn security_hash(&self) -> &str {
        &self.security_hash
    }
    #[cfg(windows)]
    pub(super) fn matches(&self, path: &Path, id: &str) -> bool {
        self.path == path
            && self.identity == id
            && valid_id(&self.plan_id)
            && valid_id(&self.journal_id)
            && self.root_index < 16
            && (self.attempt as usize) < journal_v2::MAX_ATTEMPTS
            && valid_id(&self.after_hash)
            && valid_id(&self.security_hash)
    }
}

mod journal_v2 { pub(super) const MAX_ATTEMPTS: usize = 3; }
#[path = r#"C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\native\src\host_install_io.rs"#]
mod io;
#[path = r#"C:\Users\Lomi\Documents\NN-Developed\Yoke-CodeIntelligence\native\src\host_documents.rs"#]
pub mod documents;
}
