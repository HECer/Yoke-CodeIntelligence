import hashlib,http.client,json,os,queue,subprocess,sys,threading,time,urllib.parse
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_bytes());out=Path(spec['out']);native=Path(spec['native']);source=Path(spec['root']);profile=Path(spec['hostProfilePath']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(native)==spec['cliSha256'];source_before=sha(source/'main.rs');events=[];notifications=[];pending=queue.Queue();process=None;reader=None;complete=False;stderr=None;dashboard=None;capability=None;outcome={}

def reader_main():
 try:
  while True:
   line=process.stdout.readline(16_000_001)
   if not line:break
   assert len(line)<=16_000_000
   pending.put(json.loads(line))
 except BaseException:pending.put({'ownedReaderError':True})
 finally:pending.put({'ownedReaderEof':True})
def next_frame(timeout=8):
 item=pending.get(timeout=timeout);assert not item.get('ownedReaderError') and not item.get('ownedReaderEof'),'Owned native stdio ended unexpectedly';return item
def rpc(identifier,method,params=None):
 message={'jsonrpc':'2.0','id':identifier,'method':method,'params':params or {}};process.stdin.write(json.dumps(message,ensure_ascii=False).encode()+b'\n');process.stdin.flush();until=time.monotonic()+10
 while time.monotonic()<until:
  item=next_frame(min(8,max(.01,until-time.monotonic())))
  if item.get('method')=='notifications/tools/list_changed':notifications.append(item);continue
  assert item.get('id')==identifier and 'error' not in item,'Unexpected native protocol response';return item
 raise TimeoutError('Owned native protocol response deadline')
def tool(identifier,name,args=None):
 if spec.get('protocolProfile')=='native' and name in ('open_dashboard','get_current_config'):
  args={'operation':{'open_dashboard':'openDashboard','get_current_config':'configuration'}[name],'args':args or {}};name='ci_session'
 reply=rpc(identifier,'tools/call',{'name':name,'arguments':args or {}});assert reply['result']['isError'] is False,'Owned native tool refused';value=reply['result'].get('structuredContent')
 if value is None:value=json.loads(reply['result']['content'][0]['text'])
 assert value['status']=='ok','Owned native tool response is not complete';return value['data']
def dashboard_request(method,path,body=None):
 connection=http.client.HTTPConnection(dashboard.hostname,dashboard.port,timeout=6);headers={'Authorization':'Bearer '+capability,'Origin':f'http://{dashboard.hostname}:{dashboard.port}'}
 if body is not None:headers['Content-Type']='application/json'
 connection.request(method,path,body=None if body is None else json.dumps(body,ensure_ascii=False).encode(),headers=headers);response=connection.getresponse();status=response.status;raw=response.read(4_000_001);connection.close();assert len(raw)<=4_000_000;return status,json.loads(raw)
def state():
 status,value=dashboard_request('GET','/api/state');assert status==200;return value
def manage(action,selected=None):
 selected=selected or state();body={'id':os.urandom(32).hex(),'sessionStateSha256':selected['view']['management']['sessionStateSha256'],'project':selected['view']['activeProject'],'action':action};status,value=dashboard_request('POST','/api/manage',body);events.append({'kind':action['kind'],'status':status,'notApplied':value.get('notApplied')});return status,value
try:
 argv=[str(native),'--root',str(source),'--timeout','30000','--max-bytes','4000000','serve-session','--profile',spec.get('protocolProfile','serena'),'--id','dashboard-stdio-owned','--host-profile',str(profile)]
 if spec.get('python'):argv.extend(['--python',spec['python'],'--trust-python'])
 if spec.get('serverConfig'):argv.extend(['--language-server-config',spec['serverConfig'],'--trust-servers'])
 stderr=(out/'native-stdio.stderr').open('wb');process=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,creationflags=0x08000000);reader=threading.Thread(target=reader_main);reader.start()
 initial=rpc(1,'initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'owned-dashboard-live-acceptance','version':'0.5.0'}});assert initial['result']['serverInfo']['version']=='0.5.0'
 catalog=rpc(2,'tools/list')['result']['tools']
 if spec.get('protocolProfile')=='native':assert 'ci_find' in [t['name'] for t in catalog]
 else:
  description=next(t['description'] for t in catalog if t['name']=='open_dashboard');assert 'management' in description and 'Configuration files' in description
 opened=tool(3,'open_dashboard');dashboard=urllib.parse.urlparse(opened['url']);capability=dashboard.fragment;assert dashboard.scheme=='http' and dashboard.hostname=='127.0.0.1' and len(capability)==64 and opened['browserOpened'] is False
 assert opened['capabilities']['memoryEditing'] is True and opened['capabilities']['mcpShutdown'] is False;original=state();assert original['view']['management']['enabled'] is True
 if spec.get('python'):
  runtime_session=tool(30,'get_current_config')['sessionId'];cell=tool(31,'serena_repl',{'session_id':runtime_session,'code':'owned_marker = 41\nprint(owned_marker)'});assert cell['stdout']=='41\n'
 status,created=manage({'kind':'createMemory','name':'owned/\u03c0','content':'first\r\n<script>inert</script>\r\n\U0001f980 e\u0301'});assert status==200;first=created['data']['note']['id'];status,read=manage({'kind':'readMemory','name':'owned/\u03c0'});assert status==200 and read['data']['note']['content']=='first\r\n<script>inert</script>\r\n\U0001f980 e\u0301'
 status,written=manage({'kind':'writeMemory','name':'owned/\u03c0','content':'second\r\n','expectedRevision':first});assert status==200;second=written['data']['note']['id'];status,stale=manage({'kind':'writeMemory','name':'owned/\u03c0','content':'must not overwrite','expectedRevision':first});assert status==409 and stale['notApplied'] is True
 before_mode=state();selected_modes=['editing','no-memories']+(['hide-find'] if spec.get('protocolProfile')=='native' else []);status,changed=manage({'kind':'switchModes','modes':selected_modes});assert status==200
 # No further stdio request is sent until the asynchronous notification arrives.
 notice=next_frame();assert notice.get('method')=='notifications/tools/list_changed';notifications.append(notice);outcome['catalogNotificationWhileStdioInputIdle']=True
 config=tool(4,'get_current_config');assert 'no-memories' in config['modes'];catalog=rpc(5,'tools/list')['result']['tools'];assert ('ci_find' if spec.get('protocolProfile')=='native' else 'write_memory') not in [v['name'] for v in catalog]
 status,denied=manage({'kind':'createMemory','name':'denied','content':'not allowed'});assert status!=200
 status,stale_session=manage({'kind':'createMemory','name':'stale-session','content':'must not apply'},before_mode);assert status==409 and stale_session['notApplied'] is True
 status,restored=manage({'kind':'switchModes','modes':['editing']});assert status==200;notice=next_frame();assert notice.get('method')=='notifications/tools/list_changed';notifications.append(notice)
 status,renamed=manage({'kind':'renameMemory','oldName':'owned/\u03c0','newName':'owned/renamed','expectedRevision':second});assert status==200;current=renamed['data']['note']['id'];status,deleted=manage({'kind':'deleteMemory','name':'owned/renamed','expectedRevision':current});assert status==200
 status,listed=manage({'kind':'listMemories'});assert status==200 and listed['data']['items']==[]
 if spec.get('python'):
  cell=tool(32,'serena_repl',{'session_id':runtime_session,'code':'owned_marker += 1\nprint(owned_marker)'});assert cell['stdout']=='42\n';outcome['persistentRuntimeStateKeptAcrossDashboardCalls']=True
 if spec.get('serverConfig'):
  log=Path(spec['providerLog']);assert not log.exists(),'A provider started without a semantic request'
  assert state()['view']['selectedBackends']==['angular','typescript']
  status,denied=manage({'kind':'selectLanguageServers','selection':{'kind':'backends','ids':['rust']}});assert status==403 and denied['notApplied'] is True
  status,selected=manage({'kind':'selectLanguageServers','selection':{'kind':'backends','ids':['typescript','angular']}});assert status==200 and selected['sourceWritten'] is False
  configured=tool(50,'get_current_config');assert configured['dashboardLanguageSelection']['selectedBackends']==['typescript','angular'] and not log.exists()
  if spec.get('protocolProfile')=='native':
   hovered=tool(51,'ci_find',{'languageServer':{'path':'main.rs','offset':0,'operation':'hover'}});assert hovered['selectedBackendId']=='typescript';assert log.exists();outcome['actualSelectedProviderDispatch']=True
  before=log.read_bytes() if log.exists() else b''
  status,disabled=manage({'kind':'selectLanguageServers','selection':{'kind':'legacy','languages':[]}});assert status==200
  configured=tool(52,'get_current_config');assert configured['dashboardLanguageSelection']['selectedBackends'] is None and configured['dashboardLanguageSelection']['selectedLegacyLanguages']==[]
  if spec.get('protocolProfile')=='native':
   refused=rpc(53,'tools/call',{'name':'ci_find','arguments':{'languageServer':{'path':'main.rs','offset':0,'operation':'hover'}}})['result'];value=refused.get('structuredContent')
   if value is None:value=json.loads(refused['content'][0]['text'])
   assert value['status']=='error','Disabled semantic provider returned a complete empty result'
  assert (log.read_bytes() if log.exists() else b'')==before
  status,reset=manage({'kind':'resetLanguageServers'});assert status==200 and state()['view']['selectedBackends']==['angular','typescript']
  if spec.get('python'):
   cell=tool(54,'serena_repl',{'session_id':runtime_session,'code':'owned_marker += 1\nprint(owned_marker)'});assert cell['stdout']=='43\n';outcome['persistentRuntimeStateKeptAcrossLanguageCalls']=True
  outcome['explicitLanguageGrantOrderDisableResetOnOriginalSession']=True;outcome['selectionAloneStartsNoProvider']=True
 if spec.get('globalConfig'):
  global_config=Path(spec['globalConfig']);project_config=Path(spec['projectConfig']);global_before=global_config.read_bytes();project_before=project_config.read_bytes()
  assert opened['capabilities']['configurationReading'] is True and opened['capabilities']['configurationEditing'] is True and opened['capabilities']['projectConfigurationEditing'] is False
  def document_action(action):return manage({'kind':'document','request':action})
  status,loaded=document_action({'kind':'read','documentId':'host-settings'});assert status==200 and loaded['data']['document']['content'].encode()==global_before
  proposed=global_before+b'# explicit inert change\r\nscript: <script>inert</script>\r\n'
  status,planned=document_action({'kind':'plan','documentId':'host-settings','expectedRevision':loaded['data']['document']['revision'],'content':proposed.decode()});assert status==200 and planned['data']['plan']['afterHash']==hashlib.sha256(proposed).hexdigest() and global_config.read_bytes()==global_before
  status,saved=document_action({'kind':'apply','documentId':'host-settings','planId':planned['data']['plan']['id']});assert status==200 and saved['fileChanged'] is True and saved['sourceWritten'] is False and global_config.read_bytes()==proposed
  status,loaded=document_action({'kind':'read','documentId':'host-settings'});assert status==200
  status,planned=document_action({'kind':'plan','documentId':'host-settings','expectedRevision':loaded['data']['document']['revision'],'content':'stale reviewed draft\r\n'});assert status==200
  competing=proposed+b'# explicit competing fixture write\r\n';global_config.write_bytes(competing)
  status,refused=document_action({'kind':'apply','documentId':'host-settings','planId':planned['data']['plan']['id']});assert status==422 and global_config.read_bytes()==competing
  status,journals=document_action({'kind':'pending','documentId':'host-settings'});assert status==200 and journals['data']['journals']==[]
  status,project_doc=document_action({'kind':'read','documentId':'project-settings'});assert status==200 and project_doc['data']['document']['content'].encode()==project_before
  status,refused=document_action({'kind':'plan','documentId':'project-settings','expectedRevision':project_doc['data']['document']['revision'],'content':'no workspace approval'});assert status!=200 and project_config.read_bytes()==project_before
  status,refused=document_action({'kind':'read','documentId':'outside'});assert status==403
  observed=state();assert observed['argumentsRecorded'] is False and observed['resultsRecorded'] is False and 'explicit inert change' not in json.dumps(observed)
  if spec.get('python'):
   cell=tool(65,'serena_repl',{'session_id':runtime_session,'code':'owned_marker += 1\nprint(owned_marker)'});assert cell['stdout']=='44\n';outcome['persistentRuntimeStateKeptAcrossFileCalls']=True
  outcome['selectedGlobalFileExactBytesAndStalePlanRefusal']=True;outcome['selectedProjectDocumentReadOnly']=True;outcome['documentBodiesExcludedFromActivity']=True
 if spec.get('holdForVisual'):
  (out/'private-dashboard.json').write_text(json.dumps({'url':dashboard.geturl(),'product':'Code Intelligence','version':'0.5.0','cliSha256':spec['cliSha256']}))
  until=time.monotonic()+300
  while time.monotonic()<until and not (out/'ui-stop').exists():time.sleep(.1)
  assert (out/'ui-stop').exists(),'Owned native browser inspection exceeded its bound'
 process.stdin.close();process.wait(timeout=8);reader.join(timeout=3);assert process.returncode==0 and not reader.is_alive(),'Owned native stdio did not stop on EOF'
 try:dashboard_request('GET','/api/state')
 except (ConnectionError,OSError,http.client.HTTPException):outcome['dashboardListenerClosedOnStdioEof']=True
 else:raise AssertionError('Owned dashboard survived transport EOF')
 assert sha(source/'main.rs')==source_before and sha(native)==spec['cliSha256'];complete=True
finally:
 if process is not None and process.poll() is None:process.kill();process.wait(timeout=8)
 if process is not None:
  if process.stdin and not process.stdin.closed:process.stdin.close()
  if process.stdout:process.stdout.close()
 if reader is not None:reader.join(timeout=3)
 if stderr is not None:stderr.close()
 capability=None;dashboard=None
 result={'complete':complete,'nativeExitCode':None if process is None else process.returncode,'readerJoined':reader is None or not reader.is_alive(),'managementEvents':events,'notificationCount':len(notifications),'sameOwningSessionModesAndCatalog':complete,'noteCasAndSourceBytesExact':complete,'capabilitiesExcludedFromLogs':True,'modelCalls':0,'analyzedSourceExecuted':False,**outcome};(out/'stdio-live-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
