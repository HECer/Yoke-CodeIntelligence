from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-documents-20261024-211f17f9-isolated3';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-dashboard-documents-isolated3-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')







import re
q=w/'validation/integration-20261018/dashboard-documents-20261024-211f17f9-check1';assert json.loads((q/'result.json').read_bytes())['complete'];old_inputs=json.loads((q/'source-before.json').read_bytes());inputs={n:sha(w/n) for n in old_inputs};assert {n for n,h in old_inputs.items() if inputs[n]!=h}=={'native/src/host_documents.rs','native/src/session_dashboard_management.rs','native/src/session_dashboard_session.rs'};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');complete=False
project=(w/'native/src/project_session.rs').read_text(encoding='utf8');a=project.index('pub(crate) fn label(');label=project[a:project.index('\n}',a)+2]
host=(w/'native/src/host_install.rs').read_text(encoding='utf8');a=host.index('#[cfg_attr(not(windows), allow(dead_code))]\npub(super) struct DurableOutputRegistration');registration=host[a:host.index('\n#[path = "host_install_journal_v2.rs"]',a)]
constant=re.search(r'pub\(super\) const MAX_ATTEMPTS: usize = \d+;', (w/'native/src/host_install_journal_v2.rs').read_text(encoding='utf8')).group(0)
harness='pub use yoke::{capture,model,paths};\nmod project_session { use anyhow::{Result,ensure};\n'+label+'\n}\nmod host_install { use std::path::{Path,PathBuf};use yoke::model::valid_id;\n'+registration+'\nmod journal_v2 { '+constant+' }\n'
for module,name in [('io','host_install_io.rs'),('documents','host_documents.rs')]:harness+='#[path = r#"'+str(w/'native/src'/name)+'"#]\n'+('pub ' if module=='documents' else '')+'mod '+module+';\n'
harness+='}\n'
management=(w/'native/src/session_dashboard_management.rs').read_text(encoding='utf8')
def declaration(source,needle,attributes=False):
 a=source.index(needle);start=source.rfind('#[derive',0,a) if attributes else source.rfind('#[test]',0,a);opening=source.index('{',a);depth=1;end=opening+1
 while depth:
  if source[end]=='{':depth+=1
  elif source[end]=='}':depth-=1
  end+=1
 return source[start:end]
selected_enum=declaration(management,'pub(crate) enum LanguageSelection',True);action_enum=declaration(management,'pub(crate) enum Action',True);strict_test=declaration(management,'fn argumentless_management_actions_reject_all_unknown_authority_fields')
harness+='mod management { use serde::{Serialize,Deserialize};use serde_json::json;\n'+selected_enum+'\n'+action_enum+'\n'+strict_test+'\n}\n'
source=jobroot/'documents-isolated.rs';source.write_text(harness,encoding='utf8',newline='\n');shutil.copyfile(source,out/'documents-isolated.rs');(out/'exact-source-extractions.json').write_text(json.dumps({'labelSha256':hashlib.sha256(label.encode()).hexdigest(),'registrationSha256':hashlib.sha256(registration.encode()).hexdigest(),'attemptConstantSha256':hashlib.sha256(constant.encode()).hexdigest(),'captureModelPathsFromPriorCompiledLibraryHaveUnchangedSource':True,'productionSourceFilesDirectlyIncluded':['native/src/host_documents.rs','native/src/host_install_io.rs','native/src/host_install_namespace.rs','native/src/host_metadata_directory_tests.rs'],'notAWholeProjectCargoTest':True},indent=2)+'\n')
prior=w/'validation/integration-20261018/dashboard-languages-20261024-114091e3-qualified1';before=json.loads((prior/'source-before.json').read_bytes())
for n in ['native/src/capture.rs','native/src/model.rs','native/src/paths.rs']:assert sha(w/n)==before[n]
artifacts={}
for log in ['whole-library.stdout','build-native-cli.stdout']:
 for line in (prior/log).read_text(encoding='utf8').splitlines():
  try:m=json.loads(line)
  except ValueError:continue
  if m.get('reason')!='compiler-artifact' or m['target']['kind']!=['lib'] or m['profile']['test']:continue
  name=m['target']['name'];libraries=[Path(n) for n in m['filenames'] if n.endswith('.rlib')]
  if libraries:artifacts[name]=libraries[0]
exe=jobroot/'documents-isolated-tests.exe';argv=[r'C:\Users\Lomi\.cargo\bin\rustc.exe','--edition','2024','--crate-name','dashboard_documents_isolated','--test',str(source),'-L','dependency='+str(w/'target/debug/deps'),'-C','debuginfo=0','-o',str(exe)]
for name in ['yoke','anyhow','serde','serde_json','sha2','tempfile','hex']:assert name in artifacts;argv.extend(['--extern',name+'='+str(artifacts[name])])
env['CARGO_MANIFEST_DIR']=str(w/'native');env['CARGO_PKG_VERSION']='0.5.0'
try:
 assert shutil.disk_usage(w).free>680_000_000
 run('build-isolated-actual-source-harness',argv,timeout=300);expected=sha(exe);result=run('whole-isolated-actual-source-harness',[exe,'--test-threads=1'],timeout=600);assert sha(exe)==expected;print(result.decode()[-8000:],flush=True);(out/'passed-isolated-executable.json').write_text(json.dumps({'path':str(exe),'sha256':expected,'notAWholeProjectBinaryOrCargoTest':True},indent=2)+'\n');complete=True
finally:
 result={'complete':complete,'isolatedActualSourceHarnessOnly':True,'sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'freeBytes':shutil.disk_usage(w).free};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
