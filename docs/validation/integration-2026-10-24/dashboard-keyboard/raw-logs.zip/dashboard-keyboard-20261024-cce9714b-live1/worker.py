import hashlib,http.client,json,queue,subprocess,sys,threading,time,urllib.parse
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_bytes());out=Path(spec['out']);native=Path(spec['native']);root=Path(spec['root']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(native)==spec['cliSha256'];before=sha(root/'main.rs');messages=queue.Queue();process=None;reader=None;complete=False;closed_by_owner=False
def read_frames():
 try:
  while True:
   line=process.stdout.readline(4_000_001)
   if not line:break
   assert len(line)<=4_000_000;messages.put(json.loads(line))
 finally:messages.put(None)
def rpc(i,method,params):
 process.stdin.write(json.dumps({'jsonrpc':'2.0','id':i,'method':method,'params':params}).encode()+b'\n');process.stdin.flush();end=time.monotonic()+10
 while time.monotonic()<end:
  value=messages.get(timeout=max(.01,end-time.monotonic()));assert value is not None
  if value.get('method')=='notifications/tools/list_changed':continue
  assert value.get('id')==i and 'error' not in value;return value['result']
 raise TimeoutError('Owned native protocol deadline')
stderr=(out/'native.stderr').open('wb')
try:
 process=subprocess.Popen([str(native),'--root',str(root),'--timeout','30000','--max-bytes','4000000','serve-session','--profile','native','--id','keyboard-owned','--host-profile',spec['profile']],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,creationflags=0x08000000)
 reader=threading.Thread(target=read_frames);reader.start();initial=rpc(1,'initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'owned-keyboard-acceptance','version':'0.5.0'}});assert initial['serverInfo']['version']=='0.5.0'
 response=rpc(2,'tools/call',{'name':'ci_session','arguments':{'operation':'openDashboard','args':{}}});assert response['isError'] is False;value=response.get('structuredContent') or json.loads(response['content'][0]['text']);assert value['status']=='ok';opened=value['data'];u=urllib.parse.urlparse(opened['url']);assert u.hostname=='127.0.0.1' and len(u.fragment)==64 and opened['browserOpened'] is False
 c=http.client.HTTPConnection(u.hostname,u.port,timeout=5);c.request('GET','/');r=c.getresponse();bootstrap=r.read(1_000_001);c.close();assert r.status==200 and bootstrap==(Path(spec['asset']).read_bytes());(out/'native-bootstrap.html').write_bytes(bootstrap)
 (out/'private-dashboard.json').write_text(json.dumps({'url':u.geturl(),'version':'0.5.0','cliSha256':spec['cliSha256']}))
 deadline=time.monotonic()+300
 while time.monotonic()<deadline:
  if process.poll() is not None:
   assert process.returncode==0 and not process.stdin.closed;closed_by_owner=True;(out/'native-process-exited.json').write_text(json.dumps({'nativeExitCode':0,'stdinWasStillOpen':True,'owningShutdownBeforeJobCleanup':True})+'\n')
   assert (out/'.ui-complete').exists(),'Native host exited before browser acceptance';break
  time.sleep(.1)
 else:raise TimeoutError('Owned keyboard visual acceptance deadline')
 reader.join(timeout=3);assert not reader.is_alive();assert sha(root/'main.rs')==before and sha(native)==spec['cliSha256'];complete=True
finally:
 if process:
  if process.stdin and not process.stdin.closed:process.stdin.close()
  if process.poll() is None:process.wait(timeout=8)
 if reader:reader.join(timeout=3)
 stderr.close();(out/'live-result.json').write_text(json.dumps({'complete':complete,'sourceFileUnchanged':sha(root/'main.rs')==before,'nativeOwnedShutdownBeforeStdinEof':closed_by_owner,'readerJoined':reader is not None and not reader.is_alive(),'cliSha256':spec['cliSha256']},indent=2)+'\n')
