from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-shutdown-20261024-2472bc87-live-browser1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-dashboard-shutdown-live-browser1-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')





q=w/'validation/integration-20261018/dashboard-shutdown-20261024-2472bc87-qualified1';assert json.loads((q/'result.json').read_bytes())['complete'];inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());built=json.loads((q/'built-cli.json').read_bytes());native=w/'target/debug/yoke.exe';assert built['buildPassed'] and sha(native)==built['sha256'];worker=Path(r'C:\Users\Lomi\AppData\Local\Temp\dashboard-shutdown-live-worker-20261024.py');shutil.copyfile(worker,out/'stdio-worker.py');complete=False;accepted=[]
try:
 for variant in ['persistent-python']:
  selected=out/variant;selected.mkdir();source=jobroot/('source-'+variant);source.mkdir();(source/'main.rs').write_bytes('// owned \U0001f980 e\u0301\r\nfn original() {}\r\n'.encode());other=jobroot/('other-'+variant);other.mkdir();(other/'secondary.rs').write_bytes(b'fn second() {}\r\n');log=jobroot/(variant+'-provider-log');servers=[]
  fixture=w/'native/tests/fixtures/server-selection-lsp.mjs'
  for backend in [None,'rust','typescript','angular']:
   row={'command':r'C:\Program Files\nodejs\node.exe','args':[str(fixture),str(log),backend or 'legacy','0'],'configuration':{'passiveProfile':'contract_fixture'}}
   if backend:row['backendId']=backend
   else:row['language']='rust'
   servers.append(row)
  server_config=jobroot/(variant+'-servers.json');server_config.write_text(json.dumps(servers));host={'context':'desktop-app','modes':['editing'],'steering':{},'notesPolicy':{'writable':True},'languageServers':{'global':['angular','typescript']},'dashboard':{'management':{'operationTimeoutMs':3000,'languageServers':{'backendIds':['angular','typescript'],'legacyLanguages':['rust']}},'lifetimeMs':600000},'projects':[{'name':'secondary','root':str(other),'readOnly':True}]}
  spec={'out':str(selected),'native':str(native),'root':str(source),'cliSha256':built['sha256'],'serverConfig':str(server_config),'providerLog':str(log),'holdForVisual':True}
  if variant=='persistent-python':spec['python']=r'C:\Python314\python.exe'
  if variant=='native-session':spec['protocolProfile']='native';host['steering']={'modes':{'hide-find':{'instructions':'Owned catalog selection fixture','excludedTools':['ci_find']}}}
  global_config=jobroot/(variant+'-global.yaml');global_config.write_bytes('\ufeff# owned global e\u0301\r\nvalue: explicit\r\n'.encode());project_config=source/'project.yaml';project_config.write_bytes(b'project: original\r\n');journal=jobroot/(variant+'-journals');journal.mkdir()
  host['dashboard']['management']['documents']={'documents':[{'id':'host-settings','label':'Owned host settings','path':str(global_config),'scope':{'kind':'global'},'writable':True},{'id':'project-settings','label':'Owned project settings','path':str(project_config),'scope':{'kind':'project','project':'default'},'writable':True}],'journalRoot':str(journal)};spec.update({'globalConfig':str(global_config),'projectConfig':str(project_config)})
  raw_log=jobroot/(variant+'-private.log');assert not raw_log.exists();host['dashboard']['management']['rawLogs']={'logs':[{'id':'owned-private','label':'Owned private session log','path':str(raw_log)}],'maxWindowBytes':1024};spec['rawLog']=str(raw_log)
  host['dashboard']['management']['shutdown']=True
  profile=jobroot/(variant+'-host.json');profile.write_text(json.dumps(host));spec['hostProfilePath']=str(profile);path=jobroot/(variant+'-spec.json');path.write_text(json.dumps(spec));(selected/'owned-fixture-paths.json').write_text(json.dumps({'primary':str(source),'secondary':str(other),'providerLog':str(log),'spec':str(path)}));run('actual-stdio-'+variant,[r'C:\Python314\python.exe','-I',worker,path],timeout=340);result=json.loads((selected/'stdio-live-result.json').read_bytes());assert result['complete'] and result['readerJoined'];accepted.append({'variant':variant,'result':result})
 complete=True
finally:
 result={'complete':complete,'variants':accepted,'currentCliSha256':sha(native),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'existingCredentialsAccessed':False,'systemSettingsChanged':False,'modelCalls':0,'analyzedSourceExecuted':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'complete':complete,'variants':len(accepted),'allJobsEmpty':result['allJobsEmpty']}),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
