import ctypes,hashlib,hmac,http.client,json,queue,subprocess,sys,threading,time,urllib.parse
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_bytes());out=Path(spec['out']);native=Path(spec['native']);root=Path(spec['root']);config=Path(spec['config']);expected=spec['tokenHash'];target='yoke-code-intelligence/service/token/'+spec['credentialName'];proc=None;stderr=None;complete=False;deleted=False;events=[];secret=None;first=None;second=None
class Cred(ctypes.Structure):
 _fields_=[('Flags',ctypes.c_ulong),('Type',ctypes.c_ulong),('TargetName',ctypes.c_wchar_p),('Comment',ctypes.c_wchar_p),('LastWritten',ctypes.c_ulonglong),('CredentialBlobSize',ctypes.c_ulong),('CredentialBlob',ctypes.POINTER(ctypes.c_ubyte)),('Persist',ctypes.c_ulong),('AttributeCount',ctypes.c_ulong),('Attributes',ctypes.c_void_p),('TargetAlias',ctypes.c_wchar_p),('UserName',ctypes.c_wchar_p)]
adv=ctypes.WinDLL('Advapi32',use_last_error=True);adv.CredReadW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.POINTER(ctypes.POINTER(Cred))];adv.CredReadW.restype=ctypes.c_int;adv.CredFree.argtypes=[ctypes.c_void_p];adv.CredDeleteW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong];adv.CredDeleteW.restype=ctypes.c_int
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def own_token():
 ptr=ctypes.POINTER(Cred)();assert adv.CredReadW(target,1,0,ctypes.byref(ptr)),'Owned synthetic credential unavailable'
 try:
  assert ptr.contents.TargetName==target and ptr.contents.CredentialBlobSize==32
  value=ctypes.string_at(ptr.contents.CredentialBlob,32);assert hmac.compare_digest(hashlib.sha256(value).hexdigest(),expected);return value
 finally:adv.CredFree(ptr)
def mcp(method,body=None,sid=None):
 connection=http.client.HTTPConnection(hostname,port,timeout=8);headers={'Authorization':'Bearer '+secret.hex(),'Accept':'application/json, text/event-stream','Content-Type':'application/json','MCP-Protocol-Version':'2025-06-18'}
 if sid:headers['Mcp-Session-Id']=sid
 connection.request(method,endpoint,body=None if body is None else json.dumps(body).encode(),headers=headers);response=connection.getresponse();status=response.status;media=response.getheader('Content-Type','');selected=response.getheader('Mcp-Session-Id');raw=response.read(16_000_001);connection.close();assert len(raw)<=16_000_000
 if status==200:
  frames=[json.loads(line[5:].strip()) for line in raw.decode().splitlines() if line.startswith('data:')] if media.startswith('text/event-stream') else [json.loads(raw)]
 else:frames=[]
 events.append({'transport':'mcp','method':method,'status':status,'notificationCount':sum(f.get('method')=='notifications/tools/list_changed' for f in frames)})
 return status,frames,selected
def rpc(identifier,method,params=None,sid=None):
 status,frames,selected=mcp('POST',{'jsonrpc':'2.0','id':identifier,'method':method,'params':params or {}},sid);assert status==200;reply=next(f for f in frames if f.get('id')==identifier);assert 'error' not in reply;return reply,selected,frames
def tool(identifier,name,args=None,sid=None):
 reply,_,frames=rpc(identifier,'tools/call',{'name':name,'arguments':args or {}},sid);assert reply['result']['isError'] is False;value=json.loads(reply['result']['content'][0]['text']);assert value['status']=='ok';return value['data'],frames
def dashboard_request(cap,method,path,body=None):
 url,token=cap;connection=http.client.HTTPConnection(url.hostname,url.port,timeout=5);headers={'Authorization':'Bearer '+token,'Origin':f'http://{url.hostname}:{url.port}','Content-Type':'application/json'};connection.request(method,path,body=None if body is None else json.dumps(body,ensure_ascii=False).encode(),headers=headers);response=connection.getresponse();status=response.status;raw=response.read(4_000_001);connection.close();assert len(raw)<=4_000_000;
 try:value=json.loads(raw)
 except json.JSONDecodeError:
  assert status>=400,'Successful dashboard reply must be JSON';value={'httpErrorBodyWasPlainText':True}
 return status,value
def state(cap):
 status,value=dashboard_request(cap,'GET','/api/state');assert status==200;return value
def manage(cap,action,selected=None):
 selected=selected or state(cap);body={'id':hashlib.sha256(str(time.monotonic_ns()).encode()).hexdigest(),'project':selected['view']['activeProject'],'sessionStateSha256':selected['view']['management']['sessionStateSha256'],'action':action};status,value=dashboard_request(cap,'POST','/api/manage',body);events.append({'transport':'dashboard','kind':action['kind'],'status':status,'notApplied':value.get('notApplied')});return status,value
def capability(data):
 url=urllib.parse.urlparse(data['url']);assert url.scheme=='http' and url.hostname=='127.0.0.1' and len(url.fragment)==64;assert data['browserOpened'] is False;return url,url.fragment
runtime_api=ctypes.WinDLL('kernel32',use_last_error=True);runtime_api.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];runtime_api.OpenProcess.restype=ctypes.c_void_p;runtime_api.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong];runtime_api.WaitForSingleObject.restype=ctypes.c_ulong;runtime_api.CloseHandle.argtypes=[ctypes.c_void_p];runtime_api.CloseHandle.restype=ctypes.c_int;runtime_api.QueryFullProcessImageNameW.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)];runtime_api.QueryFullProcessImageNameW.restype=ctypes.c_int;runtime_handles={};runtime_sessions={};owned_pids={};runtime_exit_proof={}
def hold_runtime(sid,identifier,marker):
 current,_=tool(identifier,'get_current_config',sid=sid);runtime_sessions[sid]=current['sessionId'];result,_=tool(identifier+1,'serena_repl',{'session_id':current['sessionId'],'code':'import os\nowned_http_marker = '+str(marker)+'\nprint(os.getpid())'},sid=sid);pid=int(result['stdout'].strip());handle=runtime_api.OpenProcess(0x00101000,False,pid);assert handle;buffer=ctypes.create_unicode_buffer(32768);length=ctypes.c_ulong(len(buffer));assert runtime_api.QueryFullProcessImageNameW(handle,0,buffer,ctypes.byref(length));assert Path(buffer.value).resolve()==Path(r'C:\Python314\python.exe').resolve();assert runtime_api.WaitForSingleObject(handle,0)==258;runtime_handles[sid]=handle;owned_pids[sid]=pid
def wait_runtime(sid):
 assert runtime_api.WaitForSingleObject(runtime_handles[sid],5000)==0;runtime_exit_proof[sid]=True
try:
 assert sha(native)==spec['cliSha256'];before=sha(root/'main.rs');secret=own_token();stderr=(out/'native-http.stderr').open('wb');proc=subprocess.Popen([str(native),'--root',str(root),'--timeout','30000','--max-bytes','4000000','serve-http','--config',str(config),'--trust-service','--trust-servers','--trust-python','--duration-ms','60000'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=stderr,creationflags=0x08000000)
 ready_queue=queue.Queue();reader=threading.Thread(target=lambda:ready_queue.put(proc.stdout.readline(65537)));reader.start();ready_raw=ready_queue.get(timeout=10);reader.join(timeout=1);assert not reader.is_alive();ready=json.loads(ready_raw);assert ready['status']=='listening';hostname,p=ready['address'].rsplit(':',1);port=int(p);endpoint=ready['endpoint'];assert hostname=='127.0.0.1'
 init={'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'owned-dashboard-http-acceptance','version':'0.5.0'}};_,sid_a,_=rpc(1,'initialize',init);assert sid_a;opened,_=tool(2,'open_dashboard',sid=sid_a);first=capability(opened);assert state(first)['view']['management']['enabled'] is True
 _,sid_b,_=rpc(3,'initialize',init);assert sid_b and sid_b!=sid_a;opened_b,_=tool(4,'open_dashboard',sid=sid_b);second=capability(opened_b);assert first[1]!=second[1]
 assert opened['capabilities']['mcpShutdown'] is True and opened_b['capabilities']['mcpShutdown'] is True
 hold_runtime(sid_a,80,41);hold_runtime(sid_b,82,99);assert owned_pids[sid_a]!=owned_pids[sid_b]
 status,created=manage(first,{'kind':'createMemory','name':'owned/http-\u03c0','content':'owned\r\n<script>inert</script>\r\n\U0001f980'});assert status==200
 status,read=manage(first,{'kind':'readMemory','name':'owned/http-\u03c0'});assert status==200 and read['data']['note']['content']=='owned\r\n<script>inert</script>\r\n\U0001f980'
 log=Path(spec['providerLog']);assert not log.exists()
 original_languages=state(first);assert original_languages['view']['selectedBackends']==['angular','typescript']
 status,changed=manage(first,{'kind':'selectLanguageServers','selection':{'kind':'backends','ids':['typescript','angular']}});assert status==200
 selected,_=tool(40,'get_current_config',sid=sid_a);assert selected['dashboardLanguageSelection']['selectedBackends']==['typescript','angular']
 isolated,_=tool(41,'get_current_config',sid=sid_b);assert isolated['dashboardLanguageSelection']['selectedBackends']==['angular','typescript']
 status,denied=manage(first,{'kind':'selectLanguageServers','selection':{'kind':'backends','ids':['rust']}});assert status==403 and denied['notApplied'] is True
 status,stale_languages=manage(first,{'kind':'resetLanguageServers'},original_languages);assert status==409 and stale_languages['notApplied'] is True
 status,disabled=manage(first,{'kind':'selectLanguageServers','selection':{'kind':'legacy','languages':[]}});assert status==200
 selected,_=tool(42,'get_current_config',sid=sid_a);assert selected['dashboardLanguageSelection']['selectedBackends'] is None and selected['dashboardLanguageSelection']['selectedLegacyLanguages']==[]
 status,reset=manage(first,{'kind':'resetLanguageServers'});assert status==200 and state(first)['view']['selectedBackends']==['angular','typescript']
 assert not log.exists(),'Dashboard selection started a provider without a semantic request'
 if spec.get('rawLog'):
  import base64
  rawlog=Path(spec['rawLog']);assert opened['capabilities']['rawLogs'] is True and opened_b['capabilities']['rawLogs'] is True
  assert not rawlog.exists();payload=b'owned private shared-host log\r\n<script>inert</script>\r\n\xff';rawlog.write_bytes(payload)
  status,a=manage(first,{'kind':'readLog','logId':'owned-private'});assert status==200
  status,b=manage(second,{'kind':'readLog','logId':'owned-private'});assert status==200
  assert base64.b64decode(a['data']['observation']['base64'])==payload and base64.b64decode(b['data']['observation']['base64'])==payload
  assert a['data']['observation']['observationId']!=b['data']['observation']['observationId']
  for cap in [first,second]:
   selected=state(cap);assert 'owned private shared-host log' not in json.dumps(selected)
   status,denied=manage(cap,{'kind':'readLog','logId':'not-selected'});assert status==422
  assert rawlog.read_bytes()==payload
 if spec.get('globalConfig'):
  global_config=Path(spec['globalConfig']);project_config=Path(spec['projectConfig']);global_before=global_config.read_bytes();project_before=project_config.read_bytes()
  assert opened['capabilities']['configurationReading'] is True and opened['capabilities']['configurationEditing'] is True and opened_b['capabilities']['configurationEditing'] is True
  def doc(cap,action):return manage(cap,{'kind':'document','request':action})
  status,loaded=doc(first,{'kind':'read','documentId':'host-settings'});assert status==200 and loaded['data']['document']['content'].encode()==global_before
  status,loaded_b=doc(second,{'kind':'read','documentId':'host-settings'});assert status==200
  status,plan_b=doc(second,{'kind':'plan','documentId':'host-settings','expectedRevision':loaded_b['data']['document']['revision'],'content':'stale second actor proposal\r\n'});assert status==200
  proposed=global_before+b'# first actor global proposal\r\n';status,plan_a=doc(first,{'kind':'plan','documentId':'host-settings','expectedRevision':loaded['data']['document']['revision'],'content':proposed.decode()});assert status==200 and global_config.read_bytes()==global_before
  status,saved=doc(first,{'kind':'apply','documentId':'host-settings','planId':plan_a['data']['plan']['id']});assert status==200 and saved['sourceWritten'] is False and global_config.read_bytes()==proposed
  status,refused=doc(second,{'kind':'apply','documentId':'host-settings','planId':plan_a['data']['plan']['id']});assert status==422 and global_config.read_bytes()==proposed
  status,refused=doc(second,{'kind':'apply','documentId':'host-settings','planId':plan_b['data']['plan']['id']});assert status==422 and global_config.read_bytes()==proposed
  status,loaded_b=doc(second,{'kind':'read','documentId':'host-settings'});assert status==200 and loaded_b['data']['document']['content'].encode()==proposed
  final=proposed+b'# fresh second actor proposal\r\n';status,plan_b=doc(second,{'kind':'plan','documentId':'host-settings','expectedRevision':loaded_b['data']['document']['revision'],'content':final.decode()});assert status==200
  status,saved=doc(second,{'kind':'apply','documentId':'host-settings','planId':plan_b['data']['plan']['id']});assert status==200 and global_config.read_bytes()==final
  status,project_doc=doc(first,{'kind':'read','documentId':'project-settings'});assert status==200 and project_doc['data']['document']['content'].encode()==project_before
  status,refused=doc(first,{'kind':'plan','documentId':'project-settings','expectedRevision':project_doc['data']['document']['revision'],'content':'no workspace authority'});assert status!=200 and project_config.read_bytes()==project_before
  status,pending=doc(second,{'kind':'pending','documentId':'host-settings'});assert status==200 and pending['data']['journals']==[] and pending['data'].get('blockedByDifferentAuthority') is not True
 old=state(first);status,changed=manage(first,{'kind':'switchModes','modes':['editing','no-memories']});assert status==200
 current,frames=tool(5,'get_current_config',sid=sid_a);assert 'no-memories' in current['modes'];assert any(f.get('method')=='notifications/tools/list_changed' for f in frames)
 unaffected,_=tool(6,'get_current_config',sid=sid_b);assert 'no-memories' not in unaffected['modes']
 status,stale=manage(first,{'kind':'createMemory','name':'stale','content':'must not apply'},old);assert status==409 and stale['notApplied'] is True
 status,accepted=manage(first,{'kind':'shutdown'});assert status==200 and accepted['data']['shutdownAccepted'] is True and accepted['data']['scope']=='owning_http_mcp_session' and accepted['data']['serviceShutdown'] is False and accepted['data']['processExitConfirmed'] is False
 wait_runtime(sid_a);assert runtime_api.WaitForSingleObject(runtime_handles[sid_b],0)==258
 closed=False;until=time.monotonic()+3
 while time.monotonic()<until:
  try:status,_=dashboard_request(first,'GET','/api/state');assert status!=200
  except (ConnectionError,OSError,http.client.HTTPException):closed=True;break
  time.sleep(.02)
 assert closed,'Stopped MCP Session retained private listener';assert state(second)['view']['management']['enabled'] is True
 current,_=tool(90,'serena_repl',{'session_id':runtime_sessions[sid_b],'code':'print(owned_http_marker)'},sid=sid_b);assert current['stdout']=='99\n'
 reply,_,_=rpc(91,'ping',sid=sid_b);assert reply['result']=={};status,_,_=mcp('POST',{'jsonrpc':'2.0','id':92,'method':'ping','params':{}},sid=sid_a);assert status in [404,409,503]
 _,sid_c,_=rpc(93,'initialize',init);assert sid_c not in [sid_a,sid_b];hold_runtime(sid_c,94,123);status,_,_=mcp('DELETE',sid=sid_c);assert status==204;wait_runtime(sid_c)
 status,_,_=mcp('DELETE',sid=sid_b);assert status==204;wait_runtime(sid_b)
 rest=proc.communicate(timeout=70)[0];assert proc.returncode==0 and json.loads(rest)['status']=='stopped';assert sha(root/'main.rs')==before and sha(native)==spec['cliSha256'];complete=True
finally:
 if proc is not None and proc.poll() is None:proc.terminate();proc.wait(timeout=10)
 if stderr is not None:stderr.close()
 for handle in runtime_handles.values():assert runtime_api.CloseHandle(handle)
 try:
  if secret is not None:assert hmac.compare_digest(own_token(),secret);assert adv.CredDeleteW(target,1,0);deleted=True
 finally:secret=None;first=None;second=None
 result={'complete':complete,'serviceExited':proc is not None and proc.poll() is not None,'syntheticCredentialDeleted':deleted,'existingCredentialsAccessed':False,'managementExecutedByIdleMcpActor':complete,'sameSessionModesAndNextResponseNotification':complete,'otherMcpSessionRemainedIndependentAndUsable':complete,'ownedShutdownAcknowledgedThenClosedOnlyItsSid':complete,'otherOwnedRuntimeRetainedValue99':complete,'serviceAcceptedNewSidAfterOwnedShutdown':complete,'allCapturedOwnedRuntimeExitsProvenBeforeJobCleanup':complete and len(runtime_exit_proof)==3,'capturedOwnedRuntimePids':list(owned_pids.values()),'deletedSessionDashboardClosed':complete,'ownedSourceAndCliBytesExact':complete,'modelCalls':0,'analyzedSourceExecuted':False,'events':events,'selectedGlobalFileBytesSharedWithCasAndPlansBoundToTheirActor':complete and bool(spec.get('globalConfig')),'projectConfigurationRemainedReadOnly':complete and bool(spec.get('globalConfig')),'sameSessionLanguageSelectionAndOtherSidIsolated':complete,'selectionAloneStartsNoProvider':complete,'privateLogWindowsExplicitSharedHostGrantAndSeparateObservationIds':complete and bool(spec.get('rawLog'))};(out/'http-live-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
