from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-logs-20261024-95e4b76d-session-tests1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-dashboard-logs-session-tests1-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')






prior=w/'validation/integration-20261018/dashboard-logs-20261024-95e4b76d-clippy2';old=json.loads((prior/'source-before.json').read_bytes());inputs={n:sha(w/n) for n in set(old)|{'native/docs/session-dashboard-raw-logs.md'}};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');complete=False;compacted=[];compact=os.environ['SystemRoot']+'\\System32\\compact.exe'
def compact_passed(path,exe,expected_exe,group):
 assert path.parent.resolve()==(w/'target/debug/deps').resolve() and not path.name.startswith(('capture_options-','session_fixed_tools-')) and path.name!='yoke.exe' and not path.is_symlink()
 size=path.stat().st_size;expected=sha(path);assert shutil.disk_usage(w).free>500_000_000+size+64_000_000 and sha(exe)==expected_exe
 if path.stat().st_file_attributes&0x800:
  run('decompress-passed-'+path.name,[compact,'/U','/F','/I','/Q',path],timeout=90);assert path.stat().st_size==size and sha(path)==expected
 run('lzx-passed-'+path.name,[compact,'/C','/F','/EXE:LZX','/I','/Q',path],timeout=90);assert path.stat().st_size==size and sha(path)==expected and sha(exe)==expected_exe
 compacted.append({'path':str(path),'bytes':size,'sha256':expected,'positiveWholeGroup':group,'associatedPassedExecutableSha256':expected_exe});(out/'compression.json').write_text(json.dumps(compacted,indent=2)+'\n')
try:
 assert shutil.disk_usage(w).free>1_200_000_000
 stdout=run('build-session_dashboard_management',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','rustc','--manifest-path','native/Cargo.toml','--test','session_dashboard_management','--profile','test','--locked','--offline','-j','1','--message-format=json'],timeout=600)
 artifacts=[];ownlib=[]
 for line in stdout.splitlines():
  try:m=json.loads(line)
  except ValueError:continue
  if m.get('reason')!='compiler-artifact' or Path(m['manifest_path']).resolve()!=(w/'native/Cargo.toml').resolve():continue
  if m['target']['name']=='session_dashboard_management' and m['target']['kind']==['test']:artifacts.append(m)
  if m['target']['kind']==['lib'] and not m['profile']['test']:ownlib.extend(Path(n) for n in m['filenames'] if n.endswith(('.rlib','.rmeta')))
 assert len(artifacts)==1;artifact=artifacts[0];exe=Path(artifact['executable']);before=sha(exe);cwd=w/'native';data=run('whole-session_dashboard_management',[exe,'--test-threads=1'],timeout=600);assert sha(exe)==before;print(data.decode()[-6000:],flush=True)
 (out/'qualified-artifact.json').write_text(json.dumps({'artifact':artifact,'executableSha256':before},indent=2)+'\n')
 for path in [Path(n) for n in artifact['filenames']]+ownlib:compact_passed(path,exe,before,'whole-session_dashboard_management')
 complete=True
finally:
 result={'complete':complete,'sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'freeBytes':shutil.disk_usage(w).free};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
