from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-storage2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')





base=w/'validation/integration-20261018';proofs=[]
smoke=base/'package-smoke-r1/receipt.json';s=json.loads(smoke.read_bytes());assert s['sourceBytesUnchanged'] and all(r['exitCode']==0 for r in s['commands']);proofs.append((base/'package-smoke-r1/yoke.exe',s['binarySha256'],[smoke],{'positiveOwnedCliCalls':len(s['commands']),'releaseCertified':False}))
p=base/'plan-integrity-development/cli-gates.json';s=json.loads(p.read_bytes());assert s['allCasesPassed'] and s['casesPassed']==14;proofs.append((base/'plan-integrity-f17c8b0-yoke.exe',s['nativeBinarySha256'],[p],{'positiveOwnedCliCases':14,'fullHistoricalBaselineAccepted':False}))
p=base/'directory-moves-final/tested-native-binary.json';s=json.loads(p.read_bytes());provider=base/'directory-moves-final/actual-directory-provider.log';assert b'test result: ok. 1 passed; 0 failed;' in provider.read_bytes();proofs.append((base/'directory-eaf9d59-yoke.exe',s['sha256'],[p,provider],{'positiveActualDirectoryProviderCase':1,'fullHistoricalBaselineAccepted':False}))
inputs=json.loads((base/'move-attributes-20261023-368ec82b-green1/source-before.json').read_bytes());inputs={n:sha(w/n) for n in inputs};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');completed=[];complete=False;initial=shutil.disk_usage(w).free;compact=os.environ['SystemRoot']+'\\System32\\compact.exe'
try:
 for path,expected,records,scope in proofs:
  assert path.resolve().is_relative_to(base.resolve()) and path.suffix=='.exe' and not path.is_symlink() and sha(path)==expected
  size=path.stat().st_size;assert shutil.disk_usage(w).free>500_000_000+size+64_000_000
  proof={str(p.relative_to(w)):sha(p) for p in records}
  run('compact-positive-copy-'+path.parent.name+'-'+path.name,[compact,'/C','/F','/EXE:LZX','/I','/Q',path],timeout=90)
  assert path.stat().st_size==size and sha(path)==expected and all(sha(w/n)==h for n,h in proof.items());completed.append({'path':str(path),'bytes':size,'sha256':expected,'positiveHistoricalQualification':proof,'qualificationScope':scope,'logicalBytesAndSha256Exact':True});(out/'compression.json').write_text(json.dumps(completed,indent=2)+'\n')
 complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'files':len(completed),'initialFreeBytes':initial,'freeBytes':shutil.disk_usage(w).free,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'onlyPreviouslyObservedSuccessfulCliCopies':True,'currentProtectedAndUnvalidatedOutputsUntouched':True,'deletions':False},indent=2)+'\n');assert _scratch_api.CloseHandle(scratch_guard)
