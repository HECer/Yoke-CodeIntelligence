from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-green1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')


prior=w/'validation/integration-20261018/memory-prompts-20261023-526ed1b8-green3/source-before.json';names=set(json.loads(prior.read_bytes()))
names.update(['native/src/compiler_move_attributes.rs','native/src/compiler_move_attribute_tests.rs','native/tests/compiler_move_attributes.rs'])
inputs={n:sha(w/n) for n in sorted(names)};(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');assert shutil.disk_usage(w).free>1_200_000_000
native=w/'target/debug/yoke.exe';complete=False;compression=[];commandlog=(out/'controller-commands.jsonl').open('w',encoding='utf8',buffering=1)
def owned(name,args,**options):
 with contextlib.redirect_stdout(commandlog):data=run(name,args,**options)
 print(json.dumps({'name':name,'exitCode':rows[-1].get('exitCode'),'activeAfterCleanup':rows[-1]['activeAfterCleanup']}),flush=True);return data
def compact_passed(path,label):
 assert path.is_file() and not path.is_symlink() and path.resolve()!=native.resolve() and path.name not in ['capture_options-784339a4da3fe379.exe','session_fixed_tools-0671ac4d8f474009.exe']
 record={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)};assert shutil.disk_usage(w).free>record['bytes']+64_000_000
 owned('compact-passed-'+label,[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',str(path)],timeout=90);assert path.stat().st_size==record['bytes'] and sha(path)==record['sha256'];compression.append({**record,'logicalBytesAndSha256Unchanged':True});(out/'compression.json').write_bytes((json.dumps(compression,indent=2)+'\n').encode())
def harness(data,target,kind):
 result=[]
 for line in data.splitlines():
  try:m=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if m.get('reason')=='compiler-artifact' and Path(m['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and m['target']['name']==target and kind in m['target']['kind'] and m['profile']['test'] and m.get('executable'):result.append(Path(m['executable']))
 assert len(result)==1 and result[0].parent.resolve()==(w/'target/debug/deps').resolve();return result[0]

try:
 cargo=r'C:\Users\Lomi\.cargo\bin\cargo.exe';python=r'C:\Python314\python.exe';helper=[python,'-X','utf8',str(w/'scripts/run_native_tests.py'),'--controlled-test-runner','--locked','--offline']
 import re
 def qualify(data,target,kind):
  result=re.findall(rb'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored; 0 measured; 0 filtered out;',data);assert len(result)==1,(target,result)
  exe=harness(data,target,kind);compact_passed(exe,kind+'-'+target)
  for line in data.splitlines():
   try:m=json.loads(line)
   except ValueError:continue
   if m.get('reason')!='compiler-artifact' or Path(m['manifest_path']).resolve()!=(w/'native/Cargo.toml').resolve() or m.get('executable')!=str(exe) or not m['profile']['test']:continue
   for filename in m['filenames']:
    path=Path(filename)
    if path.suffix=='.pdb':
     exe_hash=sha(exe);compact_passed(path,kind+'-'+target+'-pdb');assert sha(exe)==exe_hash;compression[-1].update({'associatedPassedExecutableSha256':exe_hash,'explicitCargoPdbArtifactAndPositiveWholeHarness':True});(out/'compression.json').write_text(json.dumps(compression,indent=2)+'\n')
 targets=['compiler_move_attributes','compiler_move','compiler_inline_body']
 for target in targets:
  data=owned('test-'+target,[*helper,'--test',target,'-j','1','--message-format','json','--','--test-threads=1'],timeout=900);qualify(data,target,'test')
 data=owned('library-all',[*helper,'--lib','-j','1','--message-format','json','--','--test-threads=1'],timeout=900);qualify(data,'yoke','lib')
 data=owned('main-all',[*helper,'--bin','yoke','-j','1','--message-format','json','--','--test-threads=1'],timeout=600);qualify(data,'yoke','bin')
 owned('clippy-all-targets',[cargo,'clippy','--workspace','--all-targets','--locked','--offline','-j','1','--','-D','warnings'],timeout=600)
 owned('format-complete',[python,'-X','utf8','scripts/native_fmt.py','--check'],timeout=600)
 owned('debug-build',[cargo,'build','--workspace','--locked','--offline','-j','1','--message-format','json'],timeout=600)
 owned('cli-version',[native,'--version'],timeout=30)
 npm=shutil.which('npm.cmd');assert npm
 owned('npm-typecheck',[os.environ['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'run','typecheck'],timeout=240)
 owned('npm-test',[os.environ['SystemRoot']+'\\System32\\cmd.exe','/d','/c',npm,'test'],timeout=300)
 assert all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 result={'complete':complete,'sourceInputs':len(inputs),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'currentCliSha256':sha(native),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'freeBytes':shutil.disk_usage(w).free};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
