from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-storage1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')




prior=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-green1';passed=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-recover1';proof=json.loads((passed/'result.json').read_bytes());assert proof['complete'] and proof['allJobsEmpty']
exe=Path(proof['explicitCargoArtifact']['executable']);exe_hash=sha(exe);testlog=passed/'whole-fresh-attribute-harness.stdout';assert b'test result: ok. 4 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in testlog.read_bytes();inputs=json.loads((prior/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items())
api=ctypes.WinDLL('kernel32',use_last_error=True);api.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)];api.GetCompressedFileSizeW.restype=ctypes.c_ulong

def allocation(path):
 hi=ctypes.c_ulong();lo=api.GetCompressedFileSizeW(str(path),ctypes.byref(hi));return (hi.value<<32)|lo

candidates=[]
for line in (prior/'test-compiler_move_attributes.stdout').read_bytes().splitlines():
 try:m=json.loads(line)
 except ValueError:continue
 if m.get('reason')!='compiler-artifact' or not m['target']['kind']==['lib'] or m['profile']['test']:continue
 for filename in m['filenames']:
  path=Path(filename)
  if path.suffix!='.rlib' or path.parent.resolve()!=(w/'target/debug/deps').resolve() or not path.is_file() or path.is_symlink():continue
  st=path.stat();allocated=allocation(path)
  if st.st_size<1_000_000 or allocated<st.st_size*.35:continue
  assert st.st_mtime_ns<=exe.stat().st_mtime_ns
  candidates.append({'path':str(path),'bytes':st.st_size,'allocationBefore':allocated,'manifestPath':m['manifest_path'],'targetName':m['target']['name'],'associatedPositiveWholeHarness':str(testlog.relative_to(w)),'positiveWholeHarnessSha256':sha(testlog),'associatedPassedExecutable':str(exe),'associatedPassedExecutableSha256':exe_hash,'explicitCargoDependencyArtifact':True})
# First expand only small closed archives; no executables or unqualified link outputs.
candidates.sort(key=lambda r:r['bytes']);(out/'candidates.json').write_text(json.dumps(candidates,indent=2)+'\n');done=[];initial=shutil.disk_usage(w).free;compact=os.environ['SystemRoot']+'\\System32\\compact.exe';complete=False
try:
 for rec in candidates:
  path=Path(rec['path']);assert path.parent.resolve()==(w/'target/debug/deps').resolve() and path.suffix=='.rlib'
  if shutil.disk_usage(w).free<=500_000_000+rec['bytes']+64_000_000:continue
  expected=sha(path);rec['sha256']=expected;assert sha(exe)==exe_hash
  if path.stat().st_file_attributes&0x800:
   run('decompress-cache-'+path.name,[compact,'/U','/F','/I','/Q',path],timeout=90);assert path.stat().st_size==rec['bytes'] and sha(path)==expected
  run('lzx-cache-'+path.name,[compact,'/C','/F','/EXE:LZX','/I','/Q',path],timeout=90)
  assert path.stat().st_size==rec['bytes'] and sha(path)==expected and sha(exe)==exe_hash
  rec.update({'allocationAfter':allocation(path),'logicalBytesAndSha256Exact':True});done.append(rec);(out/'compression.json').write_text(json.dumps(done,indent=2)+'\n');print(json.dumps({'files':len(done),'freeBytes':shutil.disk_usage(w).free}),flush=True)
 complete=True
finally:
 result={'complete':complete,'files':len(done),'initialFreeBytes':initial,'freeBytes':shutil.disk_usage(w).free,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'onlyClosedExplicitCargoRlibDependenciesOfPositiveWholeHarness':True,'executableOrPdbMutation':False,'deletionsOrSystemSettings':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
