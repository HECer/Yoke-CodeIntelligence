from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-compatibility1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-live-'));cwd=configroot=jobroot;client=''
env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for name,relative in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/relative;p.mkdir(parents=True,exist_ok=True);env[name]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))


q=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-qualified1';qualification=json.loads((q/'result.json').read_bytes());assert qualification['complete'] and qualification['allJobsEmpty'];inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items())
native=w/'target/debug/yoke.exe';old=w/'target/move-attributes-20261023-368ec82b-before/yoke.exe';assert sha(native)==qualification['currentCliSha256'] and sha(old)=='b6557f46176014fb0bf872a727984d23f4dd93a38379f71fbed6915bcdc66c19'
project=jobroot/'project';host=jobroot/'host';project.mkdir();host.mkdir();node=Path(shutil.which('node')).resolve();compiler=(w/'node_modules/typescript/lib/typescript.js').resolve()
sources={'source.ts': "import {delta as step} from './dep';\r\nexport function helper(n:number){return {step,n:n+step};}\r\nexport const keep=3;\r\n",'target.ts':'const step=20;\r\nexport const other=step;\r\n','dep.ts':'export const delta=2;\r\n','consumer.ts':"export {helper as renamed,keep} from './source';\r\n",'tsconfig.json':json.dumps({'compilerOptions':{'strict':True,'target':'ES2022','module':'ESNext','moduleResolution':'Bundler','noEmit':True},'files':['source.ts','target.ts','dep.ts','consumer.ts']})+'\n'}
for n,s in sources.items():(project/n).write_bytes(s.encode());(out/n).write_bytes(s.encode())
profile=host/'host.json';requests=host/'requests.json';profile.write_text(json.dumps({'moveCompiler':{'node':str(node),'typescript':str(compiler),'trusted':True}}));requests.write_text(json.dumps([{'operation':'refactor.prepare','args':{'operation':'move','arguments':{'relativePath':'source.ts','namePath':'helper','targetRelativePath':'target.ts'}}}]))
for path in [profile,requests]:shutil.copyfile(path,out/path.name)
complete=False;comparisons=[]
def call(label,binary):
 raw=run(label,[binary,'--root',project,'--timeout','60000','session','--id','owned-legacy-move','--host-profile',profile,'--requests',requests],timeout=90);value=json.loads(raw)['results'][0];assert 'plan' in value;return value
try:
 old_first=call('old-legacy-cold',old);old_warm=call('old-legacy-warm',old);new=call('new-legacy-warm',native)
 def normalized(v):
  v=json.loads(json.dumps(v));v['plan'].pop('createdAt',None);return v
 assert normalized(old_first)==normalized(old_warm)==normalized(new),'Legacy compiler effect/plan/schema changed'
 comparisons.append({'allResultFieldsExactExceptExplicitPlanCreatedAtObservation':True,'effectDigestExact':new['effectDigest']==old_warm['effectDigest'],'planIdentityAndDiffExact':new['plan']['id']==old_warm['plan']['id'] and new['plan']['diff']==old_warm['plan']['diff'],'rawOriginalAndNewWarmResultExact':new==old_warm})
 assert all((project/n).read_bytes()==s.encode() for n,s in sources.items()) and all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'comparisons':comparisons,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'originalSourcesExact':all((project/n).read_bytes()==s.encode() for n,s in sources.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'currentCliSha256':sha(native),'previousCliSha256':sha(old),'ownedParentCalls':len(rows),'modelCalls':0,'analyzedSourceExecuted':False},indent=2)+'\n');print(json.dumps({'complete':complete,'comparisons':comparisons}),flush=True)
