const step=20;
export const other=step;
