from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-live1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')



q=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-qualified1';qualified=json.loads((q/'result.json').read_bytes());assert qualified['complete'] and qualified['allJobsEmpty'];inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());native=w/'target/debug/yoke.exe';assert sha(native)==qualified['currentCliSha256']
project=jobroot/'project';host=jobroot/'host';project.mkdir();host.mkdir();red=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-red1';sources={n:(red/n).read_bytes() for n in ['source.ts','target.ts','dep.ts','consumer.ts','tsconfig.json']}
for n,data in sources.items():(project/n).write_bytes(data);(out/n).write_bytes(data)
for n in ['host.json','requests.json']:shutil.copyfile(red/n,host/n);shutil.copyfile(red/n,out/n)
profile=json.loads((host/'host.json').read_bytes());spec=profile['moveCompiler'];node=Path(spec['node']);compiler=Path(spec['typescript']);complete=False
try:
 raw=run('current-cli-move-attributes',[native,'--root',project,'--timeout','60000','session','--id','owned-attributes','--host-profile',host/'host.json','--requests',host/'requests.json'],timeout=90);value=json.loads(raw)['results'][0];assert 'plan' in value and value['compiler']=='5.8.3' and not value['complete'] and not value['sourceExecuted'];added='\n'.join(line for line in value['plan']['diff'].splitlines() if line.startswith('+') and not line.startswith('+++'));assert 'with { "flavor": "owned \u03c0", mode: "static" }' in added;assert any(r['kind']=='importAttributes' for r in value['sourceRepairs'])
 verified=json.loads(run('independent-tsc-copied-result',[native,'--root',project,'--timeout','60000','verify','--plan',value['plan']['id'],'--trust-project','--command',node,'--arg='+str(compiler.parent/'tsc.js'),'--arg=--noEmit'],timeout=90));assert verified['status']=='passed' and verified['level']=='executed' and verified['exitCode']==0 and verified['sourceIntegrity'] and verified['outputComplete'] and not verified['timedOut']
 assert all((project/n).read_bytes()==data for n,data in sources.items());assert all(sha(w/n)==h for n,h in inputs.items()) and sha(native)==qualified['currentCliSha256'];complete=True
finally:
 result={'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'originalOwnedFixtureBytesExact':all((project/n).read_bytes()==data for n,data in sources.items()),'currentCliSha256':sha(native),'sameSourceFixtureBytesAsOriginalRed':True,'originalAttributesActuallyRetainedInPublishedPlanDiff':complete,'independentTscOnCopiedResultPassed':complete,'ownedApplicationParents':len(rows),'analyzedSourceExecuted':False,'modelCalls':0};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
