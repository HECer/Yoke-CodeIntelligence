import {delta as step} from "./dep" with { "flavor": "owned π", mode: "static" };
export function helper(n:number){return {step,n:n+step};}
export const keep=3;
