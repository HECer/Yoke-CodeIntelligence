from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-red1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-qualified-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')


native=w/'target/debug/yoke.exe';assert sha(native)=='b6557f46176014fb0bf872a727984d23f4dd93a38379f71fbed6915bcdc66c19'
backup=w/'target/move-attributes-20261023-368ec82b-before/yoke.exe';backup.parent.mkdir(exist_ok=False);assert shutil.disk_usage(w).free>1_200_000_000
shutil.copyfile(native,backup);assert sha(backup)==sha(native)
run('compact-qualified-cli-copy',[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',backup],timeout=90);assert sha(backup)==sha(native)
project=jobroot/'project';host=jobroot/'host';project.mkdir();host.mkdir()
sources={'source.ts': 'import {delta as step} from "./dep" with { "flavor": "owned \u03c0", mode: "static" };\r\nexport function helper(n:number){return {step,n:n+step};}\r\nexport const keep=3;\r\n','target.ts':'const step=20;\r\nexport const other=step;\r\n','dep.ts':'export const delta=2;\r\n','consumer.ts':'export {helper as renamed,keep} from "./source";\r\n','tsconfig.json':json.dumps({'compilerOptions':{'strict':True,'target':'ES2022','module':'ESNext','moduleResolution':'Bundler','noEmit':True},'files':['source.ts','target.ts','consumer.ts','dep.ts']})+'\n'}
for name,value in sources.items():
 (project/name).write_bytes(value.encode());(out/name).write_bytes(value.encode())
node=Path(shutil.which('node')).resolve();compiler=(w/'node_modules/typescript/lib/typescript.js').resolve();profile={'moveCompiler':{'node':str(node),'typescript':str(compiler),'trusted':True}};request=[{'operation':'refactor.prepare','args':{'operation':'move','arguments':{'relativePath':'source.ts','namePath':'helper','targetRelativePath':'target.ts'}}}]
for name,value in [('host.json',profile),('requests.json',request)]:
 (host/name).write_bytes(json.dumps(value).encode());shutil.copyfile(host/name,out/name)
complete=False
try:
 reply=run('old-cli-move-attributes',[native,'--root',project,'--timeout','60000','session','--id','owned-attributes','--host-profile',host/'host.json','--requests',host/'requests.json'],expected=None,timeout=90)
 print(reply.decode()[:2000]);print((out/'old-cli-move-attributes.stderr').read_text()[:2000]);assert all((project/n).read_bytes()==s.encode() for n,s in sources.items());complete=True
finally:
 (out/'result.json').write_text(json.dumps({'complete':complete,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'originalSourcesExact':all((project/n).read_bytes()==s.encode() for n,s in sources.items()),'oldCliSha256':sha(native),'backupSha256':sha(backup),'freeBytes':shutil.disk_usage(w).free,'fixtureRoot':str(jobroot),'modelCalls':0,'analyzedSourceExecuted':False},indent=2)+'\n');assert _scratch_api.CloseHandle(scratch_guard)
