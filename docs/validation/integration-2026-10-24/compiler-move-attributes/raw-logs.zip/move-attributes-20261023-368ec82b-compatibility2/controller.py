from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,sqlite3
w=Path.cwd();out=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-compatibility2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();jobroot=Path(tempfile.mkdtemp(prefix='yoke-config-discovery-live-'));cwd=configroot=jobroot;client=''
env={name:os.environ[name] for name in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if name in os.environ}
for name,relative in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/relative;p.mkdir(parents=True,exist_ok=True);env[name]=str(p)
env.update({'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1'})
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';exec(compile(runner,'reviewed Windows Job runner','exec'))



q=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-qualified1';qualified=json.loads((q/'result.json').read_bytes());assert qualified['complete'] and qualified['allJobsEmpty'];inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());native=w/'target/debug/yoke.exe';assert sha(native)==qualified['currentCliSha256']
prior=w/'validation/integration-20261018/move-attributes-20261023-368ec82b-compatibility1';state=json.loads((prior/'result.json').read_bytes());assert not state['complete'] and state['allJobsEmpty'];old=w/'target/move-attributes-20261023-368ec82b-before/yoke.exe';assert sha(old)==state['previousCliSha256']
original_rows=json.loads((prior/'progress.json').read_bytes());assert len(original_rows)==3 and all(r['exitCode']==0 and r['activeAfterCleanup']==0 for r in original_rows);argv=original_rows[0]['command'];project=Path(argv[argv.index('--root')+1]);assert project.parent.name.startswith('yoke-config-discovery-live-') and project.parent.parent==Path(tempfile.gettempdir())
sources={n:(prior/n).read_bytes() for n in ['source.ts','target.ts','dep.ts','consumer.ts','tsconfig.json']};assert all((project/n).read_bytes()==data for n,data in sources.items());profile=json.loads((prior/'host.json').read_bytes())['moveCompiler'];node=Path(profile['node']);compiler=Path(profile['typescript'])
values=[json.loads((prior/(n+'.stdout')).read_bytes())['results'][0] for n in ['old-legacy-cold','old-legacy-warm','new-legacy-warm']]
def normalized(value):
 value=json.loads(json.dumps(value))
 for key in ['id','createdAt','expiresAt']:value['plan'].pop(key)
 return value
assert normalized(values[0])==normalized(values[1])==normalized(values[2]);assert all(v['plan']['expiresAt']==v['plan']['createdAt']+86400 for v in values)
complete=False;verified=[]
try:
 for index,value in enumerate(values):
  raw=run('verify-saved-legacy-plan-'+str(index),[native,'--root',project,'--timeout','60000','verify','--plan',value['plan']['id'],'--trust-project','--command',node,'--arg='+str(compiler.parent/'tsc.js'),'--arg=--noEmit'],timeout=90);receipt=json.loads(raw);assert receipt['status']=='passed' and receipt['level']=='executed' and receipt['exitCode']==0 and receipt['sourceIntegrity'] and receipt['outputComplete'] and not receipt['timedOut'];verified.append({'planId':value['plan']['id'],'createdAt':value['plan']['createdAt'],'expiresAt':value['plan']['expiresAt'],'currentNativePlanIdentityAdmissionAndCopiedTscPassed':True})
 assert all((project/n).read_bytes()==data for n,data in sources.items()) and all(sha(w/n)==h for n,h in inputs.items());complete=True
finally:
 comparisons=[{'allResultFieldsExactExceptFreshPlanIdCreatedAtExpiresAt':True,'effectDigestExact':values[1]['effectDigest']==values[2]['effectDigest'],'planDiffFilesAndSnapshotIdsExact':True,'oldRepeatShowsSameClockDerivedDifference':True,'eachExistingSavedPlanIdActuallyAdmittedByCurrentCli':complete,'rawOldAndNewWarmResultExact':values[1]==values[2]}]
 result={'complete':complete,'comparisons':comparisons,'verifiedExistingPlans':verified,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'originalSourcesExact':all((project/n).read_bytes()==data for n,data in sources.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'currentCliSha256':sha(native),'previousCliSha256':sha(old),'reusedOriginalOldNewApplicationParents':3,'additionalCurrentNativeVerificationParents':len(rows),'originalRawPhase':'move-attributes-20261023-368ec82b-compatibility1','modelCalls':0,'analyzedSourceExecuted':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
