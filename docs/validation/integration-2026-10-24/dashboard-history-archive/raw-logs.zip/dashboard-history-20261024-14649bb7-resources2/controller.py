from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-history-20261024-14649bb7-resources2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-dashboard-history-resources2-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')






q=w/'validation/integration-20261018/dashboard-history-20261024-14649bb7-gates4';proof=json.loads((q/'result.json').read_bytes());assert proof['complete'] and proof['allJobsEmpty'] and proof['sourceInputsUnchanged'];inputs=json.loads((q/'source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());paths=[]
for line in (q/'clippy-all-targets-metadata-only.stdout').read_bytes().splitlines():
 try:m=json.loads(line)
 except ValueError:continue
 if m.get('reason')=='compiler-artifact' and Path(m['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and m['target']['kind']==['lib'] and not m['profile']['test']:
  paths.extend(Path(n) for n in m['filenames'] if n.endswith('.rmeta'))
paths=list(dict.fromkeys(paths));assert paths;complete=False;files=[]
try:
 for path in paths:
  assert path.parent.resolve()==(w/'target/debug/deps').resolve() and path.name.startswith('libyoke-') and path.suffix=='.rmeta' and path.stat().st_nlink==1
  size=path.stat().st_size;digest=sha(path);assert size>0 and shutil.disk_usage(w).free>500_000_000+size+64_000_000
  if path.stat().st_file_attributes&0x800:run('decompress-checked-own-'+path.name,[os.environ['SystemRoot']+'\\System32\\compact.exe','/U','/F','/I','/Q',path],timeout=90);assert sha(path)==digest
  run('lzx-checked-own-'+path.name,[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',path],timeout=90);assert sha(path)==digest and path.stat().st_size==size;files.append({'path':str(path),'bytes':size,'sha256':digest,'positiveProducer':'current all-target Clippy-Dwarnings metadata artifact, not a native test result'})
 complete=True
finally:
 result={'complete':complete,'files':files,'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'freeBytes':shutil.disk_usage(w).free,'protectedOutputsAccessed':False,'deletionOrPolicyChange':False};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
