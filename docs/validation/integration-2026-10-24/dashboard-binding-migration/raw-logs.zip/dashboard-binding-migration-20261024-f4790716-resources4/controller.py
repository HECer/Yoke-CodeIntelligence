from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();out=w/'validation/integration-20261018/dashboard-binding-migration-20261024-f4790716-resources4';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-dashboard-binding-cli-resources4-'))
env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
for key,name in [('HOME','home'),('USERPROFILE','home'),('APPDATA','home/AppData/Roaming'),('LOCALAPPDATA','home/AppData/Local'),('TEMP','tmp'),('TMP','tmp')]:
 p=jobroot/name;p.mkdir(parents=True,exist_ok=True);env[key]=str(p)
env.update({'CARGO_HOME':r'C:\Users\Lomi\.cargo','RUSTUP_HOME':r'C:\Users\Lomi\.rustup','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'NUL','GIT_TERMINAL_PROMPT':'0','DO_NOT_TRACK':'1','CARGO_NET_OFFLINE':'true'});env['PATH']=r'C:\Users\Lomi\.cargo\bin'+os.pathsep+env['PATH']
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk-headroom stop','exec'))

# Hold only the newly owned compiler scratch root. Children remain mutable.
_scratch_api=ctypes.WinDLL('kernel32',use_last_error=True);_scratch_api.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_void_p];_scratch_api.CreateFileW.restype=ctypes.c_void_p;_scratch_api.CloseHandle.argtypes=[ctypes.c_void_p];_scratch_api.CloseHandle.restype=ctypes.c_int
scratch=Path(env['TEMP']);assert scratch.parent==jobroot and scratch.is_dir() and not scratch.is_symlink();scratch_guard=_scratch_api.CreateFileW(str(scratch),0x80,3,None,3,0x02200000,None);assert scratch_guard and scratch_guard!=ctypes.c_void_p(-1).value
probe=scratch/'owned-link-scratch-admission.txt'
with probe.open('xb') as f:f.write(b'owned-link-scratch-admission\n');f.flush();os.fsync(f.fileno())
assert probe.read_bytes()==b'owned-link-scratch-admission\n';(out/'compiler-scratch-guard.json').write_text(json.dumps({'path':str(scratch),'createOnlyWriteAdmissionPassed':True,'lifetimeDirectoryHandleOmitsDeleteSharing':True,'directoryChildrenRemainMutable':True,'systemPolicyOrPrivilegesChanged':False},indent=2)+'\n')






inputs=json.loads((w/'validation/integration-20261018/dashboard-binding-migration-20261024-f4790716-gates2/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n');complete=False;compacted=[]
try:
 assert shutil.disk_usage(w).free>750_000_000
 stdout=run('fresh-native-cli-build',[r'C:\Users\Lomi\.cargo\bin\cargo.exe','build','--manifest-path','native/Cargo.toml','--bin','yoke','--locked','--offline','-j','1','--message-format=json'],timeout=600);artifacts=[]
 for line in stdout.splitlines():
  try:value=json.loads(line)
  except ValueError:continue
  if value.get('reason')=='compiler-artifact' and Path(value['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and value['target']['kind']==['bin'] and value['target']['name']=='yoke' and not value['profile']['test']:artifacts.append(value)
 assert len(artifacts)==1;artifact=artifacts[0];cli=Path(artifact['executable']);assert cli.resolve()==(w/'target/debug/yoke.exe').resolve();expected=sha(cli)
 assert b'0.5.0' in run('fresh-cli-version',[cli,'--version'],timeout=30)
 assert b'host-documents' in run('fresh-cli-help',[cli,'--help'],timeout=30)
 assert b'binding-plan' in run('fresh-host-documents-help',[cli,'host-documents','--help'],timeout=30)
 assert sha(cli)==expected;(out/'built-cli.json').write_text(json.dumps({'sha256':expected,'artifact':artifact,'buildPassed':True,'versionAndHelpPassed':True,'hostDocumentsHelpPassed':True,'resourceBootstrapOnly':True,'functionalLiveAcceptancePending':True},indent=2)+'\n')
 for path in sorted(map(Path,artifact['filenames']),key=lambda p:p.suffix!='.pdb'):
  assert path.parent.resolve()==(w/'target/debug').resolve() and path.name in ['yoke.exe','yoke.pdb'];size=path.stat().st_size;digest=sha(path);assert shutil.disk_usage(w).free>500_000_000+size+64_000_000
  if path.stat().st_file_attributes&0x800:run('decompress-built-cli-'+path.name,[os.environ['SystemRoot']+'\\System32\\compact.exe','/U','/F','/I','/Q',path],timeout=90);assert sha(path)==digest
  run('lzx-built-cli-'+path.name,[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',path],timeout=90);assert sha(path)==digest and path.stat().st_size==size and sha(cli)==expected;compacted.append({'path':str(path),'bytes':size,'sha256':digest,'positiveScope':'fresh Cargo build plus version/help and host-documents help'})
 complete=True
finally:
 result={'complete':complete,'currentSourceCliBuildAndHelpOnlyNotFunctionalAcceptance':True,'compacted':compacted,'currentSourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'freeBytes':shutil.disk_usage(w).free,'noDeletionOrPolicyChange':True};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert _scratch_api.CloseHandle(scratch_guard)
