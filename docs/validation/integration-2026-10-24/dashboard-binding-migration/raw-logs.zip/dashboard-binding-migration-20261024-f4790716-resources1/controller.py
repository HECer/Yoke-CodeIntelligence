from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();vroot=w/'validation/integration-20261018';out=vroot/'dashboard-binding-migration-20261024-f4790716-resources1';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-binding-evidence-compression-'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk stop','exec'))
inputs=json.loads((vroot/'dashboard-binding-migration-20261024-f4790716-gates2/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());before=shutil.disk_usage(w).free;records=[];candidates=[];seen=set();complete=False
indexes=[('docs/validation/integration-2026-10-24/dashboard-project-recovery/raw-index.json','dashboard-project-recovery-20261024-5d99de56-'),('docs/validation/integration-2026-10-24/dashboard-project-files/raw-index.json','dashboard-project-files-20261024-4f81de1e-'),('docs/validation/integration-2026-10-24/dashboard-owned-shutdown/raw-index.json','dashboard-shutdown-20261024-2472bc87-'),('docs/validation/integration-2026-10-24/dashboard-raw-logs/raw-index.json','dashboard-logs-20261024-95e4b76d-'),('docs/validation/integration-2026-10-23/prompt-memories/raw-index.json','memory-prompts-20261023-526ed1b8-')]
for index,prefix in indexes:
 data=json.loads((w/index).read_bytes());assert isinstance(data,dict)
 for row in data['members']:
  relative=Path(row['path']);assert not relative.is_absolute() and '..' not in relative.parts and relative.parts[0].startswith(prefix)
  path=vroot/relative
  if path in seen or not path.exists() or path.suffix not in ['.stdout','.stderr','.json','.py','.html','.md','.rs','.ts']:continue
  seen.add(path);resolved=path.resolve();assert resolved.is_relative_to(vroot.resolve())
  for parent in path.parents:
   if parent==vroot:break
   assert not parent.is_symlink() and not parent.is_junction()
  meta=path.stat()
  if not path.is_file() or path.is_symlink() or path.is_junction() or meta.st_nlink!=1 or meta.st_file_attributes&0xc00:continue
  if not 128_000<=meta.st_size<=16_000_000:continue
  assert meta.st_size==row['bytes'] and sha(path)==row['sha256'],path
  candidates.append({'path':str(path),'bytes':meta.st_size,'sha256':row['sha256'],'publicIndex':index})
(out/'candidates.json').write_text(json.dumps(candidates,indent=2)+'\n');print(json.dumps({'verifiedCandidates':len(candidates),'logicalBytes':sum(r['bytes'] for r in candidates),'beforeFreeBytes':before}),flush=True)
try:
 for row in sorted(candidates,key=lambda r:r['bytes'],reverse=True):
  if shutil.disk_usage(w).free>1_350_000_000:break
  path=Path(row['path']);assert sha(path)==row['sha256'];assert shutil.disk_usage(w).free>500_000_000+row['bytes']+64_000_000
  with (out/'operation-log.txt').open('a',encoding='utf-8') as log,contextlib.redirect_stdout(log):
   run('lzx-owned-evidence-'+str(len(records)),[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',path],timeout=60)
  assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256'];records.append(row);(out/'compression.json').write_text(json.dumps(records,indent=2)+'\n')
 complete=True
finally:
 result={'complete':complete,'onlyPublicIndexVerifiedOwnEvidenceCopies':True,'files':len(records),'beforeFreeBytes':before,'afterFreeBytes':shutil.disk_usage(w).free,'noDeletionOrSystemPolicyChange':True,'protectedOutputsAndAnalyzedFixtureUntouched':True,'sourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows)};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
