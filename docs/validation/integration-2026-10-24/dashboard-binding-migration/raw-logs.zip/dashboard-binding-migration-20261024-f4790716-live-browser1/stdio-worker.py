import hashlib,http.client,json,os,queue,subprocess,sys,threading,time,urllib.parse
from pathlib import Path
spec=json.loads(Path(sys.argv[1]).read_bytes());out=Path(spec['out']);native=Path(spec['native']);source=Path(spec['root']);profile=Path(spec['hostProfilePath']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(native)==spec['cliSha256'];source_before=sha(source/'main.rs');events=[];notifications=[];pending=queue.Queue();process=None;reader=None;complete=False;stderr=None;dashboard=None;capability=None;outcome={};runtime_handle=None;runtime_api=None

def reader_main():
 try:
  while True:
   line=process.stdout.readline(16_000_001)
   if not line:break
   assert len(line)<=16_000_000
   pending.put(json.loads(line))
 except BaseException:pending.put({'ownedReaderError':True})
 finally:pending.put({'ownedReaderEof':True})
def next_frame(timeout=8):
 item=pending.get(timeout=timeout);assert not item.get('ownedReaderError') and not item.get('ownedReaderEof'),'Owned native stdio ended unexpectedly';return item
def rpc(identifier,method,params=None):
 message={'jsonrpc':'2.0','id':identifier,'method':method,'params':params or {}};process.stdin.write(json.dumps(message,ensure_ascii=False).encode()+b'\n');process.stdin.flush();until=time.monotonic()+10
 while time.monotonic()<until:
  item=next_frame(min(8,max(.01,until-time.monotonic())))
  if item.get('method')=='notifications/tools/list_changed':notifications.append(item);continue
  assert item.get('id')==identifier and 'error' not in item,'Unexpected native protocol response';return item
 raise TimeoutError('Owned native protocol response deadline')
def tool(identifier,name,args=None):
 if spec.get('protocolProfile')=='native' and name in ('open_dashboard','get_current_config'):
  args={'operation':{'open_dashboard':'openDashboard','get_current_config':'configuration'}[name],'args':args or {}};name='ci_session'
 reply=rpc(identifier,'tools/call',{'name':name,'arguments':args or {}});assert reply['result']['isError'] is False,'Owned native tool refused';value=reply['result'].get('structuredContent')
 if value is None:value=json.loads(reply['result']['content'][0]['text'])
 assert value['status']=='ok','Owned native tool response is not complete';return value['data']
def dashboard_request(method,path,body=None):
 connection=http.client.HTTPConnection(dashboard.hostname,dashboard.port,timeout=6);headers={'Authorization':'Bearer '+capability,'Origin':f'http://{dashboard.hostname}:{dashboard.port}'}
 if body is not None:headers['Content-Type']='application/json'
 connection.request(method,path,body=None if body is None else json.dumps(body,ensure_ascii=False).encode(),headers=headers);response=connection.getresponse();status=response.status;raw=response.read(4_000_001);connection.close();assert len(raw)<=4_000_000
 try:value=json.loads(raw)
 except json.JSONDecodeError:
  assert status>=400,'Successful native response must be JSON';value={'httpErrorBodyWasPlainText':True}
 return status,value
def state():
 status,value=dashboard_request('GET','/api/state');assert status==200;return value
def manage(action,selected=None):
 selected=selected or state();body={'id':os.urandom(32).hex(),'sessionStateSha256':selected['view']['management']['sessionStateSha256'],'project':selected['view']['activeProject'],'action':action};status,value=dashboard_request('POST','/api/manage',body);events.append({'kind':action['kind'],'status':status,'notApplied':value.get('notApplied')});return status,value

def host_approve(plan_id,label):
 assert len(plan_id)==64 and all(c in '0123456789abcdef' for c in plan_id)
 value=host_command(label+'-approve',['approve',plan_id]);assert value['approvedPlanId']==plan_id
def host_verify(plan_id,after_hash,label):
 assert len(after_hash)==64 and all(c in '0123456789abcdef' for c in after_hash)
 code="from pathlib import Path;import hashlib;assert hashlib.sha256(Path('project.yaml').read_bytes()).hexdigest()=="+repr(after_hash)+";print('Owned inert configuration bytes verified')"
 value=host_command(label+'-verify',['verify','--plan',plan_id,'--command',r'C:\Python314\python.exe','--arg=-I','--arg=-c','--arg='+code,'--trust-project']);assert value['status']=='passed' and value['level']=='executed'
def host_command(label,args):
 command=[str(native),'--root',str(source),'--timeout','30000',*args]
 result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40,creationflags=0x08000000)
 assert len(result.stdout)<2_000_000 and len(result.stderr)<2_000_000
 (out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr)
 assert result.returncode==0,(label,result.returncode);return json.loads(result.stdout)

try:
 argv=[str(native),'--root',str(source),'--timeout','30000','--max-bytes','4000000','--allow-writes','serve-session','--profile',spec.get('protocolProfile','serena'),'--id','dashboard-stdio-owned','--host-profile',str(profile)]
 if spec.get('python'):argv.extend(['--python',spec['python'],'--trust-python'])
 if spec.get('serverConfig'):argv.extend(['--language-server-config',spec['serverConfig'],'--trust-servers'])
 stderr=(out/'native-stdio.stderr').open('wb');process=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,creationflags=0x08000000);reader=threading.Thread(target=reader_main);reader.start()
 initial=rpc(1,'initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'owned-dashboard-live-acceptance','version':'0.5.0'}});assert initial['result']['serverInfo']['version']=='0.5.0'
 catalog=rpc(2,'tools/list')['result']['tools']
 if spec.get('protocolProfile')=='native':assert 'ci_find' in [t['name'] for t in catalog]
 else:
  description=next(t['description'] for t in catalog if t['name']=='open_dashboard');assert 'management' in description and 'owning transport driver' in description
 opened=tool(3,'open_dashboard');dashboard=urllib.parse.urlparse(opened['url']);capability=dashboard.fragment;assert dashboard.scheme=='http' and dashboard.hostname=='127.0.0.1' and len(capability)==64 and opened['browserOpened'] is False
 assert opened['capabilities']['memoryEditing'] is True and opened['capabilities']['mcpShutdown'] is True and opened['capabilities']['serviceShutdown'] is False;original=state();assert original['view']['management']['enabled'] is True
 if spec.get('python'):
  runtime_session=tool(30,'get_current_config')['sessionId'];cell=tool(31,'serena_repl',{'session_id':runtime_session,'code':'owned_marker = 41\nprint(owned_marker)'});assert cell['stdout']=='41\n'
 if spec.get('python'):
  import ctypes
  pid_value=tool(67,'serena_repl',{'session_id':runtime_session,'code':'import os\nprint(os.getpid())'})['stdout'];owned_pid=int(pid_value.strip());assert owned_pid!=process.pid
  runtime_api=ctypes.WinDLL('kernel32',use_last_error=True);runtime_api.OpenProcess.argtypes=[ctypes.c_ulong,ctypes.c_int,ctypes.c_ulong];runtime_api.OpenProcess.restype=ctypes.c_void_p;runtime_api.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong];runtime_api.WaitForSingleObject.restype=ctypes.c_ulong;runtime_api.CloseHandle.argtypes=[ctypes.c_void_p];runtime_api.CloseHandle.restype=ctypes.c_int;runtime_api.QueryFullProcessImageNameW.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_ulong)];runtime_api.QueryFullProcessImageNameW.restype=ctypes.c_int
  runtime_handle=runtime_api.OpenProcess(0x00101000,False,owned_pid);assert runtime_handle;buffer=ctypes.create_unicode_buffer(32768);length=ctypes.c_ulong(len(buffer));assert runtime_api.QueryFullProcessImageNameW(runtime_handle,0,buffer,ctypes.byref(length));assert Path(buffer.value).resolve()==Path(spec['python']).resolve();assert runtime_api.WaitForSingleObject(runtime_handle,0)==258;outcome['ownedRuntimePid']=owned_pid
 status,created=manage({'kind':'createMemory','name':'owned/\u03c0','content':'first\r\n<script>inert</script>\r\n\U0001f980 e\u0301'});assert status==200;first=created['data']['note']['id'];status,read=manage({'kind':'readMemory','name':'owned/\u03c0'});assert status==200 and read['data']['note']['content']=='first\r\n<script>inert</script>\r\n\U0001f980 e\u0301'
 status,written=manage({'kind':'writeMemory','name':'owned/\u03c0','content':'second\r\n','expectedRevision':first});assert status==200;second=written['data']['note']['id'];status,stale=manage({'kind':'writeMemory','name':'owned/\u03c0','content':'must not overwrite','expectedRevision':first});assert status==409 and stale['notApplied'] is True
 before_mode=state();selected_modes=['editing','no-memories']+(['hide-find'] if spec.get('protocolProfile')=='native' else []);status,changed=manage({'kind':'switchModes','modes':selected_modes});assert status==200
 # No further stdio request is sent until the asynchronous notification arrives.
 notice=next_frame();assert notice.get('method')=='notifications/tools/list_changed';notifications.append(notice);outcome['catalogNotificationWhileStdioInputIdle']=True
 config=tool(4,'get_current_config');assert 'no-memories' in config['modes'];catalog=rpc(5,'tools/list')['result']['tools'];assert ('ci_find' if spec.get('protocolProfile')=='native' else 'write_memory') not in [v['name'] for v in catalog]
 status,denied=manage({'kind':'createMemory','name':'denied','content':'not allowed'});assert status!=200
 status,stale_session=manage({'kind':'createMemory','name':'stale-session','content':'must not apply'},before_mode);assert status==409 and stale_session['notApplied'] is True
 status,restored=manage({'kind':'switchModes','modes':['editing']});assert status==200;notice=next_frame();assert notice.get('method')=='notifications/tools/list_changed';notifications.append(notice)
 status,renamed=manage({'kind':'renameMemory','oldName':'owned/\u03c0','newName':'owned/renamed','expectedRevision':second});assert status==200;current=renamed['data']['note']['id'];status,deleted=manage({'kind':'deleteMemory','name':'owned/renamed','expectedRevision':current});assert status==200
 status,listed=manage({'kind':'listMemories'});assert status==200 and listed['data']['items']==[]
 if spec.get('python'):
  cell=tool(32,'serena_repl',{'session_id':runtime_session,'code':'owned_marker += 1\nprint(owned_marker)'});assert cell['stdout']=='42\n';outcome['persistentRuntimeStateKeptAcrossDashboardCalls']=True
 if spec.get('serverConfig'):
  log=Path(spec['providerLog']);assert not log.exists(),'A provider started without a semantic request'
  assert state()['view']['selectedBackends']==['angular','typescript']
  status,denied=manage({'kind':'selectLanguageServers','selection':{'kind':'backends','ids':['rust']}});assert status==403 and denied['notApplied'] is True
  status,selected=manage({'kind':'selectLanguageServers','selection':{'kind':'backends','ids':['typescript','angular']}});assert status==200 and selected['sourceWritten'] is False
  configured=tool(50,'get_current_config');assert configured['dashboardLanguageSelection']['selectedBackends']==['typescript','angular'] and not log.exists()
  if spec.get('protocolProfile')=='native':
   hovered=tool(51,'ci_find',{'languageServer':{'path':'main.rs','offset':0,'operation':'hover'}});assert hovered['selectedBackendId']=='typescript';assert log.exists();outcome['actualSelectedProviderDispatch']=True
  before=log.read_bytes() if log.exists() else b''
  status,disabled=manage({'kind':'selectLanguageServers','selection':{'kind':'legacy','languages':[]}});assert status==200
  configured=tool(52,'get_current_config');assert configured['dashboardLanguageSelection']['selectedBackends'] is None and configured['dashboardLanguageSelection']['selectedLegacyLanguages']==[]
  if spec.get('protocolProfile')=='native':
   refused=rpc(53,'tools/call',{'name':'ci_find','arguments':{'languageServer':{'path':'main.rs','offset':0,'operation':'hover'}}})['result'];value=refused.get('structuredContent')
   if value is None:value=json.loads(refused['content'][0]['text'])
   assert value['status']=='error','Disabled semantic provider returned a complete empty result'
  assert (log.read_bytes() if log.exists() else b'')==before
  status,reset=manage({'kind':'resetLanguageServers'});assert status==200 and state()['view']['selectedBackends']==['angular','typescript']
  if spec.get('python'):
   cell=tool(54,'serena_repl',{'session_id':runtime_session,'code':'owned_marker += 1\nprint(owned_marker)'});assert cell['stdout']=='43\n';outcome['persistentRuntimeStateKeptAcrossLanguageCalls']=True
  outcome['explicitLanguageGrantOrderDisableResetOnOriginalSession']=True;outcome['selectionAloneStartsNoProvider']=True
 if spec.get('rawLog'):
  import base64
  rawlog=Path(spec['rawLog']);assert opened['capabilities']['rawLogs'] is True
  assert state()['view']['management']['rawLogs']['automaticCapture'] is False
  raw=b'owned private live marker\r\n<script>window.untrustedExecuted=true</script>\r\n\xff'
  assert not rawlog.exists();rawlog.write_bytes(raw)
  with rawlog.open('ab') as active:
   active.write(b'active-writer\r\n');active.flush();os.fsync(active.fileno())
   expected=raw+b'active-writer\r\n'
   status,observed=manage({'kind':'readLog','logId':'owned-private','maxBytes':64});assert status==200
  a=observed['data']['observation'];assert base64.b64decode(a['base64'])==expected[-64:] and a['sha256']==hashlib.sha256(expected[-64:]).hexdigest()
  assert a['immutableSnapshot'] is False and a['currentPathGenerationGuaranteed'] is False and a['textLossy'] is True
  assert observed['fileChanged'] is False and observed['metadataChanged'] is False and rawlog.read_bytes()==expected
  rawlog.rename(rawlog.with_suffix('.rotated'))
  replacement=b'owned private rotated marker\r\n<script>window.untrustedExecuted=true</script>\r\n\xff'
  with rawlog.open('xb') as f:f.write(replacement)
  status,newer=manage({'kind':'readLog','logId':'owned-private'});assert status==200
  b=newer['data']['observation'];assert base64.b64decode(b['base64'])==replacement and b['openedFileIdentity']!=a['openedFileIdentity'] and b['observationId']!=a['observationId']
  status,refused=manage({'kind':'readLog','logId':'owned-private','maxBytes':1025});assert status==422 and 'data' not in refused
  status,refused=manage({'kind':'readLog','logId':'owned-private','path':str(rawlog)});assert status==400
  observed_state=state();assert 'owned private rotated marker' not in json.dumps(observed_state) and 'owned private live marker' not in json.dumps(observed_state)
  assert any(r['operation']=='dashboard.logs.read' for r in observed_state['activity'])
  if spec.get('python'):
   cell=tool(66,'serena_repl',{'session_id':runtime_session,'code':'owned_marker += 1\nprint(owned_marker)'});assert cell['stdout']=='44\n';outcome['persistentRuntimeStateKeptAcrossRawLogCalls']=True
  outcome['explicitRawLogActiveWriterRotationExactBytesAndNoActivityBody']=True
 if spec.get('globalConfig'):
  global_config=Path(spec['globalConfig']);project_config=Path(spec['projectConfig']);global_before=global_config.read_bytes();project_before=project_config.read_bytes()
  assert opened['capabilities']['configurationReading'] is True and opened['capabilities']['configurationEditing'] is True and opened['capabilities']['projectConfigurationEditing'] is True
  def document_action(action):return manage({'kind':'document','request':action})
  status,loaded=document_action({'kind':'read','documentId':'host-settings'});assert status==200 and loaded['data']['document']['content'].encode()==global_before
  proposed=global_before+b'# explicit inert change\r\nscript: <script>inert</script>\r\n'
  status,planned=document_action({'kind':'plan','documentId':'host-settings','expectedRevision':loaded['data']['document']['revision'],'content':proposed.decode()});assert status==200 and planned['data']['plan']['afterHash']==hashlib.sha256(proposed).hexdigest() and global_config.read_bytes()==global_before
  status,saved=document_action({'kind':'apply','documentId':'host-settings','planId':planned['data']['plan']['id']});assert status==200 and saved['fileChanged'] is True and saved['sourceWritten'] is False and global_config.read_bytes()==proposed
  status,loaded=document_action({'kind':'read','documentId':'host-settings'});assert status==200
  status,planned=document_action({'kind':'plan','documentId':'host-settings','expectedRevision':loaded['data']['document']['revision'],'content':'stale reviewed draft\r\n'});assert status==200
  competing=proposed+b'# explicit competing fixture write\r\n';global_config.write_bytes(competing)
  status,refused=document_action({'kind':'apply','documentId':'host-settings','planId':planned['data']['plan']['id']});assert status==422 and global_config.read_bytes()==competing
  status,journals=document_action({'kind':'pending','documentId':'host-settings'});assert status==200 and journals['data']['journals']==[]
  status,project_doc=document_action({'kind':'read','documentId':'project-settings'});assert status==200 and project_doc['data']['document']['content'].encode()==project_before
  project_proposed=project_before+b'# explicitly approved inert project settings\r\n'
  status,project_plan=document_action({'kind':'plan','documentId':'project-settings','expectedRevision':project_doc['data']['document']['revision'],'content':project_proposed.decode()});assert status==200 and project_config.read_bytes()==project_before
  project_plan=project_plan['data']['plan'];workspace_id=project_plan['workspacePlanId'];assert workspace_id!=project_plan['id'] and project_plan['afterHash']==hashlib.sha256(project_proposed).hexdigest()
  apply={'kind':'apply','documentId':'project-settings','planId':project_plan['id']}
  status,denied=document_action(apply);assert status==422 and denied['notApplied'] is True and project_config.read_bytes()==project_before
  host_approve(workspace_id,'project-gates')
  status,inspected=document_action({'kind':'inspect','documentId':'project-settings','planId':project_plan['id']});assert status==200 and inspected['data']['plan']['workspaceGates']['hostApprovalReady'] is True and inspected['data']['plan']['workspaceGates']['executedVerificationReady'] is False
  status,denied=document_action(apply);assert status==422 and denied['notApplied'] is True and project_config.read_bytes()==project_before
  host_verify(workspace_id,project_plan['afterHash'],'project-gates')
  status,inspected=document_action({'kind':'inspect','documentId':'project-settings','planId':project_plan['id']});assert status==200 and inspected['data']['plan']['workspaceGates']['executedVerificationReady'] is True
  status,applied=document_action(apply);assert status==200 and applied['fileChanged'] is True and applied['sourceWritten'] is True and project_config.read_bytes()==project_proposed
  assert applied['data']['receipt']['planId']==workspace_id and applied['data']['receipt']['status']=='applied'
  status,recovery=document_action({'kind':'pending','documentId':'project-settings'});assert status==200 and recovery['data']['workspaceRecoveryAvailable'] is True and recovery['data']['complete'] is True
  journals=recovery['data']['journals'];assert len(journals)==1;review=journals[0]
  assert review['journalId']==applied['data']['receipt']['id'] and review['plan']['id']==workspace_id and review['beforeContent'].encode()==project_before and review['plan']['content'].encode()==project_proposed and review['allowedDirections']==['rollback']
  rollback={'kind':'recover','documentId':'project-settings','journalId':review['journalId'],'expectedEvent':review['eventId'],'direction':'rollback'}
  for refused_request in [dict(rollback,direction='resume'),dict(rollback,expectedEvent='0'*64)]:
   status,refused=document_action(refused_request);assert status==422 and refused['notApplied'] is True and project_config.read_bytes()==project_proposed
  foreign=project_proposed+b'# owned foreign recovery fixture\r\n';project_config.write_bytes(foreign)
  status,refused=document_action(rollback);assert status==422 and refused['notApplied'] is True and project_config.read_bytes()==foreign
  project_config.write_bytes(project_proposed)
  if not spec.get('holdForVisual'):
   status,restored=document_action(rollback);assert status==200 and restored['sourceWritten'] is True and restored['fileChanged'] is True and project_config.read_bytes()==project_before
   status,refused=document_action(rollback);assert status==422 and refused['notApplied'] is True and project_config.read_bytes()==project_before
   status,terminal=document_action({'kind':'pending','documentId':'project-settings'});assert status==200 and terminal['data']['journals'][0]['phase']=='rolled_back' and terminal['data']['journals'][0]['allowedDirections']==[]
   outcome['realReviewedRollbackExactOriginalBytesAndTerminalRefusal']=True
  outcome['realJournalBeforeAfterReviewResumeStaleAndForeignRefusals']=True
  outcome['selectedProjectNativePlanHostApprovalAndRealExecutedVerification']=True
  outcome['projectWorkspaceReceipt']=applied['data']['receipt']

  status,refused=document_action({'kind':'read','documentId':'outside'});assert status==403
  observed=state();assert observed['argumentsRecorded'] is False and observed['resultsRecorded'] is False and 'explicit inert change' not in json.dumps(observed)
  if spec.get('python'):
   cell=tool(65,'serena_repl',{'session_id':runtime_session,'code':'owned_marker += 1\nprint(owned_marker)'});assert cell['stdout']=='45\n';outcome['persistentRuntimeStateKeptAcrossFileCalls']=True
  outcome['selectedGlobalFileExactBytesAndStalePlanRefusal']=True;outcome['selectedProjectDocumentWritesUseOriginalWorkspaceGates']=True;outcome['documentBodiesExcludedFromActivity']=True

 if spec.get('globalConfig'):
  import copy
  host_data=json.loads(profile.read_bytes());original_selection=host_data['dashboard']['management']['documents'];migrated=copy.deepcopy(original_selection)
  new_journal=profile.parent/(profile.stem+'-migrated-journals');new_journal.mkdir();migrated['journalRoot']=str(new_journal)
  for item in migrated['documents']:
   if item['id']=='host-settings':item['id']='host-settings-migrated';item['label']='Owned migrated host settings'
  roots=[{'name':'default','root':str(source)}]+[{'name':row['name'],'root':row['root']} for row in host_data.get('projects',[])]
  old_selection=profile.parent/(profile.stem+'-from-selection.json');new_selection=profile.parent/(profile.stem+'-to-selection.json')
  old_selection.write_text(json.dumps({'documents':original_selection,'projects':roots}));new_selection.write_text(json.dumps({'documents':migrated,'projects':roots}))
  binding_prefix=[str(native),'--timeout','30000','--max-bytes','1000000','host-documents','--from-selection',str(old_selection),'--to-selection',str(new_selection)]
  def binding_call(label,args,success=True):
   result=subprocess.run(binding_prefix+args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40,creationflags=0x08000000)
   assert len(result.stdout)<=2_000_000 and len(result.stderr)<=2_000_000
   (out/(label+'.stdout')).write_bytes(result.stdout);(out/(label+'.stderr')).write_bytes(result.stderr)
   assert (result.returncode==0)==success,(label,result.returncode)
   return json.loads(result.stdout) if success else result
  migration_before=global_config.read_bytes();migration_hash=hashlib.sha256(migration_before).hexdigest()
  migration=binding_call('binding-plan',['binding-plan','--from-document','host-settings','--to-document','host-settings-migrated'])
  assert migration['fromAccess']!=migration['toAccess'] and global_config.read_bytes()==migration_before
  migration_plan=profile.parent/(profile.stem+'-migration-plan.json');migration_plan.write_text(json.dumps(migration))
  denied=binding_call('binding-apply-without-grant',['binding-apply','--plan',str(migration_plan)],False);assert b'--allow-host-writes' in denied.stderr and global_config.read_bytes()==migration_before
  assert len(migration['id'])==64 and len(migration['target'])==64 and all(c in '0123456789abcdef' for c in migration['id']+migration['target'])
  archive=global_config.parent/('.yoke-doc-migration-'+migration['id']+'.complete.json');occupied=b'owned occupied migration archive fixture\r\n'
  with archive.open('xb') as file:file.write(occupied)
  binding_call('binding-apply-occupied-archive',['binding-apply','--plan',str(migration_plan),'--allow-host-writes'],False)
  assert archive.read_bytes()==occupied and global_config.read_bytes()==migration_before
  review=binding_call('binding-inspect-pending',['binding-inspect','--plan',str(migration_plan)]);assert review['phase']=='committed' and review['markerPresent'] is True
  status,blocked=document_action({'kind':'pending','documentId':'host-settings'});assert status==200 and blocked['data']['blockedByBindingMigration'] is True and blocked['data']['complete'] is False and blocked['data']['journals']==[]
  outcome['actualCliMigrationRetainsForeignArchiveAndExplicitIncompleteUiBlocker']=True
  (out/'binding-migration-fixture.json').write_text(json.dumps({'planId':migration['id'],'eventId':review['eventId'],'beforeHash':migration_hash,'beforeBytes':len(migration_before),'oldSelection':str(old_selection),'newSelection':str(new_selection),'plan':str(migration_plan),'archive':str(archive)}))
  def recover_binding():
   assert archive.read_bytes()==occupied;preserved=archive.with_name(archive.name+'.owned-fixture-preserved');assert not preserved.exists();expected_parent=global_config.parent.resolve();assert archive.resolve().parent==expected_parent and preserved.parent.resolve()==expected_parent;archive.rename(preserved);assert preserved.read_bytes()==occupied
   result=binding_call('binding-recover-resume',['binding-recover','--plan',str(migration_plan),'--expected-event',review['eventId'],'--direction','resume','--allow-host-writes'])
   assert result['outcome']=='committed' and result['metadataChanged'] is True and result['fileChanged'] is False and result['sourceWritten'] is False and global_config.read_bytes()==migration_before
   owner_path=global_config.parent/('.yoke-doc-owner-'+migration['target']+'.json');owner=json.loads(owner_path.read_bytes());assert owner['schemaVersion']==2 and owner['generation']==migration['nonce'] and owner['accessBinding']==migration['toAccess']
   status,retired=document_action({'kind':'pending','documentId':'host-settings'});assert status==200 and retired['data']['blockedByDifferentAuthority'] is True
   status,old_read=document_action({'kind':'read','documentId':'host-settings'});assert status==200
   status,old_plan=document_action({'kind':'plan','documentId':'host-settings','expectedRevision':old_read['data']['document']['revision'],'content':'must not write with retired authority\r\n'});assert status==200
   status,refused=document_action({'kind':'apply','documentId':'host-settings','planId':old_plan['data']['plan']['id']});assert status==422 and global_config.read_bytes()==migration_before
   proof={'complete':True,'product':'Code Intelligence','version':'0.5.0','metadataOnlyMigration':True,'sourceWritten':False,'fileChanged':False,'globalConfigurationBytesExact':True,'beforeSha256':migration_hash,'afterSha256':hashlib.sha256(global_config.read_bytes()).hexdigest(),'oldWriteSelectionRefused':True,'oldPendingExplicitlyDifferentAuthority':True,'foreignArchiveFixturePreserved':True,'ownerGeneration':owner['generation']};(out/'ui-migration-recovered.json').write_text(json.dumps(proof,indent=2)+'\n');outcome['actualCliMigrationRecoveryExactBytesAndRetiredAuthorityRefusal']=True
  def test_new_host():
   new_profile=profile.parent/(profile.stem+'-migrated-host.json');new_data=copy.deepcopy(host_data);new_data['dashboard']['management']['documents']=migrated;new_profile.write_text(json.dumps(new_data))
   selected=out/'new-host';selected.mkdir();new_spec={'out':str(selected),'native':str(native),'root':str(source),'globalConfig':str(global_config),'hostProfilePath':str(new_profile),'documentId':'host-settings-migrated','cliSha256':spec['cliSha256'],'serverConfig':spec.get('serverConfig')};new_spec_path=profile.parent/(profile.stem+'-new-host-spec.json');new_spec_path.write_text(json.dumps(new_spec))
   helper=Path(r'C:\Users\Lomi\AppData\Local\Temp\dashboard-binding-migration-new-host-worker-20261024.py');result=subprocess.run([r'C:\Python314\python.exe','-I',str(helper),str(new_spec_path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40,creationflags=0x08000000);(out/'new-host.stdout').write_bytes(result.stdout);(out/'new-host.stderr').write_bytes(result.stderr);assert result.returncode==0;proof=json.loads((selected/'new-host-result.json').read_bytes());assert proof['complete'];(out/'ui-new-host-written.json').write_text(json.dumps(proof,indent=2)+'\n');outcome['actualFreshHostProfileCanWriteUnderNewBinding']=True
  if not spec.get('holdForVisual'):recover_binding();test_new_host()
 if spec.get('holdForVisual'):
  (out/'private-dashboard.json').write_text(json.dumps({'url':dashboard.geturl(),'product':'Code Intelligence','version':'0.5.0','cliSha256':spec['cliSha256']}))
  until=time.monotonic()+300
  while time.monotonic()<until and not (out/'ui-stop').exists():
   if process.poll() is not None and not (out/'native-process-exited.json').exists():
    assert process.returncode==0 and not process.stdin.closed;reader.join(timeout=3);assert not reader.is_alive()
    if runtime_handle is not None:assert runtime_api.WaitForSingleObject(runtime_handle,5000)==0;outcome['ownedRuntimeExitConfirmedBeforeJobCleanup']=True
    (out/'native-process-exited.json').write_text(json.dumps({'nativeExitCode':process.returncode,'stdinWasStillOpen':True,'ownedRuntimeExitConfirmed':outcome.get('ownedRuntimeExitConfirmedBeforeJobCleanup'),'cliSha256':spec['cliSha256']}))
   if (out/'ui-migration-recover').exists() and not (out/'ui-migration-recovered.json').exists():recover_binding()
   if (out/'ui-new-host-write').exists() and not (out/'ui-new-host-written.json').exists():test_new_host()
   review_request=out/'ui-host-request.json'
   if review_request.exists() and not (out/'ui-host-receipt.json').exists():
    review=json.loads(review_request.read_bytes());host_approve(review['workspacePlanId'],'ui-project');host_verify(review['workspacePlanId'],review['afterHash'],'ui-project');(out/'ui-host-receipt.json').write_text(json.dumps({'complete':True,'workspacePlanId':review['workspacePlanId'],'executedVerification':True}))
   time.sleep(.05)
  assert (out/'ui-stop').exists(),'Owned native browser inspection exceeded its bound'
 else:
  current=state();bad=dict(current);bad['view']=dict(current['view']);bad['view']['management']=dict(current['view']['management']);bad['view']['management']['sessionStateSha256']='b'*64
  status,denied=manage({'kind':'shutdown'},bad);assert status==409 and process.poll() is None
  status,denied=manage({'kind':'shutdown','service':'all'});assert status==400 and process.poll() is None
  status,accepted=manage({'kind':'shutdown'});assert status==200 and accepted['data']['shutdownAccepted'] is True and accepted['data']['scope']=='owning_stdio_mcp_connection' and accepted['data']['serviceShutdown'] is False and accepted['data']['processExitConfirmed'] is False
 process.wait(timeout=8);reader.join(timeout=3);assert process.returncode==0 and not reader.is_alive() and not process.stdin.closed,'Owned shutdown must finish before stdin EOF'
 if runtime_handle is not None:assert runtime_api.WaitForSingleObject(runtime_handle,5000)==0;outcome['ownedRuntimeExitConfirmedBeforeJobCleanup']=True
 outcome['owningShutdownExitedBeforeStdinEof']=True;process.stdin.close()
 try:dashboard_request('GET','/api/state')
 except (ConnectionError,OSError,http.client.HTTPException):outcome['dashboardListenerClosedOnOwningShutdown']=True
 else:raise AssertionError('Owned dashboard survived connection shutdown')
 assert sha(source/'main.rs')==source_before and sha(native)==spec['cliSha256'];complete=True
finally:
 if process is not None and process.poll() is None:process.kill();process.wait(timeout=8)
 if process is not None:
  if process.stdin and not process.stdin.closed:process.stdin.close()
  if process.stdout:process.stdout.close()
 if reader is not None:reader.join(timeout=3)
 if stderr is not None:stderr.close()
 if runtime_handle is not None:assert runtime_api.CloseHandle(runtime_handle)
 capability=None;dashboard=None
 result={'complete':complete,'nativeExitCode':None if process is None else process.returncode,'readerJoined':reader is None or not reader.is_alive(),'managementEvents':events,'notificationCount':len(notifications),'sameOwningSessionModesAndCatalog':complete,'noteCasAndUnselectedSourceBytesExact':complete,'capabilitiesExcludedFromLogs':True,'modelCalls':0,'analyzedSourceExecuted':False,**outcome};(out/'stdio-live-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
