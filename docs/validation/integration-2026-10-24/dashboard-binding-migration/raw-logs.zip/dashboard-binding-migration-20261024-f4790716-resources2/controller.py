from pathlib import Path
import ctypes,hashlib,json,msvcrt,os,subprocess,sys,tempfile,time,_winapi,shutil,contextlib
w=Path.cwd();vroot=w/'validation/integration-20261018';out=vroot/'dashboard-binding-migration-20261024-f4790716-resources2';out.mkdir(exist_ok=False);shutil.copyfile(__file__,out/'controller.py');cwd=configroot=w;client='';jobroot=Path(tempfile.mkdtemp(prefix='yoke-binding-owned-main-resource-'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env={key:os.environ[key] for key in ['PATH','SystemRoot','SystemDrive','WINDIR','LANG'] if key in os.environ}
text=(w/'docs/validation/integration-2026-10-21/json-mcp-hosts/controllers/ci-r6-claude-file-live.py').read_text();runner=text[text.index('k=ctypes.WinDLL('):text.index("result={'fixtureRoot'")];assert hashlib.sha256(runner.encode()).hexdigest()=='ce59776e086dfcafc0009582f7142d73f923fd5003d1885909e8e26cc12c3ae5';runner=runner.replace('if time.monotonic()-start>timeout:raise TimeoutError(name)',"if shutil.disk_usage(w).free<500_000_000:raise RuntimeError('Owned disk-headroom stop')\n                if time.monotonic()-start>timeout:raise TimeoutError(name)");exec(compile(runner,'reviewed Windows Job runner plus disk stop','exec'))
producer=vroot/'dashboard-binding-migration-20261024-f4790716-focused5';assert json.loads((producer/'result.json').read_bytes())['complete'];artifacts=[]
for line in (producer/'focused-host-documents-cli-permission-test.stdout').read_text(encoding='utf-8').splitlines():
 if not line.startswith('{'):continue
 value=json.loads(line)
 if value.get('reason')=='compiler-artifact' and Path(value['manifest_path']).resolve()==(w/'native/Cargo.toml').resolve() and value['target']['kind']==['bin'] and value['profile']['test']:artifacts.append(value)
assert len(artifacts)==1;artifact=artifacts[0];exe=Path(artifact['executable']);assert exe.parent.resolve()==(w/'target/debug/deps').resolve() and exe.name=='yoke-8316088c57832a69.exe';expected=sha(exe);inputs=json.loads((vroot/'dashboard-binding-migration-20261024-f4790716-gates2/source-before.json').read_bytes());assert all(sha(w/n)==h for n,h in inputs.items());before=shutil.disk_usage(w).free;compacted=[];complete=False
try:
 stdout=run('whole-historical-main-resource-only',[exe,'--test-threads=1'],timeout=120);assert b'7 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out' in stdout and sha(exe)==expected
 for path in sorted(map(Path,artifact['filenames']),key=lambda p:p.suffix!='.pdb'):
  assert path.parent.resolve()==exe.parent.resolve() and path.name in ['yoke-8316088c57832a69.exe','yoke-8316088c57832a69.pdb'];size=path.stat().st_size;digest=sha(path)
  if path.stat().st_file_attributes&0x800:continue
  assert shutil.disk_usage(w).free>500_000_000+size+64_000_000,(path.name,size,shutil.disk_usage(w).free)
  run('lzx-passed-historical-main-'+path.suffix,[os.environ['SystemRoot']+'\\System32\\compact.exe','/C','/F','/EXE:LZX','/I','/Q',path],timeout=90);assert path.stat().st_size==size and sha(path)==digest and sha(exe)==expected;compacted.append({'path':str(path),'bytes':size,'sha256':digest})
 complete=True
finally:
 result={'complete':complete,'scope':'Historical focused5 Cargo-declared test artifact only; NOT current-source qualification','wholeHistoricalMainPassed':7 if rows and rows[0].get('exitCode')==0 else None,'historicalSourceMap':str(producer/'source-before.json'),'historicalExecutableSha256':expected,'currentTestsCountedFromThisRun':0,'compacted':compacted,'beforeFreeBytes':before,'afterFreeBytes':shutil.disk_usage(w).free,'currentSourceInputsUnchanged':all(sha(w/n)==h for n,h in inputs.items()),'allJobsEmpty':all(r['activeAfterCleanup']==0 for r in rows),'noDeletionOrPolicyChange':True};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
